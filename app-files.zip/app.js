/**
 * HOMESTAY MANAGER - MOBILE-FIRST PWA ENGINE
 * Full-featured property, booking, turnover, and revenue management system.
 */

// ==========================================================================
// 1. STATE & LOCALSTORAGE DATA MODEL
// ==========================================================================

const APP_VERSION = '2.8.5';

// SELLER WHATSAPP NUMBER - For Buy License inquiries (Single Source of Truth)
const SELLER_WHATSAPP = '+60124022462';

// CLOUDFLARE WORKER LICENSE SERVER CONFIGURATION (Public Key Only)
const LICENSE_API_URL = 'https://staymanager-license-server.homestaymanager.workers.dev';
const BUY_PAGE_URL = LICENSE_API_URL + '/buy';
const LICENSE_PUBLIC_KEY_JWK = {
  "kty": "EC",
  "crv": "P-256",
  "x": "2O0fWckxh69Mk2ca1PLWBFzTrlR2GSOv32PxwOMcM4E",
  "y": "DbZzhpTDL8eGNd1UrHPQeKl4NoyIjzivQT2QCR51Tpk"
};

let testOverridePublicKeyJwk = null;

const STORAGE_KEYS = {
  PROPERTIES: 'staymanager_properties_v2',
  BOOKINGS: 'staymanager_bookings_v2',
  TURNOVERS: 'staymanager_turnovers_v2',
  EXPENSES: 'staymanager_expenses_v2',
  CONTACTS: 'staymanager_contacts_v2',
  PROMO_MEDIA: 'staymanager_promo_media_v2',
  SETTINGS: 'staymanager_settings_v2',
  TOKEN: 'staymanager_license_token',
  DEVICE_ID: 'staymanager_device_id',
  LAST_SEEN_AT: 'staymanager_last_seen_at',
  VERSION: 'staymanager_app_version'
};

const DEFAULT_CONTACTS = [
  {
    id: 'c-1',
    name: 'Kak Siti',
    category: 'cleaner',
    phone: '+60129998877',
    company: 'Siti Clean Services',
    notes: 'Turnover cleaning RM70/unit. Available Mon-Sat.'
  },
  {
    id: 'c-2',
    name: 'Ah Keong',
    category: 'aircond',
    phone: '+60128887766',
    company: 'Keong Cool Aircond',
    notes: 'Aircond chemical wash (RM120/unit) & emergency gas refilling.'
  },
  {
    id: 'c-3',
    name: 'Pak Din',
    category: 'plumber',
    phone: '+60127776655',
    company: 'Pak Din Plumbing',
    notes: 'Pipe repairs, toilet clog, water heater troubleshooting.'
  },
  {
    id: 'c-4',
    name: 'Sri Dobi Supply',
    category: 'linen_supplier',
    phone: '+60126665544',
    company: 'Sri Dobi & Linens Sdn Bhd',
    notes: 'Bedsheet sets, duvets, white bath towels wholesale restock.'
  }
];

const DEFAULT_PROMO_MEDIA = [
  {
    id: 'promo-demo-1',
    propertyId: 'prop-1',
    category: 'photo',
    title: 'Sunset Ocean Villa - Panoramic Living & Balcony Seaview',
    caption: '🌊 *Sunset Ocean Villa (Whole Unit - 3 Bedrooms)* 🌅\nLooking for an unforgettable beachside getaway with family or friends?\n\n✨ *Key Highlights:* \n• Accommodates up to 8–10 guests comfortably\n• 3 air-conditioned bedrooms with luxury hotel-grade linens\n• Private balcony with direct panoramic sunset ocean views\n• High-speed 500Mbps WiFi & Smart TV with Netflix\n• Fully equipped dry & wet kitchen (fridge, microwave, induction cooker)\n• Infinity swimming pool, sauna & kids playground access\n\n📍 *Location:* Seaview Residences, Jalan Pantai\n💰 *Rates from:* RM 280 / night\n\n📲 Reply to this message now to check your dates and enjoy our early bird rates!',
    imageData: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="600" height="340" viewBox="0 0 600 340"><defs><linearGradient id="ocean" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#0284c7"/><stop offset="50%" stop-color="#0369a1"/><stop offset="100%" stop-color="#075985"/></linearGradient></defs><rect width="600" height="340" fill="url(#ocean)"/><circle cx="480" cy="100" r="55" fill="#f59e0b" opacity="0.85"/><path d="M0 240 Q150 200 300 240 T600 240 L600 340 L0 340 Z" fill="#0c4a6e" opacity="0.6"/><path d="M0 270 Q150 240 300 270 T600 270 L600 340 L0 340 Z" fill="#082f49"/><text x="40" y="80" fill="#ffffff" font-family="system-ui, sans-serif" font-size="24" font-weight="bold">🌊 Sunset Ocean Villa</text><text x="40" y="115" fill="#bae6fd" font-family="system-ui, sans-serif" font-size="15">Panoramic Living & Balcony Seaview</text><rect x="40" y="150" width="170" height="32" rx="6" fill="#f59e0b"/><text x="52" y="172" fill="#ffffff" font-family="system-ui, sans-serif" font-size="13" font-weight="bold">⭐ Top Rated Beachfront</text></svg>'),
    mediaUrl: 'https://maps.google.com/?q=3.1390,101.6869',
    createdAt: new Date().toISOString()
  },
  {
    id: 'promo-demo-2',
    propertyId: 'prop-2',
    category: 'video_tour',
    title: 'Villa Impian Master Bedroom - Virtual Video Tour',
    caption: '🎥 *Virtual Video Walkthrough: Villa Impian Master Bedroom* 🌿\nTake a quick 1-minute video tour inside our cozy highland sanctuary!\n\n✨ *Room Specs:* \n• King-size bed with premium orthopedic mattress\n• Private en-suite bathroom with instant hot rain shower\n• Quiet environment surrounded by cool mountain mist\n• Access to shared BBQ patio, tea terrace & garden\n\n👇 *Click to Watch the Walkthrough Video:* \nhttps://youtu.be/sample-villa-tour\n\n💬 Send us a message today to lock in your preferred stay dates!',
    imageData: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="600" height="340" viewBox="0 0 600 340"><defs><linearGradient id="vidbg" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#065f46"/><stop offset="100%" stop-color="#047857"/></linearGradient></defs><rect width="600" height="340" fill="url(#vidbg)"/><circle cx="300" cy="170" r="44" fill="#ffffff" opacity="0.92"/><polygon points="292,152 316,170 292,188" fill="#047857"/><text x="40" y="60" fill="#ffffff" font-family="system-ui, sans-serif" font-size="22" font-weight="bold">🎥 Villa Impian Virtual Tour</text><text x="40" y="90" fill="#a7f3d0" font-family="system-ui, sans-serif" font-size="14">Master Bedroom & Highland Garden Walkthrough</text></svg>'),
    mediaUrl: 'https://youtu.be/sample-villa-tour',
    createdAt: new Date().toISOString()
  },
  {
    id: 'promo-demo-3',
    propertyId: 'all',
    category: 'poster',
    title: 'School Holiday Early Bird 15% OFF Promo Flyer',
    caption: '🎉 *SPECIAL SCHOOL HOLIDAY PROMO - 15% OFF!* 🎒✨\nPlanning your next family trip or weekend getaway? Book early and save big!\n\n🎁 *Exclusive Early Bird Package:* \n• Get *15% OFF* for reservations of 2 nights or more\n• Free welcome drinks & late check-out till 1:00 PM (subject to availability)\n• Valid across all our homestay villas & medium rooms\n\n📅 *Booking Window:* Limited to the first 10 confirmed bookings!\n📲 Reply directly with your check-in dates to claim your 15% discount voucher!',
    imageData: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="600" height="340" viewBox="0 0 600 340"><defs><linearGradient id="poster" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#7c3aed"/><stop offset="100%" stop-color="#4f46e5"/></linearGradient></defs><rect width="600" height="340" fill="url(#poster)"/><circle cx="100" cy="80" r="90" fill="#a855f7" opacity="0.3"/><circle cx="520" cy="260" r="110" fill="#6366f1" opacity="0.3"/><text x="50" y="90" fill="#fde047" font-family="system-ui, sans-serif" font-size="16" font-weight="800" letter-spacing="1">LIMITED TIME SPECIAL DEAL</text><text x="50" y="145" fill="#ffffff" font-family="system-ui, sans-serif" font-size="34" font-weight="900">SCHOOL HOLIDAY</text><text x="50" y="195" fill="#38bdf8" font-family="system-ui, sans-serif" font-size="36" font-weight="900">SAVE 15% OFF!</text><text x="50" y="240" fill="#e2e8f0" font-family="system-ui, sans-serif" font-size="14">Book min 2 nights • Free welcome perks • Instant WhatsApp booking</text></svg>'),
    mediaUrl: '',
    createdAt: new Date().toISOString()
  },
  {
    id: 'promo-demo-4',
    propertyId: 'prop-3',
    category: 'copywriting',
    title: 'Affordable Highland Stay for Couples & Remote Workers',
    caption: '🍃 *Cozy Medium Room @ Villa Impian* 🛏️\nAffordable, sparkling clean comfort in the cool highlands!\n\n• Queen bed with plush orthopedic mattress\n• Dedicated work desk with high-speed 5G WiFi (remote-work friendly)\n• Access to spacious living hall & tea-making pantry\n• Only *RM 100 / night* (Cleaning fee RM25)\n\n💬 Send us a message today to book your peaceful retreat!',
    imageData: '',
    mediaUrl: '',
    createdAt: new Date().toISOString()
  }
];




const DEFAULT_SETTINGS = {
  businessName: 'MyHomestay',
  businessSsm: '',
  businessAddress: '',
  businessEmail: '',
  currency: 'RM',
  theme: 'light',
  language: 'en',
  ownerPhone: '',
  defaultDepositPct: 30,
  bankName: '',
  bankAccNum: '',
  bankAccHolder: '',
  duitNow: '',
  bankBranch: '',
  sstRate: 0,
  quotationValidityDays: 3,
  standardNotes: '',
  ocrEngine: 'auto',
  geminiApiKey: ''
};

const TRANSLATIONS = {
  en: {
    // Navigation
    nav_today: 'Today',
    nav_calendar: 'Calendar',
    nav_bookings: 'Bookings',
    nav_turnovers: 'Turnovers',
    nav_finances: 'Finances',
    nav_settings: 'Settings',

    // Header & Global
    all_units: 'All Units',
    add_unit: '+ Add',
    demo_badge: 'DEMO MODE',
    demo_banner_text: 'Loving this app for your homestays?',
    buy_app: 'Buy App',
    activate: 'Activate',
    today: 'Today',
    cancel: 'Cancel',
    save: 'Save',
    edit: 'Edit',
    delete: 'Delete',
    close: 'Close',

    // Dashboard
    kpi_checkin: 'Today Check-In',
    kpi_checkout: 'Today Check-Out',
    kpi_inhouse: 'In-House Guests',
    kpi_turnovers: 'Turnovers Needed',
    this_month: 'This Month',
    occupancy: 'Occupancy',
    nights_booked: 'nights booked',
    homestay_units_title: 'Homestay Units Overview',
    today_actions: "Today's Schedule & Actions",
    see_all: 'See All',
    manage_btn: 'Manage',
    vacant_ready: 'Vacant & Ready',
    turnover_required: 'Turnover / Cleaning Required',
    occupied_by: 'Occupied by',
    available: 'Available',
    occupied: 'Occupied',
    turnover: 'Turnover',
    no_actions_today: 'No urgent check-ins, check-outs, or turnovers today.',

    // Calendar
    cal_title: 'Calendar',
    sun: 'Sun', mon: 'Mon', tue: 'Tue', wed: 'Wed', thu: 'Thu', fri: 'Fri', sat: 'Sat',
    selected_date: 'Selected Date',
    select_a_date: 'Select a date',
    book_date_btn: 'Book Date',
    cal_tap_hint: 'Tap on any date above to view bookings or check availability.',
    no_bookings_date: 'No bookings for this date. Unit is vacant & available.',
    cal_all_incoming_tab: '📅 All Incoming (Nearest First)',
    cal_selected_date_tab: '🎯 Selected Date',
    cal_incoming_title: 'Incoming Bookings',
    cal_incoming_subtitle: 'Ordered by nearest dates',
    cal_no_incoming: 'No upcoming or active bookings found.',
    cal_mode_checkin: 'Check-In',
    cal_mode_checkout: 'Check-Out',
    cal_mode_stays: 'All Stays',
    cal_checkins_for_date: 'Check-In(s) on',
    cal_checkouts_for_date: 'Check-Out(s) on',
    cal_no_checkins_date: 'No check-ins on this date. Unit(s) available for new booking.',
    cal_no_checkouts_date: 'No check-outs scheduled on this date.',
    cal_unit_vacating_title: 'Checking Out Today — Ready for New Booking!',
    cal_unit_vacating_desc: 'Guest departs by 12:00 PM. Unit will be cleaned & ready for a new guest to check in at 3:00 PM.',
    cal_book_unit_today: '+ Book Unit from Today',

    // Bookings & Filters
    filter_all: 'All',
    filter_quotations: '📋 Quotations',
    filter_booked: '🟡 Booked (Deposit)',
    filter_confirmed: '🟢 Confirmed (Full)',
    filter_inhouse: '🔑 In-House',
    filter_completed: '🏁 Completed',
    filter_historical_tenancy: '📜 Historical Tenancies',
    btn_historical_tenancies: 'Historical Tenancies',
    historical_tenancies_title: 'Historical Completed Tenancies',
    filter_blocked: '🚫 Blocked',
    search_placeholder: 'Search guest name, phone, ref...',
    no_bookings_found: 'No Bookings Found',
    no_bookings_hint: 'Try adjusting your search or tap + to create a new quotation / booking.',
    nights: 'nights',
    months: 'months',
    guests: 'Guests',
    total: 'Total',
    balance: 'Balance',
    btn_wa: 'WhatsApp',
    btn_edit: 'Edit',

    // Turnovers
    turnover_title: 'Turnover & Cleaning',
    turnover_subtitle: 'Prep your homestay for the next guest',
    no_turnovers: 'No Turnovers Needed',
    all_clean_hint: 'All homestays are clean, sanitized and ready for check-in.',
    checklist: 'Checklist',
    assign_cleaner: 'Assign Cleaner',
    mark_clean_ready: 'Mark as Clean & Ready',
    cleaning_in_progress: 'Cleaning in Progress',
    ready_for_checkin: 'Ready for Check-In',
    btn_wa_cleaner: 'WhatsApp Cleaner',

    // Finances
    total_rev: 'Total Revenue',
    total_exp: 'Total Expenses',
    net_profit: 'Net Profit',
    rev_by_homestay: 'Revenue by Homestay',
    expense_breakdown: 'Expense Breakdown',
    add_expense_btn: '+ Expense',
    add_btn: '+ Add',
    no_expenses: 'No expenses logged for this month.',
    cat_cleaning: '🧹 Cleaning / Laundry',
    cat_utilities: '💡 Utilities (Electricity, Water, WiFi)',
    cat_supplies: '🧻 Supplies & Amenities',
    cat_maintenance: '🔧 Maintenance & Repairs',
    cat_commission: '🏷️ Platform Commission',
    cat_other: '📦 Other Expenses',

    // Settings
    your_homestays: 'Your Homestays',
    manage_homestays_sub: 'Manage names, WiFi, smart locks & rates',
    add_unit_btn: '+ Add Unit',
    app_pref_title: 'App Preferences & Seller Info',
    business_name_label: 'Business / Brand Name',
    seller_phone_label: 'Seller Support / Order WhatsApp Number',
    currency_label: 'Currency Symbol',
    owner_phone_label: 'Owner WhatsApp Phone Number (Bound to License)',
    owner_phone_hint: 'Your official WhatsApp number. Used in quotations and permanently bound to your app license.',
    app_language_label: 'App Language / Bahasa',
    deposit_pct_label: 'Standard Deposit Percentage (%)',
    deposit_pct_hint: 'Default deposit requested upon booking (e.g. 30%).',
    quotation_validity_label: 'Default Quotation Validity (Days)',
    quotation_validity_hint: 'Default number of days a quotation remains valid before expiry.',
    standard_notes_label: 'Standard WhatsApp Notes / Footer',
    standard_notes_hint: 'Automatically appended at the bottom of customer WhatsApp automation messages.',
    days_label: 'days',
    btn_save_pref: 'Save Preferences',
    bank_title: 'Bank & Payment Details',
    bank_sub: 'Auto-included in Quotations, Invoices, and Payment Receipts sent to guests.',
    bank_name_label: 'Bank Name',
    acc_num_label: 'Account Number',
    acc_holder_label: 'Account Holder Name',
    duitnow_label: 'DuitNow ID / QR / Transfer Note',
    btn_save_bank: 'Save Payment Details',
    app_license_title: 'App License',
    buy_license: 'Buy License',
    presale_questions: 'Questions before buying? Ask on WhatsApp',
    admin_gen_sub: 'Generate phone-bound licenses and 1-click WhatsApp onboarding links for buyers.',
    buyer_phone_label: "Buyer's WhatsApp Phone Number",
    buyer_name_label: 'Buyer Name / Homestay Name (Optional)',
    btn_gen_license: 'Generate License & Magic Link',
    business_ssm_label: 'Business Registration / SSM No. (For Official PDF Docs)',
    business_address_label: 'Office / Business Address (For Quotations & Invoices)',
    business_email_label: 'Official Host Email',
    btn_generate_pdf_doc: 'Generate Official PDF Document (Quotation / Invoice / Receipt)',
    pdf_modal_title: 'Corporate & Office PDF Document Hub',
    pdf_modal_sub: 'Select document type, adjust quotation validity & save as standard A4 PDF.',
    pdf_tab_quotation: '1. Quotation (Sebut Harga)',
    pdf_tab_invoice: '2. Official Invoice (Invois)',
    pdf_tab_receipt: '3. Official Receipt (Resit Rasmi)',
    pdf_client_org_label: 'Company / Ministry / Agency Name (Optional)',
    pdf_lpo_ref_label: 'Local Purchase Order / PO Ref (Optional)',
    pdf_lang_label: 'Document Language',
    btn_print_pdf: 'Print / Save as PDF',
    btn_share_pdf_wa: 'Open WhatsApp & Share PDF',
    // App Updates & Version
    app_version_title: 'App Version & Updates',
    app_version_sub: 'Update to the latest version anytime without losing your homestay or booking data.',
    safe_update_guarantee_title: 'Zero Data Loss Guarantee:',
    safe_update_guarantee_desc: 'Your homestays, tenant records, financials, and license key stay privately stored on this device during updates.',
    btn_check_updates: 'Check for Updates',
    btn_force_refresh: 'Force Fresh Reload',
    btn_safety_backup: 'Safety Snapshot',
    update_banner_title: 'New Update Available!',
    update_banner_desc: 'New improvements & features ready. Your data is 100% preserved.',
    btn_update_now: 'Update Now',
    toast_app_updated: '🎉 App successfully updated to v2.6.6! All data is intact.',
    toast_up_to_date: '✨ You are already using the latest version (v2.6.6)!',
    toast_checking_updates: 'Checking for new updates...',
    toast_safety_saved: 'Safety backup snapshot downloaded!',

    data_backup_title: 'Data & Backup',
    data_backup_sub: 'All your data (Homestays, Bookings, Payments, Maintenance Team & Suppliers) is saved privately on your device. Export a backup anytime.',
    btn_export: 'Export Backup (.json)',
    btn_restore: 'Restore Backup',
    btn_restore_snapshot: 'Restore Pre-Update Safety Snapshot',
    no_auto_backup_found: 'No pre-update safety snapshot found. Your current data is active.',
    btn_load_demo: 'Load Rich Demo Data',
    btn_clear_data: 'Clear All Data',
    install_mobile_title: 'Install on Mobile',
    install_mobile_sub: 'To install like a native app: Open in Safari (iOS) and tap Share > Add to Home Screen, or in Chrome (Android) tap Menu > Install App.',

    // Modals - Booking
    booking_modal_new: 'New Quotation / Booking',
    booking_modal_edit: 'Edit Booking / Tenancy',
    select_property: 'Select Homestay Property',
    rental_type: 'Rental Type / Jenis Sewaan',
    type_daily: 'Daily / Short-Term',
    type_monthly: 'Monthly Tenancy',
    tenant_particulars_title: 'Tenant & Guest Particulars / Butiran Tetamu',
    tenant_individual: 'Individual',
    tenant_company: 'Company',
    company_name: 'Company Legal Name',
    company_reg_no: 'SSM Registration No.',
    company_address: 'Registered Office Address',
    contact_person_title: 'Contact Person (Communication)',
    contact_person_name: 'Contact Person Name',
    contact_person_designation: 'Designation',
    contact_person_phone: 'Contact Phone / WhatsApp',
    contact_person_email: 'Contact Email Address',
    signatory_title: 'Authorized Signatory',
    signatory_same_as_contact: 'Same as Contact Person',
    signatory_name: 'Signatory Full Name',
    signatory_designation: 'Signatory Designation',
    signatory_ic: 'Signatory NRIC / Passport',
    emergency_contact_title: 'Emergency Contact & Occupants',
    emergency_contact_name: 'Emergency Contact Name',
    emergency_contact_phone: 'Emergency Phone',
    emergency_contact_relation: 'Relationship',
    occupants_count: 'Number of Occupants',
    occupants_notes: 'Occupant Names / Details (Optional)',
    full_name: 'Full Name / Nama Penuh',
    phone_wa: 'Phone / WhatsApp',
    nric_passport: 'NRIC / Passport No. / No. KP',
    email: 'Email Address / Emel',
    address: 'Residential / Home Address / Alamat Surat Menyurat',
    checkin_date: 'Check-In Date',
    checkout_date: 'Check-Out Date',
    rate_night: 'Rate/Night',
    cleaning_fee: 'Cleaning Fee',
    sec_deposit: 'Security Deposit (Refundable)',
    total_rental: 'Total Rental:',
    quick_deposit: 'Quick Booking Fee:',
    monthly_start: 'Tenancy Start Date',
    duration_months: 'Duration (Months)',
    monthly_rent: 'Monthly Rent:',
    rental_dep: 'Rental Deposit (Refundable):',
    util_dep: 'Utilities Deposit (Refundable):',
    agreement_fee: 'Agreement & Admin Fee:',
    initial_movein: 'Initial Move-In Total:',
    guests_occupants: 'Guests / Occupants',
    booking_channel: 'Booking Channel',
    deposit_paid: 'Advance / Deposit Paid',
    booking_stage: 'Booking Stage / Status',
    special_notes: 'Special Requests / Notes',
    btn_save_booking: 'Save Booking',

    // Overlap Prevention & Change Homestay (v2.6.3)
    overlap_detected_title: 'Booking Overlap Blocked!',
    overlap_detected_sub: 'The selected dates clash with an existing booking for this homestay.',
    overlap_action_change_unit: 'Switch to Available Unit',
    overlap_action_change_dates: 'Change Stay Dates',
    btn_change_homestay: 'Change Homestay',
    change_homestay_title: 'Change Homestay Unit',
    change_homestay_subtitle: 'Transfer this booking to another homestay while keeping all tenant particulars.',
    target_homestay: 'Target Homestay Unit',
    pricing_adjustment: 'Pricing Adjustment Option',
    keep_existing_price: 'Keep Existing Price & Payments',
    keep_existing_price_desc: 'Retain current total amount and balance. Ideal if price was already agreed upon.',
    recalc_new_price: 'Recalculate with New Homestay Rate',
    recalc_new_price_desc: 'Apply target homestay nightly rate & cleaning fee. Deposit paid is preserved.',
    confirm_transfer_btn: 'Confirm & Transfer Booking',

    // Modals - Property
    prop_modal_add: 'Add Homestay Unit',
    prop_modal_edit: 'Edit Homestay Unit',
    prop_name: 'Property / Homestay Name',
    room_no: 'Room / Unit No.',
    rental_cat: 'Rental Category / Jenis Unit',
    cat_entire: '🏡 Entire House / Whole Unit (Seluruh Rumah / Villa / Homestay)',
    cat_master: '🚪 Room Rental - Master Bedroom (Sewa Bilik Master)',
    cat_medium: '🚪 Room Rental - Medium Room (Sewa Bilik Medium)',
    cat_single: '🚪 Room Rental - Single Room (Sewa Bilik Single / Standard)',
    cat_studio: '🏢 Studio Apartment / Suite',
    address_loc: 'Address / Location',
    gps_loc: 'GPS / Google Maps Link',
    open_maps: 'Open in Google Maps / Waze',
    wifi_name: 'WiFi Name (SSID)',
    wifi_pass: 'WiFi Password',
    door_pin: 'Door / Smart Lock PIN',
    theme_color: 'Theme Color',
    default_rate: 'Default Nightly Rate',
    default_clean_fee: 'Cleaning Fee',
    checkin_time: 'Check-in Time',
    checkout_time: 'Check-out Time',
    house_rules: 'House Rules & Notes',
    btn_save_prop: 'Save Property',

    // Modals - WhatsApp
    wa_modal_title: 'Send WhatsApp Message',
    wa_to: 'To: Guest',
    wa_tab_quotation: '📄 Quotation',
    wa_tab_deposit: '🧾 Deposit Receipt (Booked)',
    wa_tab_checkin: '📅 Check-In Reminder',
    wa_tab_full: '🔑 Full Receipt & Keys',
    wa_tab_invoice: '📑 Monthly Rent Invoice',
    wa_tab_rent_receipt: '🧾 Monthly Rent Receipt',
    wa_tab_refund: '💰 Deposit Refund Statement',
    wa_tab_checkout: '🏁 Check-Out Reminder',
    wa_tab_cleaner: '🧹 Cleaner Job',
    wa_tab_payment: '💳 Balance Due',
    btn_checkin_reminder: 'Check-In Reminder',
    btn_copy_text: 'Copy Text',
    btn_open_wa: 'Open WhatsApp',

    // Modals - Monthly Tenancy Invoices
    monthly_invoices_modal_title: 'Monthly Rental Invoices',
    select_billing_month: 'Select Billing Month',
    extra_utility_surcharge: 'Utility / Extra (RM)',
    tenancy_period: 'Tenancy Period',
    monthly_schedule_title: 'Billing Cycles & Invoice Status',
    month_num: 'Month',
    due_date_label: 'Due Date',
    btn_send_month_inv: 'Send Invoice',
    btn_send_month_rec: 'Send Receipt',
    btn_mark_month_paid: 'Mark Paid',
    btn_unmark_month_paid: 'Unmark',
    paid_movein: 'Paid (Move-In)',
    pending: 'Pending',
    paid: 'Paid',
    btn_view_invoices: 'Monthly Invoices',
    month_1_paid_move_in: 'Month 1 Rental Paid Via Move-In Package',
    month_1_paid_move_in_note: 'Month 1 Rental Paid Via Move-In Package (Invoicing begins from Month 2)',
    invoicing_starts_month_2: 'Invoicing begins from Month 2',
    settled_via_move_in: 'Settled Via Move-In',
    no_invoice_month_1: 'No Invoice Required (Month 1 Settled in Move-In Package)',

    // In-App User Guide
    user_guide_title: 'User Manual & Operational Guide',
    user_guide_sub: 'Step-by-step instructions on mobile setup, bookings, invoicing, WhatsApp, and finances.',
    btn_open_guide: 'Read In-App User Guide (EN / BM)',
    user_guide_modal_title: 'User Guide & Manual',
    user_guide_modal_sub: 'Interactive guide & operational walkthrough',
    guide_lang_label: 'Select Guide Language:',

    // Modals - Refund
    refund_modal_title: 'Tenancy Deposit Refund',
    rental_dep_held: 'Rental Deposit Held:',
    util_dep_held: 'Utilities Deposit Held:',
    deduct_util: 'Less: Utility Arrears (TNB/Water):',
    deduct_repair: 'Less: Repairs & Damage / Cleaning:',
    net_refund: 'Net Refund to Tenant:',
    deduct_notes: 'Deduction Notes & Bank Account for Transfer',
    btn_send_refund_wa: 'Send Refund Statement',

    // Modals - Expense
    exp_modal_title: 'Log Homestay Expense',
    exp_property: 'Property',
    exp_amount: 'Amount',
    exp_date: 'Date',
    exp_category: 'Category',
    exp_desc: 'Description / Receipt Note',
    btn_save_expense: 'Save Expense',

    // Modals - Guest Kit
    guide_modal_title: 'Digital Guest Welcome Kit',
    guide_wifi: 'WiFi Credentials',
    guide_smart_lock: 'Smart Lock / Access',
    guide_rules: 'House Rules',
    guide_share_btn: 'Share Guide with Guest via WhatsApp',

    // Modals - License
    lic_modal_title: 'Unlock Lifetime License',
    lic_modal_sub: 'One-time purchase • Zero monthly fees',
    lic_phone: 'Your Registered WhatsApp Phone Number',
    lic_phone_hint: 'Type the same WhatsApp number you used when buying. Do not add a 0 after +60.',
    lic_phone_preview_label: 'We will use:',
    lic_key: 'Enter Your Activation License Key',
    lic_key_hint: 'Copy and paste the key from WhatsApp. Keys never contain 0, 1, I or O.',
    lic_key_preview_label: 'Cleaned key:',
    btn_paste_key: 'Paste',
    btn_activate_app: 'Activate Full App',

    // Action Feed Tags & Buttons
    tag_checkin_today: 'Check-In Today',
    tag_checkout_today: 'Check-Out Today',
    tag_turnover_needed: 'Turnover Needed',
    btn_send_quotation: 'Send Quotation',
    btn_mark_booked: 'Mark Deposit Paid (Book)',
    btn_send_deposit_receipt: 'Send Deposit Receipt',
    btn_send_invoice: 'Send Invoice',
    btn_mark_confirmed: 'Mark Fully Paid (Confirm)',
    btn_send_full_receipt: 'Send Full Receipt & Key',
    btn_checkin: 'Check In',
    btn_checkout_reminder: 'Check-Out Reminder',
    btn_complete_checkout: 'Complete Check-Out',

    // Team & Suppliers Directory and Dispatch
    team_dir_title: 'Maintenance Team & Suppliers',
    team_dir_subtitle: 'Manage cleaners, technicians, handymen & suppliers',
    add_person_btn: '+ Add Person',
    btn_team_suppliers: '👷 Team & Suppliers',
    btn_service_supply_alert: '🛠️ Service / Supply Alert',
    contact_name_label: 'Contact / Person Name',
    contact_category_label: 'Service Category / Role',
    contact_phone_label: 'WhatsApp Phone Number',
    contact_company_label: 'Company / Shop Name (Optional)',
    contact_notes_label: 'Rates, Notes & Service Details',
    contact_modal_title_new: 'Add Team Member / Supplier',
    contact_modal_title_edit: 'Edit Contact Details',
    save_contact_btn: 'Save Contact',
    dispatch_modal_title: 'WhatsApp Service & Supply Alert',
    dispatch_modal_sub: 'Dispatch cleaners, technicians or order supplies',
    dispatch_recipient_label: 'Send WhatsApp To',
    dispatch_property_label: 'Homestay Unit / Property',
    dispatch_type_label: 'Service / Task Type',
    dispatch_urgency_label: 'Urgency Level',
    dispatch_details_label: 'Task / Order Instructions',
    dispatch_include_pin: 'Include Smart Lock Door PIN in message',
    btn_copy_text: 'Copy Text',
    btn_send_wa_direct: 'Send via WhatsApp',
    cat_cleaner: '🧹 Cleaner / Cleaning Crew',
    cat_aircond: '❄️ Aircond Specialist',
    cat_plumber: '🔧 Plumber',
    cat_electrician: '⚡ Electrician',
    cat_handyman: '🔨 Handyman / General Repairs',
    cat_linen_supplier: '🧺 Linen & Laundry Supplier',
    cat_gas_supplier: '⛽ Gas & Amenities Supplier',
    cat_locksmith: '🔐 Locksmith / Smart Lock Tech',
    cat_other: '📦 Other Contractor / Supplier',

    // Digital Receipts & Payments
    receipt_modal_title: 'Capture Payment Receipt & Reference',
    receipt_gallery_title: 'Payment Receipts & Proofs',
    btn_receipt_proofs: 'Payment Proofs',
    payment_type: 'Payment Type / Purpose',
    monthly_cycle: 'Month Cycle',
    amount_received: 'Amount Received (RM)',
    payment_date: 'Payment Date & Time',
    bank_channel: 'Bank / Payment Channel',
    bank_ref_no: 'Bank Ref No. / Transaction ID',
    paste: 'Paste',
    bank_ref_hint: 'Copy & paste the Reference No / Transaction ID from the tenant slip.',
    digital_receipt_slip: 'Digital Receipt Screenshot / Slip (Bukti Resit)',
    tap_to_upload_receipt: 'Tap to Upload or Snap Receipt Slip',
    receipt_formats_hint: 'JPG, PNG, WebP or PDF • Auto-compressed for zero storage lag',
    view: 'View',
    remove: 'Remove',
    payment_notes: 'Notes / Remarks (Optional)',
    save_payment_proof: 'Save Payment & Receipt',
    add_payment_receipt: '+ Record New Payment / Receipt',
    copy_ref: 'Copy Ref',
    ref_copied: 'Reference number copied!',
    download: 'Download Slip',
    no_receipts_recorded: 'No payment receipts recorded for this booking yet.',
    delete_receipt_confirm: 'Are you sure you want to delete this payment record and slip?',
    receipt_badge_count: 'Receipt(s)',

    // OCR Receipt & Bill Scanner
    ocr_scan_btn: 'Scan Bill / Receipt',
    ocr_scan_slip_btn: 'Auto-Scan Slip (OCR)',
    ocr_scan_bill_btn: 'Scan Bill (OCR)',
    ocr_modal_title: 'OCR Receipt & Bill Scanner',
    ocr_modal_sub: 'Instant optical recognition for Malaysian bank slips & utility bills',
    ocr_tab_camera: 'Camera / Upload Slip',
    ocr_tab_paste: 'Paste Text / WhatsApp',
    ocr_detected_heading: 'Detected Information',
    ocr_apply_booking: 'Apply to Guest Booking',
    ocr_save_expense: 'Log as Homestay Expense',
    ocr_processing: 'Scanning document with OCR...',
    ocr_success: 'Document parsed successfully!',
    ocr_settings_title: 'OCR Receipt & Bill Scanner',
    ocr_settings_sub: 'Optical recognition engine for Malaysian bank slips and utility bills',
    ocr_engine_label: 'Recognition Engine',
    ocr_engine_hint: 'Automatic runs on-device without internet. Gemini Flash provides high accuracy on crumpled receipts.',
    gemini_api_key_label: 'Google Gemini API Key (Optional)',
    gemini_api_hint: 'Stored privately on your device. Never transmitted elsewhere.',
    btn_save_ocr: 'Save Scanner Preferences',
    tap_upload_bill: 'Tap to Snap or Upload Bill (TNB, Water, Supplies)',
    exp_receipt_bill: 'Bill / Receipt Slip (Optional)',

    // Smart WhatsApp Chat Import
    cat_tenant: '👤 Tenant / Regular Guest',
    btn_import_tenant_chat: 'Import Tenant Chat',
    import_tenant_chat_title: 'Smart WhatsApp Chat Import',
    import_tenant_chat_sub: 'Paste guest WhatsApp conversation to auto-extract particulars',
    extract_chat_btn: 'Extract Tenant Details',
    paste_chat_placeholder: 'Paste WhatsApp conversation or booking details here...',
    view_original_chat: 'View Original Conversation',
    create_booking_btn: 'Create Quotation / Booking',
    save_contact_btn: 'Save as Contact',
    create_both_btn: 'Create Both (Booking + Contact)',
    chat_extracted_success: 'Tenant details extracted successfully!',
    import_chat_short: 'Import Chat',
    booking_type_label: 'Booking Type',
    type_individual: 'Individual',
    type_company: 'Company',
    ssm_reg_no: 'SSM Number',
    pic_name_label: 'PIC Name',
    pic_position_label: 'PIC Position',
    pic_phone_label: 'PIC Phone Number',
    pic_email_label: 'PIC Email',
    company_address_label: 'Company Address',
    id_number_label: 'IC / Identification Number',
    sample_company_btn: 'Sample Company',

    // Tenant Lifecycle & Repeat Guest Recognition
    repeat_guest_detected: 'Repeat Guest Detected',
    kpi_active_tenants: 'Active Tenants',
    kpi_repeat_guests: 'Repeat Guests',
    kpi_repeat_bookings: 'Total Repeat Bookings',
    top_returning_guests: 'Top Returning Guests',
    tenant_lifecycle_kpis_title: 'Tenant Intelligence & Repeat Guests',
    tenant_lifecycle_kpis_sub: 'Track active vs historical tenants, repeat customer retention and lifetime value',
    lbl_prev_stays: 'Previous Stays',
    lbl_last_stay: 'Last Stay Date',
    lbl_lifetime_rev: 'Lifetime Revenue',
    btn_use_existing_tenant: 'Use Tenant Record',
    tenant_status_label: 'Lifecycle Status',
    status_active: 'Active',
    status_completed: 'Completed',
    status_prospect: 'Prospect',
    status_blacklisted: 'Blacklisted',
    blacklisted_guest_warning: '⚠️ Blacklisted Guest Detected',
    filter_status_all: 'All Statuses',

    // Promotional Media & Marketing Hub
    promo_hub_modal_title: 'Promotional Media & Marketing Hub',
    promo_hub_modal_sub: 'Store photos, posters, video tours & promo copywriting for 1-tap sharing',
    filter_by_property: 'Filter by Property',
    all_properties: 'All Homestays & General',
    add_media_asset: '+ Add Media',
    cat_all: 'All',
    cat_photos: 'Photos',
    cat_posters: 'Posters / Flyers',
    cat_videos: 'Video Tours',
    cat_copywriting: 'Copywriting',
    no_promo_media_found: 'No promotional media found',
    no_promo_media_hint: 'Store photos, posters, video walkthrough links, and promotional captions for quick sharing.',
    add_first_promo_media: 'Add First Media Asset',
    add_promo_media_title: 'Add Promotional Media',
    edit_promo_media_title: 'Edit Promotional Media',
    add_promo_media_sub: 'Upload property photos, video tour links, or promo text',
    media_category_label: 'Media Category',
    media_title_label: 'Title / Headline',
    upload_promo_image: 'Upload Image / Poster (Auto-Compressed for Storage)',
    tap_upload_photo_poster: 'Tap to Upload Photo or Poster',
    auto_compressed_note: 'JPG, PNG, WebP • Auto-downscaled to ~60KB to keep your app fast',
    external_link_label: 'External Tour / Cloud Link (Optional)',
    external_link_hint: 'Zero device storage used. Great for full 4K video tours or shared Google Drive galleries.',
    promo_caption_label: 'Promotional Copywriting / Pitch Text',
    insert_template: 'Preset Template',
    promo_caption_hint: 'This copywriting is pre-filled when sharing to WhatsApp or copying to clipboard.',
    save_promo_media: 'Save Media Asset',
    share_via_whatsapp: 'Send Promo via WhatsApp',
    send_to_recipient: 'Send To Recipient',
    enter_phone_number: 'Enter / Pick Phone Number',
    guest_phone_label: 'Guest WhatsApp Number',
    phone_empty_hint: 'Leave blank to open WhatsApp and pick from your recent contacts.',
    message_preview: 'Message Preview',
    open_in_whatsapp: 'Send on WhatsApp',
    attach_promo_media: '+ Append Promo Media / Tour Link',
    promo_media_card_title: 'Promotional Media & Marketing Hub',
    promo_media_card_sub: 'Store property photos, holiday posters, video walkthroughs & marketing pitch copywriting',
    open_media_hub: 'Open Media Hub',
    copy_pitch: 'Copy Pitch',
    pitch_copied: 'Promotional pitch copied to clipboard!',
    link_copied: 'Media link copied to clipboard!',
    delete_promo_confirm: 'Are you sure you want to delete this promotional media asset?',

    // Tenancy Agreement Generator
    agr_modal_title: 'Residential Tenancy Agreement Generator',
    agr_modal_subtitle: 'Generate official A4 tenancy agreements with Muslim-friendly covenants, schedule of terms, fixtures inventory & signatures.',
    tenancy_agreement_banner_title: 'Residential Tenancy Agreement',
    tenancy_agreement_banner_sub: 'Generate official A4 tenancy agreement with Muslim-friendly covenants, inventory & signatures.',
    btn_generate_agreement: 'Generate Tenancy Agreement',
    pdf_tab_agreement: '5. Tenancy Agreement',
    agr_tab_form: '1. Setup & Particulars',
    agr_tab_preview: '2. Live Preview & Export',
    agr_lbl_select_booking: 'Select Tenant / Monthly Booking Record:',
    agr_btn_autofill: 'Auto-Fill',
    agr_sec_parties: '1. Parties (Landlord & Tenant Particulars)',
    agr_title_landlord: 'Landlord (Lessor / Tuan Rumah)',
    agr_lbl_landlord_name: 'Full Name / Business Name:',
    agr_lbl_landlord_ic: 'NRIC / Passport / Company Reg (SSM):',
    agr_lbl_landlord_phone: 'Phone / WhatsApp:',
    agr_lbl_landlord_addr: 'Landlord Correspondence Address:',
    agr_title_tenant: 'Tenant (Lessee / Penyewa)',
    agr_lbl_tenant_name: 'Full Name of Tenant:',
    agr_lbl_tenant_ic: 'NRIC / Passport / Reg No:',
    agr_lbl_tenant_phone: 'Phone Number:',
    agr_lbl_tenant_email: 'Email Address (Optional):',
    agr_lbl_tenant_addr: 'Tenant Permanent Address:',
    agr_sec_property_terms: '2. Demised Property & Tenancy Financial Terms',
    agr_lbl_prop_name: 'Homestay / Property Name:',
    agr_lbl_prop_type: 'Property Type:',
    agr_lbl_prop_addr: 'Full Address of Demised Premises:',
    agr_lbl_agr_date: 'Agreement Execution Date:',
    agr_lbl_start_date: 'Tenancy Commencement Date:',
    agr_lbl_end_date: 'Tenancy Expiry Date:',
    agr_lbl_duration: 'Tenancy Duration (Months):',
    agr_lbl_monthly_rent: 'Monthly Rent (RM / Month):',
    agr_lbl_due_day: 'Monthly Payment Due Date:',
    agr_lbl_rental_deposit: 'Rental Security Deposit (1 Month - RM):',
    agr_lbl_util_deposit: 'Utilities Deposit (Electricity/Water - RM):',
    agr_lbl_advance_rent: 'Advance 1st Month Rent (RM):',
    agr_lbl_fee: 'Agreement & Stamping Fee (RM):',
    agr_lbl_renewal_notice: 'Renewal Option Notice Period:',
    agr_lbl_payment_account: 'Landlord Bank Account Details:',
    agr_sec_muslim_title: '3. Special Muslim-Friendly House Covenants',
    agr_switch_muslim: 'Activate Muslim-Friendly House Requirement',
    agr_muslim_desc_title: 'Strict Covenants for Maintaining Muslim Living Condition:',
    agr_lbl_custom_clauses: 'Custom Additional House Rules / Covenants (Optional):',
    agr_sec_inventory: '4. Fixtures, Furniture & Inventory Schedule',
    agr_btn_add_item: '+ Add Inventory Item',
    agr_th_item_name: 'Item / Fixture Description',
    agr_th_qty: 'Quantity',
    agr_th_condition: 'Current Condition',
    agr_sec_witnesses: '5. Witnesses Particulars',
    agr_title_witness_landlord: "Landlord's Witness",
    agr_title_witness_tenant: "Tenant's Witness",
    agr_lbl_wit_name: 'Witness Full Name:',
    agr_lbl_wit_ic: 'Witness NRIC / Passport:',
    agr_btn_go_preview: 'Generate & View Live Agreement Preview →',
    agr_lbl_lang: 'Document Language:',
    agr_btn_edit_details: '← Edit Details',
    agr_btn_save_draft: 'Save Draft',
    agr_btn_print: 'Print Document',
    agr_btn_share_wa: 'WhatsApp Tenant',
    agr_btn_download_pdf: 'Download A4 PDF',

    // Overlap Warning & Alternate Units
    overlap_requested_dates: 'Requested Dates:',
    overlap_system_notice: 'The system prevents double-booking. Existing conflicting reservation details:',
    overlap_alt_available: 'Alternative Homestay Units Available on These Dates:',

    // Change Unit Modal
    current_unit_label: 'Current Unit:',
    total_amount_label: 'Total:',
    change_homestay_assurance_title: 'Full Tenant Particulars Transfer Guarantee:',
    change_homestay_assurance_desc: 'Tenant name, WhatsApp phone, NRIC/Passport, email, correspondence address, guest count, receipts & booking notes will be seamlessly transferred to the new unit. Turnover cleaning schedules will also update automatically.',

    // PDF Toolbar & Customization
    quick_presets: 'Quick:',
    days_short: 'Days',
    pdf_monthly_scope_title: 'Monthly Tenancy Document Options',
    badge_monthly_tenancy: 'Monthly Tenancy',
    pdf_monthly_utility_label: 'Utilities for this Month (Electricity & Water)',
    pdf_monthly_scope_hint: 'Select Move-in Package (Quotation) or Monthly Rent Invoice for a specific month',
    btn_auto_deposit: 'Auto Deposit',
    pdf_deposit_hint: 'This amount will be verified and printed on the official deposit receipt',
    pdf_pay_ref_hint: 'Will appear on receipt for accounting & audit trail',
    pdf_pay_ref_placeholder: 'e.g. Maybank - M2U-99218291 or DuitNow QR',
    pdf_client_org_hint: "Will appear under 'Billed To / Attention'",
    pdf_client_org_placeholder: 'e.g. Ministry of Education / Petronas Chemicals',
    pdf_lpo_ref_hint: 'For financial audit and reimbursement claim',
    pdf_lpo_ref_placeholder: 'e.g. LPO/2026/089 or Office Ref',
    pdf_lang_hint: 'Switch document language instantly',

    // PDF WhatsApp Prompt Banner
    wa_prompt_title: 'Send this Document to Guest on WhatsApp?',
    wa_prompt_sub: 'This official PDF document is ready to download and share directly with your guest via WhatsApp.',
    wa_prompt_yes: 'Yes, Send to WhatsApp',
    wa_prompt_dl: 'Download PDF',
    wa_prompt_tab: 'Open in New Tab',
    wa_prompt_dismiss: 'Dismiss',

    // Tenancy Agreement Generator
    agr_legal_disclaimer: 'This is a template and not legal advice. Please confirm stamp duty and legal requirements with a lawyer or LHDN.',
    type_individual_owner: 'Individual / Owner',
    type_individual: 'Individual',
    type_company_ssm: 'Company / Business (SSM)',
    agr_landlord_name_hint: '*Legal property owner name (not homestay brand name). You can list co-owners if applicable.',
    agr_signatory_title: 'Landlord Authorized Representative / Signatory:',
    agr_signatory_name: 'Representative Name / Director:',
    agr_signatory_capacity: 'Designation / Capacity:',
    agr_signatory_ic: 'Representative NRIC / Passport:',
    agr_open_details_form: 'Open Particulars Form',
    agr_booking_hint: 'Select a booking above to auto-fill tenant details, property, rates, and deposits.',

    // Backup Reminder & Safety
    backup_reminder_msg: 'Reminder: You have bookings and have not exported a backup in the last 14 days.',
    btn_backup_now: 'Export Backup Now',
    clear_data_modal_title: 'Clear All Data?',
    link_user_guide: 'User guide / Panduan pengguna',
    clear_data_modal_sub: 'Permanent action: All homestays, bookings, expenses & receipts will be erased from this device.',
    clear_data_backup_advice: 'Protect your data first!',
    clear_data_backup_desc: 'We strongly recommend exporting a full backup file (.json) to your device before clearing data.',
    clear_data_type_confirm_label: 'Type DELETE below to confirm:',
    btn_confirm_delete: 'Delete Everything',
    storage_quota_alert_title: 'Storage Quota Limit Reached',
    storage_quota_alert_msg: 'Device storage is nearly full. Please export a backup from Settings and clean up older receipts to continue saving smoothly.',
    storage_protected_msg: 'Persistent storage is active. Your data is protected from automatic browser cleanup.'
  },
  bm: {
    // Navigation
    nav_today: 'Hari Ini',
    nav_calendar: 'Kalendar',
    nav_bookings: 'Tempahan',
    nav_turnovers: 'Pembersihan',
    nav_finances: 'Kewangan',
    nav_settings: 'Tetapan',

    // Header & Global
    all_units: 'Semua Unit',
    add_unit: '+ Tambah',
    demo_badge: 'MOD DEMO',
    demo_banner_text: 'Suka aplikasi ini untuk homestay anda?',
    buy_app: 'Beli App',
    activate: 'Aktifkan',
    today: 'Hari Ini',
    cancel: 'Batal',
    save: 'Simpan',
    edit: 'Kemas Kini',
    delete: 'Padam',
    close: 'Tutup',

    // Dashboard
    kpi_checkin: 'Daftar Masuk Hari Ini',
    kpi_checkout: 'Daftar Keluar Hari Ini',
    kpi_inhouse: 'Tetamu Menginap',
    kpi_turnovers: 'Perlu Dibersihkan',
    this_month: 'Bulan Ini',
    occupancy: 'Kadar Penghunian',
    nights_booked: 'malam ditempah',
    homestay_units_title: 'Ringkasan Unit Homestay',
    today_actions: 'Jadual & Tindakan Hari Ini',
    see_all: 'Lihat Semua',
    manage_btn: 'Urus',
    vacant_ready: 'Kosong & Sedia',
    turnover_required: 'Perlu Pembersihan / Turnover',
    occupied_by: 'Diduduki oleh',
    available: 'Kosong',
    occupied: 'Diduduki',
    turnover: 'Pembersihan',
    no_actions_today: 'Tiada daftar masuk, keluar atau pembersihan mendesak hari ini.',

    // Calendar
    cal_title: 'Kalendar',
    sun: 'Ahd', mon: 'Isn', tue: 'Sel', wed: 'Rab', thu: 'Kha', fri: 'Jum', sat: 'Sab',
    selected_date: 'Tarikh Dipilih',
    select_a_date: 'Pilih tarikh',
    book_date_btn: 'Tempah Tarikh',
    cal_tap_hint: 'Tekan mana-mana tarikh di atas untuk melihat tempahan atau kekosongan.',
    no_bookings_date: 'Tiada tempahan pada tarikh ini. Unit kosong & sedia ditempah.',
    cal_all_incoming_tab: '📅 Semua Akan Datang (Terdekat)',
    cal_selected_date_tab: '🎯 Tarikh Dipilih',
    cal_incoming_title: 'Tempahan Akan Datang',
    cal_incoming_subtitle: 'Susunan mengikut tarikh terdekat',
    cal_no_incoming: 'Tiada tempahan aktif atau akan datang ditemui.',
    cal_mode_checkin: 'Daftar Masuk',
    cal_mode_checkout: 'Daftar Keluar',
    cal_mode_stays: 'Penginapan',
    cal_checkins_for_date: 'Daftar Masuk pada',
    cal_checkouts_for_date: 'Daftar Keluar pada',
    cal_no_checkins_date: 'Tiada tetamu mendaftar masuk pada tarikh ini. Unit sedia untuk tempahan baharu.',
    cal_no_checkouts_date: 'Tiada daftar keluar dijadualkan pada tarikh ini.',
    cal_unit_vacating_title: 'Keluar Hari Ini — Sedia Untuk Tempahan Baharu!',
    cal_unit_vacating_desc: 'Tetamu keluar jam 12:00 PM. Unit dibersihkan & sedia untuk tetamu baharu mendaftar masuk jam 3:00 PM.',
    cal_book_unit_today: '+ Tempah Unit Mulai Hari Ini',

    // Bookings & Filters
    filter_all: 'Semua',
    filter_quotations: '📋 Sebut Harga',
    filter_booked: '🟡 Ditempah (Deposit)',
    filter_confirmed: '🟢 Disahkan (Penuh)',
    filter_inhouse: '🔑 Sedang Menginap',
    filter_completed: '🏁 Selesai',
    filter_historical_tenancy: '📜 Sejarah Sewaan',
    btn_historical_tenancies: 'Sejarah Sewaan',
    historical_tenancies_title: 'Sejarah Sewaan Bulanan Tamat',
    filter_blocked: '🚫 Disekat',
    search_placeholder: 'Cari nama tetamu, telefon, rujukan...',
    no_bookings_found: 'Tiada Tempahan Dijumpai',
    no_bookings_hint: 'Cuba tukar carian atau tekan + untuk mencipta sebut harga / tempahan baru.',
    nights: 'malam',
    months: 'bulan',
    guests: 'Tetamu',
    total: 'Jumlah',
    balance: 'Baki',
    btn_wa: 'WhatsApp',
    btn_edit: 'Kemas Kini',

    // Turnovers
    turnover_title: 'Pembersihan & Turnover',
    turnover_subtitle: 'Sediakan unit homestay anda untuk tetamu seterusnya',
    no_turnovers: 'Tiada Pembersihan Diperlukan',
    all_clean_hint: 'Semua unit bersih, disanitasi dan sedia untuk tetamu.',
    checklist: 'Senarai Semak',
    assign_cleaner: 'Tugaskan Pencuci',
    mark_clean_ready: 'Tanda Bersih & Sedia',
    cleaning_in_progress: 'Sedang Dibersihkan',
    ready_for_checkin: 'Sedia Untuk Daftar Masuk',
    btn_wa_cleaner: 'WhatsApp Pencuci',

    // Finances
    total_rev: 'Jumlah Pendapatan',
    total_exp: 'Jumlah Perbelanjaan',
    net_profit: 'Keuntungan Bersih',
    rev_by_homestay: 'Pendapatan Mengikut Unit',
    expense_breakdown: 'Pecahan Perbelanjaan',
    add_expense_btn: '+ Belanja',
    add_btn: '+ Tambah',
    no_expenses: 'Tiada rekod perbelanjaan untuk bulan ini.',
    cat_cleaning: '🧹 Pembersihan / Dobi',
    cat_utilities: '💡 Utiliti (Elektrik, Air, WiFi)',
    cat_supplies: '🧻 Barangan & Kelengkapan',
    cat_maintenance: '🔧 Penyelenggaraan & Baiki',
    cat_commission: '🏷️ Komisen Platform',
    cat_other: '📦 Perbelanjaan Lain',

    // Settings
    your_homestays: 'Unit Homestay & Bilik Anda',
    manage_homestays_sub: 'Urus nama, WiFi, kunci pintar & kadar sewa',
    add_unit_btn: '+ Tambah Unit',
    app_pref_title: 'Pilihan Aplikasi & Maklumat Penjual',
    business_name_label: 'Nama Homestay / Perniagaan',
    seller_phone_label: 'Nombor WhatsApp Sokongan / Tempahan',
    currency_label: 'Simbol Mata Wang',
    owner_phone_label: 'Nombor WhatsApp Pemilik (Terkunci ke Lesen)',
    owner_phone_hint: 'Nombor WhatsApp rasmi anda. Digunakan dalam sebut harga dan diikat secara kekal pada lesen aplikasi anda.',
    app_language_label: 'Bahasa Aplikasi',
    deposit_pct_label: 'Peratusan Deposit Standard (%)',
    deposit_pct_hint: 'Deposit standard yang diminta semasa tempahan (contoh: 30%).',
    quotation_validity_label: 'Tempoh Sah Sebut Harga (Hari)',
    quotation_validity_hint: 'Jumlah hari sebut harga sah sebelum luput.',
    standard_notes_label: 'Nota Standard WhatsApp (Kaki Mesej)',
    standard_notes_hint: 'Dimasukkan secara automatik di bahagian bawah mesej automasi WhatsApp.',
    days_label: 'hari',
    btn_save_pref: 'Simpan Tetapan',
    bank_title: 'Maklumat Akaun Bank & DuitNow',
    bank_sub: 'Dimasukkan secara automatik dalam Sebut Harga, Invois, dan Resit Bayaran tetamu.',
    bank_name_label: 'Nama Bank',
    acc_num_label: 'Nombor Akaun',
    acc_holder_label: 'Nama Pemegang Akaun',
    duitnow_label: 'ID DuitNow / QR / Nota Rujukan',
    btn_save_bank: 'Simpan Maklumat Pembayaran',
    app_license_title: 'Lesen Aplikasi',
    buy_license: 'Beli Lesen',
    presale_questions: 'Soalan sebelum membeli? Tanya di WhatsApp',
    admin_gen_sub: 'Jana lesen terikat nombor telefon dan pautan aktivasi 1-klik WhatsApp untuk pembeli.',
    buyer_phone_label: 'Nombor WhatsApp Pembeli',
    buyer_name_label: 'Nama Pembeli / Nama Homestay (Pilihan)',
    btn_gen_license: 'Jana Kunci Lesen & Pautan Pintar',
    business_ssm_label: 'No. Pendaftaran SSM / Perniagaan (Untuk Dokumen PDF Rasmi)',
    business_address_label: 'Alamat Pejabat / Premis (Untuk Sebut Harga & Invois)',
    business_email_label: 'Emel Rasmi Hos',
    btn_generate_pdf_doc: 'Jana Dokumen PDF Rasmi (Quotation / Invois / Resit)',
    pdf_modal_title: 'Jana Dokumen PDF Rasmi (Office & Claim Ready)',
    pdf_modal_sub: 'Pilih jenis dokumen, sesuaikan tempoh sah sebut harga & muat turun sebagai PDF A4 standard.',
    pdf_tab_quotation: '1. Sebut Harga (Quotation)',
    pdf_tab_invoice: '2. Invois Rasmi (Invoice)',
    pdf_tab_receipt: '3. Resit Rasmi (Receipt)',
    pdf_client_org_label: 'Nama Syarikat / Kementerian / Jabatan (Pilihan)',
    pdf_lpo_ref_label: 'No. Pesanan Tempatan / LPO Ref (Pilihan)',
    pdf_lang_label: 'Bahasa Dokumen',
    btn_print_pdf: 'Cetak / Simpan Sebagai PDF',
    btn_share_pdf_wa: 'Buka WhatsApp & Kongsi PDF',
    // App Updates & Version
    app_version_title: 'Versi Aplikasi & Kemas Kini',
    app_version_sub: 'Kemas kini ke versi terkini pada bila-bila masa tanpa kehilangan data homestay atau tempahan anda.',
    safe_update_guarantee_title: 'Jaminan Sifar Kehilangan Data:',
    safe_update_guarantee_desc: 'Data unit homestay, rekod penyewa, kewangan dan lesen anda kekal tersimpan secara peribadi di peranti ini semasa kemas kini.',
    btn_check_updates: 'Semak Kemas Kini',
    btn_force_refresh: 'Muat Semula Bersih',
    btn_safety_backup: 'Salinan Keselamatan',
    update_banner_title: 'Kemas Kini Baharu Tersedia!',
    update_banner_desc: 'Ciri baharu & penambahbaikan sedia dipasang. Data anda kekal 100% selamat.',
    btn_update_now: 'Kemas Kini Sekarang',
    toast_app_updated: '🎉 Aplikasi berjaya dikemas kini ke v2.6.6! Semua data kekal selamat.',
    toast_up_to_date: '✨ Anda sedang menggunakan versi terkini (v2.6.6)!',
    toast_checking_updates: 'Menyemak kemas kini terkini...',
    toast_safety_saved: 'Salinan sandaran keselamatan berjaya dimuat turun!',

    data_backup_title: 'Data & Salinan Sandaran',
    data_backup_sub: 'Semua data anda (Homestay, Tempahan, Rekod Bayaran, Pasukan Penyelenggaraan & Pembekal) disimpan dengan selamat pada peranti anda. Eksport salinan sandaran bila-bila masa.',
    btn_export: 'Eksport Salinan (.json)',
    btn_restore: 'Pulihkan Salinan',
    btn_restore_snapshot: 'Pulihkan Salinan Keselamatan Pra-Kemas Kini',
    no_auto_backup_found: 'Tiada salinan keselamatan pra-kemas kini dijumpai. Data semasa anda sedang aktif.',
    btn_load_demo: 'Muat Data Demo Penuh',
    btn_clear_data: 'Padam Semua Data',
    install_mobile_title: 'Pasang Pada Telefon Pintar',
    install_mobile_sub: 'Untuk pasang seperti app biasa: Buka di Safari (iOS) dan tekan Share > Add to Home Screen, atau di Chrome (Android) tekan Menu > Install App.',

    // Modals - Booking
    booking_modal_new: 'Tempahan & Sebut Harga Baru',
    booking_modal_edit: 'Kemas Kini Tempahan / Sewaan',
    select_property: 'Pilih Unit Homestay',
    rental_type: 'Jenis Sewaan / Rental Type',
    type_daily: 'Sewaan Harian / Jangka Pendek',
    type_monthly: 'Sewaan Bulanan / Tenancy',
    tenant_particulars_title: 'Butiran Tetamu & Penyewa',
    tenant_individual: 'Individu',
    tenant_company: 'Syarikat',
    company_name: 'Nama Berdaftar Syarikat',
    company_reg_no: 'No. Pendaftaran SSM',
    company_address: 'Alamat Pejabat Berdaftar Syarikat',
    contact_person_title: 'Pegawai Dihubungi (Komunikasi)',
    contact_person_name: 'Nama Pegawai Dihubungi',
    contact_person_designation: 'Jawatan Pegawai',
    contact_person_phone: 'No. Tel / WhatsApp Pegawai',
    contact_person_email: 'Alamat Emel Pegawai',
    signatory_title: 'Penandatangan Diberi Kuasa',
    signatory_same_as_contact: 'Sama seperti Pegawai Dihubungi',
    signatory_name: 'Nama Penuh Penandatangan',
    signatory_designation: 'Jawatan Penandatangan',
    signatory_ic: 'No. K/P Penandatangan',
    emergency_contact_title: 'Kontak Kecemasan & Penghuni',
    emergency_contact_name: 'Nama Kontak Kecemasan / Waris',
    emergency_contact_phone: 'No. Telefon Kecemasan',
    emergency_contact_relation: 'Hubungan / Pertalian',
    occupants_count: 'Bilangan Penghuni Premis',
    occupants_notes: 'Maklumat / Senarai Nama Penghuni (Pilihan)',
    full_name: 'Nama Penuh',
    phone_wa: 'No. Telefon / WhatsApp',
    nric_passport: 'No. Kad Pengenalan / Pasport',
    email: 'Alamat Emel',
    address: 'Alamat Rumah / Surat Menyurat',
    checkin_date: 'Tarikh Daftar Masuk',
    checkout_date: 'Tarikh Daftar Keluar',
    rate_night: 'Kadar/Malam',
    cleaning_fee: 'Yuran Pembersihan',
    sec_deposit: 'Deposit Keselamatan (Dipulangkan)',
    total_rental: 'Jumlah Sewaan:',
    quick_deposit: 'Pilihan Pantas Deposit:',
    monthly_start: 'Tarikh Mula Sewaan',
    duration_months: 'Tempoh (Bulan)',
    monthly_rent: 'Sewa Bulanan:',
    rental_dep: 'Deposit Sewa (Dipulangkan):',
    util_dep: 'Deposit Utiliti (Dipulangkan):',
    agreement_fee: 'Yuran Perjanjian & Duti Setem:',
    initial_movein: 'Jumlah Bayaran Kemasukan:',
    guests_occupants: 'Bilangan Tetamu / Penghuni',
    booking_channel: 'Saluran Tempahan',
    deposit_paid: 'Bayaran Deposit / Pendahuluan',
    booking_stage: 'Status / Peringkat Tempahan',
    special_notes: 'Permintaan Khas / Catatan',
    btn_save_booking: 'Simpan Tempahan',

    // Overlap Prevention & Change Homestay (v2.6.3)
    overlap_detected_title: 'Pertindihan Tempahan Dihalang!',
    overlap_detected_sub: 'Tarikh yang dipilih bertindih dengan tempahan sedia ada untuk homestay ini.',
    overlap_action_change_unit: 'Tukar ke Unit Tersedia',
    overlap_action_change_dates: 'Tukar Tarikh Menginap',
    btn_change_homestay: 'Tukar Homestay',
    change_homestay_title: 'Tukar Unit Homestay',
    change_homestay_subtitle: 'Pindahkan tempahan ini ke unit homestay lain dengan mengekalkan semua butiran penyewa.',
    target_homestay: 'Unit Homestay Sasaran',
    pricing_adjustment: 'Pilihan Pelarasan Harga',
    keep_existing_price: 'Kekalkan Harga & Bayaran Sedia Ada',
    keep_existing_price_desc: 'Kekalkan jumlah sewaan dan baki sedia ada mengikut persetujuan awal.',
    recalc_new_price: 'Kira Semula Ikut Kadar Homestay Baru',
    recalc_new_price_desc: 'Guna kadar harian & caj pembersihan unit baru. Deposit dibayar dikekalkan.',
    confirm_transfer_btn: 'Sahkan & Pindahkan Tempahan',

    // Modals - Property
    prop_modal_add: 'Tambah Unit Homestay / Bilik',
    prop_modal_edit: 'Kemas Kini Unit Homestay / Bilik',
    prop_name: 'Nama Homestay / Hartanah',
    room_no: 'No. Bilik / Unit',
    rental_cat: 'Kategori Sewaan / Jenis Unit',
    cat_entire: '🏡 Seluruh Rumah / Villa / Homestay (Whole Unit)',
    cat_master: '🚪 Sewa Bilik - Bilik Master',
    cat_medium: '🚪 Sewa Bilik - Bilik Medium',
    cat_single: '🚪 Sewa Bilik - Bilik Single',
    cat_studio: '🏢 Studio Apartmen / Suite',
    address_loc: 'Alamat / Lokasi',
    gps_loc: 'Pautan GPS / Google Maps',
    open_maps: 'Buka di Google Maps / Waze',
    wifi_name: 'Nama WiFi (SSID)',
    wifi_pass: 'Kata Laluan WiFi',
    door_pin: 'PIN Kunci Pintu / Smart Lock',
    theme_color: 'Warna Tema',
    default_rate: 'Kadar Sewa Harian Standard',
    default_clean_fee: 'Yuran Pembersihan',
    checkin_time: 'Waktu Daftar Masuk',
    checkout_time: 'Waktu Daftar Keluar',
    house_rules: 'Peraturan Rumah & Catatan',
    btn_save_prop: 'Simpan Unit',

    // Modals - WhatsApp
    wa_modal_title: 'Hantar Mesej WhatsApp',
    wa_to: 'Kepada: Tetamu',
    wa_tab_quotation: '📄 Sebut Harga',
    wa_tab_deposit: '🧾 Resit Booking & Deposit',
    wa_tab_checkin: '📅 Peringatan Masuk',
    wa_tab_full: '🔑 Resit Penuh & Kunci PIN',
    wa_tab_invoice: '📑 Invois Bulanan',
    wa_tab_rent_receipt: '🧾 Resit Sewa Bulanan',
    wa_tab_refund: '💰 Penyata Pemulangan Deposit',
    wa_tab_checkout: '🏁 Peringatan Daftar Keluar',
    wa_tab_cleaner: '🧹 Tugasan Pembersihan',
    wa_tab_payment: '💳 Peringatan Baki Bayaran',
    btn_checkin_reminder: 'Peringatan Masuk',
    btn_copy_text: 'Salin Teks',
    btn_open_wa: 'Buka WhatsApp Terus',

    // Modals - Refund
    refund_modal_title: 'Penyata Pemulangan Deposit Sewaan',
    rental_dep_held: 'Deposit Sewa Dipegang:',
    util_dep_held: 'Deposit Utiliti Dipegang:',
    deduct_util: 'Tolak: Tunggakan Utiliti (TNB/Air):',
    deduct_repair: 'Tolak: Pembaikan & Pembersihan:',
    net_refund: 'Jumlah Bersih Dipulangkan:',
    deduct_notes: 'Catatan Tolakan & Akaun Bank Pemulangan',
    btn_send_refund_wa: 'Hantar Penyata Pemulangan',

    // Modals - Expense
    exp_modal_title: 'Rekod Perbelanjaan Homestay',
    exp_property: 'Unit Homestay',
    exp_amount: 'Jumlah',
    exp_date: 'Tarikh',
    exp_category: 'Kategori',
    exp_desc: 'Penerangan / Catatan Resit',
    btn_save_expense: 'Simpan Perbelanjaan',

    // Modals - Guest Kit
    guide_modal_title: 'Kit Panduan Digital Tetamu',
    guide_wifi: 'Maklumat Sambungan WiFi',
    guide_smart_lock: 'Akses Kunci Pintu Pintar',
    guide_rules: 'Peraturan Rumah',
    guide_share_btn: 'Kongsi Panduan ke WhatsApp Tetamu',

    // Modals - License
    lic_modal_title: 'Buka Kunci Lesen Seumur Hidup',
    lic_modal_sub: 'Pembelian sekali • Tiada yuran bulanan',
    lic_phone: 'Nombor WhatsApp Berdaftar Anda',
    lic_phone_hint: 'Taip nombor WhatsApp yang sama digunakan semasa membeli. Jangan tambah 0 selepas +60.',
    lic_phone_preview_label: 'Kami akan gunakan:',
    lic_key: 'Masukkan Kunci Lesen Aktivasi Anda',
    lic_key_hint: 'Salin dan tampal kunci dari WhatsApp. Kunci tidak mengandungi 0, 1, I atau O.',
    lic_key_preview_label: 'Kunci yang dibersihkan:',
    btn_paste_key: 'Tampal',
    btn_activate_app: 'Aktifkan Aplikasi Penuh',

    // Action Feed Tags & Buttons
    tag_checkin_today: 'Daftar Masuk Hari Ini',
    tag_checkout_today: 'Daftar Keluar Hari Ini',
    tag_turnover_needed: 'Perlu Pembersihan',
    btn_send_quotation: 'Hantar Sebut Harga',
    btn_mark_booked: 'Tanda Deposit Dibayar (Kunci)',
    btn_send_deposit_receipt: 'Hantar Resit Deposit',
    btn_send_invoice: 'Hantar Invois',
    btn_mark_confirmed: 'Tanda Bayaran Penuh (Sahkan)',
    btn_send_full_receipt: 'Hantar Resit Penuh & Kunci',
    btn_checkin: 'Daftar Masuk',
    btn_checkout_reminder: 'Peringatan Daftar Keluar',
    btn_complete_checkout: 'Selesaikan Daftar Keluar',

    // Modals - Monthly Tenancy Invoices
    monthly_invoices_modal_title: 'Jadual Invois Sewaan Bulanan',
    select_billing_month: 'Pilih Bulan Invois',
    extra_utility_surcharge: 'Caj Utiliti / Tambahan (RM)',
    tenancy_period: 'Tempoh Sewaan',
    monthly_schedule_title: 'Kitaran Sewaan & Status Bayaran',
    month_num: 'Bulan ke-',
    due_date_label: 'Tarikh Akhir Bayaran',
    btn_send_month_inv: 'Hantar Invois',
    btn_send_month_rec: 'Hantar Resit',
    btn_mark_month_paid: 'Tanda Bayar',
    btn_unmark_month_paid: 'Batal Tanda',
    paid_movein: 'Dibayar (Kemasukan)',
    pending: 'Belum Bayar',
    paid: 'Telah Dibayar',
    btn_view_invoices: 'Jadual Invois',
    month_1_paid_move_in: 'Sewa Bulan 1 Telah Dibayar Melalui Pakej Kemasukan',
    month_1_paid_move_in_note: 'Sewa Bulan 1 Telah Dibayar Melalui Pakej Kemasukan (Penjanaan Invois Bermula Bulan ke-2)',
    invoicing_starts_month_2: 'Penjanaan invois bermula dari Bulan ke-2',
    settled_via_move_in: 'Lunas (Pakej Kemasukan)',
    no_invoice_month_1: 'Tiada Invois Diperlukan (Bulan 1 Telah Lunas Dalam Pakej Kemasukan)',

    // In-App User Guide
    user_guide_title: 'Panduan Pengguna & Manual Operasi',
    user_guide_sub: 'Panduan langkah demi langkah pemasangan telefon, tempahan, invois, WhatsApp, dan kewangan.',
    btn_open_guide: 'Buka Panduan Pengguna (BM / EN)',
    user_guide_modal_title: 'Panduan Pengguna & Manual',
    user_guide_modal_sub: 'Panduan lengkap & panduan operasi sistem',
    guide_lang_label: 'Pilihan Bahasa Panduan:',

    // Team & Suppliers Directory and Dispatch
    team_dir_title: 'Pasukan Penyelenggaraan & Pembekal',
    team_dir_subtitle: 'Urus tukang cuci, juruteknik, tukang baiki & pembekal',
    add_person_btn: '+ Tambah Kenalan',
    btn_team_suppliers: '👷 Pasukan & Pembekal',
    btn_service_supply_alert: '🛠️ Notis Servis & Bekalan',
    contact_name_label: 'Nama Kenalan / Pekerja',
    contact_category_label: 'Kategori Servis / Peranan',
    contact_phone_label: 'Nombor WhatsApp',
    contact_company_label: 'Nama Syarikat / Kedai (Pilihan)',
    contact_notes_label: 'Kadar Caj, Skop Kerja & Nota',
    contact_modal_title_new: 'Tambah Pasukan / Pembekal',
    contact_modal_title_edit: 'Kemaskini Butiran Kenalan',
    save_contact_btn: 'Simpan Kenalan',
    dispatch_modal_title: 'WhatsApp Notis Servis & Bekalan',
    dispatch_modal_sub: 'Hantar arahan kepada pencuci, juruteknik atau tempah bekalan',
    dispatch_recipient_label: 'Hantar WhatsApp Kepada',
    dispatch_property_label: 'Unit Homestay Terlibat',
    dispatch_type_label: 'Jenis Servis / Tugasan',
    dispatch_urgency_label: 'Tahap Keperluan',
    dispatch_details_label: 'Arahan Kerja / Baiki / Tempahan',
    dispatch_include_pin: 'Sertakan Kod PIN Pintu & Akses',
    btn_copy_text: 'Salin Teks',
    btn_send_wa_direct: 'Hantar melalui WhatsApp',
    cat_cleaner: '🧹 Tukang Cuci / Pasukan Kemas',
    cat_aircond: '❄️ Pakar Servis Aircond',
    cat_plumber: '🔧 Tukang Paip',
    cat_electrician: '⚡ Juruelektrik / Pendawaian',
    cat_handyman: '🔨 Baiki Am / Tukang Rumah',
    cat_linen_supplier: '🧺 Pembekal Linen & Dobi',
    cat_gas_supplier: '⛽ Pembekal Gas & Keperluan',
    cat_locksmith: '🔐 Tukang Kunci / Smart Lock',
    cat_other: '📦 Kontraktor / Pembekal Lain',

    // Digital Receipts & Payments
    receipt_modal_title: 'Rekod Resit Bayaran & No. Rujukan',
    receipt_gallery_title: 'Bukti Bayaran & Resit Transaksi',
    btn_receipt_proofs: 'Bukti Bayaran',
    payment_type: 'Jenis / Tujuan Bayaran',
    monthly_cycle: 'Pusingan Bulan',
    amount_received: 'Jumlah Diterima (RM)',
    payment_date: 'Tarikh & Masa Bayaran',
    bank_channel: 'Bank / Saluran Bayaran',
    bank_ref_no: 'No. Rujukan Bank / ID Transaksi',
    paste: 'Tampal',
    bank_ref_hint: 'Salin & tampal No. Rujukan Transaksi daripada resit pindahan bank penyewa.',
    digital_receipt_slip: 'Tangkapan Skrin Resit / Slip (Bukti Resit)',
    tap_to_upload_receipt: 'Tekan untuk Muat Naik atau Tangkap Gambar Slip',
    receipt_formats_hint: 'JPG, PNG, WebP atau PDF • Dimampat automatik tanpa bebanan memori',
    view: 'Lihat',
    remove: 'Padam',
    payment_notes: 'Catatan / Nota (Pilihan)',
    save_payment_proof: 'Simpan Rekod Bayaran & Resit',
    add_payment_receipt: '+ Rekod Bayaran / Resit Baharu',
    copy_ref: 'Salin No. Ref',
    ref_copied: 'Nombor rujukan bank berjaya disalin!',
    download: 'Muat Turun Slip',
    no_receipts_recorded: 'Tiada resit bayaran direkodkan bagi tempahan ini lagi.',
    delete_receipt_confirm: 'Adakah anda pasti mahu memadamkan rekod bayaran dan slip ini?',
    receipt_badge_count: 'Resit',

    // OCR Receipt & Bill Scanner
    ocr_scan_btn: 'Imbas Resit / Bil',
    ocr_scan_slip_btn: 'Imbas Resit (OCR)',
    ocr_scan_bill_btn: 'Imbas Bil (OCR)',
    ocr_modal_title: 'Pengimbas Resit & Bil OCR',
    ocr_modal_sub: 'Pengecaman automatik untuk resit bank Malaysia & bil utiliti',
    ocr_tab_camera: 'Kamera / Muat Naik Resit',
    ocr_tab_paste: 'Tampal Mesej WhatsApp / Teks',
    ocr_detected_heading: 'Maklumat Berjaya Dikesan',
    ocr_apply_booking: 'Rekod ke Tempahan Tetamu',
    ocr_save_expense: 'Rekod sebagai Perbelanjaan',
    ocr_processing: 'Sedang mengimbas dokumen dengan OCR...',
    ocr_success: 'Dokumen berjaya diimbas!',
    ocr_settings_title: 'Pengimbas Resit & Bil OCR',
    ocr_settings_sub: 'Enjin pengecaman optik untuk resit bank Malaysia dan bil utiliti',
    ocr_engine_label: 'Enjin Pengecaman',
    ocr_engine_hint: 'Mod Automatik berfungsi luar talian (tanpa internet). Gemini Flash memberikan ketepatan tinggi untuk resit renyuk atau condong.',
    gemini_api_key_label: 'Kunci API Google Gemini (Pilihan)',
    gemini_api_hint: 'Disimpan secara peribadi pada peranti anda sahaja.',
    btn_save_ocr: 'Simpan Tetapan Pengimbas',
    tap_upload_bill: 'Ketik untuk Tangkap atau Muat Naik Bil (TNB, Air, Barangan)',
    exp_receipt_bill: 'Resit / Salinan Bil (Pilihan)',

    // Smart WhatsApp Chat Import
    cat_tenant: '👤 Penyewa / Tetamu Tetap',
    btn_import_tenant_chat: 'Import Chat WhatsApp',
    import_tenant_chat_title: 'Import Perbualan WhatsApp Pintar',
    import_tenant_chat_sub: 'Tampal perbualan WhatsApp penyewa untuk ekstrak butiran automatik',
    extract_chat_btn: 'Ekstrak Butiran Tetamu',
    paste_chat_placeholder: 'Tampal mesej perbualan atau maklumat tempahan tetamu di sini...',
    view_original_chat: 'Lihat Mesej Perbualan Asal',
    create_booking_btn: 'Buat Sebut Harga / Tempahan',
    save_contact_btn: 'Simpan sebagai Kenalan',
    create_both_btn: 'Buat Kedua-duanya (Tempahan + Kenalan)',
    chat_extracted_success: 'Butiran tetamu berjaya diekstrak!',
    import_chat_short: 'Import Chat',
    booking_type_label: 'Jenis Tempahan',
    type_individual: 'Individu',
    type_company: 'Syarikat',
    ssm_reg_no: 'Nombor Pendaftaran SSM',
    pic_name_label: 'Nama PIC',
    pic_position_label: 'Jawatan PIC',
    pic_phone_label: 'Nombor Telefon PIC',
    pic_email_label: 'Emel PIC',
    company_address_label: 'Alamat Syarikat',
    id_number_label: 'No. Kad Pengenalan / Pasport',
    sample_company_btn: 'Sampel Syarikat',

    // Tenant Lifecycle & Repeat Guest Recognition
    repeat_guest_detected: 'Tetamu Berulang Dikesan',
    kpi_active_tenants: 'Penyewa Aktif',
    kpi_repeat_guests: 'Tetamu Berulang',
    kpi_repeat_bookings: 'Jumlah Tempahan Berulang',
    top_returning_guests: 'Tetamu Paling Kerap Menginap',
    tenant_lifecycle_kpis_title: 'Kecerdasan Penyewa & Tetamu Berulang',
    tenant_lifecycle_kpis_sub: 'Jejak penyewa aktif vs sejarah, pengekalan tetamu setia dan nilai jangka hayat',
    lbl_prev_stays: 'Penginapan Terdahulu',
    lbl_last_stay: 'Tarikh Terakhir',
    lbl_lifetime_rev: 'Hasil Terkumpul',
    btn_use_existing_tenant: 'Gunakan Maklumat Penyewa',
    tenant_status_label: 'Status Kitaran Hayat',
    status_active: 'Aktif',
    status_completed: 'Selesai',
    status_prospect: 'Prospek',
    status_blacklisted: 'Senarai Hitam',
    blacklisted_guest_warning: '⚠️ Tetamu Senarai Hitam Dikesan',
    filter_status_all: 'Semua Status',

    // Promotional Media & Marketing Hub
    promo_hub_modal_title: 'Hab Media Promosi & Pemasaran',
    promo_hub_modal_sub: 'Simpan foto, poster, video homestay & ayat iklan untuk dihantar pantas',
    filter_by_property: 'Tapis mengikut Homestay',
    all_properties: 'Semua Homestay & Umum',
    add_media_asset: '+ Tambah Media',
    cat_all: 'Semua',
    cat_photos: 'Foto Unit',
    cat_posters: 'Poster / Flyer',
    cat_videos: 'Video Tour',
    cat_copywriting: 'Ayat Iklan',
    no_promo_media_found: 'Tiada media promosi dijumpai',
    no_promo_media_hint: 'Simpan foto bilik, kemudahan, poster diskaun dan ayat promosi untuk dikongsi dengan bakal tetamu.',
    add_first_promo_media: 'Tambah Media Pertama',
    add_promo_media_title: 'Tambah Media Promosi',
    edit_promo_media_title: 'Kemaskini Media Promosi',
    add_promo_media_sub: 'Muat naik gambar, pautan video tour atau ayat promosi',
    media_category_label: 'Kategori Media',
    media_title_label: 'Tajuk / Tajuk Utama',
    upload_promo_image: 'Muat Naik Gambar / Poster (Mampat Automatik)',
    tap_upload_photo_poster: 'Tekan untuk Muat Naik Foto atau Poster',
    auto_compressed_note: 'JPG, PNG, WebP • Dimampatkan automatik ~60KB tanpa beban memori',
    external_link_label: 'Pautan Video Tour / Galeri Awan (Pilihan)',
    external_link_hint: 'Sifar penggunaan memori telefon. Sesuai untuk pautan video YouTube, TikTok atau Google Drive.',
    promo_caption_label: 'Ayat Iklan / Copywriting Promosi',
    insert_template: 'Templat Contoh',
    promo_caption_hint: 'Teks ini akan disertakan semasa perkongsian WhatsApp atau salin ke papan keratan.',
    save_promo_media: 'Simpan Media',
    share_via_whatsapp: 'Hantar Promosi via WhatsApp',
    send_to_recipient: 'Hantar Kepada',
    enter_phone_number: 'Masukkan / Pilih Nombor Telefon',
    guest_phone_label: 'Nombor WhatsApp Bakal Tetamu',
    phone_empty_hint: 'Biarkan kosong untuk buka WhatsApp dan pilih kenalan anda.',
    message_preview: 'Pratonton Mesej',
    open_in_whatsapp: 'Hantar di WhatsApp',
    attach_promo_media: '+ Sertakan Media Promosi / Pautan Tour',
    promo_media_card_title: 'Hab Media Promosi & Pemasaran',
    promo_media_card_sub: 'Simpan foto unit, poster promosi, video walkthrough dan ayat tawaran untuk bakal tetamu',
    open_media_hub: 'Buka Hab Media',
    copy_pitch: 'Salin Ayat',
    pitch_copied: 'Ayat promosi berjaya disalin ke papan keratan!',
    link_copied: 'Pautan media berjaya disalin ke papan keratan!',
    delete_promo_confirm: 'Adakah anda pasti mahu memadamkan media promosi ini?',

    // Tenancy Agreement Generator
    agr_modal_title: 'Penjana Perjanjian Sewaan Kediaman',
    agr_modal_subtitle: 'Jana surat perjanjian rasmi A4 lengkap dengan syarat rumah mesra Muslim, jadual terma, inventori & tandatangan.',
    tenancy_agreement_banner_title: 'Perjanjian Sewaan Kediaman (Tenancy Agreement)',
    tenancy_agreement_banner_sub: 'Auto-jana perjanjian rasmi A4, klausa mesra Muslim, inventori & tandatangan.',
    btn_generate_agreement: 'Jana Perjanjian Sewa',
    pdf_tab_agreement: '5. Perjanjian Sewaan',
    agr_tab_form: '1. Butiran & Syarat Perjanjian',
    agr_tab_preview: '2. Pratonton & Jana Dokumen A4',
    agr_lbl_select_booking: 'Pilih Rekod Penyewa / Tempahan Bulanan:',
    agr_btn_autofill: 'Isi Semula Auto',
    agr_sec_parties: '1. Butiran Pihak-Pihak (Tuan Rumah & Penyewa)',
    agr_title_landlord: 'Tuan Rumah (Landlord / Lessor)',
    agr_lbl_landlord_name: 'Nama Penuh Tuan Rumah / Syarikat:',
    agr_lbl_landlord_ic: 'No. K/P / No. Syarikat (SSM):',
    agr_lbl_landlord_phone: 'No. Telefon / WhatsApp:',
    agr_lbl_landlord_addr: 'Alamat Surat-Menyurat Tuan Rumah:',
    agr_title_tenant: 'Penyewa (Tenant / Lessee)',
    agr_lbl_tenant_name: 'Nama Penuh Penyewa:',
    agr_lbl_tenant_ic: 'No. K/P / Pasport:',
    agr_lbl_tenant_phone: 'No. Telefon:',
    agr_lbl_tenant_email: 'Alamat Emel (Jika Ada):',
    agr_lbl_tenant_addr: 'Alamat Tetap Penyewa (K/P / Asal):',
    agr_sec_property_terms: '2. Maklumat Premis Demis & Terma Kewangan',
    agr_lbl_prop_name: 'Nama Unit / Homestay:',
    agr_lbl_prop_type: 'Jenis Hartanah:',
    agr_lbl_prop_addr: 'Alamat Penuh Premis Yang Disewakan (Premis Demis):',
    agr_lbl_agr_date: 'Tarikh Perjanjian Dibuat:',
    agr_lbl_start_date: 'Tarikh Mula Sewaan:',
    agr_lbl_end_date: 'Tarikh Tamat Sewaan:',
    agr_lbl_duration: 'Tempoh Sewaan (Bulan):',
    agr_lbl_monthly_rent: 'Sewa Bulanan (RM / Bulan):',
    agr_lbl_due_day: 'Hari Genap Masa Bayaran:',
    agr_lbl_rental_deposit: 'Cagaran Sewa (1 Bulan - RM):',
    agr_lbl_util_deposit: 'Cagaran Utiliti (Elektrik/Air - RM):',
    agr_lbl_advance_rent: 'Sewa Bulan Pertama (RM):',
    agr_lbl_fee: 'Duti Setem & Yuran (RM):',
    agr_lbl_renewal_notice: 'Notis Opsyen Pembaharuan:',
    agr_lbl_payment_account: 'Akaun Bank Tuan Rumah:',
    agr_sec_muslim_title: '3. Klausa Khas Pemeliharaan Keadaan Rumah Mesra Muslim',
    agr_switch_muslim: 'Aktifkan Klausa Syarat Mesra Muslim',
    agr_muslim_desc_title: 'Syarat Mutlak Pemeliharaan Status & Kesucian Rumah Sewa:',
    agr_lbl_custom_clauses: 'Klausa / Syarat Khas Tambahan Tuan Rumah (Optional):',
    agr_sec_inventory: '4. Senarai Perkakas, Perabot & Inventori Premis',
    agr_btn_add_item: '+ Tambah Item',
    agr_th_item_name: 'Perkara / Inventori',
    agr_th_qty: 'Kuantiti',
    agr_th_condition: 'Keadaan Semasa',
    agr_sec_witnesses: '5. Maklumat Saksi-Saksi (Witnesses)',
    agr_title_witness_landlord: 'Saksi Tuan Rumah',
    agr_title_witness_tenant: 'Saksi Penyewa',
    agr_lbl_wit_name: 'Nama Saksi:',
    agr_lbl_wit_ic: 'No. K/P Saksi:',
    agr_btn_go_preview: 'Jana & Lihat Pratonton Dokumen Perjanjian →',
    agr_lbl_lang: 'Bahasa Dokumen:',
    agr_btn_edit_details: '← Edit Butiran',
    agr_btn_save_draft: 'Simpan Draf',
    agr_btn_print: 'Cetak Dokumen',
    agr_btn_share_wa: 'WhatsApp Penyewa',
    agr_btn_download_pdf: 'Muat Turun PDF A4',

    // Overlap Warning & Alternate Units
    overlap_requested_dates: 'Tarikh dipohon:',
    overlap_system_notice: 'Sistem menghalang tempahan bertindih (double-booking). Maklumat tempahan sedia ada yang bercanggah:',
    overlap_alt_available: 'Homestay Lain Yang Kosong Pada Tarikh Ini:',

    // Change Unit Modal
    current_unit_label: 'Unit Semasa:',
    total_amount_label: 'Jumlah:',
    change_homestay_assurance_title: 'Jaminan Pemindahan Butiran Penuh:',
    change_homestay_assurance_desc: 'Nama tetamu, telefon WhatsApp, No. Kad Pengenalan/Pasport, emel, alamat surat-menyurat, bilangan tetamu, resit bayaran & nota tempahan akan dipindahkan secara automatik ke unit baru. Jadual pembersihan (turnover) juga akan dikemaskini.',

    // PDF Toolbar & Customization
    quick_presets: 'Pantas:',
    days_short: 'Hari',
    pdf_monthly_scope_title: 'Pilihan Dokumen Sewaan Bulanan',
    badge_monthly_tenancy: 'Sewaan Bulanan',
    pdf_monthly_utility_label: 'Caj Utiliti Bulan Ini (Elektrik & Air)',
    pdf_monthly_scope_hint: 'Pilih Pakej Kemasukan (Sebut Harga) atau Invois Sewaan bagi bulan tertentu',
    btn_auto_deposit: 'Auto Deposit',
    pdf_deposit_hint: 'Jumlah ini akan disahkan diterima dan dicetak di atas resit deposit',
    pdf_pay_ref_hint: 'Akan tertera pada resit untuk rujukan audit perakaunan',
    pdf_pay_ref_placeholder: 'cth: Maybank - M2U-99218291 atau DuitNow QR',
    pdf_client_org_hint: "Akan tertera di bawah 'Dikeluarkan Kepada / Billed To'",
    pdf_client_org_placeholder: 'cth: Kementerian Pendidikan / Petronas Chemicals',
    pdf_lpo_ref_hint: 'Untuk rujukan audit & tuntutan kewangan',
    pdf_lpo_ref_placeholder: 'cth: LPO/2026/089 atau Ruj. Pejabat',
    pdf_lang_hint: 'Tukar format teks dokumen secara serta-merta',

    // PDF WhatsApp Prompt Banner
    wa_prompt_title: 'Hantar Dokumen ini ke WhatsApp Tetamu?',
    wa_prompt_sub: 'Fail PDF rasmi ini sedia untuk dimuat turun dan dihantar terus kepada tetamu melalui WhatsApp.',
    wa_prompt_yes: 'Ya, Hantar ke WhatsApp',
    wa_prompt_dl: 'Muat Turun PDF',
    wa_prompt_tab: 'Buka di Tab Baru',
    wa_prompt_dismiss: 'Tutup Notis',

    // Tenancy Agreement Generator
    agr_legal_disclaimer: 'Ini adalah templat dan bukan nasihat undang-undang. Sila sahkan duti setem dan keperluan undang-undang dengan peguam atau LHDN.',
    type_individual_owner: 'Individu / Pemilik',
    type_individual: 'Individu',
    type_company_ssm: 'Syarikat / SSM',
    agr_landlord_name_hint: '*Nama pemilik sah hartanah (Bukan nama branding homestay). Boleh senaraikan pemilik bersama jika ada.',
    agr_signatory_title: 'Wakil / Penandatangan Tuan Rumah (Authorized Signatory):',
    agr_signatory_name: 'Nama Wakil / Pengarah:',
    agr_signatory_capacity: 'Jawatan / Kapasiti:',
    agr_signatory_ic: 'No. K/P Wakil (NRIC):',
    agr_open_details_form: 'Buka Borang Butiran',
    agr_booking_hint: 'Pilih tempahan di atas untuk auto-isi semua butiran penyewa, homestay, kadar sewa, dan deposit.',

    // Backup Reminder & Safety
    backup_reminder_msg: 'Peringatan: Anda mempunyai rekod tempahan tetapi belum mengeksport fail sandaran dalam tempoh 14 hari yang lalu.',
    btn_backup_now: 'Eksport Sandaran Sekarang',
    clear_data_modal_title: 'Padam Semua Data?',
    clear_data_modal_sub: 'Tindakan kekal: Semua rekod homestay, tempahan, perbelanjaan & resit akan dipadam dari peranti ini.',
    clear_data_backup_advice: 'Lindungi data anda dahulu!',
    clear_data_backup_desc: 'Kami sangat menyarankan anda memuat turun fail sandaran (.json) sebelum memadam data peranti ini.',
    clear_data_type_confirm_label: 'Taip DELETE di bawah untuk sahkan:',
    btn_confirm_delete: 'Sahkan Padam Semua',
    storage_quota_alert_title: 'Had Kuota Storan Penuh',
    storage_quota_alert_msg: 'Storan peranti hampir penuh. Sila eksport fail sandaran dari Tetapan dan padam resit lama untuk meneruskan penyimpanan.',
    storage_protected_msg: 'Storan dilindungi daripada dipadam automatik oleh pelayar.',
    link_user_guide: 'User guide / Panduan pengguna'
  }
};

function t(key) {
  const lang = appState.settings.language || 'en';
  return (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || (TRANSLATIONS['en'][key]) || key;
}

// ==========================================================================
// LOCAL DATE & TIMEZONE UTILITIES (Asia/Kuala_Lumpur)
// ==========================================================================

function formatLocalDate(d = new Date()) {
  if (!d) return '';
  if (typeof d === 'string') {
    if (/^\d{4}-\d{2}-\d{2}$/.test(d)) return d;
    d = new Date(d);
  }
  if (isNaN(d.getTime())) return '';
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function calcNightsBetween(d1Str, d2Str) {
  if (!d1Str || !d2Str) return 0;
  const p1 = d1Str.split('-').map(Number);
  const p2 = d2Str.split('-').map(Number);
  if (p1.length < 3 || p2.length < 3) return 0;
  const utc1 = Date.UTC(p1[0], p1[1] - 1, p1[2]);
  const utc2 = Date.UTC(p2[0], p2[1] - 1, p2[2]);
  const diff = Math.round((utc2 - utc1) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff : 0;
}

// ==========================================================================
// INDEXEDDB IMAGE STORAGE ENGINE & QUOTA SAFEGUARDS
// ==========================================================================

const IMAGE_DB_NAME = 'StayManagerImageDB';
const IMAGE_DB_VERSION = 1;
const IMAGE_STORE_NAME = 'images';
let imageDBPromise = null;
const IMAGE_CACHE = new Map();

function openImageDB() {
  if (imageDBPromise) return imageDBPromise;
  imageDBPromise = new Promise((resolve) => {
    if (!('indexedDB' in window)) {
      console.warn('IndexedDB not supported on this browser.');
      return resolve(null);
    }
    const req = indexedDB.open(IMAGE_DB_NAME, IMAGE_DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(IMAGE_STORE_NAME)) {
        db.createObjectStore(IMAGE_STORE_NAME, { keyPath: 'id' });
      }
    };
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = (e) => {
      console.error('Failed to open IndexedDB:', e);
      resolve(null);
    };
  });
  return imageDBPromise;
}

async function saveImageToDB(id, dataUrl) {
  if (!id || !dataUrl) return false;
  IMAGE_CACHE.set(id, dataUrl);
  try {
    const db = await openImageDB();
    if (!db) return false;
    return new Promise((resolve) => {
      const tx = db.transaction([IMAGE_STORE_NAME], 'readwrite');
      const store = tx.objectStore(IMAGE_STORE_NAME);
      store.put({ id, dataUrl, createdAt: new Date().toISOString() });
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch (e) {
    console.error('Error saving image to IndexedDB:', e);
    return false;
  }
}

async function getImageFromDB(id, bypassCache = false) {
  if (!id) return null;
  if (!bypassCache && IMAGE_CACHE.has(id)) return IMAGE_CACHE.get(id);
  try {
    const db = await openImageDB();
    if (!db) return null;
    return new Promise((resolve) => {
      const tx = db.transaction([IMAGE_STORE_NAME], 'readonly');
      const store = tx.objectStore(IMAGE_STORE_NAME);
      const req = store.get(id);
      req.onsuccess = () => {
        if (req.result && req.result.dataUrl) {
          IMAGE_CACHE.set(id, req.result.dataUrl);
          resolve(req.result.dataUrl);
        } else {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    });
  } catch (e) {
    return null;
  }
}

async function getAllImagesFromDB() {
  try {
    const db = await openImageDB();
    if (!db) return [];
    return new Promise((resolve) => {
      const tx = db.transaction([IMAGE_STORE_NAME], 'readonly');
      const store = tx.objectStore(IMAGE_STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  } catch (e) {
    return [];
  }
}

async function deleteImageFromDB(id) {
  if (!id) return false;
  IMAGE_CACHE.delete(id);
  try {
    const db = await openImageDB();
    if (!db) return false;
    return new Promise((resolve) => {
      const tx = db.transaction([IMAGE_STORE_NAME], 'readwrite');
      const store = tx.objectStore(IMAGE_STORE_NAME);
      store.delete(id);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch (e) {
    return false;
  }
}

async function preloadAllImages() {
  try {
    const items = await getAllImagesFromDB();
    items.forEach(it => {
      if (it && it.id && it.dataUrl) {
        IMAGE_CACHE.set(it.id, it.dataUrl);
      }
    });
  } catch (e) {}
}

async function migrateImagesToIndexedDB() {
  let modified = false;
  let migrationFailed = false;

  // 1. Migrate booking receipt images
  if (Array.isArray(appState.bookings)) {
    for (const b of appState.bookings) {
      if (Array.isArray(b.payments)) {
        for (const p of b.payments) {
          if (p.receiptImage && p.receiptImage.startsWith('data:image')) {
            const imgId = p.receiptImageId || `img-rcpt-${b.id}-${p.id || Math.random().toString(36).substr(2, 6)}`;
            const saved = await saveImageToDB(imgId, p.receiptImage);
            if (saved) {
              const readBack = await getImageFromDB(imgId, true);
              if (readBack && readBack.length > 50) {
                p.receiptImageId = imgId;
                p.receiptImage = null; // Only clear after verified write and read-back!
                modified = true;
              } else {
                migrationFailed = true;
                console.warn(`[Migration] Read-back verification failed for receipt ${imgId}. Original preserved.`);
              }
            } else {
              migrationFailed = true;
              console.warn(`[Migration] Failed to save receipt ${imgId} to IndexedDB. Original preserved.`);
            }
          } else if (p.receiptImageId && !p.receiptImage) {
            const d = await getImageFromDB(p.receiptImageId);
            if (d) IMAGE_CACHE.set(p.receiptImageId, d);
          }
        }
      }
    }
  }

  // 2. Migrate promotional media images
  if (Array.isArray(appState.promotionalMedia)) {
    for (const m of appState.promotionalMedia) {
      if (m.imageData && m.imageData.startsWith('data:image')) {
        const imgId = m.imageId || `img-promo-${m.id}`;
        const saved = await saveImageToDB(imgId, m.imageData);
        if (saved) {
          const readBack = await getImageFromDB(imgId, true);
          if (readBack && readBack.length > 50) {
            m.imageId = imgId;
            m.imageData = null; // Only clear after verified write and read-back!
            modified = true;
          } else {
            migrationFailed = true;
            console.warn(`[Migration] Read-back verification failed for promo media ${imgId}. Original preserved.`);
          }
        } else {
          migrationFailed = true;
          console.warn(`[Migration] Failed to save promo media ${imgId} to IndexedDB. Original preserved.`);
        }
      } else if (m.imageId && !m.imageData) {
        const d = await getImageFromDB(m.imageId);
        if (d) IMAGE_CACHE.set(m.imageId, d);
      }
    }
  }

  if (modified) {
    saveToStorage();
    console.log('[Migration] Successfully moved verified base64 image slips into IndexedDB.');
  }

  if (migrationFailed) {
    if (!window._migrationWarnedOnce) {
      window._migrationWarnedOnce = true;
      if (typeof showToast === 'function') {
        showToast(
          (appState.settings?.language === 'bm'
            ? 'Amaran: Sebahagian imej gagal dipindahkan ke IndexedDB dan disimpan dalam storan selamat. Migrasi akan dicuba semula pada pelancaran seterusnya.'
            : 'Warning: Some images could not be moved to IndexedDB and were preserved safely. Migration will retry on next launch.'),
          'warning'
        );
      }
    }
  }
}

async function requestStoragePersistence(notifyUser = false) {
  if (navigator.storage && navigator.storage.persist) {
    try {
      const isPersisted = await navigator.storage.persisted();
      if (isPersisted) {
        if (notifyUser) showToast(t('storage_protected_msg'));
        return true;
      }
      const granted = await navigator.storage.persist();
      if (notifyUser) {
        if (granted) {
          showToast(t('storage_protected_msg'));
        } else {
          showToast(appState.settings.language === 'bm' 
            ? 'Pelayar tidak memberi kebenaran storan kekal (biasa dalam mod incognito).' 
            : 'Persistent storage permission not granted by browser.');
        }
      }
      return granted;
    } catch (e) {
      return false;
    }
  }
  return false;
}

function showQuotaExceededAlert() {
  const isBM = appState.settings.language === 'bm';
  const title = isBM ? 'Had Storan Penuh!' : 'Storage Quota Limit Reached!';
  const msg = isBM
    ? 'Storan tempatan pelayar anda telah penuh. Sila eksport fail sandaran (Backup) dari Tetapan dan padamkan gambar/resit lama untuk mengosongkan ruang.'
    : 'Your browser storage quota has been exceeded. Please export a backup from Settings and clean up older receipts to free up space.';
  alert(`⚠️ ${title}\n\n${msg}`);
}

function checkAndPromptBackupReminder() {
  const banner = document.getElementById('backupReminderBanner');
  if (!banner) return;

  if (!appState.bookings || appState.bookings.length === 0) {
    banner.style.display = 'none';
    return;
  }

  if (sessionStorage.getItem('staymanager_backup_reminder_dismissed') === 'true') {
    banner.style.display = 'none';
    return;
  }

  const lastBackupStr = localStorage.getItem('staymanager_last_backup_date');
  if (!lastBackupStr) {
    banner.style.display = 'flex';
    return;
  }

  const lastDate = new Date(lastBackupStr);
  const now = new Date();
  const diffDays = Math.floor((now - lastDate) / (1000 * 60 * 60 * 24));
  if (diffDays >= 14) {
    banner.style.display = 'flex';
  } else {
    banner.style.display = 'none';
  }
}

function dismissBackupReminderBanner() {
  const banner = document.getElementById('backupReminderBanner');
  if (banner) banner.style.display = 'none';
  sessionStorage.setItem('staymanager_backup_reminder_dismissed', 'true');
}

function openClearDataModal() {
  const modal = document.getElementById('clearDataConfirmModal');
  if (!modal) return;
  const input = document.getElementById('clearDataConfirmInput');
  const btnFinal = document.getElementById('btnConfirmClearDataFinal');
  if (input) input.value = '';
  if (btnFinal) btnFinal.disabled = true;
  modal.classList.add('active');
}

function closeClearDataModal() {
  const modal = document.getElementById('clearDataConfirmModal');
  if (modal) modal.classList.remove('active');
}

function handleConfirmClearData() {
  const preservedLicense = appState.licenseKey;
  const preservedIsLicensed = appState.isLicensed;
  const preservedToken = appState.licenseToken;
  const preservedPayload = appState.licensePayload;
  const preservedDays = appState.licenseDaysRemaining;
  const preservedProState = appState.proHubState;
  const preservedSettings = { ...appState.settings };

  appState.properties = [];
  appState.bookings = [];
  appState.turnovers = [];
  appState.expenses = [];
  appState.contacts = [...DEFAULT_CONTACTS];
  appState.promotionalMedia = [];
  appState.selectedPropertyId = 'all';
  appState.isLicensed = preservedIsLicensed;
  appState.licenseToken = preservedToken;
  appState.licensePayload = preservedPayload;
  appState.licenseDaysRemaining = preservedDays;
  appState.proHubState = preservedProState;
  appState.licenseKey = preservedLicense;
  appState.isMasterAdmin = false;
  appState.settings = preservedSettings;

  openImageDB().then(db => {
    if (db) {
      const tx = db.transaction([IMAGE_STORE_NAME], 'readwrite');
      tx.objectStore(IMAGE_STORE_NAME).clear();
      IMAGE_CACHE.clear();
    }
  }).catch(() => {});

  localStorage.setItem('staymanager_initialized', 'true');
  saveToStorage();
  closeClearDataModal();
  renderApp();
  showToast(appState.settings.language === 'bm' 
    ? 'Semua data homestay & tempahan telah berjaya dipadam.' 
    : 'All homestay & booking data cleared successfully!');
}

const INITIAL_PROPERTIES = [
  {
    id: 'prop-1',
    name: 'Sunset Ocean Villa (Whole House)',
    propType: 'entire',
    roomNo: 'Whole Unit (3-Bedroom)',
    address: 'Unit 12-05, Seaview Residences, Jalan Pantai 1',
    gpsLocation: 'https://maps.google.com/?q=3.1390,101.6869',
    wifiName: 'SunsetVilla_HighSpeed',
    wifiPass: 'oceanbreeze2026',
    doorCode: '5829#',
    color: '#0284c7',
    defaultRate: 280,
    cleaningFee: 60,
    checkInTime: '15:00',
    checkOutTime: '12:00',
    rules: 'No smoking indoors. Quiet hours after 10:00 PM. Please turn off air conditioning when leaving.'
  },
  {
    id: 'prop-2',
    name: 'Villa Impian - Master Bedroom',
    propType: 'room_master',
    roomNo: 'Bilik Master (Attached Bathroom)',
    address: 'Lot 45, Green Hills Sanctuary, Cameron View',
    gpsLocation: 'https://maps.google.com/?q=4.4721,101.3789',
    wifiName: 'VillaImpian_5G',
    wifiPass: 'freshcool99',
    doorCode: '1122#',
    color: '#059669',
    defaultRate: 150,
    cleaningFee: 30,
    checkInTime: '15:00',
    checkOutTime: '12:00',
    rules: 'No pets inside. Shoes off at entrance. Kitchen and living hall are shared.'
  },
  {
    id: 'prop-3',
    name: 'Villa Impian - Room 2 (Medium)',
    propType: 'room_medium',
    roomNo: 'Bilik 2',
    address: 'Lot 45, Green Hills Sanctuary, Cameron View',
    gpsLocation: 'https://maps.google.com/?q=4.4721,101.3789',
    wifiName: 'VillaImpian_5G',
    wifiPass: 'freshcool99',
    doorCode: '1123#',
    color: '#d97706',
    defaultRate: 100,
    cleaningFee: 25,
    checkInTime: '15:00',
    checkOutTime: '12:00',
    rules: 'Quiet hours after 10:00 PM. Shared kitchen & living hall.'
  }
];

let appState = {
  properties: [],
  bookings: [],
  turnovers: [],
  expenses: [],
  contacts: [],
  promotionalMedia: [],
  selectedPromoPropertyId: 'all',
  selectedPromoCategory: 'all',
  promoSearchQuery: '',
  settings: { ...DEFAULT_SETTINGS },
  isLicensed: false,
  licenseToken: null,
  licenseKey: null,
  licensePayload: null,
  licenseDaysRemaining: 0,
  proHubState: 'CHECKING',
  selectedPropertyId: 'all',
  activeTab: 'dashboard',
  currentCalDate: new Date(),
  selectedCalDate: formatLocalDate(new Date()),
  calListingMode: 'incoming',
  calFilterMode: 'checkin',
  activeWaBooking: null,
  activeWaTemplate: 'confirm',
  activePdfBooking: null,
  activePdfDocType: 'quotation',
  activePdfLang: 'bm',
  quotationCounter: 1001,
  invoiceCounter: 1001,
  depositReceiptCounter: 1001,
  paymentReceiptCounter: 1001,
  refundCounter: 1001,
  activeDispatchRecipientId: null,
  activeDispatchPropertyId: null,
  activeDispatchService: 'turnover_clean',
};
window.appState = appState;


// ==========================================================================
// 2. INITIALIZATION & DEMO DATA SEEDING
// ==========================================================================

async function initApp() {
  loadFromStorage();

  // Auto-purge stale cache if app upgraded to new version
  const lastKnownVer = localStorage.getItem(STORAGE_KEYS.VERSION);
  if (lastKnownVer && lastKnownVer !== APP_VERSION) {
    console.log(`[Auto-Update] Detected version change from ${lastKnownVer} to ${APP_VERSION}. Purging old caches...`);
    if ('caches' in window) {
      caches.keys().then(keys => Promise.all(keys.map(k => caches.delete(k)))).catch(() => {});
    }
  }

  // License Recovery & Anti-Tamper Soft Grace:
  // Recover license across legacy and modern storage keys before any evaluation
  const rawSavedKey = localStorage.getItem('staymanager_license_key')
    || localStorage.getItem('staymanager_license_v2')
    || localStorage.getItem('staymanager_license')
    || (appState.settings && appState.settings.licenseKey);

  let recoveredKey = null;
  if (rawSavedKey) {
    if (typeof rawSavedKey === 'string' && (rawSavedKey.startsWith('{') || rawSavedKey.startsWith('"'))) {
      try {
        const parsed = JSON.parse(rawSavedKey);
        recoveredKey = (parsed && parsed.key) ? cleanLicenseKey(parsed.key) : null;
      } catch (_) {
        recoveredKey = cleanLicenseKey(rawSavedKey);
      }
    } else {
      recoveredKey = cleanLicenseKey(rawSavedKey);
    }
  }

  // Preserve recovered key in persistent backup
  if (recoveredKey) {
    localStorage.setItem('staymanager_license_key', recoveredKey);
    appState.licenseKey = recoveredKey;
  }

  // Cryptographically evaluate stored token
  await evaluateLicenseState();

  // If token evaluation did not yield an active license but we have an authentic saved license key
  if (!appState.isLicensed && recoveredKey) {
    console.log('[License Engine] Token missing or unverified. Restoring Pro access from backup key:', recoveredKey);
    appState.licenseKey = recoveredKey;
    appState.isLicensed = true;
    appState.proHubState = navigator.onLine ? 'ACTIVE' : 'OFFLINE';

    // Extract registered phone from token payload or persistent storage if available
    let tokenPhone = null;
    try {
      const rawTok = localStorage.getItem(STORAGE_KEYS.TOKEN);
      if (rawTok && rawTok.includes('.')) {
        const pStr = base64UrlToString(rawTok.split('.')[1]);
        const pObj = JSON.parse(pStr);
        if (pObj && pObj.phone) tokenPhone = pObj.phone;
      }
    } catch (_) {}

    const targetPhone = appState.settings?.ownerPhone
      || localStorage.getItem('staymanager_license_phone')
      || tokenPhone
      || '60124022462';
    if (navigator.onLine && typeof activateWithServer === 'function') {
      activateWithServer(recoveredKey, targetPhone).then(() => {
        console.log('[License Engine] Pro license successfully refreshed with master server.');
      }).catch(err => {
        console.warn('[License Engine] Silent restore server sync note:', err.message || err);
      });
    }
  }

  // Check URL params for Demo or 1-Click Auto-Activation (?phone=...&key=...)
  const urlParams = new URLSearchParams(window.location.search);
  const isDemoParam = urlParams.get('demo') === '1';
  const phoneParam = urlParams.get('phone');
  const keyParam = urlParams.get('key');

  if (keyParam) {
    const rawTargetPhone = phoneParam || appState.settings.ownerPhone;
    if (rawTargetPhone && navigator.onLine) {
      try {
        await activateWithServer(keyParam, rawTargetPhone);
        showToast(appState.settings.language === 'bm' 
          ? '🎉 Tahniah! Lesen Pro berjaya diaktifkan!' 
          : '🎉 Pro License activated successfully!');
      } catch (err) {
        console.warn('URL auto-activation error:', err);
        const phoneInput = document.getElementById('licensePhoneInput');
        const keyInput = document.getElementById('licenseKeyInput');
        if (phoneInput && rawTargetPhone) phoneInput.value = rawTargetPhone;
        if (keyInput) keyInput.value = keyParam.toUpperCase();
        openLicenseModal();
      }
    } else {
      const phoneInput = document.getElementById('licensePhoneInput');
      const keyInput = document.getElementById('licenseKeyInput');
      if (phoneInput && rawTargetPhone) phoneInput.value = rawTargetPhone;
      if (keyInput) keyInput.value = keyParam.toUpperCase();
      openLicenseModal();
    }

    // Remove query params from address bar for clean PWA URL
    if (window.history.replaceState) {
      const cleanUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
      window.history.replaceState({ path: cleanUrl }, '', cleanUrl);
    }
  }

  const isFirstEverVisit = localStorage.getItem('staymanager_initialized') === null;
  if (isDemoParam || (isFirstEverVisit && (!appState.properties || appState.properties.length === 0))) {
    seedDemoData();
    localStorage.setItem('staymanager_initialized', 'true');
  } else {
    localStorage.setItem('staymanager_initialized', 'true');
  }

  try {
    applyTheme(appState.settings.theme);
  } catch (e) { console.warn('Theme init note:', e); }

  try {
    applyLanguageUI();
  } catch (e) { console.warn('Language init note:', e); }

  try {
    setupEventListeners();
  } catch (e) { console.error('Listeners init error:', e); }

  try {
    initAgreementGenerator();
  } catch (e) { console.error('Agreement generator init error:', e); }

  try {
    closeAllModals();
  } catch (e) {}

  // Set Calendar initial title dynamically immediately
  const calTitle = document.getElementById('calMonthTitle');
  if (calTitle) {
    const locale = (appState.settings && appState.settings.language === 'bm') ? 'ms-MY' : 'en-US';
    calTitle.textContent = appState.currentCalDate.toLocaleDateString(locale, { month: 'long', year: 'numeric' });
  }

  // Preload and migrate images asynchronously to IndexedDB
  preloadAllImages().then(() => migrateImagesToIndexedDB()).catch(console.error);

  // Storage persistence protection
  requestStoragePersistence(false);

  // Check 14-day backup reminder
  checkAndPromptBackupReminder();

  try {
    renderApp();
  } catch (e) { console.error('RenderApp error:', e); }

  try {
    initPWAUpdateService();
  } catch (e) { console.warn('PWA update service note:', e); }

  // Online silent refresh check (if token is older than 7 days)
  if (navigator.onLine && appState.licenseToken) {
    checkAndRefreshTokenSilently().catch(err => console.warn('[License Refresh] Silent check note:', err));
  } else if (appState.proHubState === 'CLOCK_ERROR') {
    const isBM = appState.settings.language === 'bm';
    setTimeout(() => {
      alert(isBM 
        ? '⚠️ Ralat Jam Peranti: Tarikh peranti anda lebih awal daripada rekod sebelum ini. Sila betulkan tarikh & masa telefon anda atau sambung ke internet untuk mengesahkan lesen.' 
        : '⚠️ Device Clock Error: Your device date/time is earlier than previously recorded. Please set your device clock correctly or connect to the internet to verify your license.');
    }, 800);
  }

  // Connectivity change listeners
  window.addEventListener('online', () => {
    if (appState.licenseToken) {
      checkAndRefreshTokenSilently().catch(() => {});
    }
    if (appState.isLicensed) {
      appState.proHubState = 'ACTIVE';
      renderApp();
    }
  });

  window.addEventListener('offline', () => {
    if (appState.isLicensed) {
      appState.proHubState = 'OFFLINE';
      renderApp();
    }
  });
}

function loadFromStorage() {
  try {
    const savedProps = localStorage.getItem(STORAGE_KEYS.PROPERTIES);
    const savedBookings = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
    const savedTurnovers = localStorage.getItem(STORAGE_KEYS.TURNOVERS);
    const savedExpenses = localStorage.getItem(STORAGE_KEYS.EXPENSES);
    const savedContacts = localStorage.getItem(STORAGE_KEYS.CONTACTS);
    const savedPromo = localStorage.getItem(STORAGE_KEYS.PROMO_MEDIA);
    const savedSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);

    if (savedProps) appState.properties = JSON.parse(savedProps);
    if (savedBookings) {
      appState.bookings = JSON.parse(savedBookings);
      migrateBookingTenantModel();
    }
    if (savedTurnovers) appState.turnovers = JSON.parse(savedTurnovers);
    if (savedExpenses) appState.expenses = JSON.parse(savedExpenses);
    
    if (savedContacts) {
      try {
        appState.contacts = JSON.parse(savedContacts);
      } catch (e) {
        appState.contacts = [...DEFAULT_CONTACTS];
      }
    } else {
      appState.contacts = [...DEFAULT_CONTACTS];
    }

    // De-clutter Settings Contacts: prune auto-injected c-t- temporary records from previous versions
    if (Array.isArray(appState.contacts)) {
      appState.contacts = appState.contacts.filter(c => !c.id || !c.id.startsWith('c-t-'));
    }

    if (savedPromo) {
      try {
        appState.promotionalMedia = JSON.parse(savedPromo);
      } catch (e) {
        appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];
      }
    } else {
      appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];
    }

    if (savedSettings) {
      try {
        appState.settings = { ...DEFAULT_SETTINGS, ...JSON.parse(savedSettings) };
      } catch (e) {
        appState.settings = { ...DEFAULT_SETTINGS };
      }
    }
    // Migration: Purge legacy fake sample data so it never leaks to live documents
    if (appState.settings) {
      if (appState.settings.bankAccNum === '5123 4567 8901') appState.settings.bankAccNum = '';
      if (appState.settings.bankAccHolder === 'Homestay Host') appState.settings.bankAccHolder = '';
      if (appState.settings.duitNow === '0123456789') appState.settings.duitNow = '';
      if (appState.settings.bankBranch === 'Changlun / Kedah' || appState.settings.bankBranch === 'Changlun / Cawangan Utama') appState.settings.bankBranch = '';
      if (appState.settings.businessSsm === '20260100988-X') appState.settings.businessSsm = '';
      if (appState.settings.businessEmail === 'host@myhomestay.com') appState.settings.businessEmail = '';
      if (appState.settings.ownerPhone === '+60123456789') appState.settings.ownerPhone = '';
      if (appState.settings.sellerPhone) delete appState.settings.sellerPhone;
      if (appState.settings.sstRate === undefined || appState.settings.sstRate === null) appState.settings.sstRate = 0;
    }

    const savedQuoCounter = localStorage.getItem('staymanager_quotation_counter');
    appState.quotationCounter = savedQuoCounter ? parseInt(savedQuoCounter, 10) : 1001;
    if (isNaN(appState.quotationCounter) || appState.quotationCounter < 1) appState.quotationCounter = 1001;

    const savedInvCounter = localStorage.getItem('staymanager_invoice_counter');
    appState.invoiceCounter = savedInvCounter ? parseInt(savedInvCounter, 10) : 1001;
    if (isNaN(appState.invoiceCounter) || appState.invoiceCounter < 1) appState.invoiceCounter = 1001;

    const savedDepCounter = localStorage.getItem('staymanager_deposit_receipt_counter');
    appState.depositReceiptCounter = savedDepCounter ? parseInt(savedDepCounter, 10) : 1001;
    if (isNaN(appState.depositReceiptCounter) || appState.depositReceiptCounter < 1) appState.depositReceiptCounter = 1001;

    const savedRecCounter = localStorage.getItem('staymanager_payment_receipt_counter');
    appState.paymentReceiptCounter = savedRecCounter ? parseInt(savedRecCounter, 10) : 1001;
    if (isNaN(appState.paymentReceiptCounter) || appState.paymentReceiptCounter < 1) appState.paymentReceiptCounter = 1001;

    const savedRefCounter = localStorage.getItem('staymanager_refund_counter');
    appState.refundCounter = savedRefCounter ? parseInt(savedRefCounter, 10) : 1001;
    if (isNaN(appState.refundCounter) || appState.refundCounter < 1) appState.refundCounter = 1001;
    
    // Safety fallback: Check pre-update auto-backup if property/booking data is empty
    const autoBackupStr = localStorage.getItem('staymanager_auto_backup');
    if (autoBackupStr) {
      try {
        const autoBackup = JSON.parse(autoBackupStr);
        if (autoBackup) {
          // Restore properties and records if empty
          if ((!appState.properties || appState.properties.length === 0) && Array.isArray(autoBackup.properties) && autoBackup.properties.length > 0) {
            appState.properties = autoBackup.properties;
            if (Array.isArray(autoBackup.bookings)) appState.bookings = autoBackup.bookings;
            if (Array.isArray(autoBackup.turnovers)) appState.turnovers = autoBackup.turnovers;
            if (Array.isArray(autoBackup.expenses)) appState.expenses = autoBackup.expenses;
            if (Array.isArray(autoBackup.contacts)) appState.contacts = autoBackup.contacts;
            if (Array.isArray(autoBackup.promotionalMedia)) appState.promotionalMedia = autoBackup.promotionalMedia;
            if (autoBackup.settings) appState.settings = { ...DEFAULT_SETTINGS, ...autoBackup.settings };
          }
        }
      } catch (bErr) {
        console.warn('Auto backup check notice:', bErr);
      }
    }

    // Run schema migrations and auto-safety snapshot
    runDataMigrations();
    migrateExistingBookingDocuments();
    syncDocumentCounters();
  } catch (e) {
    console.error('Error loading localStorage:', e);
  }
}

function migrateBookingTenantModel() {
  if (!Array.isArray(appState.bookings)) return;
  appState.bookings.forEach(b => {
    if (!b.tenantType) {
      b.tenantType = (b.companyRegNo || b.companyName) ? 'company' : 'individual';
    }
    if (b.tenantType === 'company') {
      b.companyName = b.companyName || b.guestName || '';
      b.companyRegNo = b.companyRegNo || b.guestNric || '';
      b.companyAddress = b.companyAddress || b.guestAddress || '';
      if (!b.guestName && b.companyName) b.guestName = b.companyName;
      if (!b.contactPhone && b.guestPhone) b.contactPhone = b.guestPhone;
      if (!b.contactEmail && b.guestEmail) b.contactEmail = b.guestEmail;
    } else {
      b.guestName = b.guestName || b.companyName || '';
      b.guestNric = b.guestNric || b.companyRegNo || '';
      b.guestAddress = b.guestAddress || b.companyAddress || '';
    }
    if (b.contactPerson === undefined) b.contactPerson = '';
    if (b.contactDesignation === undefined) b.contactDesignation = '';
    if (b.contactPhone === undefined) b.contactPhone = b.guestPhone || '';
    if (b.contactEmail === undefined) b.contactEmail = b.guestEmail || '';
    if (b.contactIc === undefined) b.contactIc = '';
    if (b.signatoryName === undefined) b.signatoryName = (b.tenantType === 'company' ? (b.contactPerson || '') : '');
    if (b.signatoryDesignation === undefined) b.signatoryDesignation = (b.tenantType === 'company' ? (b.contactDesignation || '') : '');
    if (b.signatoryIc === undefined) b.signatoryIc = (b.tenantType === 'company' ? (b.contactIc || '') : '');
    if (b.signatorySameAsContact === undefined) {
      b.signatorySameAsContact = (b.tenantType === 'company' && !!b.signatoryName && b.signatoryName === b.contactPerson);
    }
    if (b.emergencyContactName === undefined) b.emergencyContactName = '';
    if (b.emergencyContactPhone === undefined) b.emergencyContactPhone = '';
    if (b.emergencyContactRelation === undefined) b.emergencyContactRelation = '';
    if (b.occupantsCount === undefined || b.occupantsCount === null) {
      b.occupantsCount = b.guestCount || 2;
    }
    if (b.occupantsNotes === undefined) b.occupantsNotes = '';
  });
}

// ==========================================================================
// 2B. DOCUMENT NUMBERING, MIGRATION & AUDIT LIFECYCLE (Phase B)
// ==========================================================================

function migrateExistingBookingDocuments() {
  if (!Array.isArray(appState.bookings)) return;

  appState.bookings.forEach(b => {
    b.documents = Array.isArray(b.documents) ? b.documents : [];

    const isMonthly = b.rentalType === 'monthly';
    const dateStr = b.createdAt || b.checkIn || formatLocalDate(new Date());
    const year = new Date(dateStr.includes('T') ? dateStr : dateStr + 'T00:00:00').getFullYear() || new Date().getFullYear();
    const idShort = (b.id || '').replace(/\D/g, '').slice(-4) || '1088';

    // 1. Quotation: freeze existing quotationNo or calculate what was shown
    if (!b.quotationNo && b.status === 'quotation') {
      b.quotationNo = `QT-${year}-${idShort}`;
    }
    if (b.quotationNo) {
      const hasQuoDoc = b.documents.some(d => d.docType === 'quotation');
      if (!hasQuoDoc) {
        b.documents.push({
          id: `doc-quo-${b.id}`,
          docType: 'quotation',
          docNo: b.quotationNo,
          baseDocNo: b.quotationNo.replace(/\s+Rev\s+\d+$/i, ''),
          revision: 0,
          status: 'issued',
          date: (b.createdAt || b.checkIn || formatLocalDate(new Date())).split('T')[0],
          amount: Number(b.totalAmount || 0),
          issuedAt: b.createdAt || new Date().toISOString(),
          replacesDocNo: null,
          replacedByDocNo: null,
          hasBeenPrintedOrDownloaded: true
        });
      }
    }

    // 2. Invoice: freeze existing invoice number
    if (!b.invoiceNo) {
      b.invoiceNo = isMonthly ? `INV-M-${year}-${idShort}` : `INV-${year}-${idShort}`;
    }
    const hasInvDoc = b.documents.some(d => d.docType === 'invoice' && !d.monthIndex);
    if (!hasInvDoc && b.status !== 'quotation') {
      b.documents.push({
        id: `doc-inv-${b.id}`,
        docType: 'invoice',
        docNo: b.invoiceNo,
        baseDocNo: b.invoiceNo,
        revision: 0,
        status: 'issued',
        date: (b.checkIn || b.createdAt || formatLocalDate(new Date())).split('T')[0],
        amount: Number(b.totalAmount || 0),
        issuedAt: b.createdAt || new Date().toISOString(),
        replacesDocNo: null,
        replacedByDocNo: null,
        hasBeenPrintedOrDownloaded: true
      });
    }

    // 3. Deposit Receipt: freeze existing deposit receipt number
    if (b.depositPaid > 0 || (b.depositAmount && b.depositAmount > 0)) {
      if (!b.depositReceiptNo) {
        b.depositReceiptNo = isMonthly ? `REC-BOOK-M-${year}-${idShort}` : `REC-DEP-${year}-${idShort}`;
      }
      const hasDepDoc = b.documents.some(d => d.docType === 'deposit_receipt');
      if (!hasDepDoc) {
        b.documents.push({
          id: `doc-dep-${b.id}`,
          docType: 'deposit_receipt',
          docNo: b.depositReceiptNo,
          baseDocNo: b.depositReceiptNo,
          revision: 0,
          status: 'issued',
          date: (b.createdAt || b.checkIn || formatLocalDate(new Date())).split('T')[0],
          amount: Number(b.depositPaid || b.depositAmount || 0),
          issuedAt: b.createdAt || new Date().toISOString(),
          replacesDocNo: null,
          replacedByDocNo: null,
          hasBeenPrintedOrDownloaded: true
        });
      }
    }

    // 4. Payment Receipt (Full / Balance Settlement)
    if (b.balance <= 0 && b.totalAmount > 0 && (b.status === 'confirmed' || b.status === 'checked-in' || b.status === 'checked-out')) {
      if (!b.paymentReceiptNo) {
        b.paymentReceiptNo = isMonthly ? `REC-M-${year}-${idShort}` : `REC-${year}-${idShort}`;
      }
      const hasRecDoc = b.documents.some(d => d.docType === 'receipt' && !d.monthIndex);
      if (!hasRecDoc) {
        b.documents.push({
          id: `doc-rec-${b.id}`,
          docType: 'receipt',
          docNo: b.paymentReceiptNo,
          baseDocNo: b.paymentReceiptNo,
          revision: 0,
          status: 'issued',
          date: (b.checkIn || formatLocalDate(new Date())).split('T')[0],
          amount: Number(b.totalAmount || 0),
          issuedAt: b.createdAt || new Date().toISOString(),
          replacesDocNo: null,
          replacedByDocNo: null,
          hasBeenPrintedOrDownloaded: true
        });
      }
    }

    // 5. Individual Payments in booking.payments (Guarantee uniqueness per payment)
    if (Array.isArray(b.payments)) {
      const usedReceiptNos = new Set();
      b.payments.forEach((p, idx) => {
        if (!p.receiptNo) {
          if (p.type === 'deposit') {
            p.receiptNo = b.depositReceiptNo || (isMonthly ? `REC-BOOK-M-${year}-${idShort}` : `REC-DEP-${year}-${idShort}`);
          } else if (p.type === 'monthly_rent') {
            p.receiptNo = `REC-M${p.monthIndex || 1}-${year}-${idShort}`;
          } else {
            p.receiptNo = b.paymentReceiptNo || (isMonthly ? `REC-M-${year}-${idShort}` : `REC-${year}-${idShort}`);
          }
        }
        // Strict invariant: Two payments on the same booking must NEVER share a receipt number
        if (usedReceiptNos.has(p.receiptNo)) {
          p.receiptNo = `${p.receiptNo}-${idx + 1}`;
        }
        usedReceiptNos.add(p.receiptNo);
      });
    }

    // 6. Monthly Invoices
    if (isMonthly && Array.isArray(b.monthlyInvoices)) {
      b.monthlyInvoices.forEach(inv => {
        if (!inv.invoiceNo) {
          inv.invoiceNo = `INV-M${inv.monthIndex}-${year}-${idShort}`;
        }
        if (inv.status === 'paid' && !inv.receiptNo) {
          inv.receiptNo = `REC-M${inv.monthIndex}-${year}-${idShort}`;
        }
        // Month 1 rental is settled via Move-In Package; invoice documents begin from Month 2
        if (inv.monthIndex >= 2) {
          const hasMInvDoc = b.documents.some(d => d.docType === 'invoice' && d.monthIndex === inv.monthIndex);
          if (!hasMInvDoc) {
            b.documents.push({
              id: `doc-inv-m${inv.monthIndex}-${b.id}`,
              docType: 'invoice',
              monthIndex: inv.monthIndex,
              docNo: inv.invoiceNo,
              baseDocNo: inv.invoiceNo,
              revision: 0,
              status: 'issued',
              date: inv.periodStart,
              amount: Number(inv.totalAmount || inv.rentAmount || 0),
              issuedAt: inv.periodStart,
              replacesDocNo: null,
              replacedByDocNo: null,
              hasBeenPrintedOrDownloaded: true
            });
          }
        }
        if (inv.status === 'paid') {
          const hasMRecDoc = b.documents.some(d => d.docType === 'receipt' && d.monthIndex === inv.monthIndex);
          if (!hasMRecDoc) {
            b.documents.push({
              id: `doc-rec-m${inv.monthIndex}-${b.id}`,
              docType: 'receipt',
              monthIndex: inv.monthIndex,
              docNo: inv.receiptNo,
              baseDocNo: inv.receiptNo,
              revision: 0,
              status: 'issued',
              date: inv.paidAt ? inv.paidAt.split('T')[0] : inv.periodStart,
              amount: Number(inv.totalAmount || inv.rentAmount || 0),
              issuedAt: inv.paidAt || inv.periodStart,
              replacesDocNo: null,
              replacedByDocNo: null,
              hasBeenPrintedOrDownloaded: true
            });
          }
        }
      });
    }

    // 7. Refund record
    const ref = b.refundDetails || b.depositRefund;
    if (ref) {
      if (!ref.refundNo) {
        ref.refundNo = `REF-${year}-${idShort}`;
      }
      const hasRefDoc = b.documents.some(d => d.docType === 'refund');
      if (!hasRefDoc) {
        b.documents.push({
          id: `doc-ref-${b.id}`,
          docType: 'refund',
          docNo: ref.refundNo,
          baseDocNo: ref.refundNo,
          revision: 0,
          status: 'issued',
          date: ref.refundedAt ? ref.refundedAt.split('T')[0] : formatLocalDate(new Date()),
          amount: Number(ref.netRefund || 0),
          issuedAt: ref.refundedAt || new Date().toISOString(),
          replacesDocNo: null,
          replacedByDocNo: null,
          hasBeenPrintedOrDownloaded: true
        });
      }
    }
  });
}

function syncDocumentCounters() {
  let maxQuo = appState.quotationCounter || 1000;
  let maxInv = appState.invoiceCounter || 1000;
  let maxDep = appState.depositReceiptCounter || 1000;
  let maxRec = appState.paymentReceiptCounter || 1000;
  let maxRef = appState.refundCounter || 1000;

  function extractTrailingNumber(str) {
    if (!str || typeof str !== 'string') return 0;
    const clean = str.split(' ')[0]; // ignore Rev suffixes
    const match = clean.match(/-(\d+)$/);
    return match ? parseInt(match[1], 10) : 0;
  }

  if (Array.isArray(appState.bookings)) {
    appState.bookings.forEach(b => {
      if (b.quotationNo) {
        const n = extractTrailingNumber(b.quotationNo);
        if (n > maxQuo) maxQuo = n;
      }
      if (b.invoiceNo) {
        const n = extractTrailingNumber(b.invoiceNo);
        if (n > maxInv) maxInv = n;
      }
      if (b.depositReceiptNo) {
        const n = extractTrailingNumber(b.depositReceiptNo);
        if (n > maxDep) maxDep = n;
      }
      if (b.paymentReceiptNo) {
        const n = extractTrailingNumber(b.paymentReceiptNo);
        if (n > maxRec) maxRec = n;
      }
      if (b.refundDetails && b.refundDetails.refundNo) {
        const n = extractTrailingNumber(b.refundDetails.refundNo);
        if (n > maxRef) maxRef = n;
      }

      if (Array.isArray(b.payments)) {
        b.payments.forEach(p => {
          if (p.receiptNo) {
            const n = extractTrailingNumber(p.receiptNo);
            if (p.type === 'deposit') {
              if (n > maxDep) maxDep = n;
            } else {
              if (n > maxRec) maxRec = n;
            }
          }
        });
      }

      if (Array.isArray(b.monthlyInvoices)) {
        b.monthlyInvoices.forEach(inv => {
          if (inv.invoiceNo) {
            const n = extractTrailingNumber(inv.invoiceNo);
            if (n > maxInv) maxInv = n;
          }
          if (inv.receiptNo) {
            const n = extractTrailingNumber(inv.receiptNo);
            if (n > maxRec) maxRec = n;
          }
        });
      }

      if (Array.isArray(b.documents)) {
        b.documents.forEach(d => {
          const n = extractTrailingNumber(d.docNo || d.baseDocNo);
          if (d.docType === 'quotation' && n > maxQuo) maxQuo = n;
          if (d.docType === 'invoice' && n > maxInv) maxInv = n;
          if (d.docType === 'deposit_receipt' && n > maxDep) maxDep = n;
          if (d.docType === 'receipt' && n > maxRec) maxRec = n;
          if (d.docType === 'refund' && n > maxRef) maxRef = n;
        });
      }
    });
  }

  appState.quotationCounter = Math.max(1001, maxQuo);
  appState.invoiceCounter = Math.max(1001, maxInv);
  appState.depositReceiptCounter = Math.max(1001, maxDep);
  appState.paymentReceiptCounter = Math.max(1001, maxRec);
  appState.refundCounter = Math.max(1001, maxRef);
}

function getOrAllocateDocNo(booking, docType, monthIndex = null, isIssuing = false, paymentId = null) {
  if (!booking) return { docNo: 'DRAFT', status: 'draft', isDraft: true, isReprint: false, docRecord: null };
  booking.documents = Array.isArray(booking.documents) ? booking.documents : [];

  const isMonthly = booking.rentalType === 'monthly';
  const year = new Date().getFullYear();
  const payments = Array.isArray(booking.payments) ? booking.payments : [];

  // Identify target payment if this is a receipt or deposit receipt for non-monthly booking
  let targetPayment = null;
  if (!isMonthly && (docType === 'receipt' || docType === 'deposit_receipt')) {
    if (paymentId) {
      targetPayment = payments.find(p => p.id === paymentId) || null;
    }
    if (!targetPayment && payments.length > 0) {
      if (docType === 'deposit_receipt') {
        targetPayment = payments.find(p => p.type === 'deposit') || payments[0];
      } else {
        targetPayment = payments[payments.length - 1];
      }
    }
  }

  // Find existing document
  let existingDoc = null;
  if (docType === 'quotation') {
    const quotations = booking.documents.filter(d => d.docType === 'quotation');
    if (quotations.length > 0) {
      existingDoc = quotations.find(d => d.status !== 'superseded') || quotations[quotations.length - 1];
    } else if (booking.quotationNo) {
      existingDoc = { docNo: booking.quotationNo, status: 'issued', baseDocNo: booking.quotationNo, revision: 0 };
    }
  } else if (docType === 'invoice') {
    if (isMonthly && monthIndex) {
      existingDoc = booking.documents.find(d => d.docType === 'invoice' && d.monthIndex === monthIndex && d.status !== 'void');
    } else {
      existingDoc = booking.documents.find(d => d.docType === 'invoice' && !d.monthIndex && d.status !== 'void');
      if (!existingDoc && booking.invoiceNo) {
        existingDoc = { docNo: booking.invoiceNo, status: 'issued', baseDocNo: booking.invoiceNo, revision: 0 };
      }
    }
  } else if (targetPayment) {
    // Look for document linked to this specific payment
    existingDoc = booking.documents.find(d => 
      ((d.paymentId && d.paymentId === targetPayment.id) || 
       (targetPayment.receiptNo && d.docNo === targetPayment.receiptNo)) && 
      d.status !== 'void'
    );
    if (!existingDoc) {
      existingDoc = booking.documents.find(d => 
        (d.paymentId && d.paymentId === targetPayment.id) || 
        (targetPayment.receiptNo && d.docNo === targetPayment.receiptNo)
      );
    }
    if (!existingDoc && targetPayment.receiptNo) {
      existingDoc = { 
        docNo: targetPayment.receiptNo, 
        status: 'issued', 
        baseDocNo: targetPayment.receiptNo, 
        revision: 0, 
        paymentId: targetPayment.id,
        amount: targetPayment.amount,
        date: targetPayment.date
      };
    }
  } else if (docType === 'deposit_receipt') {
    existingDoc = booking.documents.find(d => d.docType === 'deposit_receipt' && d.status !== 'void');
    if (!existingDoc && booking.depositReceiptNo) {
      existingDoc = { docNo: booking.depositReceiptNo, status: 'issued', baseDocNo: booking.depositReceiptNo, revision: 0 };
    }
  } else if (docType === 'receipt') {
    if (isMonthly && monthIndex) {
      existingDoc = booking.documents.find(d => d.docType === 'receipt' && d.monthIndex === monthIndex && d.status !== 'void');
    } else {
      existingDoc = booking.documents.find(d => d.docType === 'receipt' && !d.monthIndex && d.status !== 'void');
      if (!existingDoc && booking.paymentReceiptNo) {
        existingDoc = { docNo: booking.paymentReceiptNo, status: 'issued', baseDocNo: booking.paymentReceiptNo, revision: 0 };
      }
    }
  } else if (docType === 'refund') {
    existingDoc = booking.documents.find(d => d.docType === 'refund' && d.status !== 'void');
  }

  // If already exists and is issued or void or superseded
  if (existingDoc && existingDoc.status !== 'draft') {
    return {
      docNo: existingDoc.docNo,
      status: existingDoc.status,
      isDraft: false,
      isReprint: true,
      docRecord: existingDoc
    };
  }

  // If not issuing, show prospective draft number WITHOUT consuming counter
  if (!isIssuing) {
    let nextNum = 1001;
    let prefix = 'DOC';
    if (docType === 'quotation') {
      nextNum = (appState.quotationCounter || 1000) + 1;
      prefix = 'QT';
    } else if (docType === 'invoice') {
      nextNum = (appState.invoiceCounter || 1000) + 1;
      prefix = isMonthly ? (monthIndex ? `INV-M${monthIndex}` : 'INV-M') : 'INV';
    } else if (docType === 'deposit_receipt') {
      nextNum = (appState.depositReceiptCounter || 1000) + 1;
      prefix = isMonthly ? 'RCPT-BOOK-M' : 'RCPT-DEP';
    } else if (docType === 'receipt') {
      nextNum = (appState.paymentReceiptCounter || 1000) + 1;
      prefix = isMonthly ? (monthIndex ? `RCPT-M${monthIndex}` : 'RCPT-M') : 'RCPT';
    } else if (docType === 'refund') {
      nextNum = (appState.refundCounter || 1000) + 1;
      prefix = 'REF';
    }
    const prospective = `${prefix}-${year}-${String(nextNum).padStart(4, '0')} (Draf)`;
    return {
      docNo: prospective,
      status: 'draft',
      isDraft: true,
      isReprint: false,
      docRecord: null
    };
  }

  // If isIssuing is TRUE: consume counter permanently!
  let allocatedNo = '';
  let counterVal = 1001;
  if (docType === 'quotation') {
    appState.quotationCounter = (appState.quotationCounter || 1000) + 1;
    counterVal = appState.quotationCounter;
    allocatedNo = `QT-${year}-${String(counterVal).padStart(4, '0')}`;
    booking.quotationNo = allocatedNo;
  } else if (docType === 'invoice') {
    appState.invoiceCounter = (appState.invoiceCounter || 1000) + 1;
    counterVal = appState.invoiceCounter;
    const prefix = isMonthly ? (monthIndex ? `INV-M${monthIndex}` : 'INV-M') : 'INV';
    allocatedNo = `${prefix}-${year}-${String(counterVal).padStart(4, '0')}`;
    if (!monthIndex) booking.invoiceNo = allocatedNo;
  } else if (docType === 'deposit_receipt') {
    appState.depositReceiptCounter = (appState.depositReceiptCounter || 1000) + 1;
    counterVal = appState.depositReceiptCounter;
    const prefix = isMonthly ? 'RCPT-BOOK-M' : 'RCPT-DEP';
    allocatedNo = `${prefix}-${year}-${String(counterVal).padStart(4, '0')}`;
    if (targetPayment) {
      targetPayment.receiptNo = allocatedNo;
    }
    booking.depositReceiptNo = allocatedNo;
  } else if (docType === 'receipt') {
    appState.paymentReceiptCounter = (appState.paymentReceiptCounter || 1000) + 1;
    counterVal = appState.paymentReceiptCounter;
    const prefix = isMonthly ? (monthIndex ? `RCPT-M${monthIndex}` : 'RCPT-M') : 'RCPT';
    allocatedNo = `${prefix}-${year}-${String(counterVal).padStart(4, '0')}`;
    if (targetPayment) {
      targetPayment.receiptNo = allocatedNo;
    }
    if (!monthIndex && (!targetPayment || booking.balance <= targetPayment.amount)) {
      booking.paymentReceiptNo = allocatedNo;
    }
  } else if (docType === 'refund') {
    appState.refundCounter = (appState.refundCounter || 1000) + 1;
    counterVal = appState.refundCounter;
    allocatedNo = `REF-${year}-${String(counterVal).padStart(4, '0')}`;
  }

  const newDocRecord = {
    id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    paymentId: targetPayment ? targetPayment.id : null,
    docType,
    monthIndex,
    docNo: allocatedNo,
    baseDocNo: allocatedNo,
    revision: 0,
    status: 'issued',
    date: targetPayment ? (targetPayment.date || formatLocalDate(new Date())) : formatLocalDate(new Date()),
    amount: targetPayment ? Number(targetPayment.amount || 0) : Number(booking.totalAmount || 0),
    issuedAt: targetPayment ? (targetPayment.dateTime || new Date().toISOString()) : new Date().toISOString(),
    replacesDocNo: null,
    replacedByDocNo: null,
    hasBeenPrintedOrDownloaded: false
  };

  booking.documents.push(newDocRecord);
  saveToStorage();

  return {
    docNo: allocatedNo,
    status: 'issued',
    isDraft: false,
    isReprint: false,
    docRecord: newDocRecord
  };
}

function handleCreateQuotationRevision(booking) {
  if (!booking) return;
  booking.documents = Array.isArray(booking.documents) ? booking.documents : [];

  const existingQuos = booking.documents.filter(d => d.docType === 'quotation');
  const activeQuo = existingQuos.find(d => d.status !== 'superseded') || existingQuos[existingQuos.length - 1];

  if (!activeQuo) {
    getOrAllocateDocNo(booking, 'quotation', null, true);
    updatePdfDocView();
    return;
  }

  activeQuo.status = 'superseded';

  const nextRev = (activeQuo.revision || 0) + 1;
  const baseNo = activeQuo.baseDocNo || activeQuo.docNo.replace(/\s+Rev\s+\d+$/i, '');
  const newDocNo = `${baseNo} Rev ${nextRev}`;

  activeQuo.replacedByDocNo = newDocNo;

  const newRevDoc = {
    id: `doc-quo-${Date.now()}`,
    docType: 'quotation',
    monthIndex: null,
    docNo: newDocNo,
    baseDocNo: baseNo,
    revision: nextRev,
    status: 'issued',
    date: formatLocalDate(new Date()),
    amount: Number(booking.totalAmount || 0),
    issuedAt: new Date().toISOString(),
    replacesDocNo: activeQuo.docNo,
    replacedByDocNo: null,
    hasBeenPrintedOrDownloaded: false
  };

  booking.documents.push(newRevDoc);
  booking.quotationNo = newDocNo;

  saveToStorage();
  updatePdfDocView();

  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? `Pindaan sebut harga rasmi ${newDocNo} berjaya dijana!` : `Quotation revision ${newDocNo} created successfully!`);
}

function openVoidDocModal(booking) {
  if (!booking) return;
  const docType = appState.activePdfDocType || 'invoice';
  const monthIdx = appState.activePdfMonthIndex;
  booking.documents = Array.isArray(booking.documents) ? booking.documents : [];

  let targetDoc = null;
  let targetPayment = null;

  if (!isMonthlyBooking(booking) && (docType === 'receipt' || docType === 'deposit_receipt')) {
    const payments = Array.isArray(booking.payments) ? booking.payments : [];
    targetPayment = payments.find(p => p.id === appState.activePdfPaymentId) || payments[payments.length - 1];
    if (targetPayment) {
      targetDoc = booking.documents.find(d => 
        (d.paymentId && d.paymentId === targetPayment.id) || 
        (d.docNo && targetPayment.receiptNo && d.docNo === targetPayment.receiptNo)
      );
      if (!targetDoc && targetPayment.receiptNo) {
        targetDoc = booking.documents.find(d => d.docNo === targetPayment.receiptNo);
      }
    }
  }

  if (!targetDoc) {
    if (isMonthlyBooking(booking) && monthIdx) {
      targetDoc = booking.documents.find(d => d.docType === docType && d.monthIndex === monthIdx && d.status !== 'void');
    } else {
      targetDoc = booking.documents.find(d => d.docType === docType && !d.monthIndex && d.status !== 'void');
    }
  }

  if (!targetDoc) {
    showToast(appState.settings.language === 'bm' ? 'Dokumen asal belum diterbitkan untuk dibatalkan.' : 'No issued document found to void.');
    return;
  }

  appState.pendingVoidBooking = booking;
  appState.pendingVoidDoc = targetDoc;
  appState.pendingVoidPayment = targetPayment;

  const targetNoEl = document.getElementById('voidDocTargetNo');
  if (targetNoEl) targetNoEl.textContent = targetDoc.docNo;

  const targetAmtEl = document.getElementById('voidDocTargetAmount');
  if (targetAmtEl) {
    const displayAmt = targetPayment ? targetPayment.amount : (targetDoc.amount || booking.totalAmount || 0);
    targetAmtEl.textContent = formatCurrency(displayAmt);
  }

  const modal = document.getElementById('voidDocModal');
  if (modal) modal.classList.add('active');
}

function closeVoidDocModal() {
  const modal = document.getElementById('voidDocModal');
  if (modal) modal.classList.remove('active');
  appState.pendingVoidBooking = null;
  appState.pendingVoidDoc = null;
  appState.pendingVoidPayment = null;
}

function handleConfirmVoidReissue() {
  const booking = appState.pendingVoidBooking;
  const oldDoc = appState.pendingVoidDoc;
  const targetPayment = appState.pendingVoidPayment;
  if (!booking || !oldDoc) return;

  const reasonSelect = document.getElementById('voidDocReasonSelect');
  const reasonInput = document.getElementById('voidDocReasonInput');
  const selVal = reasonSelect ? reasonSelect.value : 'Kesilapan Amaun';
  const customVal = reasonInput ? reasonInput.value.trim() : '';
  const voidReason = customVal ? `${selVal}: ${customVal}` : selVal;

  oldDoc.status = 'void';
  oldDoc.voidedAt = new Date().toISOString();
  oldDoc.voidReason = voidReason;

  const year = new Date().getFullYear();
  const isMonthly = booking.rentalType === 'monthly';
  let newDocNo = '';

  if (oldDoc.docType === 'invoice') {
    appState.invoiceCounter = (appState.invoiceCounter || 1000) + 1;
    const prefix = isMonthly ? (oldDoc.monthIndex ? `INV-M${oldDoc.monthIndex}` : 'INV-M') : 'INV';
    newDocNo = `${prefix}-${year}-${String(appState.invoiceCounter).padStart(4, '0')}`;
    if (!oldDoc.monthIndex) booking.invoiceNo = newDocNo;
  } else if (oldDoc.docType === 'deposit_receipt') {
    appState.depositReceiptCounter = (appState.depositReceiptCounter || 1000) + 1;
    const prefix = isMonthly ? 'RCPT-BOOK-M' : 'RCPT-DEP';
    newDocNo = `${prefix}-${year}-${String(appState.depositReceiptCounter).padStart(4, '0')}`;
    if (!targetPayment) booking.depositReceiptNo = newDocNo;
  } else if (oldDoc.docType === 'receipt') {
    appState.paymentReceiptCounter = (appState.paymentReceiptCounter || 1000) + 1;
    const prefix = isMonthly ? (oldDoc.monthIndex ? `RCPT-M${oldDoc.monthIndex}` : 'RCPT-M') : 'RCPT';
    newDocNo = `${prefix}-${year}-${String(appState.paymentReceiptCounter).padStart(4, '0')}`;
    if (!oldDoc.monthIndex && !targetPayment) booking.paymentReceiptNo = newDocNo;
  } else if (oldDoc.docType === 'refund') {
    appState.refundCounter = (appState.refundCounter || 1000) + 1;
    newDocNo = `REF-${year}-${String(appState.refundCounter).padStart(4, '0')}`;
  }

  // If this belongs to a specific payment, update THAT payment's receiptNo
  if (targetPayment) {
    targetPayment.receiptNo = newDocNo;
  } else {
    const p = (booking.payments || []).find(x => x.receiptNo === oldDoc.docNo || (oldDoc.paymentId && x.id === oldDoc.paymentId));
    if (p) p.receiptNo = newDocNo;
  }

  oldDoc.replacedByDocNo = newDocNo;

  const newDoc = {
    id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    paymentId: targetPayment ? targetPayment.id : (oldDoc.paymentId || null),
    docType: oldDoc.docType,
    monthIndex: oldDoc.monthIndex,
    docNo: newDocNo,
    baseDocNo: newDocNo,
    revision: 0,
    status: 'issued',
    date: formatLocalDate(new Date()),
    amount: Number(targetPayment ? targetPayment.amount : (oldDoc.amount || booking.totalAmount || 0)),
    issuedAt: new Date().toISOString(),
    replacesDocNo: oldDoc.docNo,
    replacedByDocNo: null,
    hasBeenPrintedOrDownloaded: false
  };

  booking.documents.push(newDoc);
  saveToStorage();
  closeVoidDocModal();
  updatePdfDocView();

  const isBM = appState.settings.language === 'bm';
  showToast(isBM 
    ? `Dokumen ${oldDoc.docNo} telah dibatalkan (VOID). Nombor baharu ${newDocNo} telah diterbitkan!` 
    : `Document ${oldDoc.docNo} marked VOID. Reissued under new number ${newDocNo}!`);
}

function isMonthlyBooking(b) {
  return b && b.rentalType === 'monthly';
}

function renderDocumentHistoryTab(booking) {
  if (!booking) return;
  migrateExistingBookingDocuments();

  const metaEl = document.getElementById('pdfHistoryBookingMeta');
  const prop = getPropertyById(booking.propertyId);
  if (metaEl) {
    metaEl.textContent = `${booking.guestName} (${booking.guestPhone || '-'}) • ${prop ? prop.name : 'Homestay'}`;
  }

  const badgeEl = document.getElementById('pdfHistoryDocCountBadge');
  const docs = Array.isArray(booking.documents) ? booking.documents : [];
  if (badgeEl) {
    badgeEl.textContent = `${docs.length} Dokumen`;
  }

  const tbody = document.getElementById('pdfHistoryTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (docs.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" style="padding:24px; text-align:center; color:#94a3b8;">
          <i class="fa-solid fa-folder-open" style="font-size:24px; display:block; margin-bottom:6px;"></i>
          Tiada rekod sejarah dokumen bagi tempahan ini lagi.
        </td>
      </tr>
    `;
    return;
  }

  const isBM = (appState.activePdfLang || appState.settings.language) === 'bm';

  docs.slice().reverse().forEach(d => {
    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid #f1f5f9';

    let typeLabel = '';
    let typeColor = '#0284c7';
    if (d.docType === 'quotation') {
      typeLabel = isBM ? 'Sebut Harga' : 'Quotation';
      typeColor = '#ea580c';
    } else if (d.docType === 'invoice') {
      typeLabel = isBM ? (d.monthIndex ? `Invois Bulan ${d.monthIndex}` : 'Invois Rasmi') : (d.monthIndex ? `Month ${d.monthIndex} Invoice` : 'Official Invoice');
      typeColor = '#7c3aed';
    } else if (d.docType === 'deposit_receipt') {
      typeLabel = isBM ? 'Resit Deposit' : 'Deposit Receipt';
      typeColor = '#0284c7';
    } else if (d.docType === 'receipt') {
      typeLabel = isBM ? (d.monthIndex ? `Resit Sewa Bln ${d.monthIndex}` : 'Resit Bayaran Penuh') : (d.monthIndex ? `Month ${d.monthIndex} Receipt` : 'Payment Receipt');
      typeColor = '#059669';
    } else if (d.docType === 'refund') {
      typeLabel = isBM ? 'Penyata Pemulangan' : 'Refund Statement';
      typeColor = '#d97706';
    }

    let statusPill = '';
    if (d.status === 'void') {
      statusPill = `<span style="background:#fee2e2; color:#dc2626; font-size:10px; font-weight:800; padding:2px 8px; border-radius:999px;">BATAL (VOID)</span>`;
    } else if (d.status === 'superseded') {
      statusPill = `<span style="background:#fef3c7; color:#b45309; font-size:10px; font-weight:800; padding:2px 8px; border-radius:999px;">DIGANTIKAN</span>`;
    } else if (d.status === 'draft') {
      statusPill = `<span style="background:#f1f5f9; color:#475569; font-size:10px; font-weight:800; padding:2px 8px; border-radius:999px;">DRAF</span>`;
    } else {
      statusPill = `<span style="background:#dcfce7; color:#166534; font-size:10px; font-weight:800; padding:2px 8px; border-radius:999px;">DITERBITKAN</span>`;
    }

    let refHtml = '-';
    if (d.replacesDocNo) {
      refHtml = `<span style="color:#059669; font-weight:700;">Menggantikan: ${d.replacesDocNo}</span>`;
    } else if (d.replacedByDocNo) {
      refHtml = `<span style="color:#dc2626; font-weight:700;">Digantikan: ${d.replacedByDocNo}</span>`;
    }
    if (d.voidReason) {
      refHtml += `<div style="font-size:10px; color:#64748b; margin-top:2px;">Sebab: ${d.voidReason}</div>`;
    }

    tr.innerHTML = `
      <td style="padding:10px 8px; font-family:monospace; font-weight:800; color:#0f172a;">${d.docNo}</td>
      <td style="padding:10px 8px; font-weight:700; color:${typeColor};">${typeLabel}</td>
      <td style="padding:10px 8px; color:#64748b;">${d.date || '-'}</td>
      <td style="padding:10px 8px; text-align:right; font-weight:800; color:#0f172a;">${formatCurrency(d.amount)}</td>
      <td style="padding:10px 8px; text-align:center;">${statusPill}</td>
      <td style="padding:10px 8px; font-size:11px;">${refHtml}</td>
      <td style="padding:10px 8px; text-align:center;">
        <button type="button" class="btn btn-outline btn-xs btn-view-historical-doc" data-docno="${d.docNo}" data-doctype="${d.docType}" data-month="${d.monthIndex || ''}" style="font-size:11px; padding:3px 8px; font-weight:700;">
          <i class="fa-regular fa-eye"></i> Papar
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  tbody.querySelectorAll('.btn-view-historical-doc').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const docType = e.currentTarget.getAttribute('data-doctype');
      const mIdx = e.currentTarget.getAttribute('data-month');
      appState.activePdfDocType = docType;
      appState.activePdfMonthIndex = mIdx ? parseInt(mIdx) : null;
      updatePdfTypeTabsUI();
      updatePdfDocView();
    });
  });
}

function runDataMigrations() {
  try {
    const savedVersion = localStorage.getItem(STORAGE_KEYS.VERSION) || '1.0.0';
    if (savedVersion !== APP_VERSION) {
      // 1. Pre-update safety snapshot stored locally in localStorage
      // Safeguard: Only record snapshot if current state has data, or if no snapshot exists yet
      const hasCurrentData = (appState.properties && appState.properties.length > 0) || appState.isLicensed;
      if (hasCurrentData || !localStorage.getItem('staymanager_auto_backup')) {
        const autoSnapshot = {
          properties: appState.properties,
          bookings: appState.bookings,
          turnovers: appState.turnovers,
          expenses: appState.expenses,
          contacts: appState.contacts,
          maintenanceTeam: appState.contacts,
          maintenanceTasks: appState.turnovers,
          promotionalMedia: appState.promotionalMedia,
          settings: appState.settings,
          licenseKey: appState.licenseKey,
          isLicensed: appState.isLicensed,
          version: savedVersion,
          backupDate: new Date().toISOString()
        };
        localStorage.setItem('staymanager_auto_backup', JSON.stringify(autoSnapshot));
      }

      // 2. Backward-compatible field safety migrations:
      // Ensure all properties have valid property types and room numbers
      if (Array.isArray(appState.properties)) {
        appState.properties.forEach(p => {
          if (!p.propType) p.propType = 'entire';
          if (p.roomNo === undefined) p.roomNo = '';
        });
      }

      // Ensure all bookings have rental types and tenant particulars & auto-settle balances for confirmed / completed stays
      migrateBookingTenantModel();
      if (Array.isArray(appState.bookings)) {
        appState.bookings.forEach(b => {
          if (!b.rentalType) b.rentalType = 'daily';
          if (b.guestNric === undefined) b.guestNric = '';
          if (b.guestEmail === undefined) b.guestEmail = '';
          if (b.guestAddress === undefined) b.guestAddress = '';
          // If status is Fully Paid (confirmed), In-House, or Checked-Out, ensure balance is 0 and depositPaid equals totalAmount
          if ((b.status === 'confirmed' || b.status === 'checked-in' || b.status === 'checked-out') && (b.balance > 0 || b.depositPaid < b.totalAmount)) {
            b.depositPaid = b.totalAmount;
            b.balance = 0;
          }
        });
      }

      // Ensure contacts array exists
      if (!Array.isArray(appState.contacts) || appState.contacts.length === 0) {
        const savedContacts = localStorage.getItem(STORAGE_KEYS.CONTACTS);
        if (savedContacts) {
          try {
            appState.contacts = JSON.parse(savedContacts);
          } catch(e) {
            appState.contacts = [...DEFAULT_CONTACTS];
          }
        } else {
          appState.contacts = [...DEFAULT_CONTACTS];
        }
      }

      // Ensure promotionalMedia array exists
      if (!Array.isArray(appState.promotionalMedia) || appState.promotionalMedia.length === 0) {
        const savedPromo = localStorage.getItem(STORAGE_KEYS.PROMO_MEDIA);
        if (savedPromo) {
          try {
            appState.promotionalMedia = JSON.parse(savedPromo);
          } catch(e) {
            appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];
          }
        } else {
          appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];
        }
      }

      // Ensure settings have default language
      if (!appState.settings.language) {
        appState.settings.language = 'en';
      }

      // Save updated version
      localStorage.setItem(STORAGE_KEYS.VERSION, APP_VERSION);
      saveToStorage();

      // Show toast if upgrading from a previous version
      if (savedVersion !== '1.0.0' && savedVersion !== APP_VERSION) {
        setTimeout(() => {
          showToast(t('toast_app_updated'));
        }, 1000);
      }
    }
  } catch (err) {
    console.error('Data migration note:', err);
  }
}

function saveToStorage() {
  try {
    localStorage.setItem(STORAGE_KEYS.PROPERTIES, JSON.stringify(appState.properties));
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(appState.bookings));
    localStorage.setItem(STORAGE_KEYS.TURNOVERS, JSON.stringify(appState.turnovers));
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(appState.expenses));
    localStorage.setItem(STORAGE_KEYS.CONTACTS, JSON.stringify(appState.contacts));
    localStorage.setItem(STORAGE_KEYS.PROMO_MEDIA, JSON.stringify(appState.promotionalMedia));
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(appState.settings));
    if (appState.quotationCounter) {
      localStorage.setItem('staymanager_quotation_counter', appState.quotationCounter.toString());
    }
    if (appState.invoiceCounter) {
      localStorage.setItem('staymanager_invoice_counter', appState.invoiceCounter.toString());
    }
    if (appState.depositReceiptCounter) {
      localStorage.setItem('staymanager_deposit_receipt_counter', appState.depositReceiptCounter.toString());
    }
    if (appState.paymentReceiptCounter) {
      localStorage.setItem('staymanager_payment_receipt_counter', appState.paymentReceiptCounter.toString());
    }
    if (appState.refundCounter) {
      localStorage.setItem('staymanager_refund_counter', appState.refundCounter.toString());
    }
  } catch (err) {
    if (err && (err.name === 'QuotaExceededError' || err.code === 22 || err.code === 1014)) {
      showQuotaExceededAlert();
    } else {
      console.error('Storage save error:', err);
    }
  }
}

// ==========================================================================
// 2B. PWA LIVE UPDATE ENGINE & SEAMLESS MIGRATIONS
// ==========================================================================

let swRegistration = null;
let newWorkerWaiting = null;

function initPWAUpdateService() {
  if (!('serviceWorker' in navigator)) return;

  navigator.serviceWorker.register('./sw.js').then(reg => {
    swRegistration = reg;

    // Check if there is already a worker waiting to activate
    if (reg.waiting) {
      newWorkerWaiting = reg.waiting;
      showUpdateBanner();
    }

    reg.addEventListener('updatefound', () => {
      const newWorker = reg.installing;
      if (!newWorker) return;

      newWorker.addEventListener('statechange', () => {
        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
          newWorkerWaiting = newWorker;
          showUpdateBanner();
        }
      });
    });
  }).catch(err => {
    console.log('SW registration note:', err);
  });

  // When the new worker takes control, reload smoothly
  let isRefreshing = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (isRefreshing) return;
    isRefreshing = true;
    window.location.reload();
  });

  // Check for updates automatically on startup and every 15 minutes
  setTimeout(() => checkForAppUpdates(false), 1500);
  setInterval(() => checkForAppUpdates(false), 15 * 60 * 1000);
}

function showUpdateBanner() {
  const banner = document.getElementById('appUpdateBanner');
  if (banner) {
    banner.classList.add('active');
  }
}

function dismissUpdateBanner() {
  const banner = document.getElementById('appUpdateBanner');
  if (banner) {
    banner.classList.remove('active');
  }
}

async function applyAppUpdate() {
  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Mengemas kini aplikasi ke versi terkini...' : 'Updating application to latest version...');
  try {
    if (newWorkerWaiting) {
      newWorkerWaiting.postMessage({ type: 'SKIP_WAITING' });
    }
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      for (const r of regs) {
        await r.update();
      }
    }
  } catch (e) {
    console.warn('Update note:', e);
  }

  setTimeout(() => {
    const cleanUrl = window.location.href.split('?')[0];
    window.location.replace(`${cleanUrl}?v=${Date.now()}`);
  }, 450);
}

async function forcePurgeCacheAndReload() {
  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Membersihkan cache & memuat semula...' : 'Purging cache & reloading fresh...');
  try {
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }
  } catch (e) {
    console.warn('Purge cache error:', e);
  }
  setTimeout(() => {
    const cleanUrl = window.location.href.split('?')[0];
    window.location.replace(`${cleanUrl}?v=${Date.now()}`);
  }, 350);
}

async function checkForAppUpdates(isManual = false) {
  if (isManual) {
    showToast(t('toast_checking_updates'));
  }

  try {
    // 1. Tell the service worker registration to check the server for new sw.js
    if (swRegistration) {
      await swRegistration.update();
    }

    // 2. Fetch version.json directly with cache-busting timestamp
    const res = await fetch(`./version.json?t=${Date.now()}`);
    if (res.ok) {
      const verData = await res.json();
      if (verData && verData.version && verData.version !== APP_VERSION) {
        showUpdateBanner();
        if (isManual) {
          showToast(`${t('update_banner_title')} (v${verData.version})`);
        }
        return;
      } else {
        dismissUpdateBanner();
      }
    }

    if (isManual) {
      const isBM = appState.settings.language === 'bm';
      setTimeout(() => {
        showToast(isBM 
          ? `✨ Aplikasi adalah versi terkini (v${APP_VERSION})!` 
          : `✨ App is up to date (v${APP_VERSION})!`);
      }, 400);
    }
  } catch (e) {
    if (isManual) {
      const isBM = appState.settings.language === 'bm';
      showToast(isBM 
        ? `✨ Aplikasi adalah versi terkini (v${APP_VERSION})!` 
        : `✨ App is up to date (v${APP_VERSION})!`);
    }
  }
}

function downloadSafetySnapshot() {
  exportDataBackup();
  showToast(t('toast_safety_saved'));
}

function seedDemoData() {
  appState.properties = [...INITIAL_PROPERTIES];
  
  const today = new Date();
  const formatDate = (d) => formatLocalDate(d);

  const dMinus2 = new Date(today); dMinus2.setDate(today.getDate() - 2);
  const dMinus1 = new Date(today); dMinus1.setDate(today.getDate() - 1);
  const dToday = new Date(today);
  const dPlus1 = new Date(today); dPlus1.setDate(today.getDate() + 1);
  const dPlus2 = new Date(today); dPlus2.setDate(today.getDate() + 2);
  const dPlus4 = new Date(today); dPlus4.setDate(today.getDate() + 4);
  const dPlus6 = new Date(today); dPlus6.setDate(today.getDate() + 6);
  const dPlus8 = new Date(today); dPlus8.setDate(today.getDate() + 8);

  appState.bookings = [
    {
      id: 'b-demo-1',
      propertyId: 'prop-1',
      rentalType: 'daily',
      guestName: 'Sarah Jenkins',
      guestPhone: '+60123456789',
      guestNric: '900412-14-5588',
      guestEmail: 'sarah.j@example.com',
      guestAddress: 'No 45, Jalan Ampang Hilir, 55000 Kuala Lumpur',
      guestCount: 4,
      checkIn: formatDate(dMinus2),
      checkOut: formatDate(dToday),
      nights: 2,
      nightlyRate: 280,
      cleaningFee: 60,
      securityDeposit: 100,
      totalAmount: 720,
      depositPaid: 720,
      balance: 0,
      status: 'checked-in',
      channel: 'whatsapp',
      notes: 'Family vacation. Key PIN 5829# sent. Security deposit RM 100 held.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'b-demo-2',
      propertyId: 'prop-2',
      rentalType: 'daily',
      guestName: 'David Lee',
      guestPhone: '+60198765432',
      guestNric: '920820-01-6789',
      guestEmail: 'david.lee@outlook.com',
      guestAddress: 'Block B-12-3, Sri Petaling, 57000 KL',
      guestCount: 2,
      checkIn: formatDate(dToday),
      checkOut: formatDate(dPlus2),
      nights: 2,
      nightlyRate: 150,
      cleaningFee: 30,
      securityDeposit: 50,
      totalAmount: 380,
      depositPaid: 380,
      balance: 0,
      status: 'confirmed',
      channel: 'airbnb',
      notes: 'Fully paid! Booked Villa Impian Master Bedroom. Arriving at 4:00 PM.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'b-demo-3',
      propertyId: 'prop-3',
      rentalType: 'daily',
      guestName: 'Ahmad Faiz',
      guestPhone: '+60176543210',
      guestNric: '951104-10-5231',
      guestEmail: 'ahmad.faiz@gmail.com',
      guestAddress: 'No 18, Jalan Melati 3, 40000 Shah Alam',
      guestCount: 1,
      checkIn: formatDate(dPlus2),
      checkOut: formatDate(dPlus4),
      nights: 2,
      nightlyRate: 100,
      cleaningFee: 25,
      securityDeposit: 50,
      totalAmount: 275,
      depositPaid: 100,
      balance: 175,
      status: 'booked',
      channel: 'whatsapp',
      notes: 'Room 2 booking fee paid RM 100. Balance due before check-in.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'b-demo-4',
      propertyId: 'prop-1',
      rentalType: 'daily',
      guestName: 'Chloe Lim',
      guestPhone: '+60112345678',
      guestNric: '',
      guestEmail: 'chloe@example.com',
      guestAddress: '',
      guestCount: 2,
      checkIn: formatDate(dPlus4),
      checkOut: formatDate(dPlus6),
      nights: 2,
      nightlyRate: 280,
      cleaningFee: 60,
      securityDeposit: 100,
      totalAmount: 720,
      depositPaid: 0,
      balance: 720,
      status: 'quotation',
      channel: 'whatsapp',
      notes: 'Enquiry received for Sunset Ocean Villa. Quotation sent on WhatsApp.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'b-demo-5',
      propertyId: 'prop-2',
      rentalType: 'monthly',
      guestName: 'Dr. Zulkifli Rahman',
      guestPhone: '+60133445566',
      guestNric: '780612-03-5123',
      guestEmail: 'dr.zul@hospital.gov.my',
      guestAddress: 'No 99, Lorong Seri Teruntum, 25000 Kuantan, Pahang',
      guestCount: 1,
      checkIn: formatDate(dToday),
      checkOut: formatDate(new Date(today.getFullYear(), today.getMonth() + 6, today.getDate())),
      monthlyStart: formatDate(dToday),
      monthlyDuration: 6,
      monthlyRate: 750,
      rentalDeposit: 750,
      utilitiesDeposit: 200,
      agreementFee: 100,
      totalAmount: 1800,
      depositPaid: 1800,
      balance: 0,
      status: 'checked-in',
      channel: 'direct',
      notes: '6-Month Master Bedroom tenancy. Agreement signed & deposit settled.',
      createdAt: new Date().toISOString()
    }
  ];

  appState.turnovers = [
    {
      id: 't-demo-1',
      propertyId: 'prop-1',
      bookingId: 'b-demo-1',
      date: formatDate(dToday),
      status: 'pending',
      cleanerName: 'Kak Siti (Cleaner)',
      cleanerPhone: '+60129998877',
      checklist: [
        { text: 'Strip & wash bedsheets & pillowcases', done: false },
        { text: 'Sanitize bathroom & provide fresh towels', done: false },
        { text: 'Restock toiletries, coffee & mineral water', done: false },
        { text: 'Reset Smart Lock PIN code (5829#)', done: false },
        { text: 'Check air-conditioners & TV remotes', done: false },
        { text: 'Empty all trash bins', done: false }
      ]
    }
  ];

  appState.expenses = [
    {
      id: 'exp-1',
      propertyId: 'prop-1',
      date: formatDate(dMinus2),
      category: 'cleaning',
      description: 'Turnover deep cleaning fee',
      amount: 60
    },
    {
      id: 'exp-2',
      propertyId: 'prop-1',
      date: formatDate(dMinus1),
      category: 'supplies',
      description: 'Restocked shampoo, body wash & coffee packets',
      amount: 45
    },
    {
      id: 'exp-3',
      propertyId: 'prop-2',
      date: formatDate(dMinus2),
      category: 'utilities',
      description: 'High-speed WiFi monthly subscription',
      amount: 89
    }
  ];

  appState.contacts = [...DEFAULT_CONTACTS];
  appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];

  saveToStorage();
  showToast('Demo data loaded with 2 homestays & sample bookings!');
}

// ==========================================================================
// 3. EVENT LISTENERS & NAVIGATION
// ==========================================================================

function setupEventListeners() {
  // Bottom Navigation Tabs
  document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
    item.addEventListener('click', () => {
      const tab = item.getAttribute('data-tab');
      switchTab(tab);
    });
  });

  // 0. Global Delegated Click Listeners (Must register first so they are never blocked by any missing DOM elements)
  document.addEventListener('click', (e) => {
    const quickDownloadAgrBtn = e.target.closest('.btn-quick-download-agreement');
    if (quickDownloadAgrBtn) {
      e.preventDefault();
      e.stopPropagation();
      const bid = quickDownloadAgrBtn.getAttribute('data-bid');
      const b = (bid ? appState.bookings.find(x => String(x.id) === String(bid)) : null) || appState.activeWaBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'preview');
      setTimeout(() => {
        downloadAgreementPdf();
      }, 400);
      return;
    }

    const agrFormBtn = e.target.closest('.btn-open-agreement-form');
    if (agrFormBtn) {
      e.preventDefault();
      e.stopPropagation();
      const bid = agrFormBtn.getAttribute('data-bid');
      const b = (bid ? appState.bookings.find(x => String(x.id) === String(bid)) : null) || appState.activeWaBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'form');
      return;
    }

    const agrPreviewBtn = e.target.closest('.btn-open-agreement-preview, .btn-open-agreement');
    if (agrPreviewBtn) {
      e.preventDefault();
      e.stopPropagation();
      const bid = agrPreviewBtn.getAttribute('data-bid');
      const b = (bid ? appState.bookings.find(x => String(x.id) === String(bid)) : null) || appState.activeWaBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'preview');
      return;
    }
  });

  // Header quick buttons
  document.getElementById('btnLangToggle')?.addEventListener('click', toggleLanguage);
  document.getElementById('btnThemeToggle')?.addEventListener('click', toggleTheme);
  document.getElementById('btnDemoToggle')?.addEventListener('click', () => {
    if (appState.isLicensed) {
      openProSystemModal();
    } else {
      openLicenseModal();
    }
  });

  const btnHeaderCheckUp = document.getElementById('btnHeaderCheckUpdates');
  if (btnHeaderCheckUp) {
    btnHeaderCheckUp.addEventListener('click', () => checkForAppUpdates(true));
  }

  const btnHeaderRefresh = document.getElementById('btnHeaderForceRefresh');
  if (btnHeaderRefresh) {
    btnHeaderRefresh.addEventListener('click', () => {
      if (typeof forcePurgeCacheAndReload === 'function') forcePurgeCacheAndReload();
    });
  }

  const btnOpenAgrGen = document.getElementById('btnOpenAgreementGen');
  if (btnOpenAgrGen) {
    btnOpenAgrGen.addEventListener('click', () => {
      openAgreementModal(null, 'form');
    });
  }

  // Pro System Hub Modal Handlers
  const btnClosePro = document.getElementById('btnCloseProSystemModal');
  if (btnClosePro) btnClosePro.addEventListener('click', closeProSystemModal);

  const btnProGuide = document.getElementById('btnProModalReadGuide');
  if (btnProGuide) {
    btnProGuide.addEventListener('click', () => {
      closeProSystemModal();
      openUserGuideModal();
    });
  }

  const btnProUp = document.getElementById('btnProModalCheckUpdate');
  if (btnProUp) {
    btnProUp.addEventListener('click', () => {
      closeProSystemModal();
      checkForAppUpdates(true);
    });
  }

  const btnProBak = document.getElementById('btnProModalBackup');
  if (btnProBak) {
    btnProBak.addEventListener('click', () => {
      closeProSystemModal();
      exportDataBackup();
    });
  }

  const btnProSet = document.getElementById('btnProModalOpenSettings');
  if (btnProSet) {
    btnProSet.addEventListener('click', () => {
      closeProSystemModal();
      switchTab('settings');
    });
  }

  // Language selector in Settings
  const langSelect = document.getElementById('settingLanguageSelect');
  if (langSelect) {
    langSelect.addEventListener('change', (e) => setLanguage(e.target.value));
  }

  // Property Switcher '+ Add' button
  document.getElementById('btnAddPropertyPill')?.addEventListener('click', () => openPropertyModal());

  // Dashboard quick triggers
  document.getElementById('btnSeeAllBookings')?.addEventListener('click', () => switchTab('bookings'));
  document.getElementById('btnManageProperties')?.addEventListener('click', () => switchTab('settings'));

  // Floating Action Button
  document.getElementById('fabAddBooking')?.addEventListener('click', () => openBookingModal());

  // Calendar Controls
  document.getElementById('calPrevMonth')?.addEventListener('click', () => changeCalMonth(-1));
  document.getElementById('calNextMonth')?.addEventListener('click', () => changeCalMonth(1));
  document.getElementById('btnQuickBookForDate')?.addEventListener('click', () => {
    openBookingModal(null, appState.selectedCalDate);
  });

  // Calendar Mode Selector (Check-In vs Check-Out vs Stays)
  document.querySelectorAll('#calModeSelector .cal-mode-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const mode = pill.getAttribute('data-cal-filter') || 'checkin';
      appState.calFilterMode = mode;
      document.querySelectorAll('#calModeSelector .cal-mode-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      renderCalendarTab();
    });
  });

  document.getElementById('calTabIncoming')?.addEventListener('click', () => {
    appState.calListingMode = 'incoming';
    document.querySelectorAll('.cal-day-cell').forEach(c => c.classList.remove('selected'));
    renderCalendarListing();
  });
  document.getElementById('calTabSelected')?.addEventListener('click', () => {
    appState.calListingMode = 'selected';
    renderCalendarListing();
  });

  // Bookings Search & Filter
  document.getElementById('bookingSearchInput')?.addEventListener('input', renderBookingsTab);
  document.querySelectorAll('#bookingStatusFilters .filter-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#bookingStatusFilters .filter-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      renderBookingsTab();
    });
  });

  // Modals close buttons
  document.getElementById('btnCloseBookingModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCancelBookingModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnClosePropertyModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCancelPropertyModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCloseWaModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCloseExpenseModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCancelExpenseModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCloseGuestGuideModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCloseLicenseModal')?.addEventListener('click', closeAllModals);
  
  // Refund Modal Close
  const closeRefund = document.getElementById('btnCloseRefundModal');
  if (closeRefund) closeRefund.addEventListener('click', closeAllModals);
  const cancelRefund = document.getElementById('btnCancelRefundModal');
  if (cancelRefund) cancelRefund.addEventListener('click', closeAllModals);

  // Monthly Invoices Modal Close
  const closeMInv = document.getElementById('btnCloseMonthlyInvoicesModal');
  if (closeMInv) closeMInv.addEventListener('click', closeAllModals);

  // Tenancy Agreement Global Triggers (ensures clicking works regardless of caller)
  const btnEditAgrHub = document.getElementById('btnEditTenancyAgreementFromHub');
  if (btnEditAgrHub) {
    btnEditAgrHub.addEventListener('click', (e) => {
      e.stopPropagation();
      const b = appState.activeWaBooking || appState.activePdfBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'form');
    });
  }

  const btnAgrHub = document.getElementById('btnOpenTenancyAgreementFromHub');
  if (btnAgrHub) {
    btnAgrHub.addEventListener('click', (e) => {
      e.stopPropagation();
      const b = appState.activeWaBooking || appState.activePdfBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'preview');
    });
  }

  const btnQuickAgrHub = document.getElementById('btnQuickDownloadAgreementFromHub');
  if (btnQuickAgrHub) {
    btnQuickAgrHub.addEventListener('click', (e) => {
      e.stopPropagation();
      const b = appState.activeWaBooking || appState.activePdfBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'preview');
      setTimeout(() => {
        downloadAgreementPdf();
      }, 400);
    });
  }

  const btnPdfAgrTab = document.getElementById('btnPdfTabAgreement');
  if (btnPdfAgrTab) {
    btnPdfAgrTab.addEventListener('click', () => {
      const b = appState.activePdfBooking || appState.activeWaBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      closePdfDocModal();
      openAgreementModal(b, 'preview');
    });
  }

  // Overlap Warning & Change Homestay Modals Close Handlers
  const closeOverlap = document.getElementById('btnCloseOverlapModal');
  if (closeOverlap) closeOverlap.addEventListener('click', closeAllModals);
  const dismissOverlap = document.getElementById('btnOverlapDismiss');
  if (dismissOverlap) dismissOverlap.addEventListener('click', closeAllModals);
  const closeChange = document.getElementById('btnCloseChangeHomestayModal');
  if (closeChange) closeChange.addEventListener('click', closeAllModals);
  const cancelChange = document.getElementById('btnCancelChangeHomestay');
  if (cancelChange) cancelChange.addEventListener('click', closeAllModals);

  // Change Homestay Form Submission
  const changeHomestayForm = document.getElementById('changeHomestayForm');
  if (changeHomestayForm) changeHomestayForm.addEventListener('submit', handleConfirmChangeHomestay);

  // In-App User Guide Modal Handlers
  const btnOpenGuideHeader = document.getElementById('btnOpenUserGuide');
  if (btnOpenGuideHeader) btnOpenGuideHeader.addEventListener('click', () => openUserGuideModal());

  const btnOpenGuideSettings = document.getElementById('btnOpenUserGuideSettings');
  if (btnOpenGuideSettings) btnOpenGuideSettings.addEventListener('click', () => openUserGuideModal());

  const closeGuideModal = document.getElementById('btnCloseUserGuideModal');
  if (closeGuideModal) closeGuideModal.addEventListener('click', closeAllModals);

  // Guide Language Segment Buttons
  document.querySelectorAll('#guideLangSegmented .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#guideLangSegmented .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const glang = btn.getAttribute('data-glang') || 'en';
      renderUserGuideAccordion(glang);
    });
  });

  // WhatsApp Monthly Controls dynamic triggers
  const waMonthSel = document.getElementById('waInvoiceMonthSelect');
  if (waMonthSel) {
    waMonthSel.addEventListener('change', (e) => {
      appState.activeWaMonthIndex = parseInt(e.target.value) || 1;
      renderWhatsAppPreview();
    });
  }

  const waExtraInp = document.getElementById('waInvoiceExtraInput');
  if (waExtraInp) {
    waExtraInp.addEventListener('input', renderWhatsAppPreview);
  }

  // License & Sales Event Handlers
  document.getElementById('btnOpenActivateModal')?.addEventListener('click', openLicenseModal);
  document.getElementById('btnBuyLicense')?.addEventListener('click', handleBuyLicense);
  document.getElementById('btnBuyLicenseViaWa')?.addEventListener('click', handleBuyLicense);
  document.getElementById('linkPresaleWhatsApp')?.addEventListener('click', (e) => {
    e.preventDefault();
    handleContactSellerWhatsApp('presale');
  });
  document.getElementById('licenseForm')?.addEventListener('submit', handleActivateLicenseSubmit);
  document.getElementById('licensePhoneInput')?.addEventListener('input', updateLicensePhonePreview);
  document.getElementById('licensePhoneInput')?.addEventListener('paste', () => setTimeout(updateLicensePhonePreview, 0));
  document.getElementById('licenseKeyInput')?.addEventListener('input', updateLicenseKeyPreview);
  document.getElementById('licenseKeyInput')?.addEventListener('paste', () => setTimeout(updateLicenseKeyPreview, 0));
  document.getElementById('btnPasteLicenseKey')?.addEventListener('click', handlePasteLicenseKey);



  // Rental Type Segmented Control (Daily vs Monthly)
  document.querySelectorAll('#rentalTypeSegmented .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#rentalTypeSegmented .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const type = btn.getAttribute('data-type');
      document.getElementById('bookingRentalType').value = type;
      setBookingFormRentalType(type);
      updateBookingModalPricing();
    });
  });

  // Tenant Type Segmented Control (Individual vs Company)
  document.querySelectorAll('#tenantTypeSegmented .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.getAttribute('data-tenant-type') || 'individual';
      setBookingTenantType(type);
    });
  });

  // Signatory "Same as Contact Person" Checkbox & Live Mirroring
  document.getElementById('bookingSignatorySameAsContact')?.addEventListener('change', (e) => {
    if (e.target.checked) {
      syncSignatoryWithContactPerson();
    }
  });

  ['bookingContactPerson', 'bookingContactDesignation'].forEach(id => {
    document.getElementById(id)?.addEventListener('input', () => {
      const chk = document.getElementById('bookingSignatorySameAsContact');
      if (chk && chk.checked) {
        syncSignatoryWithContactPerson();
      }
    });
  });

  // Sync Occupants Count with Guest Count in Monthly mode
  const occCountInput = document.getElementById('bookingOccupantsCount');
  const guestCountInput = document.getElementById('bookingGuestCount');
  if (occCountInput && guestCountInput) {
    occCountInput.addEventListener('input', () => {
      if (document.getElementById('bookingRentalType')?.value === 'monthly') {
        guestCountInput.value = occCountInput.value;
      }
    });
    guestCountInput.addEventListener('input', () => {
      if (document.getElementById('bookingRentalType')?.value === 'monthly') {
        occCountInput.value = guestCountInput.value;
      }
    });
  }

  // Booking Form Submission & Dynamic Pricing Calc
  document.getElementById('bookingForm')?.addEventListener('submit', handleSaveBooking);
  [
    'bookingCheckIn', 'bookingCheckOut', 'bookingNightlyRate', 'bookingCleaningFee', 'bookingSecurityDeposit',
    'bookingMonthlyStart', 'bookingMonthlyDuration', 'bookingMonthlyRate', 'bookingRentalDeposit',
    'bookingUtilitiesDeposit', 'bookingAgreementFee', 'bookingPropertySelect'
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', updateBookingModalPricing);
      el.addEventListener('change', updateBookingModalPricing);
      if (['bookingCheckIn', 'bookingCheckOut', 'bookingMonthlyStart', 'bookingMonthlyDuration', 'bookingPropertySelect'].includes(id)) {
        el.addEventListener('input', checkBookingModalOverlap);
        el.addEventListener('change', checkBookingModalOverlap);
      }
    }
  });

  // Auto-sync Rental Deposit to 1 Month Rental by default
  const mRateEl = document.getElementById('bookingMonthlyRate');
  const rDepEl = document.getElementById('bookingRentalDeposit');
  if (mRateEl && rDepEl) {
    mRateEl.addEventListener('input', () => {
      if (rDepEl.dataset.customized !== 'true') {
        rDepEl.value = mRateEl.value;
      }
    });
    rDepEl.addEventListener('input', () => {
      rDepEl.dataset.customized = (rDepEl.value !== mRateEl.value) ? 'true' : 'false';
    });
  }

  // Tenancy Deposit Refund Form
  const refundForm = document.getElementById('depositRefundForm');
  if (refundForm) refundForm.addEventListener('submit', handleProcessDepositRefund);

  // Repeat Guest Recognition Inputs
  ['bookingGuestPhone', 'bookingGuestNric', 'bookingContactPhone', 'bookingCompanyRegNo'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', checkBookingRepeatGuest);
      el.addEventListener('change', checkBookingRepeatGuest);
    }
  });

  const btnApplyRepeat = document.getElementById('btnApplyRepeatGuestDetails');
  if (btnApplyRepeat) {
    btnApplyRepeat.addEventListener('click', () => {
      if (currentRepeatGuestStats) {
        applyRepeatGuestDetails(currentRepeatGuestStats);
      }
    });
  }
  [
    'refundRentalDepInput', 'refundUtilitiesDepInput', 'refundDeductUtilitiesInput', 'refundDeductRepairsInput'
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', updateDepositRefundCalculation);
      el.addEventListener('change', updateDepositRefundCalculation);
    }
  });

  // Property Form Submission & Modals
  document.getElementById('propertyForm')?.addEventListener('submit', handleSaveProperty);
  document.getElementById('btnAddNewPropertyModal')?.addEventListener('click', () => openPropertyModal());

  // Expense Buttons & Form
  const openExpModal = () => openExpenseModal();
  document.getElementById('btnAddExpenseBtn')?.addEventListener('click', openExpModal);
  document.getElementById('btnAddExpenseBtn2')?.addEventListener('click', openExpModal);
  document.getElementById('expenseForm')?.addEventListener('submit', handleSaveExpense);

  // WhatsApp Modal Buttons & Template Switcher
  document.querySelectorAll('.wa-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.wa-tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tmpl = btn.getAttribute('data-template');
      appState.activeWaTemplate = tmpl;

      // Toggle quotation controls
      const quotationControls = document.getElementById('waQuotationControls');
      if (quotationControls) {
        quotationControls.classList.toggle('hidden', tmpl !== 'quotation');
      }

      // Toggle monthly controls
      const monthlyControls = document.getElementById('waMonthlyControls');
      if (monthlyControls) {
        const isMonthly = appState.activeWaBooking?.rentalType === 'monthly';
        monthlyControls.classList.toggle('hidden', !(isMonthly && (tmpl === 'monthly_invoice' || tmpl === 'monthly_rent_receipt')));
      }

      renderWhatsAppPreview();
    });
  });

  document.getElementById('waQuotationValidityInput')?.addEventListener('input', (e) => {
    if (appState.activeWaBooking) {
      appState.activeWaBooking.quotationValidityDays = parseInt(e.target.value) || 3;
    }
    renderWhatsAppPreview();
  });

  // Corporate & Office PDF Modal Wiring (v2.6.5)
  document.getElementById('btnOpenPdfModalFromWa')?.addEventListener('click', () => {
    const b = appState.activeWaBooking || (appState.bookings && appState.bookings[0]);
    if (b) {
      const tmpl = appState.activeWaTemplate;
      const docType = (tmpl === 'deposit_receipt') 
        ? 'deposit_receipt' 
        : (tmpl === 'full_receipt' || tmpl === 'monthly_rent_receipt' || tmpl === 'refund_receipt') 
          ? 'receipt' 
          : (tmpl === 'monthly_invoice' || tmpl === 'payment') 
            ? 'invoice' 
            : 'quotation';
      closeAllModals();
      openPdfDocModal(b, docType, appState.activeWaMonthIndex);
    } else {
      showToast(appState.settings.language === 'bm' ? 'Sila pilih tempahan terlebih dahulu.' : 'Please select a booking first.');
    }
  });

  document.getElementById('btnClosePdfModal')?.addEventListener('click', closePdfDocModal);
  document.getElementById('btnClosePdfModalBtn')?.addEventListener('click', closePdfDocModal);

  document.getElementById('btnPdfTabQuotation')?.addEventListener('click', () => setPdfDocType('quotation'));
  document.getElementById('btnPdfTabInvoice')?.addEventListener('click', () => setPdfDocType('invoice'));
  document.getElementById('btnPdfTabDeposit')?.addEventListener('click', () => setPdfDocType('deposit_receipt'));
  document.getElementById('btnPdfTabReceipt')?.addEventListener('click', () => setPdfDocType('receipt'));
  document.getElementById('btnPdfTabHistory')?.addEventListener('click', () => setPdfDocType('history'));

  document.getElementById('btnPdfLangBM')?.addEventListener('click', () => setPdfLanguage('bm'));
  document.getElementById('btnPdfLangEN')?.addEventListener('click', () => setPdfLanguage('en'));

  document.getElementById('pdfQuotationValidityInput')?.addEventListener('input', (e) => {
    setPdfQuotationValidity(e.target.value);
  });

  document.querySelectorAll('.pdf-validity-preset').forEach(btn => {
    btn.addEventListener('click', () => {
      const days = btn.getAttribute('data-days');
      setPdfQuotationValidity(days);
    });
  });

  document.getElementById('pdfDepositAmountInput')?.addEventListener('input', (e) => {
    const val = parseFloat(e.target.value) || 0;
    if (appState.activePdfBooking) {
      appState.activePdfBooking.depositPaid = val;
      appState.activePdfBooking.balance = Math.max(0, (appState.activePdfBooking.totalAmount || 0) - val);
      saveToStorage();
    }
    updatePdfDocView();
  });

  document.getElementById('btnPdfResetDeposit')?.addEventListener('click', () => {
    if (appState.activePdfBooking) {
      const orig = Math.round((appState.activePdfBooking.totalAmount || 0) * (appState.settings.defaultDepositPct || 30) / 100);
      appState.activePdfBooking.depositPaid = orig;
      appState.activePdfBooking.balance = Math.max(0, (appState.activePdfBooking.totalAmount || 0) - orig);
      const depInput = document.getElementById('pdfDepositAmountInput');
      if (depInput) depInput.value = orig;
      saveToStorage();
      updatePdfDocView();
    }
  });

  document.getElementById('pdfPaymentRefInput')?.addEventListener('input', (e) => {
    if (appState.activePdfBooking) {
      appState.activePdfBooking.lastPaymentRef = e.target.value;
      saveToStorage();
    }
    updatePdfDocView();
  });

  document.getElementById('pdfClientCompanyInput')?.addEventListener('input', (e) => {
    if (appState.activePdfBooking) {
      appState.activePdfBooking.guestCompany = e.target.value;
      saveToStorage();
    }
    updatePdfDocView();
  });

  document.getElementById('pdfLpoRefInput')?.addEventListener('input', (e) => {
    if (appState.activePdfBooking) {
      appState.activePdfBooking.lpoRef = e.target.value;
      saveToStorage();
    }
    updatePdfDocView();
  });

  document.getElementById('btnPrintPdfDoc')?.addEventListener('click', printPdfDocument);
  document.getElementById('btnDownloadPdfDoc')?.addEventListener('click', downloadPdfDocument);
  document.getElementById('btnViewPdfTab')?.addEventListener('click', viewPdfInNewTab);
  document.getElementById('btnSharePdfWa')?.addEventListener('click', sharePdfViaWhatsApp);
  document.getElementById('btnPromptSendWa')?.addEventListener('click', sharePdfViaWhatsApp);
  document.getElementById('btnPromptDownload')?.addEventListener('click', downloadPdfDocument);
  document.getElementById('btnPromptViewTab')?.addEventListener('click', viewPdfInNewTab);
  document.getElementById('btnPromptDismiss')?.addEventListener('click', () => {
    const banner = document.getElementById('pdfWaPromptBanner');
    if (banner) banner.style.display = 'none';
  });

  // Shortcut from Bank Warning Banner to Settings
  document.getElementById('btnGoToSettingsFromPdfBankWarn')?.addEventListener('click', () => {
    closePdfDocModal();
    switchTab('settings');
    setTimeout(() => {
      const bankEl = document.getElementById('settingBankAccNumInput');
      if (bankEl) {
        bankEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        bankEl.focus();
      }
    }, 200);
  });

  // Document Lifecycle Toolbar Actions (B2)
  document.getElementById('btnPdfMarkIssued')?.addEventListener('click', () => {
    if (!appState.activePdfBooking) return;
    const docType = appState.activePdfDocType || 'quotation';
    const monthIdx = appState.activePdfMonthIndex;
    const alloc = getOrAllocateDocNo(appState.activePdfBooking, docType, monthIdx, true, appState.activePdfPaymentId);
    updatePdfDocView();
    const isBM = appState.settings.language === 'bm';
    showToast(isBM 
      ? `Dokumen rasmi ${alloc.docNo} berjaya disahkan dan diterbitkan!` 
      : `Official document ${alloc.docNo} successfully finalized and issued!`);
  });

  document.getElementById('btnPdfCreateRevision')?.addEventListener('click', () => {
    if (!appState.activePdfBooking) return;
    handleCreateQuotationRevision(appState.activePdfBooking);
  });

  document.getElementById('btnPdfVoidReissue')?.addEventListener('click', () => {
    if (!appState.activePdfBooking) return;
    openVoidDocModal(appState.activePdfBooking);
  });

  document.getElementById('btnCloseVoidDocModal')?.addEventListener('click', closeVoidDocModal);
  document.getElementById('btnCancelVoidDoc')?.addEventListener('click', closeVoidDocModal);
  document.getElementById('btnConfirmVoidReissue')?.addEventListener('click', handleConfirmVoidReissue);

  // Direct 1-Click PDF Download from WhatsApp Modal
  document.getElementById('btnDirectDownloadPdfFromWa')?.addEventListener('click', () => {
    const b = appState.activeWaBooking || (appState.bookings && appState.bookings[0]);
    if (b) {
      const tmpl = appState.activeWaTemplate;
      const docType = (tmpl === 'deposit_receipt') 
        ? 'deposit_receipt' 
        : (tmpl === 'full_receipt' || tmpl === 'monthly_rent_receipt' || tmpl === 'refund_receipt') 
          ? 'receipt' 
          : (tmpl === 'monthly_invoice' || tmpl === 'payment') 
            ? 'invoice' 
            : 'quotation';
      closeAllModals();
      openPdfDocModal(b, docType, appState.activeWaMonthIndex);
      setTimeout(() => {
        downloadPdfDocument();
      }, 350);
    } else {
      showToast(appState.settings.language === 'bm' ? 'Sila pilih tempahan terlebih dahulu.' : 'Please select a booking first.');
    }
  });

  // Booking Form Status Change -> Toggle Quotation Validity Group & Auto-Settle Full Balance
  const bookingStatusSel = document.getElementById('bookingStatusSelect');
  if (bookingStatusSel) {
    bookingStatusSel.addEventListener('change', () => {
      const st = bookingStatusSel.value;
      const validityGroup = document.getElementById('bookingQuotationValidityGroup');
      if (validityGroup) {
        validityGroup.style.display = st === 'quotation' ? 'block' : 'none';
      }

      // Auto-compute current total in modal
      const rType = document.getElementById('bookingRentalType')?.value || 'daily';
      let currentTotal = 0;
      if (rType === 'monthly') {
        const mRate = parseFloat(document.getElementById('bookingMonthlyRate')?.value) || 0;
        const rDep = parseFloat(document.getElementById('bookingRentalDeposit')?.value) || 0;
        const uDep = parseFloat(document.getElementById('bookingUtilitiesDeposit')?.value) || 0;
        const aFee = parseFloat(document.getElementById('bookingAgreementFee')?.value) || 0;
        currentTotal = mRate + rDep + uDep + aFee;
      } else {
        const checkInVal = document.getElementById('bookingCheckIn')?.value;
        const checkOutVal = document.getElementById('bookingCheckOut')?.value;
        const rateVal = parseFloat(document.getElementById('bookingNightlyRate')?.value) || 0;
        const cleanVal = parseFloat(document.getElementById('bookingCleaningFee')?.value) || 0;
        const secDep = parseFloat(document.getElementById('bookingSecurityDeposit')?.value) || 0;
        let nights = 0;
        if (checkInVal && checkOutVal) {
          nights = calcNightsBetween(checkInVal, checkOutVal);
        }
        currentTotal = (nights * rateVal) + cleanVal + secDep;
      }

      const depInput = document.getElementById('bookingDepositPaid');
      const hintEl = document.getElementById('bookingDepositPaidHint');
      const isBM = appState.settings.language === 'bm';
      const cur = appState.settings.currency || 'RM';

      if (st === 'confirmed' || st === 'checked-in' || st === 'checked-out') {
        if (depInput && currentTotal > 0) {
          depInput.value = currentTotal;
        }
        if (hintEl) {
          hintEl.textContent = isBM ? `✓ Bayaran penuh disahkan. Baki akan menjadi ${cur} 0.00` : `✓ Full payment confirmed. Balance will be settled to ${cur} 0.00`;
          hintEl.style.color = 'var(--success)';
        }
      } else if (st === 'quotation') {
        if (depInput) depInput.value = 0;
        if (hintEl) {
          hintEl.textContent = isBM ? 'Sebut harga sahaja — tiada bayaran dibuat.' : 'Quotation only — no payment made yet.';
          hintEl.style.color = 'var(--text-muted)';
        }
      } else if (st === 'booked') {
        if (hintEl) {
          hintEl.textContent = isBM ? 'Deposit sebahagian dibayar. Baki akan dikutip sebelum daftar masuk.' : 'Partial deposit paid. Remaining balance due before check-in.';
          hintEl.style.color = 'var(--warning)';
        }
      } else {
        if (hintEl) hintEl.textContent = '';
      }
    });
  }

  document.getElementById('btnCopyWaText')?.addEventListener('click', handleCopyWaText);
  document.getElementById('btnSendWaDirect')?.addEventListener('click', handleSendWaDirect);

  // Deposit Presets in Booking Form
  document.getElementById('btnPresetDep30')?.addEventListener('click', () => applyDepositPreset(0.30, 'booked'));
  document.getElementById('btnPresetDep50')?.addEventListener('click', () => applyDepositPreset(0.50, 'booked'));
  document.getElementById('btnPresetDepFull')?.addEventListener('click', () => applyDepositPreset(1.0, 'confirmed'));
  document.getElementById('btnPresetDepZero')?.addEventListener('click', () => applyDepositPreset(0, 'quotation'));

  // Settings & Preferences
  document.getElementById('btnSavePreferences')?.addEventListener('click', handleSavePreferences);
  document.getElementById('btnSaveBankDetails')?.addEventListener('click', handleSaveBankDetails);
  document.getElementById('btnExportData')?.addEventListener('click', exportDataBackup);
  document.getElementById('btnImportDataInput')?.addEventListener('change', importDataBackup);
  const btnRestoreSnap = document.getElementById('btnRestoreAutoBackup');
  if (btnRestoreSnap) btnRestoreSnap.addEventListener('click', restoreAutoBackup);
  document.getElementById('btnResetAllData')?.addEventListener('click', openClearDataModal);

  // Clear All Data Confirmation Modal Listeners
  document.getElementById('btnCloseClearDataModal')?.addEventListener('click', closeClearDataModal);
  document.getElementById('btnCancelClearData')?.addEventListener('click', closeClearDataModal);
  document.getElementById('btnClearModalExportBackup')?.addEventListener('click', exportDataBackup);
  document.getElementById('btnConfirmClearDataFinal')?.addEventListener('click', handleConfirmClearData);
  document.getElementById('clearDataConfirmInput')?.addEventListener('input', (e) => {
    const val = (e.target.value || '').trim().toUpperCase();
    const btn = document.getElementById('btnConfirmClearDataFinal');
    if (btn) btn.disabled = (val !== 'DELETE' && val !== 'PADAM');
  });

  // Backup Reminder Banner Listeners
  document.getElementById('btnBackupReminderExport')?.addEventListener('click', () => {
    exportDataBackup();
    dismissBackupReminderBanner();
  });
  document.getElementById('btnDismissBackupReminder')?.addEventListener('click', dismissBackupReminderBanner);

  // App Update System Event Listeners
  const btnApplyUpdate = document.getElementById('btnApplyAppUpdate');
  if (btnApplyUpdate) btnApplyUpdate.addEventListener('click', applyAppUpdate);

  const btnDismissUp = document.getElementById('btnDismissUpdate');
  if (btnDismissUp) btnDismissUp.addEventListener('click', dismissUpdateBanner);

  const btnCheckUp = document.getElementById('btnCheckForUpdates');
  if (btnCheckUp) btnCheckUp.addEventListener('click', () => checkForAppUpdates(true));

  const btnForcePurge = document.getElementById('btnForcePurgeCache');
  if (btnForcePurge) btnForcePurge.addEventListener('click', forcePurgeCacheAndReload);

  const btnSafetySnap = document.getElementById('btnDownloadSafetySnapshot');
  if (btnSafetySnap) btnSafetySnap.addEventListener('click', downloadSafetySnapshot);

  // Contact Modal & Team Directory
  const btnAddContact = document.getElementById('btnAddNewContactModal');
  if (btnAddContact) btnAddContact.addEventListener('click', () => openContactModal());

  const btnCloseContact = document.getElementById('btnCloseContactModal');
  if (btnCloseContact) btnCloseContact.addEventListener('click', closeAllModals);

  const btnCancelContact = document.getElementById('btnCancelContact');
  if (btnCancelContact) btnCancelContact.addEventListener('click', closeAllModals);

  const contactForm = document.getElementById('contactForm');
  if (contactForm) contactForm.addEventListener('submit', handleSaveContact);

  // Turnovers Quick Actions
  const btnTurnoverDir = document.getElementById('btnTurnoverTeamDir');
  if (btnTurnoverDir) {
    btnTurnoverDir.addEventListener('click', () => {
      switchTab('settings');
      setTimeout(() => {
        document.getElementById('settingsContactList')?.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    });
  }

  const btnTurnoverAlert = document.getElementById('btnTurnoverServiceAlert');
  if (btnTurnoverAlert) {
    btnTurnoverAlert.addEventListener('click', () => openServiceDispatchModal());
  }

  // Service & Supply Dispatch Modal
  const btnCloseDispatch = document.getElementById('btnCloseServiceDispatchModal');
  if (btnCloseDispatch) btnCloseDispatch.addEventListener('click', closeAllModals);

  [
    'dispatchRecipientSelect', 'dispatchPropertySelect', 'dispatchServiceTypeSelect',
    'dispatchUrgencySelect', 'dispatchIncludePinCheck'
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', renderServiceDispatchPreview);
  });

  const dispatchDetails = document.getElementById('dispatchDetailsInput');
  if (dispatchDetails) dispatchDetails.addEventListener('input', renderServiceDispatchPreview);

  const btnCopyDispatch = document.getElementById('btnCopyDispatchText');
  if (btnCopyDispatch) btnCopyDispatch.addEventListener('click', handleCopyServiceDispatchText);

  const btnSendDispatch = document.getElementById('btnSendDispatchWa');
  if (btnSendDispatch) btnSendDispatch.addEventListener('click', handleSendServiceDispatchWa);

  // Finance Selectors
  document.getElementById('financeMonthSelect')?.addEventListener('change', renderFinancesTab);
  document.getElementById('financeYearSelect')?.addEventListener('change', renderFinancesTab);
  if (typeof populateFinanceDateSelectors === 'function') populateFinanceDateSelectors();

  // Payment Proof & Receipt Modals Event Handlers
  const closePayProof = document.getElementById('btnClosePaymentProofModal');
  if (closePayProof) closePayProof.addEventListener('click', closeAllModals);

  const cancelPayProof = document.getElementById('btnCancelPaymentProofModal');
  if (cancelPayProof) cancelPayProof.addEventListener('click', closeAllModals);

  const closeReceiptViewer = document.getElementById('btnCloseReceiptViewerModal');
  if (closeReceiptViewer) closeReceiptViewer.addEventListener('click', closeAllModals);

  const closeReceiptViewerBtn = document.getElementById('btnCloseReceiptViewerBtn');
  if (closeReceiptViewerBtn) closeReceiptViewerBtn.addEventListener('click', closeAllModals);

  const closeLightbox = document.getElementById('btnCloseLightbox');
  if (closeLightbox) closeLightbox.addEventListener('click', closeAllModals);

  const lightboxModal = document.getElementById('receiptLightboxModal');
  if (lightboxModal) {
    lightboxModal.addEventListener('click', (e) => {
      if (e.target.id === 'receiptLightboxModal') closeAllModals();
    });
  }

  // Receipt File Upload Dropzone
  const dropzone = document.getElementById('receiptDropzone');
  const fileInput = document.getElementById('paymentProofFileInput');
  if (dropzone && fileInput) {
    dropzone.addEventListener('click', (e) => {
      if (e.target.closest('#btnRemoveReceiptImg') || e.target.closest('#btnViewReceiptPreview')) return;
      fileInput.click();
    });

    ['dragenter', 'dragover'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
      });
    });

    dropzone.addEventListener('drop', (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        handleReceiptFileSelected(e.dataTransfer.files[0]);
      }
    });

    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files.length > 0) {
        handleReceiptFileSelected(e.target.files[0]);
      }
    });
  }

  // Remove Receipt Image Button
  const btnRemoveReceipt = document.getElementById('btnRemoveReceiptImg');
  if (btnRemoveReceipt) {
    btnRemoveReceipt.addEventListener('click', (e) => {
      e.stopPropagation();
      document.getElementById('paymentProofImageData').value = '';
      document.getElementById('paymentProofImageName').value = '';
      document.getElementById('paymentProofFileInput').value = '';
      document.getElementById('receiptPreviewImg').src = '';
      document.getElementById('receiptUploadPrompt').style.display = 'block';
      document.getElementById('receiptPreviewContainer').style.display = 'none';
    });
  }

  // View Receipt Preview Button in Form Dropzone
  const btnViewReceiptPreview = document.getElementById('btnViewReceiptPreview');
  if (btnViewReceiptPreview) {
    btnViewReceiptPreview.addEventListener('click', (e) => {
      e.stopPropagation();
      const imgData = document.getElementById('paymentProofImageData').value;
      const fName = document.getElementById('paymentProofImageName').value || 'Receipt Preview';
      if (imgData) openReceiptLightbox(imgData, fName);
    });
  }

  // Bank Pills Quick Selector
  document.querySelectorAll('#paymentProofBankPills .bank-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#paymentProofBankPills .bank-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      const bankName = pill.getAttribute('data-bank');
      document.getElementById('paymentProofBankInput').value = bankName;
    });
  });

  // Paste Reference Number Helper
  const btnPasteRef = document.getElementById('btnPastePaymentRef');
  if (btnPasteRef) {
    btnPasteRef.addEventListener('click', async () => {
      try {
        if (navigator.clipboard && navigator.clipboard.readText) {
          const text = await navigator.clipboard.readText();
          if (text) {
            document.getElementById('paymentProofRefInput').value = text.trim();
            showToast(appState.settings.language === 'bm' ? 'No. Rujukan berjaya ditampal!' : 'Reference No. pasted!');
            return;
          }
        }
      } catch (err) {
        console.warn('Clipboard read error:', err);
      }
      document.getElementById('paymentProofRefInput').focus();
    });
  }

  // Payment Proof Type Selector Change
  const payTypeSelect = document.getElementById('paymentProofTypeSelect');
  if (payTypeSelect) {
    payTypeSelect.addEventListener('change', () => {
      const type = payTypeSelect.value;
      const bId = document.getElementById('paymentProofBookingId').value;
      const booking = appState.bookings.find(b => b.id === bId);
      
      const monthGroup = document.getElementById('paymentProofMonthIndexGroup');
      if (monthGroup) {
        monthGroup.style.display = (type === 'monthly_rent') ? 'block' : 'none';
      }

      if (booking) {
        let amt = 0;
        if (type === 'deposit') {
          amt = booking.depositPaid > 0 ? booking.depositPaid : Math.round(booking.totalAmount * (appState.settings.defaultDepositPct || 30) / 100);
        } else if (type === 'balance') {
          amt = booking.balance > 0 ? booking.balance : booking.totalAmount;
        } else if (type === 'full') {
          amt = booking.totalAmount;
        } else if (type === 'monthly_rent') {
          amt = booking.monthlyRate || 0;
        } else if (type === 'security_deposit') {
          amt = booking.securityDeposit || booking.utilitiesDeposit || 0;
        } else {
          amt = booking.balance > 0 ? booking.balance : 0;
        }
        document.getElementById('paymentProofAmountInput').value = amt;
      }
    });
  }

  // Save Payment Proof Form Submit
  const paymentProofForm = document.getElementById('paymentProofForm');
  if (paymentProofForm) {
    paymentProofForm.addEventListener('submit', handleSavePaymentProof);
  }

  // ==========================================
  // Promotional Media & Marketing Hub Listeners
  // ==========================================
  const btnOpenPromo = document.getElementById('btnOpenPromoMedia');
  if (btnOpenPromo) btnOpenPromo.addEventListener('click', () => openPromotionalMediaModal());

  const btnOpenPromoSettings = document.getElementById('btnOpenPromoMediaSettings');
  if (btnOpenPromoSettings) btnOpenPromoSettings.addEventListener('click', () => openPromotionalMediaModal());

  const btnClosePromo = document.getElementById('btnClosePromotionalMediaModal');
  if (btnClosePromo) btnClosePromo.addEventListener('click', closeAllModals);

  const btnAddPromo = document.getElementById('btnAddNewPromoMediaModal');
  if (btnAddPromo) btnAddPromo.addEventListener('click', () => openPromoMediaEditModal());

  const btnEmptyAddPromo = document.getElementById('btnEmptyAddPromoMedia');
  if (btnEmptyAddPromo) btnEmptyAddPromo.addEventListener('click', () => openPromoMediaEditModal());

  const btnClosePromoEdit = document.getElementById('btnClosePromoMediaEditModal');
  if (btnClosePromoEdit) btnClosePromoEdit.addEventListener('click', closeAllModals);

  const btnCancelPromoEdit = document.getElementById('btnCancelPromoMediaEdit');
  if (btnCancelPromoEdit) btnCancelPromoEdit.addEventListener('click', closeAllModals);

  const promoForm = document.getElementById('promoMediaEditForm');
  if (promoForm) promoForm.addEventListener('submit', savePromoMediaItem);

  // Promo Property Filter Change
  const promoPropFilter = document.getElementById('promoPropertyFilter');
  if (promoPropFilter) {
    promoPropFilter.addEventListener('change', (e) => {
      appState.selectedPromoPropertyId = e.target.value;
      renderPromotionalMediaList();
    });
  }

  // Promo Category Pills
  document.querySelectorAll('#promoCategoryFilter .cal-mode-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#promoCategoryFilter .cal-mode-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      appState.selectedPromoCategory = pill.getAttribute('data-category');
      renderPromotionalMediaList();
    });
  });

  // Promo Search Input
  const promoSearchInput = document.getElementById('promoSearchInput');
  if (promoSearchInput) {
    promoSearchInput.addEventListener('input', (e) => {
      appState.promoSearchQuery = e.target.value;
      renderPromotionalMediaList();
    });
  }

  // Promo Image File Upload Dropzone
  const promoDropzone = document.getElementById('promoImageDropzone');
  const promoFileInput = document.getElementById('promoMediaFileInput');
  if (promoDropzone && promoFileInput) {
    promoDropzone.addEventListener('click', (e) => {
      if (e.target.closest('#btnRemovePromoImage') || e.target.closest('#btnViewPromoImagePreview')) return;
      promoFileInput.click();
    });

    ['dragenter', 'dragover'].forEach(eventName => {
      promoDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        promoDropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      promoDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        promoDropzone.classList.remove('dragover');
      });
    });

    promoDropzone.addEventListener('drop', (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        handlePromoImageFileSelected(e.dataTransfer.files[0]);
      }
    });

    promoFileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files.length > 0) {
        handlePromoImageFileSelected(e.target.files[0]);
      }
    });
  }

  // Remove Promo Image Button
  const btnRemovePromoImg = document.getElementById('btnRemovePromoImage');
  if (btnRemovePromoImg) {
    btnRemovePromoImg.addEventListener('click', (e) => {
      e.stopPropagation();
      document.getElementById('promoMediaImageData').value = '';
      document.getElementById('promoMediaFileInput').value = '';
      document.getElementById('promoImagePreviewImg').src = '';
      document.getElementById('promoImageDropPrompt').style.display = 'block';
      document.getElementById('promoImagePreviewContainer').style.display = 'none';
    });
  }

  // View Promo Image Preview in Edit Modal
  const btnViewPromoPreview = document.getElementById('btnViewPromoImagePreview');
  if (btnViewPromoPreview) {
    btnViewPromoPreview.addEventListener('click', (e) => {
      e.stopPropagation();
      const imgData = document.getElementById('promoMediaImageData').value;
      const title = document.getElementById('promoMediaTitleInput').value || 'Image Preview';
      if (imgData) openReceiptLightbox(imgData, title);
    });
  }

  // Preset Template Button in Promo Edit Form
  const btnInsertPitch = document.getElementById('btnInsertPitchPreset');
  if (btnInsertPitch) btnInsertPitch.addEventListener('click', insertPromoPitchTemplate);

  // WhatsApp Quick Send Modal Listeners
  const btnClosePromoWa = document.getElementById('btnClosePromoWaQuickModal');
  if (btnClosePromoWa) btnClosePromoWa.addEventListener('click', closeAllModals);

  const btnCancelPromoWa = document.getElementById('btnCancelPromoWaQuick');
  if (btnCancelPromoWa) btnCancelPromoWa.addEventListener('click', closeAllModals);

  const btnExecutePromoWa = document.getElementById('btnExecutePromoWaSend');
  if (btnExecutePromoWa) btnExecutePromoWa.addEventListener('click', executePromoWaSend);

  const promoWaRecipient = document.getElementById('promoWaRecipientSelect');
  if (promoWaRecipient) {
    promoWaRecipient.addEventListener('change', (e) => {
      const isCustom = e.target.value === 'custom';
      const customGroup = document.getElementById('promoWaCustomPhoneGroup');
      const customInput = document.getElementById('promoWaCustomPhoneInput');
      if (customGroup) customGroup.style.display = isCustom ? 'block' : 'none';
      if (!isCustom && customInput) customInput.value = e.target.value;
    });
  }

  // WhatsApp Modal Attach Button
  const btnAttachPromo = document.getElementById('btnAttachPromoMediaWa');
  if (btnAttachPromo) btnAttachPromo.addEventListener('click', attachPromoMediaToWaMessage);

  // Universal Modal Dismissal: Click outside on backdrop or press Escape
  document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        closeAllModals();
      }
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeAllModals();
    }
  });

  // Setup OCR Receipt & Bill Scanner Listeners
  try {
    setupOcrEventListeners();
  } catch (ocrInitErr) {
    console.warn('OCR listeners init notice:', ocrInitErr);
  }

  // Setup Smart WhatsApp Chat Import Listeners
  try {
    setupTenantChatEventListeners();
  } catch (chatInitErr) {
    console.warn('Tenant Chat Import listeners init notice:', chatInitErr);
  }
}

function applyDepositPreset(pct, targetStatus) {
  const checkInVal = document.getElementById('bookingCheckIn').value;
  const checkOutVal = document.getElementById('bookingCheckOut').value;
  const rateVal = parseFloat(document.getElementById('bookingNightlyRate').value) || 0;
  const cleanVal = parseFloat(document.getElementById('bookingCleaningFee').value) || 0;

  let nights = 0;
  if (checkInVal && checkOutVal && checkInVal < checkOutVal) {
    nights = calcNightsBetween(checkInVal, checkOutVal);
  }

  const total = (nights * rateVal) + cleanVal;
  const depositAmount = Math.round(total * pct * 100) / 100;
  document.getElementById('bookingDepositPaid').value = depositAmount;
  if (targetStatus) {
    document.getElementById('bookingStatusSelect').value = targetStatus;
    const validityGroup = document.getElementById('bookingQuotationValidityGroup');
    if (validityGroup) {
      validityGroup.style.display = targetStatus === 'quotation' ? 'block' : 'none';
    }
  }
}

function handleSaveBankDetails() {
  appState.settings.bankName = document.getElementById('settingBankNameInput').value.trim() || 'Maybank';
  appState.settings.bankAccNum = document.getElementById('settingBankAccNumInput').value.trim() || '';
  appState.settings.bankAccHolder = document.getElementById('settingBankAccHolderInput').value.trim() || '';
  appState.settings.duitNow = document.getElementById('settingDuitNowInput').value.trim() || '';
  saveToStorage();
  showToast(t('Bank & payment details saved!'));
}

// ==========================================================================
// LANGUAGE / I18N SYSTEM
// ==========================================================================

function toggleLanguage() {
  const currentLang = appState.settings.language || 'en';
  const newLang = currentLang === 'en' ? 'bm' : 'en';
  setLanguage(newLang);
}

function setLanguage(lang) {
  appState.settings.language = lang;
  saveToStorage();
  applyLanguageUI();
  renderApp();
  showToast(lang === 'bm' ? '🇲🇾 Bahasa Melayu diaktifkan!' : '🇬🇧 English language activated!');
}

function applyLanguageUI() {
  const lang = appState.settings.language || 'en';

  // 1. Scan and translate all elements with data-i18n
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (key) {
      el.textContent = t(key);
    }
  });

  // 2. Scan and translate all elements with data-i18n-placeholder
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (key) {
      el.placeholder = t(key);
    }
  });

  // 3. Header language pill
  const langLabel = document.getElementById('currentLangLabel');
  if (langLabel) langLabel.textContent = lang.toUpperCase();

  // 4. Update language dropdown in settings
  const langSelect = document.getElementById('settingLanguageSelect');
  if (langSelect && langSelect.value !== lang) {
    langSelect.value = lang;
  }

  // 5. Header Subtitle
  const dateSub = document.getElementById('currentDateStr');
  if (dateSub) {
    const locale = lang === 'bm' ? 'ms-MY' : 'en-US';
    dateSub.textContent = new Date().toLocaleDateString(locale, { weekday: 'short', month: 'short', day: 'numeric' });
  }

  // 6. Navigation items
  const navItems = document.querySelectorAll('.bottom-nav .nav-item');
  if (navItems.length >= 6) {
    navItems[0].querySelector('span').textContent = t('nav_today');
    navItems[1].querySelector('span').textContent = t('nav_calendar');
    navItems[2].querySelector('span').textContent = t('nav_bookings');
    navItems[3].querySelector('span').textContent = t('nav_turnovers');
    navItems[4].querySelector('span').textContent = t('nav_finances');
    navItems[5].querySelector('span').textContent = t('nav_settings');
  }

  // 7. Booking status filter pills
  const filterPills = document.querySelectorAll('#bookingStatusFilters .filter-pill');
  if (filterPills.length >= 7) {
    filterPills[0].textContent = t('filter_all');
    filterPills[1].textContent = t('filter_quotations');
    filterPills[2].textContent = t('filter_booked');
    filterPills[3].textContent = t('filter_confirmed');
    filterPills[4].textContent = t('filter_inhouse');
    filterPills[5].textContent = t('filter_completed');
    filterPills[6].textContent = t('filter_blocked');
  }

  // 8. Calendar Weekdays
  const calWeekdays = document.querySelectorAll('.cal-weekdays span');
  if (calWeekdays.length === 7) {
    const dayKeys = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
    calWeekdays.forEach((span, idx) => {
      span.textContent = t(dayKeys[idx]);
    });
  }

  // 9. WhatsApp Template tabs
  const waTabs = document.querySelectorAll('.wa-template-selector .wa-tab-btn');
  waTabs.forEach(btn => {
    const template = btn.getAttribute('data-template');
    if (template === 'quotation') btn.textContent = t('wa_tab_quotation');
    else if (template === 'deposit_receipt') btn.textContent = t('wa_tab_deposit');
    else if (template === 'checkin_reminder') btn.textContent = t('wa_tab_checkin');
    else if (template === 'full_receipt') btn.textContent = t('wa_tab_full');
    else if (template === 'monthly_invoice') btn.textContent = t('wa_tab_invoice');
    else if (template === 'monthly_rent_receipt') btn.textContent = t('wa_tab_rent_receipt');
    else if (template === 'refund_receipt') btn.textContent = t('wa_tab_refund');
    else if (template === 'checkout') btn.textContent = t('wa_tab_checkout');
    else if (template === 'cleaner') btn.textContent = t('wa_tab_cleaner');
    else if (template === 'payment') btn.textContent = t('wa_tab_payment');
  });

  // 10. Rental Type segment buttons
  const dailySeg = document.querySelector('#rentalTypeSegmented [data-type="daily"]');
  const monthlySeg = document.querySelector('#rentalTypeSegmented [data-type="monthly"]');
  if (dailySeg) dailySeg.innerHTML = `<i class="fa-solid fa-sun"></i> ${t('type_daily')}`;
  if (monthlySeg) monthlySeg.innerHTML = `<i class="fa-solid fa-calendar-days"></i> ${t('type_monthly')}`;

  // 11. Booking status dropdown options
  const statusSelect = document.getElementById('bookingStatusSelect');
  if (statusSelect && statusSelect.options.length >= 7) {
    statusSelect.options[0].text = lang === 'bm' ? '📋 Sebut Harga / Quotation' : '📋 Quotation / Sebut Harga';
    statusSelect.options[1].text = lang === 'bm' ? '🟡 Ditempah (Deposit Dibayar)' : '🟡 Booked (Deposit Paid)';
    statusSelect.options[2].text = lang === 'bm' ? '🟢 Disahkan (Bayar Penuh)' : '🟢 Confirmed (Fully Paid)';
    statusSelect.options[3].text = lang === 'bm' ? '🔑 Sedang Menginap (Check-In)' : '🔑 In-House (Checked In)';
    statusSelect.options[4].text = lang === 'bm' ? '🏁 Selesai / Tamat Sewaan' : '🏁 Checked Out / Tenancy Ended';
    statusSelect.options[5].text = lang === 'bm' ? '🚫 Disekat / Penyelenggaraan' : '🚫 Blocked / Maintenance';
    statusSelect.options[6].text = lang === 'bm' ? '❌ Dibatalkan' : '❌ Cancelled';
  }

  // 12. Property Type dropdown options
  const propTypeSelect = document.getElementById('propertyTypeSelect');
  if (propTypeSelect && propTypeSelect.options.length >= 5) {
    propTypeSelect.options[0].text = t('cat_entire');
    propTypeSelect.options[1].text = t('cat_master');
    propTypeSelect.options[2].text = t('cat_medium');
    propTypeSelect.options[3].text = t('cat_single');
    propTypeSelect.options[4].text = t('cat_studio');
  }

  // 13. Expense Category dropdown options
  const expCatSelect = document.getElementById('expenseCategorySelect');
  if (expCatSelect && expCatSelect.options.length >= 6) {
    expCatSelect.options[0].text = t('cat_cleaning');
    expCatSelect.options[1].text = t('cat_utilities');
    expCatSelect.options[2].text = t('cat_supplies');
    expCatSelect.options[3].text = t('cat_maintenance');
    expCatSelect.options[4].text = t('cat_commission');
    expCatSelect.options[5].text = t('cat_other');
  }
}

// ==========================================================================
// LICENSE & SERVER-SIDE CRYPTOGRAPHIC ENGINE (WebCrypto ECDSA P-256)
// ==========================================================================

function normalizePhoneNumber(rawPhone) {
  if (!rawPhone) return '';
  let digits = rawPhone.toString().replace(/[^0-9]/g, '');
  if (digits.startsWith('01') && digits.length >= 10 && digits.length <= 11) {
    digits = '6' + digits;
  } else if (digits.startsWith('0') && digits.length >= 9) {
    digits = '6' + digits;
  }
  return digits;
}

/**
 * Strict License Phone Normalizer (matches server rules):
 * - digits = remove all non-digits
 * - drop leading "00"
 * - if starting with "60", drop ONE extra "0" directly after 60 (60012... -> 6012...)
 * - else if starting with "0", replace with "60"
 * - else if starting with "1" and has 9 or 10 digits, prefix "60"
 * - reject results < 9 or > 15 digits
 */
function normalizeLicensePhone(raw) {
  if (!raw && raw !== 0) return '';
  let digits = String(raw).replace(/\D/g, '');
  if (digits.startsWith('00')) {
    digits = digits.slice(2);
  }
  if (digits.startsWith('60')) {
    if (digits.startsWith('600')) {
      digits = '60' + digits.slice(3);
    }
  } else if (digits.startsWith('0')) {
    digits = '60' + digits.slice(1);
  } else if (digits.startsWith('1') && (digits.length === 9 || digits.length === 10)) {
    digits = '60' + digits;
  }
  if (digits.length < 9 || digits.length > 15) {
    return '';
  }
  return digits;
}

function formatDisplayLicensePhone(raw) {
  if (!raw) return '';
  const clean = normalizeLicensePhone(raw);
  if (!clean) return '';
  if (clean.startsWith('60')) {
    if (clean.length === 11) {
      return '+60 ' + clean.slice(2, 4) + '-' + clean.slice(4, 7) + ' ' + clean.slice(7);
    }
    if (clean.length === 12) {
      return '+60 ' + clean.slice(2, 4) + '-' + clean.slice(4, 8) + ' ' + clean.slice(8);
    }
    if (clean.length === 10) {
      return '+60 ' + clean.slice(2, 3) + '-' + clean.slice(3, 6) + ' ' + clean.slice(6);
    }
    return '+60 ' + clean.slice(2);
  }
  return '+' + clean;
}

function updateLicensePhonePreview() {
  const phoneInput = document.getElementById('licensePhoneInput');
  const previewContainer = document.getElementById('licensePhonePreviewContainer');
  const previewEl = document.getElementById('licensePhonePreview');
  if (!phoneInput || !previewContainer || !previewEl) return;

  const raw = phoneInput.value || '';
  const formatted = formatDisplayLicensePhone(raw);

  if (!raw.trim() || !formatted) {
    previewContainer.style.display = 'none';
    previewEl.textContent = '';
  } else {
    previewContainer.style.display = 'flex';
    previewEl.textContent = formatted;
  }
}

/**
 * Intelligent License Key Extractor:
 * - Uppercase
 * - Strip zero-width and invisible characters
 * - Treat dash-like characters (– — − ‐ ‑ etc.) as hyphens
 * - Searches for STAY followed by 20 chars [A-Z2-9] (excluding 0, 1, I, O)
 * - Allows spaces or no hyphens between blocks
 * - Extracts first matching canonical key
 */
function extractLicenseKey(raw) {
  if (!raw || typeof raw !== 'string') return null;
  let s = raw.toUpperCase();
  s = s.replace(/[\u200B-\u200D\uFEFF\u200E\u200F\u202A-\u202E\u2060-\u206F]/g, '');
  s = s.replace(/[\u2010\u2011\u2012\u2013\u2014\u2015\u2212\uFE63\uFF0D]/g, '-');

  const re = /(?:^|[^A-Z0-9])STAY(?:[\s-]*[A-Z2-9]){20}(?![A-Z0-9])/g;
  const match = s.match(re);
  if (!match || match.length === 0) return null;

  const rawMatch = match[0];
  const stayIdx = rawMatch.indexOf('STAY');
  const cleanChars = rawMatch.slice(stayIdx).replace(/[^A-Z2-9]/g, '');
  if (cleanChars.length !== 24 || !cleanChars.startsWith('STAY')) return null;

  return `STAY-${cleanChars.slice(4, 9)}-${cleanChars.slice(9, 14)}-${cleanChars.slice(14, 19)}-${cleanChars.slice(19, 24)}`;
}

function cleanLicenseKey(rawKey) {
  const extracted = extractLicenseKey(rawKey);
  if (extracted) return extracted;
  if (typeof rawKey === 'string' && rawKey.trim().length >= 8 && /^[A-Z0-9-]+$/i.test(rawKey.trim())) {
    return rawKey.trim().toUpperCase();
  }
  return null;
}

function formatLicenseKeyPreview(rawKey) {
  if (!rawKey || typeof rawKey !== 'string') return '';
  const extracted = extractLicenseKey(rawKey);
  if (extracted) return extracted;

  let s = rawKey.toUpperCase();
  s = s.replace(/[\u200B-\u200D\uFEFF\u200E\u200F\u202A-\u202E\u2060-\u206F]/g, '');
  s = s.replace(/[\u2010\u2011\u2012\u2013\u2014\u2015\u2212\uFE63\uFF0D-]/g, '-');
  const stayIdx = s.indexOf('STAY');
  if (stayIdx !== -1) {
    s = s.slice(stayIdx);
  }
  s = s.replace(/[^A-Z2-9]/g, '');
  if (!s) return '';
  const parts = [];
  if (s.length > 0) parts.push(s.slice(0, 4));
  if (s.length > 4) parts.push(s.slice(4, 9));
  if (s.length > 9) parts.push(s.slice(9, 14));
  if (s.length > 14) parts.push(s.slice(14, 19));
  if (s.length > 19) parts.push(s.slice(19, 24));
  return parts.join('-');
}

function updateLicenseKeyPreview() {
  const keyInput = document.getElementById('licenseKeyInput');
  const previewContainer = document.getElementById('licenseKeyPreviewContainer');
  const previewEl = document.getElementById('licenseKeyPreview');
  if (!keyInput || !previewContainer || !previewEl) return;

  const raw = keyInput.value || '';
  const extracted = extractLicenseKey(raw);

  // If input contains a valid key embedded inside a larger message or unformatted blocks,
  // extract and canonicalize the input value
  if (extracted && raw.trim() !== extracted && (raw.length > 29 || raw.indexOf(' ') !== -1 || raw.indexOf('\n') !== -1 || !raw.startsWith('STAY-'))) {
    keyInput.value = extracted;
  }

  const currentVal = keyInput.value || '';
  const preview = formatLicenseKeyPreview(currentVal);
  const isFullClean = cleanLicenseKey(currentVal);

  if (!currentVal.trim() || !preview) {
    previewContainer.style.display = 'none';
    previewEl.textContent = '';
  } else {
    previewContainer.style.display = 'flex';
    previewEl.textContent = preview;
    if (isFullClean) {
      previewEl.style.color = 'var(--success, #16a34a)';
    } else {
      previewEl.style.color = 'var(--primary, #3b82f6)';
    }
  }
}

async function handlePasteLicenseKey() {
  const isBM = appState.settings.language === 'bm';
  const keyInput = document.getElementById('licenseKeyInput');
  if (!keyInput) return;

  let pastedText = '';
  if (navigator.clipboard && typeof navigator.clipboard.readText === 'function') {
    try {
      pastedText = await navigator.clipboard.readText();
    } catch (err) {
      console.warn('Clipboard readText failed or permission denied:', err);
    }
  }

  if (pastedText && pastedText.trim()) {
    const extracted = extractLicenseKey(pastedText);
    keyInput.value = extracted || pastedText.trim();
    updateLicenseKeyPreview();
    showToast(isBM ? '📋 Kunci ditampal dari papan keratan!' : '📋 Key pasted from clipboard!');
    return;
  }

  // Friendly fallback if clipboard API is blocked, denied, or returns empty
  const fallback = prompt(isBM
    ? 'Tampal kunci lesen atau mesej WhatsApp anda di sini:'
    : 'Paste your license key or WhatsApp message here:');
  if (fallback && fallback.trim()) {
    const extracted = extractLicenseKey(fallback);
    keyInput.value = extracted || fallback.trim();
    updateLicenseKeyPreview();
    showToast(isBM ? '📋 Kunci dimasukkan!' : '📋 Key entered!');
  }
}

function getOrCreateDeviceId() {
  let id = localStorage.getItem(STORAGE_KEYS.DEVICE_ID);
  if (!id || typeof id !== 'string' || id.length < 8 || id.length > 64 || !/^[A-Za-z0-9_-]+$/.test(id)) {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      id = crypto.randomUUID();
    } else {
      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      id = 'dev-' + Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
    }
    localStorage.setItem(STORAGE_KEYS.DEVICE_ID, id);
  }
  return id;
}

function base64UrlToString(b64u) {
  if (!b64u) return '';
  let b64 = b64u.replace(/-/g, '+').replace(/_/g, '/');
  while (b64.length % 4) b64 += '=';
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

function base64UrlToArrayBuffer(b64u) {
  if (!b64u) return new ArrayBuffer(0);
  let b64 = b64u.replace(/-/g, '+').replace(/_/g, '/');
  while (b64.length % 4) b64 += '=';
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

let cachedCryptoPublicKey = null;
async function getCryptoPublicKey() {
  if (cachedCryptoPublicKey) return cachedCryptoPublicKey;
  if (!window.crypto || !window.crypto.subtle) {
    throw new Error('WebCrypto subtle is not supported in this environment');
  }
  const keyJwk = testOverridePublicKeyJwk || LICENSE_PUBLIC_KEY_JWK;
  cachedCryptoPublicKey = await window.crypto.subtle.importKey(
    'jwk',
    keyJwk,
    { name: 'ECDSA', namedCurve: 'P-256' },
    false,
    ['verify']
  );
  return cachedCryptoPublicKey;
}

async function verifyLicenseToken(token) {
  if (!token || typeof token !== 'string') {
    return { valid: false, error: 'Empty token' };
  }
  const parts = token.split('.');
  if (parts.length !== 3) {
    return { valid: false, error: 'Malformed token structure' };
  }

  const [encodedHeader, encodedPayload, encodedSignature] = parts;
  const dataToVerify = `${encodedHeader}.${encodedPayload}`;
  const signatureBytes = base64UrlToArrayBuffer(encodedSignature);

  try {
    const publicKey = await getCryptoPublicKey();
    const isValid = await window.crypto.subtle.verify(
      { name: 'ECDSA', hash: { name: 'SHA-256' } },
      publicKey,
      signatureBytes,
      new TextEncoder().encode(dataToVerify)
    );

    if (!isValid) {
      return { valid: false, error: 'Invalid cryptographic signature' };
    }

    const payload = JSON.parse(base64UrlToString(encodedPayload));
    return { valid: true, payload };
  } catch (err) {
    return { valid: false, error: err.message || 'Verification failed' };
  }
}

async function evaluateLicenseState() {
  const token = localStorage.getItem(STORAGE_KEYS.TOKEN);
  if (!token) {
    appState.isLicensed = false;
    appState.licenseToken = null;
    appState.licensePayload = null;
    appState.licenseDaysRemaining = 0;
    appState.proHubState = 'UNLICENSED';
    return { isLicensed: false };
  }

  const verification = await verifyLicenseToken(token);
  if (!verification.valid) {
    console.warn('[License Engine] Token rejected:', verification.error);
    localStorage.removeItem(STORAGE_KEYS.TOKEN);
    appState.isLicensed = false;
    appState.licenseToken = null;
    appState.licensePayload = null;
    appState.licenseDaysRemaining = 0;
    appState.proHubState = 'UNLICENSED';
    return { isLicensed: false, error: verification.error };
  }

  const payload = verification.payload;
  const currentDeviceId = getOrCreateDeviceId();

  // Enforce device-binding
  if (!payload.deviceId || payload.deviceId !== currentDeviceId) {
    console.warn('[License Engine] Token deviceId mismatch. Registered:', payload.deviceId, 'Current:', currentDeviceId);
    // Preserve token in localStorage; do not wipe out on deviceId fluctuation
    appState.isLicensed = false;
    appState.licenseToken = token;
    appState.licensePayload = payload;
    appState.licenseDaysRemaining = 0;
    appState.proHubState = 'DEVICE_RESET';
    return { isLicensed: false, error: 'DEVICE_MISMATCH' };
  }

  // Monotonic device clock verification (prevent backward clock rollback)
  const nowMs = Date.now();
  const savedLastSeen = localStorage.getItem(STORAGE_KEYS.LAST_SEEN_AT);
  if (savedLastSeen) {
    const lastSeenMs = parseInt(savedLastSeen, 10);
    // If device clock is earlier than lastSeenAt by more than 1 day (86400 * 1000 ms)
    if (!isNaN(lastSeenMs) && (lastSeenMs - nowMs > 86400 * 1000)) {
      console.warn('[License Engine] Device clock rolled back! lastSeenAt:', new Date(lastSeenMs), 'current:', new Date(nowMs));
      appState.isLicensed = false;
      appState.licenseToken = token;
      appState.licensePayload = payload;
      appState.licenseDaysRemaining = 0;
      appState.proHubState = 'CLOCK_ERROR';
      return { isLicensed: false, clockError: true };
    }
  }

  // Update last seen to current time if current time is >= lastSeen
  const lastSeenMs = savedLastSeen ? parseInt(savedLastSeen, 10) : 0;
  if (isNaN(lastSeenMs) || nowMs >= lastSeenMs) {
    localStorage.setItem(STORAGE_KEYS.LAST_SEEN_AT, nowMs.toString());
  }

  const nowSec = Math.floor(nowMs / 1000);
  const expSec = parseInt(payload.exp, 10) || 0;
  const daysRemaining = Math.max(0, Math.floor((expSec - nowSec) / 86400));

  appState.licenseToken = token;
  appState.licensePayload = payload;
  appState.licenseDaysRemaining = daysRemaining;

  if (nowSec > expSec) {
    // Token expired locally
    appState.isLicensed = false;
    appState.proHubState = 'NEEDS_RECONNECT';
    return { isLicensed: false, expired: true, daysRemaining: 0 };
  }

  // Token valid and unexpired
  appState.isLicensed = true;
  appState.proHubState = navigator.onLine ? 'ACTIVE' : 'OFFLINE';
  return { isLicensed: true, payload, daysRemaining };
}

function formatLicenseDate(sec, lang = 'en') {
  if (!sec) return '-';
  const d = new Date(sec * 1000);
  return d.toLocaleDateString(lang === 'bm' ? 'ms-MY' : 'en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}

function getLicenseErrorMessage(errorCode, lang = 'en') {
  const isBM = lang === 'bm';
  switch (errorCode) {
    case 'CLOCK_ERROR':
      return isBM
        ? 'Jam peranti anda tidak tepat (lebih awal daripada rekod sebelum ini). Sila betulkan tarikh & masa telefon anda atau sambung ke internet.'
        : 'Your device clock is earlier than previously recorded. Please set your device date and time correctly or connect to the internet.';
    case 'INVALID_CREDENTIALS':
      return isBM
        ? 'Kunci lesen atau nombor telefon WhatsApp tidak sah. Sila semak semula maklumat anda.'
        : 'Invalid license key or WhatsApp phone number. Please verify your details.';
    case 'REVOKED':
      return isBM
        ? 'Kunci lesen ini telah dibatalkan oleh pentadbir. Sila hubungi penjual di WhatsApp.'
        : 'This license key has been revoked. Please contact the seller on WhatsApp.';
    case 'DEVICE_LIMIT_REACHED':
      return isBM
        ? 'Had maksimum peranti telah dicapai untuk lesen ini. Sila hubungi penjual di WhatsApp untuk menetapkan semula senarai peranti.'
        : 'Maximum device limit reached for this license. Please contact the seller on WhatsApp to reset your registered devices.';
    case 'RATE_LIMITED':
      return isBM
        ? 'Terlalu banyak percubaan gagal dari alamat IP anda. Sila tunggu 15 minit sebelum mencuba lagi.'
        : 'Too many failed attempts from your IP address. Please wait 15 minutes before trying again.';
    case 'DEVICE_RESET':
      return isBM
        ? 'Pendaftaran peranti anda telah diset semula oleh pentadbir. Sila aktifkan semula menggunakan kunci lesen anda.'
        : 'Your device registration was reset by admin. Please re-activate using your license key.';
    case 'TOKEN_EXPIRED':
      return isBM
        ? 'Sesi lesen anda telah tamat tempoh lebih 30 hari. Sila aktifkan semula menggunakan kunci lesen anda.'
        : 'Your license session expired more than 30 days ago. Please re-activate with your license key.';
    case 'INVALID_TOKEN':
      return isBM
        ? 'Token pengesahan lesen tidak sah. Sila aktifkan semula aplikasi.'
        : 'The license verification token is invalid. Please re-activate.';
    case 'LICENSE_NOT_FOUND':
      return isBM
        ? 'Rekod lesen tidak dijumpai di pelayan. Sila pastikan kunci lesen anda sah.'
        : 'License record not found on the server. Please verify your license key.';
    case 'MISSING_FIELDS':
      return isBM
        ? 'Sila masukkan kedua-dua nombor telefon WhatsApp dan kunci lesen anda.'
        : 'Please enter both your WhatsApp phone number and license key.';
    case 'INVALID_DEVICE_ID':
      return isBM
        ? 'Pengesahan identiti peranti gagal. Sila muat semula halaman dan cuba lagi.'
        : 'Device identification check failed. Please refresh the page and try again.';
    case 'PAYLOAD_TOO_LARGE':
      return isBM
        ? 'Data permintaan terlalu besar. Sila cuba lagi.'
        : 'Request data was too large. Please try again.';
    case 'SERVER_ERROR':
      return isBM
        ? 'Pelayan lesen mengalami ralat sementara. Sila cuba sebentar lagi.'
        : 'The license server encountered a temporary error. Please try again in a few moments.';
    default:
      return isBM
        ? 'Tidak dapat menyambung ke pelayan lesen. Sila periksa sambungan internet anda.'
        : 'Unable to reach the license server. Please verify your internet connection.';
  }
}

async function activateWithServer(rawKey, rawPhone) {
  if (!rawKey || !rawPhone) {
    const err = new Error('Missing fields');
    err.code = 'MISSING_FIELDS';
    throw err;
  }

  const cleanKey = cleanLicenseKey(rawKey);
  if (!cleanKey) {
    const err = new Error('Invalid license key or WhatsApp phone number.');
    err.code = 'INVALID_CREDENTIALS';
    throw err;
  }
  const cleanPhone = normalizeLicensePhone(rawPhone);
  if (!cleanPhone) {
    const err = new Error('Invalid license key or WhatsApp phone number.');
    err.code = 'INVALID_CREDENTIALS';
    throw err;
  }
  const deviceId = getOrCreateDeviceId();

  const response = await fetch(`${LICENSE_API_URL}/activate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      key: cleanKey,
      phone: cleanPhone,
      deviceId: deviceId
    })
  });

  const data = await response.json().catch(() => ({ error: 'SERVER_ERROR' }));

  if (!response.ok || !data.success || !data.token) {
    const err = new Error(data.message || 'Activation failed');
    err.code = data.error || 'SERVER_ERROR';
    throw err;
  }

  localStorage.setItem(STORAGE_KEYS.TOKEN, data.token);
  appState.licenseToken = data.token;
  if (cleanPhone) {
    appState.settings.ownerPhone = '+' + cleanPhone;
  }

  const evalResult = await evaluateLicenseState();
  if (evalResult && evalResult.isLicensed === true) {
    localStorage.setItem('staymanager_license_key', cleanKey);
    localStorage.setItem('staymanager_license_phone', cleanPhone);
    localStorage.setItem('staymanager_license_v2', JSON.stringify({ key: cleanKey, phone: cleanPhone, isLicensed: true, activatedAt: new Date().toISOString() }));
    appState.licenseKey = cleanKey;
    saveToStorage();
  }
  return { ...data, evalResult };
}

function openLicenseModal() {
  const phoneInput = document.getElementById('licensePhoneInput');
  const keyInput = document.getElementById('licenseKeyInput');

  if (phoneInput) phoneInput.value = appState.settings.ownerPhone || '';
  if (keyInput) keyInput.value = appState.licenseKey || '';

  const errBox = document.getElementById('licenseActivationErrorBox');
  if (errBox) errBox.style.display = 'none';

  updateLicensePhonePreview();
  updateLicenseKeyPreview();

  document.getElementById('licenseModal').classList.add('active');
}

async function handleActivateLicenseSubmit(e) {
  e.preventDefault();
  const isBM = appState.settings.language === 'bm';
  const phoneInput = document.getElementById('licensePhoneInput');
  const keyInput = document.getElementById('licenseKeyInput');
  const submitBtn = document.getElementById('btnActivateLicenseSubmit');

  const inputPhone = phoneInput ? phoneInput.value.trim() : '';
  const rawKey = keyInput ? keyInput.value : '';

  const errBox = document.getElementById('licenseActivationErrorBox');
  if (errBox) errBox.style.display = 'none';

  if (!rawKey.trim() || !inputPhone) {
    alert(isBM 
      ? 'Sila masukkan nombor WhatsApp dan kunci lesen anda.' 
      : 'Please enter both your WhatsApp phone number and license key.');
    return;
  }

  const cleanKey = cleanLicenseKey(rawKey);
  const cleanPhone = normalizeLicensePhone(inputPhone);
  if (!cleanKey || !cleanPhone) {
    const friendlyMsg = getLicenseErrorMessage('INVALID_CREDENTIALS', isBM ? 'bm' : 'en');
    alert(`❌ ${friendlyMsg}`);
    return;
  }

  const originalBtnHtml = submitBtn ? submitBtn.innerHTML : '';
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> ${isBM ? 'Mengesahkan Lesen...' : 'Activating App...'}`;
  }

  try {
    const activateResult = await activateWithServer(cleanKey, inputPhone);

    // CRITICAL REQUIREMENT 1: Check appState.isLicensed after activateWithServer returns
    if (appState.isLicensed === true) {
      if (errBox) errBox.style.display = 'none';
      try { closeAllModals(); } catch (_) {}
      try { renderApp(); } catch (_) {}
      showToast(isBM ? '🎉 Tahniah! Lesen Pro berjaya diaktifkan!' : '🎉 Congratulations! Pro License activated successfully!');
      return;
    }

    // If appState.isLicensed is false, do NOT show success toast!
    let refCode = 'ERR_VERIFY_FAILED';
    let errTitleEn = 'Verification Failed';
    let errTitleBm = 'Pengesahan Lesen Gagal';
    let errMsgEn = 'The license could not be activated and verified on this device.';
    let errMsgBm = 'Lesen tidak dapat diaktifkan dan disahkan pada peranti ini.';

    const isSecure = (typeof window !== 'undefined' && window.isSecureContext !== false);
    const hasCrypto = (typeof window !== 'undefined' && window.crypto && window.crypto.subtle);

    if (!isSecure || !hasCrypto) {
      refCode = !isSecure ? 'ERR_INSECURE_CONTEXT' : 'ERR_CRYPTO_UNAVAILABLE';
      errTitleEn = 'Secure Connection Needed';
      errTitleBm = 'Sambungan Selamat Diperlukan';
      errMsgEn = 'A secure connection (HTTPS) is required to verify cryptographic license keys on this device. Please open the app over HTTPS or localhost.';
      errMsgBm = 'Sambungan selamat (HTTPS) diperlukan untuk mengesahkan kunci lesen kriptografi pada peranti ini. Sila buka aplikasi melalui HTTPS atau localhost.';
    } else if (appState.proHubState === 'CLOCK_ERROR' || activateResult?.evalResult?.clockError) {
      refCode = 'ERR_CLOCK_ROLLBACK';
      errTitleEn = 'Device Clock Problem';
      errTitleBm = 'Masalah Jam Peranti';
      errMsgEn = 'Your device date and time is earlier than previously recorded. Please set your device clock to the correct time and try again.';
      errMsgBm = 'Tarikh dan masa peranti anda tidak tepat (lebih awal daripada rekod terdahulu). Sila betulkan jam peranti anda dan cuba lagi.';
    } else if (activateResult?.evalResult?.expired || appState.proHubState === 'NEEDS_RECONNECT') {
      refCode = 'ERR_TOKEN_EXPIRED';
      errTitleEn = 'Activation Token Expired';
      errTitleBm = 'Token Pengaktifan Tamat Tempoh';
      errMsgEn = 'The activation token received has expired. Please check your internet connection and try activating again.';
      errMsgBm = 'Token pengaktifan yang diterima telah tamat tempoh. Sila semak sambungan internet anda dan cuba aktifkan semula.';
    } else if (activateResult?.evalResult?.error === 'DEVICE_MISMATCH' || (appState.licensePayload && appState.licensePayload.deviceId !== getOrCreateDeviceId())) {
      refCode = 'ERR_DEVICE_MISMATCH';
      errTitleEn = 'Device Mismatch';
      errTitleBm = 'Peranti Tidak Sepadan';
      errMsgEn = 'This license token could not be verified on this device due to a device ID mismatch. Please contact the seller if you changed phones.';
      errMsgBm = 'Token lesen ini tidak dapat disahkan pada peranti ini kerana ID peranti tidak sepadan. Sila hubungi penjual jika anda menukar telefon.';
    } else {
      refCode = 'ERR_SIGNATURE_INVALID';
      errTitleEn = 'License Verification Failed';
      errTitleBm = 'Pengesahan Lesen Gagal';
      errMsgEn = 'The license token signature could not be verified on this device. Please check your license key or contact the seller.';
      errMsgBm = 'Tandatangan token lesen tidak dapat disahkan pada peranti ini. Sila semak kunci lesen anda atau hubungi penjual.';
    }

    const errTitleEl = document.getElementById('licenseActivationErrorTitle');
    const errCodeEl = document.getElementById('licenseActivationErrorCode');
    const errMsgEl = document.getElementById('licenseActivationErrorMsg');
    const btnContact = document.getElementById('btnContactSellerActivationError');
    const btnContactText = document.getElementById('btnContactSellerActivationErrorText');

    if (errBox) {
      if (errTitleEl) errTitleEl.textContent = isBM ? errTitleBm : errTitleEn;
      if (errCodeEl) errCodeEl.textContent = refCode;
      if (errMsgEl) errMsgEl.textContent = isBM ? errMsgBm : errMsgEn;
      if (btnContactText) btnContactText.textContent = isBM ? 'Hubungi Penjual di WhatsApp' : 'Contact Seller on WhatsApp';
      if (btnContact) {
        btnContact.onclick = () => handleContactSellerWhatsApp('verification_failed', refCode);
      }
      errBox.style.display = 'block';
      if (typeof errBox.scrollIntoView === 'function') {
        errBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    } else {
      alert(`❌ [${refCode}] ${isBM ? errMsgBm : errMsgEn}`);
    }
  } catch (err) {
    const errorCode = err.code || 'SERVER_ERROR';
    const friendlyMsg = getLicenseErrorMessage(errorCode, isBM ? 'bm' : 'en');

    if (errorCode === 'REVOKED' || errorCode === 'DEVICE_LIMIT_REACHED') {
      if (confirm(`${friendlyMsg}\n\n${isBM ? 'Adakah anda mahu menghubungi penjual melalui WhatsApp sekarang?' : 'Would you like to contact the seller on WhatsApp now?'}`)) {
        handleContactSellerWhatsApp(errorCode === 'REVOKED' ? 'revoked' : 'device_limit_reached');
      }
    } else {
      const errBox = document.getElementById('licenseActivationErrorBox');
      const errTitleEl = document.getElementById('licenseActivationErrorTitle');
      const errCodeEl = document.getElementById('licenseActivationErrorCode');
      const errMsgEl = document.getElementById('licenseActivationErrorMsg');
      const btnContact = document.getElementById('btnContactSellerActivationError');
      const btnContactText = document.getElementById('btnContactSellerActivationErrorText');

      if (errBox) {
        if (errTitleEl) errTitleEl.textContent = isBM ? 'Ralat Pengaktifan' : 'Activation Error';
        if (errCodeEl) errCodeEl.textContent = errorCode;
        if (errMsgEl) errMsgEl.textContent = friendlyMsg;
        if (btnContactText) btnContactText.textContent = isBM ? 'Hubungi Penjual di WhatsApp' : 'Contact Seller on WhatsApp';
        if (btnContact) {
          btnContact.onclick = () => handleContactSellerWhatsApp('general', errorCode);
        }
        errBox.style.display = 'block';
        if (typeof errBox.scrollIntoView === 'function') {
          errBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      } else {
        alert(`❌ ${friendlyMsg}`);
      }
    }
  } finally {
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalBtnHtml;
    }
  }
}

async function checkAndRefreshTokenSilently(forceCheck = false) {
  if (!navigator.onLine) {
    if (appState.isLicensed) appState.proHubState = 'OFFLINE';
    return;
  }

  const token = localStorage.getItem(STORAGE_KEYS.TOKEN);
  if (!token) return;

  await evaluateLicenseState();
  const payload = appState.licensePayload;
  if (!payload) return;

  const nowSec = Math.floor(Date.now() / 1000);
  const tokenAgeSec = nowSec - (payload.iat || 0);
  const isOlderThan7Days = tokenAgeSec >= 7 * 86400;

  if (!isOlderThan7Days && !forceCheck && appState.isLicensed) {
    return;
  }

  try {
    const response = await fetch(`${LICENSE_API_URL}/refresh`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ token })
    });

    const data = await response.json().catch(() => ({ error: 'SERVER_ERROR' }));
    const isBM = appState.settings.language === 'bm';

    if (response.ok && data.success && data.token) {
      localStorage.setItem(STORAGE_KEYS.TOKEN, data.token);
      localStorage.setItem(STORAGE_KEYS.LAST_SEEN_AT, Date.now().toString());
      appState.licenseToken = data.token;
      await evaluateLicenseState();
      appState.proHubState = 'ACTIVE';
      renderApp();
      console.log('[License Engine] Token refreshed silently. Valid for 60 days.');
      return;
    }

    const errorCode = data.error || 'SERVER_ERROR';

    if (errorCode === 'REVOKED') {
      appState.isLicensed = false;
      appState.licenseToken = null;
      localStorage.removeItem(STORAGE_KEYS.TOKEN);
      appState.proHubState = 'REVOKED';
      renderApp();
      alert(isBM 
        ? '🚫 Kunci lesen anda telah dibatalkan oleh pentadbir. Sila hubungi penjual di WhatsApp.' 
        : '🚫 Your license has been revoked by admin. Please contact the seller on WhatsApp.');
      return;
    }

    if (errorCode === 'DEVICE_RESET') {
      appState.isLicensed = false;
      localStorage.removeItem(STORAGE_KEYS.TOKEN);
      appState.proHubState = 'DEVICE_RESET';
      renderApp();
      alert(isBM 
        ? '🔄 Pendaftaran peranti anda telah diset semula. Sila aktifkan semula menggunakan kunci lesen anda.' 
        : '🔄 Your device registration was reset by admin. Please re-activate using your license key.');
      openLicenseModal();
      return;
    }

    if (errorCode === 'TOKEN_EXPIRED') {
      appState.isLicensed = false;
      localStorage.removeItem(STORAGE_KEYS.TOKEN);
      appState.proHubState = 'NEEDS_RECONNECT';
      renderApp();
      alert(isBM 
        ? '⏱️ Sesi lesen anda telah tamat tempoh lebih 30 hari. Sila aktifkan semula menggunakan kunci lesen anda.' 
        : '⏱️ Your license session has expired. Please re-activate using your license key.');
      openLicenseModal();
      return;
    }

    if (errorCode === 'LICENSE_NOT_FOUND' || errorCode === 'INVALID_TOKEN') {
      appState.isLicensed = false;
      localStorage.removeItem(STORAGE_KEYS.TOKEN);
      appState.proHubState = 'UNLICENSED';
      renderApp();
      return;
    }
  } catch (netErr) {
    console.warn('[License Engine] Network error during refresh:', netErr);
    // Network error must NOT lock Pro if local token is still within validity
    if (appState.isLicensed) {
      appState.proHubState = 'SERVER_UNREACHABLE';
    }
  }
}

function handleBuyLicense() {
  const isBM = appState.settings.language === 'bm';
  if (!navigator.onLine) {
    const msg = isBM
      ? 'Sambungan internet diperlukan untuk membuka halaman pembelian.'
      : 'An internet connection is needed to open the purchase page.';
    if (typeof showToast === 'function') {
      showToast(msg);
    } else {
      alert(msg);
    }
    return;
  }
  window.open(BUY_PAGE_URL, '_blank', 'noopener');
}

function handleContactSellerWhatsApp(reason = 'general', refCode = null) {
  const sellerDigits = (SELLER_WHATSAPP || '').replace(/[^0-9]/g, '');
  const devId = getOrCreateDeviceId().slice(0, 8);
  const isBM = appState.settings.language === 'bm';

  let reasonLineEn = 'Reason: General question / support';
  let reasonLineBm = 'Sebab: Soalan umum / bantuan sokongan';

  if (reason === 'revoked') {
    reasonLineEn = 'Reason: License revoked';
    reasonLineBm = 'Sebab: Lesen dibatalkan';
  } else if (reason === 'device_limit_reached') {
    reasonLineEn = 'Reason: Device limit reached';
    reasonLineBm = 'Sebab: Had peranti telah dicapai';
  } else if (reason === 'presale') {
    reasonLineEn = 'Reason: Pre-activation inquiry';
    reasonLineBm = 'Sebab: Pertanyaan sebelum pengaktifan';
  } else if (reason === 'verification_failed') {
    reasonLineEn = `Reason: Verification failed${refCode ? ` (${refCode})` : ''}`;
    reasonLineBm = `Sebab: Pengesahan lesen gagal${refCode ? ` (${refCode})` : ''}`;
  }

  const openingEn = reason === 'presale'
    ? 'Hi! I have a question before buying StayManager Pro.'
    : 'Hi! I need assistance with my StayManager Pro license.';

  const openingBm = reason === 'presale'
    ? 'Salam, saya ada soalan sebelum membeli StayManager Pro.'
    : 'Salam, saya memerlukan bantuan mengenai lesen StayManager Pro saya.';

  const refSnippetEn = (refCode && reason !== 'verification_failed') ? `\nRef: ${refCode}` : '';
  const refSnippetBm = (refCode && reason !== 'verification_failed') ? `\nRuj: ${refCode}` : '';

  const message = isBM
    ? `${openingBm}\nID Peranti: ${devId}${refSnippetBm}\n${reasonLineBm}\nTerima kasih!`
    : `${openingEn}\nDevice ID: ${devId}${refSnippetEn}\n${reasonLineEn}\nThank you!`;

  const url = `https://wa.me/${sellerDigits}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank', 'noopener');
}

// ==========================================================================
// 4. TAB & PROPERTY SWITCHING
// ==========================================================================

function switchTab(tabId) {
  closeAllModals();
  appState.activeTab = tabId;
  document.querySelectorAll('.bottom-nav .nav-item').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-tab') === tabId);
  });
  document.querySelectorAll('.tab-view').forEach(view => {
    view.classList.toggle('active', view.id === `view-${tabId}`);
  });

  // Render specific tab with defensive error boundary
  try {
    if (tabId === 'dashboard') renderDashboardTab();
    else if (tabId === 'calendar') renderCalendarTab();
    else if (tabId === 'bookings') renderBookingsTab();
    else if (tabId === 'turnovers') renderTurnoversTab();
    else if (tabId === 'finances') renderFinancesTab();
    else if (tabId === 'settings') renderSettingsTab();
  } catch (tabErr) {
    console.error(`Error rendering tab ${tabId}:`, tabErr);
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderApp() {
  applyLanguageUI();
  renderHeader();
  renderPropertyPills();
  switchTab(appState.activeTab);
}

function renderHeader() {
  document.getElementById('appBusinessName').textContent = appState.settings.businessName;
  const locale = appState.settings.language === 'bm' ? 'ms-MY' : 'en-US';
  const todayStr = new Date().toLocaleDateString(locale, { weekday: 'short', month: 'short', day: 'numeric' });
  document.getElementById('currentDateStr').textContent = todayStr;

  // Toggle Demo Sales Banner based on License state
  const demoBanner = document.getElementById('demoSalesBanner');
  if (demoBanner) {
    if (appState.isLicensed) {
      demoBanner.style.display = 'none';
      demoBanner.classList.add('hidden');
    } else {
      demoBanner.style.display = 'flex';
      demoBanner.classList.remove('hidden');
    }
  }

  // Update Header Status Badge (Top-right pill)
  const demoBtn = document.getElementById('btnDemoToggle');
  if (demoBtn) {
    if (appState.isLicensed) {
      demoBtn.innerHTML = `<i class="fa-solid fa-circle-check" style="color:var(--success);"></i> <span class="demo-badge-text" style="color:var(--success-text); font-weight:800;">Pro</span>`;
      demoBtn.title = (appState.currentLang === 'bm' ? 'Lesen Pro Aktif' : 'Pro Active');
      demoBtn.style.background = 'var(--success-light)';
      demoBtn.style.borderColor = 'rgba(16, 185, 129, 0.4)';
    } else {
      demoBtn.innerHTML = `<i class="fa-solid fa-sparkles"></i> <span class="demo-badge-text">${t('demo_badge') || 'Demo'}</span>`;
      demoBtn.title = 'Demo Mode (Click to activate)';
      demoBtn.style.background = 'var(--warning-light)';
      demoBtn.style.borderColor = 'rgba(245, 158, 11, 0.4)';
    }
  }
}

function renderPropertyPills() {
  const container = document.getElementById('propertyPills');
  container.innerHTML = '';

  // "All Properties" pill
  const allPill = document.createElement('button');
  allPill.className = `property-pill ${appState.selectedPropertyId === 'all' ? 'active' : ''}`;
  allPill.innerHTML = `<span class="property-dot" style="background:#0284c7;"></span> ${t('all_units')} (${appState.properties.length})`;
  allPill.addEventListener('click', () => {
    appState.selectedPropertyId = 'all';
    renderPropertyPills();
    renderApp();
  });
  container.appendChild(allPill);

  // Individual Property pills
  appState.properties.forEach(prop => {
    const pill = document.createElement('button');
    pill.className = `property-pill ${appState.selectedPropertyId === prop.id ? 'active' : ''}`;
    pill.innerHTML = `<span class="property-dot" style="background:${prop.color || '#0284c7'};"></span> ${prop.name}`;
    pill.addEventListener('click', () => {
      appState.selectedPropertyId = prop.id;
      renderPropertyPills();
      renderApp();
    });
    container.appendChild(pill);
  });
}

function getFilteredBookings() {
  if (appState.selectedPropertyId === 'all') return appState.bookings;
  return appState.bookings.filter(b => b.propertyId === appState.selectedPropertyId);
}

function isCompletedTenancy(b, todayStr = formatLocalDate(new Date())) {
  if (!b) return false;
  if (b.rentalType === 'monthly') {
    return b.status === 'checked-out' || b.status === 'completed' || b.isHistorical === true || (b.checkOut && b.checkOut < todayStr);
  }
  return false;
}

function isHistoricalStay(b, todayStr = formatLocalDate(new Date())) {
  if (!b) return false;
  if (b.rentalType === 'monthly') {
    return isCompletedTenancy(b, todayStr);
  }
  return b.status === 'checked-out' || b.status === 'completed' || b.isHistorical === true || (b.checkOut && b.checkOut < todayStr && b.status !== 'cancelled' && b.status !== 'quotation');
}

function normalizeIdNumber(rawId) {
  if (!rawId) return '';
  return String(rawId).replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
}

/**
 * Calculates guest stay history & repeat statistics:
 * Matches by Phone Number FIRST.
 * Matches by Identification Number (IC / Passport / SSM) SECOND.
 */
function getGuestStayStats(phone, ic, currentBookingId = null) {
  const normPhone = normalizePhoneNumber(phone);
  const normIc = normalizeIdNumber(ic);

  let matchedBookings = [];
  let matchedContact = null;
  let matchedBy = null;

  const allBookings = Array.isArray(appState.bookings) ? appState.bookings : [];
  const allContacts = Array.isArray(appState.contacts) ? appState.contacts : [];

  // 1. Match by Phone Number first
  if (normPhone && normPhone.length >= 6) {
    matchedContact = allContacts.find(c => normalizePhoneNumber(c.phone) === normPhone);
    matchedBookings = allBookings.filter(b => {
      if (currentBookingId && String(b.id) === String(currentBookingId)) return false;
      return normalizePhoneNumber(b.guestPhone) === normPhone || 
             normalizePhoneNumber(b.contactPhone) === normPhone || 
             normalizePhoneNumber(b.picPhone) === normPhone;
    });

    if (matchedContact || matchedBookings.length > 0) {
      matchedBy = 'phone';
    }
  }

  // 2. Match by Identification Number second (if no phone match)
  if (!matchedBy && normIc && normIc.length >= 4) {
    matchedContact = allContacts.find(c => normalizeIdNumber(c.ic) === normIc);
    matchedBookings = allBookings.filter(b => {
      if (currentBookingId && String(b.id) === String(currentBookingId)) return false;
      return normalizeIdNumber(b.guestNric) === normIc || 
             normalizeIdNumber(b.companyRegNo) === normIc || 
             normalizeIdNumber(b.contactIc) === normIc || 
             normalizeIdNumber(b.ic) === normIc;
    });

    if (matchedContact || matchedBookings.length > 0) {
      matchedBy = 'id';
    }
  }

  if (!matchedBy) {
    return {
      matched: false,
      matchedBy: null,
      totalStays: 0,
      lifetimeRevenue: 0,
      firstStayDate: null,
      lastStayDate: null,
      tenant: null,
      contact: null,
      bookings: [],
      isBlacklisted: false
    };
  }

  // Calculate stats from valid non-cancelled, non-quotation stays
  const validStays = matchedBookings.filter(b => b.status !== 'cancelled' && b.status !== 'quotation');
  
  // Sort by checkIn date ascending
  validStays.sort((a, b) => (a.checkIn || '').localeCompare(b.checkIn || ''));

  const totalStays = validStays.length;
  const lifetimeRevenue = validStays.reduce((sum, b) => sum + (Number(b.totalAmount) || 0), 0);
  const firstStayDate = validStays.length > 0 ? validStays[0].checkIn : null;
  const lastStayDate = validStays.length > 0 ? validStays[validStays.length - 1].checkIn : null;

  // Latest booking record for prefilling details
  const latestBooking = validStays.length > 0 ? validStays[validStays.length - 1] : (matchedBookings[0] || null);
  const isBlacklisted = !!(matchedContact && matchedContact.status === 'blacklisted');

  const tenantDetails = {
    name: matchedContact?.name || latestBooking?.guestName || latestBooking?.companyName || latestBooking?.contactPerson || '',
    phone: matchedContact?.phone || latestBooking?.guestPhone || latestBooking?.contactPhone || phone || '',
    ic: matchedContact?.ic || latestBooking?.guestNric || latestBooking?.companyRegNo || ic || '',
    email: matchedContact?.email || latestBooking?.guestEmail || latestBooking?.contactEmail || '',
    address: matchedContact?.address || latestBooking?.guestAddress || latestBooking?.companyAddress || '',
    tenantType: latestBooking?.tenantType || (matchedContact?.company ? 'company' : 'individual'),
    companyName: latestBooking?.companyName || matchedContact?.company || '',
    companyRegNo: latestBooking?.companyRegNo || matchedContact?.ic || '',
    companyAddress: latestBooking?.companyAddress || matchedContact?.address || '',
    contactPerson: latestBooking?.contactPerson || (latestBooking?.tenantType === 'company' ? latestBooking?.signatoryName : '') || '',
    contactDesignation: latestBooking?.contactDesignation || (latestBooking?.tenantType === 'company' ? latestBooking?.signatoryDesignation : '') || '',
    contactPhone: latestBooking?.contactPhone || matchedContact?.phone || '',
    contactEmail: latestBooking?.contactEmail || matchedContact?.email || '',
    status: matchedContact?.status || 'active',
    notes: matchedContact?.notes || latestBooking?.notes || ''
  };

  return {
    matched: true,
    matchedBy,
    totalStays,
    lifetimeRevenue,
    firstStayDate,
    lastStayDate,
    tenant: tenantDetails,
    contact: matchedContact,
    bookings: validStays,
    isBlacklisted
  };
}

/**
 * Synchronizes tenant lifecycle statuses:
 * - Active: currently has active / in-house / confirmed / ongoing tenancy
 * - Completed: checked out (daily stay) or vacated/completed (long-term tenancy)
 * - Prospect: inquiries / quotation only
 * - Blacklisted: preserved, never overridden
 */
function syncTenantLifecycleStatus(todayStr = formatLocalDate(new Date())) {
  if (!Array.isArray(appState.contacts)) appState.contacts = [];
  const bookings = Array.isArray(appState.bookings) ? appState.bookings : [];

  // De-clutter Settings: Ensure auto-injected c-t- records do not pollute the Contacts directory
  appState.contacts = appState.contacts.filter(c => !c.id || !c.id.startsWith('c-t-'));

  // Re-evaluate lifecycle status for existing saved contacts
  appState.contacts.forEach(c => {
    // Blacklisted contacts are strictly preserved
    if (c.status === 'blacklisted') return;

    const normPhone = normalizePhoneNumber(c.phone);
    const normIc = normalizeIdNumber(c.ic);

    const matchingBookings = bookings.filter(b => {
      if (b.status === 'cancelled') return false;
      if (normPhone && normPhone.length >= 6) {
        if (normalizePhoneNumber(b.guestPhone) === normPhone || 
            normalizePhoneNumber(b.contactPhone) === normPhone || 
            normalizePhoneNumber(b.picPhone) === normPhone) {
          return true;
        }
      }
      if (normIc && normIc.length >= 4) {
        if (normalizeIdNumber(b.guestNric) === normIc || 
            normalizeIdNumber(b.companyRegNo) === normIc || 
            normalizeIdNumber(b.contactIc) === normIc ||
            normalizeIdNumber(b.ic) === normIc) {
          return true;
        }
      }
      return false;
    });

    if (matchingBookings.length === 0) {
      if (!c.status) c.status = 'active';
      return;
    }

    // Check if any booking is currently active (Daily not checked out / not past; Monthly not completed / not vacated)
    const hasActiveBooking = matchingBookings.some(b => {
      if (b.status === 'quotation') return false;
      if (b.status === 'checked-out' || b.status === 'completed' || b.isHistorical === true) return false;
      if (b.checkOut && b.checkOut < todayStr) return false;
      return true;
    });

    if (hasActiveBooking) {
      c.status = 'active';
    } else {
      const validStays = matchingBookings.filter(b => b.status !== 'quotation');
      if (validStays.length > 0) {
        // Daily Checked Out -> Completed; Long-term Vacated / Completed -> Completed
        c.status = 'completed';
      } else {
        c.status = 'prospect';
      }
    }
  });

  return appState.contacts;
}

let currentRepeatGuestStats = null;

function checkBookingRepeatGuest() {
  const isCompany = (document.getElementById('bookingTenantType')?.value === 'company');
  const guestPhone = document.getElementById('bookingGuestPhone')?.value ? document.getElementById('bookingGuestPhone').value.trim() : '';
  const guestNric = document.getElementById('bookingGuestNric')?.value ? document.getElementById('bookingGuestNric').value.trim() : '';
  const contactPhone = document.getElementById('bookingContactPhone')?.value ? document.getElementById('bookingContactPhone').value.trim() : '';
  const companyRegNo = document.getElementById('bookingCompanyRegNo')?.value ? document.getElementById('bookingCompanyRegNo').value.trim() : '';
  const currentBookingId = document.getElementById('bookingIdInput')?.value || null;

  const phone = isCompany ? (contactPhone || guestPhone) : (guestPhone || contactPhone);
  const ic = isCompany ? (companyRegNo || guestNric) : (guestNric || companyRegNo);

  const alertBox = document.getElementById('repeatGuestAlertBox');
  const blacklistAlert = document.getElementById('blacklistedGuestAlertBox');
  const blacklistReason = document.getElementById('blacklistedGuestReason');

  if (!phone && !ic) {
    if (alertBox) alertBox.style.display = 'none';
    if (blacklistAlert) blacklistAlert.style.display = 'none';
    currentRepeatGuestStats = null;
    return null;
  }

  const stats = getGuestStayStats(phone, ic, currentBookingId);
  currentRepeatGuestStats = stats;

  // Repeat Guest Recognition Banner
  if (alertBox) {
    if (stats.matched && stats.totalStays > 0) {
      alertBox.style.display = 'block';
      const stayCountEl = document.getElementById('repeatGuestStayCount');
      const lastStayEl = document.getElementById('repeatGuestLastStay');
      const lifetimeRevEl = document.getElementById('repeatGuestLifetimeRev');
      if (stayCountEl) stayCountEl.textContent = stats.totalStays;
      if (lastStayEl) lastStayEl.textContent = stats.lastStayDate || '-';
      if (lifetimeRevEl) lifetimeRevEl.textContent = formatCurrency(stats.lifetimeRevenue);
    } else {
      alertBox.style.display = 'none';
    }
  }

  // Blacklist Alert Banner
  if (blacklistAlert) {
    if (stats.isBlacklisted) {
      blacklistAlert.style.display = 'block';
      if (blacklistReason) {
        blacklistReason.textContent = stats.contact?.notes || (appState.settings.language === 'bm' ? 'Penyewa ini ditandakan dalam senarai hitam.' : 'This guest is flagged on the blacklist.');
      }
    } else {
      blacklistAlert.style.display = 'none';
    }
  }

  return stats;
}

function applyRepeatGuestDetails(stats) {
  if (!stats || !stats.tenant) return;
  const tData = stats.tenant;
  const isCompany = (tData.tenantType === 'company');

  if (typeof setBookingTenantType === 'function') {
    setBookingTenantType(isCompany ? 'company' : 'individual');
  }

  if (isCompany) {
    const elName = document.getElementById('bookingCompanyName');
    if (elName && tData.companyName) elName.value = tData.companyName;
    const elReg = document.getElementById('bookingCompanyRegNo');
    if (elReg && tData.companyRegNo) elReg.value = tData.companyRegNo;
    const elAddr = document.getElementById('bookingCompanyAddress');
    if (elAddr && tData.companyAddress) elAddr.value = tData.companyAddress;
    const elCP = document.getElementById('bookingContactPerson');
    if (elCP && tData.contactPerson) elCP.value = tData.contactPerson;
    const elCD = document.getElementById('bookingContactDesignation');
    if (elCD && tData.contactDesignation) elCD.value = tData.contactDesignation;
    const elCPH = document.getElementById('bookingContactPhone');
    if (elCPH && tData.contactPhone) elCPH.value = tData.contactPhone;
    const elCE = document.getElementById('bookingContactEmail');
    if (elCE && tData.contactEmail) elCE.value = tData.contactEmail;
  } else {
    const elName = document.getElementById('bookingGuestName');
    if (elName && tData.name) elName.value = tData.name;
    const elPhone = document.getElementById('bookingGuestPhone');
    if (elPhone && tData.phone) elPhone.value = tData.phone;
    const elNric = document.getElementById('bookingGuestNric');
    if (elNric && tData.ic) elNric.value = tData.ic;
    const elEmail = document.getElementById('bookingGuestEmail');
    if (elEmail && tData.email) elEmail.value = tData.email;
    const elAddr = document.getElementById('bookingGuestAddress');
    if (elAddr && tData.address) elAddr.value = tData.address;
  }

  const isBM = appState.settings.language === 'bm';
  if (typeof showToast === 'function') {
    showToast(isBM ? 'Rekod penyewa sedia ada telah dimasukkan!' : 'Existing tenant record applied!');
  }
}

function getFilteredTurnovers() {
  if (appState.selectedPropertyId === 'all') return appState.turnovers;
  return appState.turnovers.filter(t => t.propertyId === appState.selectedPropertyId);
}

function getFilteredExpenses() {
  if (appState.selectedPropertyId === 'all') return appState.expenses;
  return appState.expenses.filter(e => e.propertyId === appState.selectedPropertyId);
}

function getPropertyById(id) {
  return appState.properties.find(p => p.id === id) || { name: 'Homestay', color: '#0284c7', doorCode: '1234', wifiName: '', wifiPass: '' };
}

function formatCurrency(amount) {
  const curr = appState.settings.currency || 'RM';
  return `${curr} ${Number(amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

// ==========================================================================
// 5. DASHBOARD (TODAY & ACTIONS) TAB
// ==========================================================================

function renderDashboardTab() {
  const todayStr = formatLocalDate(new Date());

  // Automatically sync tenant lifecycle status (Daily Checked Out -> Completed, Long-term Vacated/Completed -> Completed)
  syncTenantLifecycleStatus(todayStr);

  const bookings = getFilteredBookings();
  const turnovers = getFilteredTurnovers();

  // KPIs (completed historical tenancies and checked-out stays do not appear in active dashboard)
  const todayCheckIns = bookings.filter(b => 
    b.checkIn === todayStr && 
    b.status !== 'cancelled' && 
    b.status !== 'checked-out' && 
    b.status !== 'completed' && 
    !isHistoricalStay(b, todayStr)
  );
  const todayCheckOuts = bookings.filter(b => 
    b.checkOut === todayStr && 
    b.status !== 'cancelled' && 
    b.status !== 'checked-out' && 
    b.status !== 'completed' && 
    !isHistoricalStay(b, todayStr) && 
    !isCompletedTenancy(b, todayStr)
  );
  const inHouse = bookings.filter(b => 
    b.checkIn <= todayStr && 
    b.checkOut > todayStr && 
    b.status !== 'cancelled' && 
    b.status !== 'checked-out' && 
    b.status !== 'completed' && 
    !isHistoricalStay(b, todayStr) && 
    !isCompletedTenancy(b, todayStr)
  );
  const pendingTurnovers = turnovers.filter(t => t.status !== 'completed');

  const elCheckIns = document.getElementById('kpiCheckInsCount');
  if (elCheckIns) elCheckIns.textContent = todayCheckIns.length;
  const elCheckOuts = document.getElementById('kpiCheckOutsCount');
  if (elCheckOuts) elCheckOuts.textContent = todayCheckOuts.length;
  const elInHouse = document.getElementById('kpiInHouseCount');
  if (elInHouse) elInHouse.textContent = inHouse.length;
  const elTurnovers = document.getElementById('kpiTurnoversCount');
  if (elTurnovers) elTurnovers.textContent = pendingTurnovers.length;

  // Tenant Intelligence & Repeat Guest KPIs (strictly active tenants only)
  const activeTenantBookings = bookings.filter(b => 
    (b.status === 'checked-in' || b.status === 'confirmed') && 
    b.checkIn <= todayStr && 
    b.checkOut >= todayStr && 
    b.status !== 'cancelled' && 
    b.status !== 'checked-out' && 
    b.status !== 'completed' && 
    !isHistoricalStay(b, todayStr) &&
    !isCompletedTenancy(b, todayStr)
  );
  const activeContactsCount = (appState.contacts || []).filter(c => c.category === 'tenant' && (c.status === 'active' || !c.status)).length;
  const totalActiveTenants = Math.max(activeTenantBookings.length, activeContactsCount);
  const elActiveTenants = document.getElementById('dashKpiActiveTenants');
  if (elActiveTenants) elActiveTenants.textContent = totalActiveTenants;

  // Repeat Guests calculation
  const guestGroups = {};
  const allValidStays = (appState.bookings || []).filter(b => b.status !== 'cancelled' && b.status !== 'quotation');
  allValidStays.forEach(b => {
    const pKey = normalizePhoneNumber(b.guestPhone || b.contactPhone);
    const iKey = normalizeIdNumber(b.guestNric || b.companyRegNo);
    const key = (pKey && pKey.length >= 6) 
      ? `p:${pKey}` 
      : ((iKey && iKey.length >= 4) ? `i:${iKey}` : `n:${(b.guestName || b.companyName || b.id).toLowerCase()}`);

    if (!guestGroups[key]) {
      guestGroups[key] = {
        name: b.guestName || b.companyName || b.contactPerson || 'Guest',
        phone: b.guestPhone || b.contactPhone || '',
        ic: b.guestNric || b.companyRegNo || '',
        totalStays: 0,
        lifetimeRevenue: 0,
        lastStayDate: null
      };
    }
    guestGroups[key].totalStays += 1;
    guestGroups[key].lifetimeRevenue += (Number(b.totalAmount) || 0);
    if (!guestGroups[key].lastStayDate || (b.checkIn && b.checkIn > guestGroups[key].lastStayDate)) {
      guestGroups[key].lastStayDate = b.checkIn;
    }
  });

  const repeatGuests = Object.values(guestGroups).filter(g => g.totalStays >= 2);
  const totalRepeatBookings = repeatGuests.reduce((sum, g) => sum + g.totalStays, 0);

  const elRepeatGuests = document.getElementById('dashKpiRepeatGuests');
  if (elRepeatGuests) elRepeatGuests.textContent = repeatGuests.length;

  const elRepeatBookings = document.getElementById('dashKpiRepeatBookings');
  if (elRepeatBookings) elRepeatBookings.textContent = totalRepeatBookings;

  // Top Returning Guests ranking
  repeatGuests.sort((a, b) => {
    if (b.totalStays !== a.totalStays) return b.totalStays - a.totalStays;
    return b.lifetimeRevenue - a.lifetimeRevenue;
  });

  const topReturningEl = document.getElementById('dashTopReturningGuestsList');
  const topReturningCountEl = document.getElementById('dashTopReturningGuestsCount');
  if (topReturningCountEl) {
    topReturningCountEl.textContent = `${repeatGuests.length} ${appState.settings.language === 'bm' ? 'Tetamu' : 'Guests'}`;
  }
  if (topReturningEl) {
    topReturningEl.innerHTML = '';
    const top5 = repeatGuests.slice(0, 5);
    if (top5.length === 0) {
      topReturningEl.innerHTML = `
        <div style="text-align:center; padding:10px 8px; font-size:11px; color:var(--text-muted);">
          ${appState.settings.language === 'bm' 
            ? 'Tiada rekod tetamu berulang lagi. Tempahan daripada tetamu setia akan dipaparkan di sini.' 
            : 'No repeat guests recorded yet. Returning customer statistics will appear here.'}
        </div>
      `;
    } else {
      top5.forEach(g => {
        const item = document.createElement('div');
        item.style.cssText = 'display:flex; justify-content:space-between; align-items:center; background:var(--bg-surface); padding:6px 10px; border-radius:6px; border:1px solid var(--border-color); font-size:11.5px;';
        item.innerHTML = `
          <div>
            <div style="font-weight:700; color:var(--text-main);">${escapeHtml(g.name)}</div>
            <div style="font-size:10.5px; color:var(--text-muted);">
              ${g.phone ? `<i class="fa-brands fa-whatsapp" style="color:var(--success);"></i> ${escapeHtml(g.phone)}` : ''} 
              ${g.lastStayDate ? `• ${t('lbl_last_stay')}: ${g.lastStayDate}` : ''}
            </div>
          </div>
          <div style="display:flex; gap:6px; align-items:center;">
            <span class="badge" style="background:#fef3c7; color:#92400e; font-size:10px; padding:2px 6px; border-radius:4px; font-weight:700;">
              <i class="fa-solid fa-repeat"></i> ${g.totalStays} ${appState.settings.language === 'bm' ? 'Penginapan' : 'Stays'}
            </span>
            <span style="font-weight:700; color:var(--primary); font-size:11.5px;">${formatCurrency(g.lifetimeRevenue)}</span>
          </div>
        `;
        topReturningEl.appendChild(item);
      });
    }
  }

  // Monthly Performance Mini Widget
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const currentMonthBookings = bookings.filter(b => {
    if (b.status === 'cancelled') return false;
    const d = new Date(b.checkIn);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const monthRev = currentMonthBookings.reduce((sum, b) => sum + (Number(b.totalAmount) || 0), 0);
  const bookedNights = currentMonthBookings.reduce((sum, b) => sum + (Number(b.nights) || 0), 0);

  // Total possible nights this month for filtered properties
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const propCount = appState.selectedPropertyId === 'all' ? appState.properties.length : 1;
  const totalCapacity = daysInMonth * Math.max(1, propCount);
  const occupancyRate = propCount > 0 ? Math.min(100, Math.round((bookedNights / totalCapacity) * 100)) : 0;

  document.getElementById('dashMonthRevenue').textContent = formatCurrency(monthRev);
  document.getElementById('dashOccupancyRate').textContent = `${occupancyRate}%`;
  document.getElementById('dashOccupancyProgress').style.width = `${occupancyRate}%`;
  document.getElementById('dashBookedNightsCount').textContent = `${bookedNights} nights booked`;
  document.getElementById('dashActivePropertiesCount').textContent = `${appState.properties.length} Homestay${appState.properties.length !== 1 ? 's' : ''}`;

  // Action Feed: Priority Check-ins, Check-outs, and Turnovers
  const actionFeed = document.getElementById('dashboardActionFeed');
  actionFeed.innerHTML = '';

  const actionItems = [];

  todayCheckIns.forEach(b => {
    const prop = getPropertyById(b.propertyId);
    actionItems.push({
      type: 'checkin',
      tag: t('tag_checkin_today'),
      title: `${b.guestName} → ${prop.name}`,
      detail: `${b.guestCount} ${t('guests')} • ${t('checkin_time')}: ${prop.checkInTime || '3:00 PM'}`,
      booking: b,
      prop: prop
    });
  });

  todayCheckOuts.forEach(b => {
    const prop = getPropertyById(b.propertyId);
    actionItems.push({
      type: 'checkout',
      tag: t('tag_checkout_today'),
      title: `${b.guestName} ← ${prop.name}`,
      detail: `${t('checkout_time')}: ${prop.checkOutTime || '12:00 PM'} • ${t('turnover_required')}`,
      booking: b,
      prop: prop
    });
  });

  pendingTurnovers.forEach(tItem => {
    const prop = getPropertyById(tItem.propertyId);
    actionItems.push({
      type: 'cleaning',
      tag: t('tag_turnover_needed'),
      title: `${t('turnover')}: ${prop.name}`,
      detail: `${t('exp_date')}: ${tItem.date} • ${tItem.cleanerName || t('assign_cleaner')}`,
      turnover: tItem,
      prop: prop
    });
  });

  if (actionItems.length === 0) {
    actionFeed.innerHTML = `
      <div class="card" style="text-align:center; padding: 24px 16px;">
        <i class="fa-solid fa-circle-check" style="font-size: 32px; color: var(--success); margin-bottom: 8px;"></i>
        <h4 style="font-size: 14px; font-weight:700;">${appState.settings.language === 'bm' ? 'Semua Urusan Hari Ini Selesai!' : 'All Clear for Today!'}</h4>
        <p class="card-subtitle">${t('no_actions_today')}</p>
      </div>
    `;
  } else {
    actionItems.forEach(item => {
      const card = document.createElement('div');
      card.className = 'action-card';
      if (item.type === 'checkin') card.style.borderLeftColor = 'var(--primary)';
      if (item.type === 'checkout') card.style.borderLeftColor = 'var(--warning)';
      if (item.type === 'cleaning') card.style.borderLeftColor = 'var(--danger)';

      const tagClass = item.type === 'checkin' ? 'tag-checkin' : (item.type === 'checkout' ? 'tag-checkout' : 'tag-cleaning');

      card.innerHTML = `
        <div class="action-card-header">
          <span class="action-card-tag ${tagClass}">${item.tag}</span>
          <span class="card-subtitle"><i class="fa-solid fa-clock"></i> ${t('today')}</span>
        </div>
        <h3 class="action-card-title">${item.title}</h3>
        <p class="action-card-detail"><i class="fa-solid fa-info-circle"></i> ${item.detail}</p>
        <div class="action-card-btns">
          ${item.booking ? `
            <button class="btn btn-whatsapp btn-xs btn-wa-trigger" data-bid="${item.booking.id}" data-type="${item.type}">
              <i class="fa-brands fa-whatsapp"></i> ${item.type === 'checkin' ? t('btn_send_full_receipt') : t('btn_checkout_reminder')}
            </button>
            <button class="btn btn-outline btn-xs btn-open-pdf-doc" data-bid="${item.booking.id}" title="${appState.settings.language === 'bm' ? 'Jana Dokumen PDF Rasmi' : 'Generate Official PDF'}" style="color:var(--primary); font-weight:700;">
              <i class="fa-solid fa-file-pdf"></i> PDF
            </button>
          ` : ''}
          ${item.turnover ? `
            <button class="btn btn-whatsapp btn-xs btn-wa-cleaner" data-tid="${item.turnover.id}">
              <i class="fa-brands fa-whatsapp"></i> ${t('btn_wa_cleaner')}
            </button>
            <button class="btn btn-outline btn-xs btn-view-turnovers">
              <i class="fa-solid fa-list-check"></i> ${t('checklist')}
            </button>
          ` : ''}
        </div>
      `;

      actionFeed.appendChild(card);
    });

    // Attach event listeners for action feed buttons
    actionFeed.querySelectorAll('.btn-open-pdf-doc').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const bid = e.currentTarget.getAttribute('data-bid');
        const b = appState.bookings.find(x => x.id === bid);
        if (b) {
          const docType = (b.status === 'confirmed' || b.status === 'completed' || b.status === 'checked-in') ? 'receipt' : b.status === 'booked' ? 'deposit_receipt' : 'quotation';
          openPdfDocModal(b, docType);
        }
      });
    });

    actionFeed.querySelectorAll('.btn-wa-trigger').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const bid = e.currentTarget.getAttribute('data-bid');
        const type = e.currentTarget.getAttribute('data-type');
        const booking = appState.bookings.find(b => b.id === bid);
        if (booking) {
          openWhatsAppModal(booking, type === 'checkin' ? 'full_receipt' : 'checkout');
        }
      });
    });

    actionFeed.querySelectorAll('.btn-wa-cleaner').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tid = e.currentTarget.getAttribute('data-tid');
        const turnover = appState.turnovers.find(tItem => tItem.id === tid);
        if (turnover) {
          openWhatsAppCleanerJob(turnover);
        }
      });
    });

    actionFeed.querySelectorAll('.btn-view-turnovers').forEach(btn => {
      btn.addEventListener('click', () => switchTab('turnovers'));
    });
  }

  // Homestay Units Overview List
  const propList = document.getElementById('dashboardPropertyStatusList');
  propList.innerHTML = '';

  const displayProps = appState.selectedPropertyId === 'all' 
    ? appState.properties 
    : appState.properties.filter(p => p.id === appState.selectedPropertyId);

  if (displayProps.length === 0) {
    propList.innerHTML = `
      <div style="text-align:center; padding:20px; background:var(--bg-surface-subtle); border-radius:var(--radius-md); border:1px dashed var(--border-color);">
        <p style="font-size:12px; color:var(--text-muted); margin-bottom:8px;">${appState.settings.language === 'bm' ? 'Tiada unit homestay didaftarkan lagi.' : 'No homestay units added yet.'}</p>
        <button class="btn btn-primary btn-xs" onclick="openPropertyModal()"><i class="fa-solid fa-plus"></i> ${t('add_unit_btn')}</button>
      </div>
    `;
  } else {
    displayProps.forEach(prop => {
      // Check if property is currently occupied today (completed tenancies do NOT mark property as occupied)
      const currentStay = appState.bookings.find(b => 
        b.propertyId === prop.id && 
        b.checkIn <= todayStr && 
        b.checkOut > todayStr && 
        b.status !== 'cancelled' &&
        b.status !== 'checked-out' &&
        b.status !== 'completed' &&
        !isCompletedTenancy(b, todayStr)
      );

      const hasTurnover = appState.turnovers.some(tItem => tItem.propertyId === prop.id && tItem.status !== 'completed');

      let statusText = t('vacant_ready');
      let badgeClass = 'badge-vacant';

      if (currentStay) {
        statusText = `${t('occupied_by')} ${currentStay.guestName}`;
        badgeClass = 'badge-occupied';
      } else if (hasTurnover) {
        statusText = t('turnover_required');
        badgeClass = 'badge-turnover';
      }

      const card = document.createElement('div');
      card.className = 'prop-status-card';
      card.innerHTML = `
        <div class="prop-status-info">
          <h4 style="display:flex; align-items:center; gap:6px;">
            <span class="property-dot" style="background:${prop.color};"></span>
            ${prop.name}
          </h4>
          <p>${statusText}</p>
        </div>
        <span class="prop-status-badge ${badgeClass}">${currentStay ? t('occupied') : (hasTurnover ? t('turnover') : t('available'))}</span>
      `;
      propList.appendChild(card);
    });
  }

  // Update Dashboard Historical Tenancies quick link
  const historicalTenancies = appState.bookings.filter(b => isCompletedTenancy(b, todayStr));
  const btnHist = document.getElementById('btnDashHistoricalTenancies');
  const histCountEl = document.getElementById('dashHistoricalTenancyCount');
  if (btnHist && histCountEl) {
    if (historicalTenancies.length > 0) {
      btnHist.style.display = 'inline-flex';
      histCountEl.textContent = historicalTenancies.length;
      btnHist.onclick = () => {
        switchTab('bookings');
        const histPill = document.querySelector('#bookingStatusFilters .filter-pill[data-filter="historical_tenancy"]');
        if (histPill) histPill.click();
      };
    } else {
      btnHist.style.display = 'none';
    }
  }
}

// ==========================================================================
// 6. CALENDAR TAB
// ==========================================================================

function changeCalMonth(offset) {
  appState.currentCalDate.setMonth(appState.currentCalDate.getMonth() + offset);
  renderCalendarTab();
}

function renderCalendarTab() {
  const currentMonth = appState.currentCalDate.getMonth();
  const currentYear = appState.currentCalDate.getFullYear();
  
  // Sync Calendar Mode pills active state
  const currentCalMode = appState.calFilterMode || 'checkin';
  document.querySelectorAll('#calModeSelector .cal-mode-pill').forEach(pill => {
    pill.classList.toggle('active', pill.getAttribute('data-cal-filter') === currentCalMode);
  });
  
  const locale = appState.settings.language === 'bm' ? 'ms-MY' : 'en-US';
  const monthName = appState.currentCalDate.toLocaleDateString(locale, { month: 'long', year: 'numeric' });
  document.getElementById('calMonthTitle').textContent = monthName;

  const firstDay = new Date(currentYear, currentMonth, 1).getDay();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const daysInPrevMonth = new Date(currentYear, currentMonth, 0).getDate();

  const grid = document.getElementById('calDaysGrid');
  grid.innerHTML = '';

  const bookings = getFilteredBookings();
  const todayStr = formatLocalDate(new Date());

  // Previous month trailing days
  for (let i = firstDay - 1; i >= 0; i--) {
    const dayNum = daysInPrevMonth - i;
    const prevDate = new Date(currentYear, currentMonth - 1, dayNum);
    const dateStr = formatLocalDate(prevDate);
    const cell = createCalDayCell(dayNum, dateStr, true, bookings, todayStr);
    grid.appendChild(cell);
  }

  // Current month days
  for (let day = 1; day <= daysInMonth; day++) {
    const currDate = new Date(currentYear, currentMonth, day);
    const dateStr = formatLocalDate(currDate);
    const cell = createCalDayCell(day, dateStr, false, bookings, todayStr);
    grid.appendChild(cell);
  }

  // Next month leading days (fill up to 42 cells grid if needed)
  const totalCells = grid.children.length;
  const remaining = (totalCells <= 35 ? 35 : 42) - totalCells;
  for (let day = 1; day <= remaining; day++) {
    const nextDate = new Date(currentYear, currentMonth + 1, day);
    const dateStr = formatLocalDate(nextDate);
    const cell = createCalDayCell(day, dateStr, true, bookings, todayStr);
    grid.appendChild(cell);
  }

  // Render Legend
  const legend = document.getElementById('calPropertyLegend');
  legend.innerHTML = '';
  appState.properties.forEach(p => {
    const item = document.createElement('div');
    item.className = 'cal-legend-item';
    item.innerHTML = `<span class="property-dot" style="background:${p.color};"></span> ${p.name}`;
    legend.appendChild(item);
  });

  // Render Calendar Listing (Incoming Bookings or Selected Day)
  renderCalendarListing();
}

function createCalDayCell(dayNum, dateStr, isOtherMonth, bookings, todayStr) {
  const isSelected = dateStr === appState.selectedCalDate && appState.calListingMode === 'selected';
  const calFilter = appState.calFilterMode || 'checkin';
  const cell = document.createElement('div');
  cell.className = `cal-day-cell ${isOtherMonth ? 'other-month' : ''} ${dateStr === todayStr ? 'today' : ''} ${isSelected ? 'selected' : ''}`;
  cell.setAttribute('data-date', dateStr);

  const numSpan = document.createElement('span');
  numSpan.className = 'cal-day-num';
  numSpan.textContent = dayNum;
  cell.appendChild(numSpan);

  const activeBookings = bookings.filter(b => b.status !== 'cancelled');
  const checkins = activeBookings.filter(b => b.checkIn === dateStr);
  const checkouts = activeBookings.filter(b => b.checkOut === dateStr);
  const stays = activeBookings.filter(b => {
    if (b.checkIn === b.checkOut) return b.checkIn === dateStr;
    return b.checkIn <= dateStr && b.checkOut > dateStr;
  });

  if (calFilter === 'checkin') {
    if (checkins.length > 0) {
      cell.classList.add('has-checkin', 'has-booking');
      const isConfirmed = checkins.some(b => ['booked', 'confirmed', 'checked-in', 'active', 'blocked'].includes(b.status));
      if (isConfirmed) cell.classList.add('is-confirmed-booked');

      const badge = document.createElement('span');
      badge.className = 'cal-day-mode-badge badge-checkin';
      badge.innerHTML = `<i class="fa-solid fa-arrow-right-to-bracket"></i> ${checkins.length}`;
      cell.appendChild(badge);

      const dotsContainer = document.createElement('div');
      dotsContainer.className = 'cal-dots-container';
      checkins.forEach(b => {
        const prop = getPropertyById(b.propertyId);
        const dot = document.createElement('span');
        dot.className = 'cal-stay-dot';
        dot.style.backgroundColor = prop.color || '#16a34a';
        dot.title = `${prop.name}: ${b.guestName} (${t('cal_mode_checkin')})`;
        if (b.status === 'quotation') dot.classList.add('is-quotation');
        dotsContainer.appendChild(dot);
      });
      cell.appendChild(dotsContainer);
    }
  } else if (calFilter === 'checkout') {
    if (checkouts.length > 0) {
      cell.classList.add('has-checkout', 'has-booking');
      const isConfirmed = checkouts.some(b => ['booked', 'confirmed', 'checked-in', 'active', 'blocked'].includes(b.status));
      if (isConfirmed) cell.classList.add('is-confirmed-booked');

      const badge = document.createElement('span');
      badge.className = 'cal-day-mode-badge badge-checkout';
      badge.innerHTML = `<i class="fa-solid fa-arrow-right-from-bracket"></i> ${checkouts.length}`;
      cell.appendChild(badge);

      const dotsContainer = document.createElement('div');
      dotsContainer.className = 'cal-dots-container';
      checkouts.forEach(b => {
        const prop = getPropertyById(b.propertyId);
        const dot = document.createElement('span');
        dot.className = 'cal-stay-dot';
        dot.style.backgroundColor = prop.color || '#ea580c';
        dot.title = `${prop.name}: ${b.guestName} (${t('cal_mode_checkout')})`;
        if (b.status === 'quotation') dot.classList.add('is-quotation');
        dotsContainer.appendChild(dot);
      });
      cell.appendChild(dotsContainer);
    }
  } else {
    // 'stays' mode
    if (stays.length > 0) {
      cell.classList.add('has-booking');
      const isConfirmed = stays.some(b => ['booked', 'confirmed', 'checked-in', 'active', 'blocked'].includes(b.status));
      if (isConfirmed) cell.classList.add('is-confirmed-booked');

      const badge = document.createElement('span');
      badge.className = 'cal-day-mode-badge badge-stays';
      badge.style.background = 'rgba(2, 132, 199, 0.15)';
      badge.style.color = 'var(--primary)';
      badge.innerHTML = `<i class="fa-solid fa-bed"></i> ${stays.length}`;
      cell.appendChild(badge);

      const dotsContainer = document.createElement('div');
      dotsContainer.className = 'cal-dots-container';
      stays.forEach(b => {
        const prop = getPropertyById(b.propertyId);
        const dot = document.createElement('span');
        dot.className = 'cal-stay-dot';
        dot.style.backgroundColor = prop.color || '#0284c7';
        dot.title = `${prop.name}: ${b.guestName} (${b.status})`;
        if (b.status === 'quotation') dot.classList.add('is-quotation');
        dotsContainer.appendChild(dot);
      });
      cell.appendChild(dotsContainer);
    }
  }

  cell.addEventListener('click', () => {
    if (appState.selectedCalDate === dateStr && appState.calListingMode === 'selected') {
      appState.calListingMode = 'incoming';
      document.querySelectorAll('.cal-day-cell').forEach(c => c.classList.remove('selected'));
    } else {
      appState.selectedCalDate = dateStr;
      appState.calListingMode = 'selected';
      document.querySelectorAll('.cal-day-cell').forEach(c => c.classList.remove('selected'));
      cell.classList.add('selected');
    }
    renderCalendarListing();
  });

  return cell;
}

function getIncomingBookings() {
  const allBookings = getFilteredBookings();
  const todayStr = formatLocalDate(new Date());
  const calFilter = appState.calFilterMode || 'checkin';

  const active = allBookings.filter(b => b.status !== 'cancelled' && b.status !== 'checked-out' && b.status !== 'completed' && !isCompletedTenancy(b, todayStr));

  if (calFilter === 'checkout') {
    // In checkout mode: show upcoming check-outs (from today onwards)
    const checkouts = active.filter(b => b.checkOut >= todayStr);
    checkouts.sort((a, b) => {
      if (a.checkOut !== b.checkOut) return a.checkOut.localeCompare(b.checkOut);
      return a.checkIn.localeCompare(b.checkIn);
    });
    return checkouts;
  }

  // Check-In or Stays mode: incoming bookings
  const incoming = active.filter(b => b.checkOut >= todayStr);
  incoming.sort((a, b) => {
    const aInHouse = (a.checkIn <= todayStr && a.checkOut >= todayStr);
    const bInHouse = (b.checkIn <= todayStr && b.checkOut >= todayStr);

    if (aInHouse && bInHouse) {
      if (a.checkIn !== b.checkIn) return a.checkIn.localeCompare(b.checkIn);
      return a.checkOut.localeCompare(b.checkOut);
    }
    if (aInHouse && !bInHouse) return -1;
    if (!aInHouse && bInHouse) return 1;

    // Both future check-ins: sort by earliest checkIn date first (ascending)
    if (a.checkIn !== b.checkIn) {
      return a.checkIn.localeCompare(b.checkIn);
    }
    return a.checkOut.localeCompare(b.checkOut);
  });

  return incoming;
}

function renderCalendarListing() {
  const mode = appState.calListingMode || 'incoming';
  const calFilter = appState.calFilterMode || 'checkin';
  const list = document.getElementById('selectedDayBookingsList');
  if (!list) return;
  list.innerHTML = '';

  const incomingBookings = getIncomingBookings();
  const todayStr = formatLocalDate(new Date());
  const lang = appState.settings.language || 'en';
  const isBM = lang === 'bm';

  // Update tabs
  const tabIncoming = document.getElementById('calTabIncoming');
  const tabSelected = document.getElementById('calTabSelected');
  const tabSelectedLabel = document.getElementById('calSelectedTabLabel');

  if (tabIncoming && tabSelected) {
    if (mode === 'incoming') {
      tabIncoming.classList.add('active');
      tabSelected.classList.remove('active');
    } else {
      tabIncoming.classList.remove('active');
      tabSelected.classList.add('active');
    }

    if (tabSelectedLabel) {
      if (appState.selectedCalDate) {
        const d = new Date(appState.selectedCalDate + 'T00:00:00');
        const dStr = d.toLocaleDateString(isBM ? 'ms-MY' : 'en-US', { day: 'numeric', month: 'short' });
        tabSelectedLabel.textContent = `🎯 ${dStr}`;
      } else {
        tabSelectedLabel.textContent = isBM ? '🎯 Tarikh Dipilih' : '🎯 Selected Date';
      }
    }
  }

  const titleEl = document.getElementById('selectedDayTitle');
  const subtitleEl = document.querySelector('#selectedDayDetails .card-subtitle');

  if (mode === 'incoming') {
    let modeTitle = isBM ? 'Tempahan Akan Datang' : 'Incoming Bookings';
    let modeSubtitle = isBM ? 'Susunan mengikut tarikh terdekat' : 'Ordered by nearest dates';
    let modeIcon = 'fa-calendar-days';

    if (calFilter === 'checkin') {
      modeTitle = isBM ? 'Daftar Masuk Akan Datang' : 'Upcoming Check-Ins';
      modeSubtitle = isBM ? 'Susunan tarikh daftar masuk terdekat' : 'Ordered by nearest check-in dates';
      modeIcon = 'fa-arrow-right-to-bracket';
    } else if (calFilter === 'checkout') {
      modeTitle = isBM ? 'Daftar Keluar & Kekosongan' : 'Upcoming Check-Outs & Vacancies';
      modeSubtitle = isBM ? 'Susunan tarikh daftar keluar terdekat' : 'Ordered by nearest check-out dates';
      modeIcon = 'fa-arrow-right-from-bracket';
    }

    if (subtitleEl) subtitleEl.textContent = modeSubtitle;
    if (titleEl) {
      titleEl.innerHTML = `<i class="fa-solid ${modeIcon}" style="color:var(--primary); margin-right:6px;"></i>${modeTitle} <span class="badge-count" style="font-size:12px; font-weight:700; background:var(--primary-light); color:var(--primary); padding:2px 8px; border-radius:12px; margin-left:6px; vertical-align:middle;">${incomingBookings.length}</span>`;
    }

    if (incomingBookings.length === 0) {
      const emptyMsg = calFilter === 'checkout'
        ? (isBM ? 'Tiada daftar keluar dijadualkan.' : 'No check-outs scheduled.')
        : (isBM ? 'Semua unit kini tiada tempahan baharu. Tekan + untuk tambah tempahan.' : 'All units currently have no upcoming bookings. Tap + to add a booking.');

      list.innerHTML = `
        <div class="empty-hint" style="padding: 24px 16px; text-align: center;">
          <i class="fa-solid fa-calendar-xmark" style="font-size: 28px; color: var(--text-muted); opacity: 0.5; margin-bottom: 8px; display: block;"></i>
          <p style="font-size: 14px; font-weight: 600; color: var(--text-main); margin-bottom: 4px;">
            ${isBM ? 'Tiada Rekod Dijumpai' : 'No Records Found'}
          </p>
          <p style="font-size: 12.5px; color: var(--text-muted); margin-bottom: 14px;">
            ${emptyMsg}
          </p>
          <button class="btn btn-primary btn-sm" id="btnCalAddBookingEmpty">
            <i class="fa-solid fa-plus"></i> ${isBM ? 'Tambah Tempahan' : 'Add Booking'}
          </button>
        </div>
      `;
      const emptyAddBtn = document.getElementById('btnCalAddBookingEmpty');
      if (emptyAddBtn) emptyAddBtn.addEventListener('click', () => openBookingModal());
      return;
    }

    // Render incoming bookings cards
    incomingBookings.forEach(b => {
      const card = createCalendarBookingCard(b, todayStr, isBM, false);
      list.appendChild(card);
    });

  } else {
    // Mode is 'selected' (date selected on calendar)
    const dateStr = appState.selectedCalDate || todayStr;
    const d = new Date(dateStr + 'T00:00:00');
    const formattedDate = d.toLocaleDateString(isBM ? 'ms-MY' : 'en-US', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' });

    if (subtitleEl) {
      subtitleEl.textContent = isBM ? 'Tarikh Dipilih' : 'Selected Date';
    }
    if (titleEl) {
      titleEl.innerHTML = `<i class="fa-regular fa-calendar-check" style="color:var(--primary); margin-right:6px;"></i>${formattedDate}`;
    }

    const allFiltered = getFilteredBookings().filter(b => b.status !== 'cancelled');
    const dayCheckIns = allFiltered.filter(b => b.checkIn === dateStr);
    const dayCheckOuts = allFiltered.filter(b => b.checkOut === dateStr);
    const dayInStays = allFiltered.filter(b => {
      if (b.checkIn === b.checkOut) return b.checkIn === dateStr;
      return b.checkIn <= dateStr && b.checkOut > dateStr;
    });

    const activeProps = appState.selectedPropertyId === 'all'
      ? appState.properties
      : appState.properties.filter(p => p.id === appState.selectedPropertyId);
    const occupiedPropIds = new Set(dayInStays.map(b => b.propertyId));
    const vacantCount = Math.max(0, activeProps.length - occupiedPropIds.size);

    // 1. Render Metrics Bar
    const metricsBar = document.createElement('div');
    metricsBar.className = 'cal-date-metrics-bar';
    metricsBar.innerHTML = `
      <div class="cal-metric-chip ${calFilter === 'checkin' ? 'active-in' : ''}">
        <span class="metric-num">${dayCheckIns.length}</span>
        <span class="metric-lbl"><i class="fa-solid fa-arrow-right-to-bracket"></i> ${isBM ? 'Masuk' : 'Check-In'}</span>
      </div>
      <div class="cal-metric-chip ${calFilter === 'checkout' ? 'active-out' : ''}">
        <span class="metric-num">${dayCheckOuts.length}</span>
        <span class="metric-lbl"><i class="fa-solid fa-arrow-right-from-bracket"></i> ${isBM ? 'Keluar' : 'Check-Out'}</span>
      </div>
      <div class="cal-metric-chip ${calFilter === 'stays' ? 'active-in' : ''}">
        <span class="metric-num">${dayInStays.length}</span>
        <span class="metric-lbl"><i class="fa-solid fa-bed"></i> ${isBM ? 'Menginap' : 'In-Stay'}</span>
      </div>
      <div class="cal-metric-chip active-avail">
        <span class="metric-num">${vacantCount}</span>
        <span class="metric-lbl"><i class="fa-solid fa-door-open"></i> ${isBM ? 'Kosong' : 'Available'}</span>
      </div>
    `;
    list.appendChild(metricsBar);

    // 2. Render content according to calFilter
    if (calFilter === 'checkout') {
      if (dayCheckOuts.length > 0) {
        dayCheckOuts.forEach(b => {
          const prop = getPropertyById(b.propertyId);
          const alertCard = document.createElement('div');
          alertCard.className = 'cal-vacating-alert-card';
          alertCard.innerHTML = `
            <div class="alert-icon">
              <i class="fa-solid fa-door-open"></i>
            </div>
            <div class="alert-content">
              <strong>✨ ${prop.name} — ${isBM ? 'Daftar Keluar Hari Ini' : 'Checking Out Today'}</strong>
              <p>${isBM 
                ? `Tetamu <b>${b.guestName}</b> keluar jam ${prop.checkOutTime || '12:00 PM'}. Unit dibersihkan &amp; sedia untuk tetamu baharu mendaftar masuk jam ${prop.checkInTime || '3:00 PM'}!` 
                : `Guest <b>${b.guestName}</b> departs by ${prop.checkOutTime || '12:00 PM'}. Unit will be cleaned &amp; ready for a new guest check-in at ${prop.checkInTime || '3:00 PM'}!`}</p>
              <button class="btn btn-primary btn-sm btn-book-vacating-unit" data-pid="${prop.id}" data-date="${dateStr}">
                <i class="fa-solid fa-calendar-plus"></i> ${isBM ? '+ Tempah Unit Ini Mulai Hari Ini' : '+ Book This Unit Starting Today'}
              </button>
            </div>
          `;
          list.appendChild(alertCard);

          const card = createCalendarBookingCard(b, todayStr, isBM, true, dateStr);
          list.appendChild(card);
        });
      } else {
        list.innerHTML += `
          <div class="empty-hint" style="padding: 20px 16px; text-align: center;">
            <i class="fa-solid fa-circle-info" style="font-size: 26px; color: var(--text-muted); opacity: 0.6; margin-bottom: 8px; display: block;"></i>
            <p style="font-size: 14px; font-weight: 700; color: var(--text-main); margin-bottom: 4px;">
              ${isBM ? 'Tiada Daftar Keluar pada Tarikh Ini' : 'No Check-Outs on this Date'}
            </p>
            <p style="font-size: 12.5px; color: var(--text-muted); margin-bottom: 14px;">
              ${vacantCount > 0 
                ? (isBM ? `${vacantCount} unit homestay sedia ditempah.` : `${vacantCount} homestay unit(s) available for new booking.`)
                : (isBM ? 'Semua unit sedang diduduki tetamu.' : 'All units occupied by in-house guests.')}
            </p>
            <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
              <button class="btn btn-primary btn-sm" id="btnQuickBookForDateEmpty">
                <i class="fa-solid fa-plus"></i> ${isBM ? 'Tempah Tarikh Ini' : 'Book This Date'}
              </button>
              <button class="btn btn-outline btn-sm" id="btnSwitchToIncoming">
                <i class="fa-regular fa-clock"></i> ${isBM ? '📅 Semua Akan Datang' : '📅 All Incoming Bookings'}
              </button>
            </div>
          </div>
        `;
      }
    } else if (calFilter === 'checkin') {
      if (dayCheckIns.length > 0) {
        dayCheckIns.forEach(b => {
          const card = createCalendarBookingCard(b, todayStr, isBM, true, dateStr);
          list.appendChild(card);
        });

        if (vacantCount > 0) {
          const availBanner = document.createElement('div');
          availBanner.style.cssText = 'background:var(--bg-surface-subtle); border:1px dashed var(--border-color); border-radius:var(--radius-md); padding:10px 14px; margin-top:10px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;';
          availBanner.innerHTML = `
            <span style="font-size:12.5px; color:var(--text-muted);">
              <i class="fa-solid fa-circle-check" style="color:var(--success);"></i> <strong>${vacantCount}</strong> ${isBM ? 'lagi unit kosong pada tarikh ini.' : 'more unit(s) available on this date.'}
            </span>
            <button class="btn btn-outline btn-xs" id="btnAddCheckinTodayBtn">
              <i class="fa-solid fa-plus"></i> ${isBM ? 'Tambah Tempahan' : 'Add Booking'}
            </button>
          `;
          list.appendChild(availBanner);
          const addBtn = availBanner.querySelector('#btnAddCheckinTodayBtn');
          if (addBtn) addBtn.addEventListener('click', () => openBookingModal(null, dateStr));
        }
      } else {
        list.innerHTML += `
          <div class="empty-hint" style="padding: 20px 16px; text-align: center;">
            <i class="fa-solid fa-calendar-check" style="font-size: 26px; color: var(--success); margin-bottom: 8px; display: block;"></i>
            <p style="font-size: 14px; font-weight: 700; color: var(--text-main); margin-bottom: 4px;">
              ${isBM ? 'Tiada Daftar Masuk pada Tarikh Ini' : 'No Check-Ins on this Date'}
            </p>
            <p style="font-size: 12.5px; color: var(--text-muted); margin-bottom: 14px;">
              ${vacantCount > 0 
                ? (isBM ? `${vacantCount} unit sedia untuk ditempah.` : `${vacantCount} unit(s) available for new booking.`)
                : (isBM ? 'Tiada daftar masuk baharu (unit sedang menginap).' : 'No new check-in arrivals scheduled.')}
            </p>
            <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
              <button class="btn btn-primary btn-sm" id="btnQuickBookForDateEmpty">
                <i class="fa-solid fa-plus"></i> ${isBM ? 'Tempah Tarikh Ini' : 'Book This Date'}
              </button>
              <button class="btn btn-outline btn-sm" id="btnSwitchToIncoming">
                <i class="fa-regular fa-clock"></i> ${isBM ? '📅 Semua Akan Datang' : '📅 All Incoming Bookings'}
              </button>
            </div>
          </div>
        `;
      }
    } else {
      // Stays mode
      if (dayInStays.length > 0) {
        dayInStays.forEach(b => {
          const card = createCalendarBookingCard(b, todayStr, isBM, true, dateStr);
          list.appendChild(card);
        });
      } else {
        list.innerHTML += `
          <div class="empty-hint" style="padding: 20px 16px; text-align: center;">
            <i class="fa-solid fa-bed" style="font-size: 26px; color: var(--success); margin-bottom: 8px; display: block;"></i>
            <p style="font-size: 14px; font-weight: 700; color: var(--text-main); margin-bottom: 4px;">
              ${isBM ? 'Tiada Penginapan pada Tarikh Ini' : 'No Stays on this Date'}
            </p>
            <p style="font-size: 12.5px; color: var(--text-muted); margin-bottom: 14px;">
              ${isBM ? 'Semua unit kosong & sedia ditempah.' : 'All units vacant & ready for booking.'}
            </p>
            <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
              <button class="btn btn-primary btn-sm" id="btnQuickBookForDateEmpty">
                <i class="fa-solid fa-plus"></i> ${isBM ? 'Tempah Tarikh Ini' : 'Book This Date'}
              </button>
              <button class="btn btn-outline btn-sm" id="btnSwitchToIncoming">
                <i class="fa-regular fa-clock"></i> ${isBM ? '📅 Semua Akan Datang' : '📅 All Incoming Bookings'}
              </button>
            </div>
          </div>
        `;
      }
    }

    const qbBtn = document.getElementById('btnQuickBookForDateEmpty');
    if (qbBtn) qbBtn.addEventListener('click', () => openBookingModal(null, dateStr));

    const swBtn = document.getElementById('btnSwitchToIncoming');
    if (swBtn) swBtn.addEventListener('click', () => {
      appState.calListingMode = 'incoming';
      document.querySelectorAll('.cal-day-cell').forEach(c => c.classList.remove('selected'));
      renderCalendarListing();
    });
  }

  // Bind actions
  attachCalendarCardActions(list);
}

function createCalendarBookingCard(b, todayStr, isBM, isSelectedDayMode, selectedDateStr = null) {
  const prop = getPropertyById(b.propertyId);
  const card = document.createElement('div');
  card.className = 'booking-card cal-listing-booking-card';
  card.style.borderLeft = `4px solid ${prop.color}`;

  const proximity = getBookingProximityInfo(b, todayStr, isBM);
  let badgeText = proximity.label;
  let badgeClass = proximity.badgeClass;

  if (isSelectedDayMode && selectedDateStr) {
    if (b.checkIn === selectedDateStr) {
      badgeText = isBM ? '📥 Daftar Masuk' : '📥 Check-In Day';
      badgeClass = 'cal-prox-today';
    } else if (b.checkOut === selectedDateStr) {
      badgeText = isBM ? '📤 Daftar Keluar' : '📤 Check-Out Day';
      badgeClass = 'cal-prox-checkout';
    } else {
      badgeText = isBM ? '🔑 Sedang Menginap' : '🔑 In-Stay';
      badgeClass = 'cal-prox-instay';
    }
  }

  // Status tag
  let statusBadge = '';
  if (b.status === 'confirmed') {
    statusBadge = `<span class="badge-pill badge-confirmed">${isBM ? '🟢 Sah' : '🟢 Confirmed'}</span>`;
  } else if (b.status === 'booked') {
    statusBadge = `<span class="badge-pill badge-booked">${isBM ? '🟡 Ditempah' : '🟡 Booked'}</span>`;
  } else if (b.status === 'checked-in') {
    statusBadge = `<span class="badge-pill badge-inhouse">${isBM ? '🔑 Menginap' : '🔑 In-House'}</span>`;
  } else if (b.status === 'quotation') {
    statusBadge = `<span class="badge-pill badge-quotation">${isBM ? '📋 Sebut Harga' : '📋 Quotation'}</span>`;
  }

  const isCheckinReminderEligible = (b.status === 'booked' || b.status === 'confirmed') && b.checkIn >= todayStr;

  card.innerHTML = `
    <div class="booking-card-top">
      <span class="booking-prop-badge" style="background:${prop.color}20; color:${prop.color};">
        <span class="property-dot" style="background:${prop.color};"></span> ${prop.name}
      </span>
      <div style="display:flex; gap:6px; align-items:center;">
        ${(b.payments && b.payments.length > 0) ? `
          <button type="button" class="btn-open-receipt-gallery" data-bid="${b.id}" style="font-size:10px; font-weight:800; padding:1px 6px; border-radius:999px; background:#eff6ff; color:#1d4ed8; border:1px solid #93c5fd; cursor:pointer;" title="${t('receipt_gallery_title')}">
            <i class="fa-solid fa-receipt"></i> ${b.payments.length}
          </button>
        ` : ''}
        ${statusBadge}
        <span class="cal-proximity-badge ${badgeClass}">${badgeText}</span>
      </div>
    </div>
    <h3 class="booking-guest-title">${b.guestName} <span style="font-size:13px; font-weight:600; color:var(--text-muted);">(${b.guestCount || 1} ${t('guests')})</span></h3>
    <p class="booking-dates-row">
      <i class="fa-regular fa-calendar"></i> <strong>${b.checkIn}</strong> → <strong>${b.checkOut}</strong> (${b.nights || 1} ${t('nights')})
    </p>
    <div class="booking-financial-pill">
      <span>${t('total')}: <strong>${formatCurrency(b.totalAmount)}</strong></span>
      <span>${t('balance')}: <strong style="color:${b.balance > 0 ? 'var(--danger)' : 'var(--success)'};">${formatCurrency(b.balance)}</strong></span>
    </div>
    <div class="booking-actions-row" style="flex-wrap: wrap;">
      <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}">
        <i class="fa-brands fa-whatsapp"></i> ${t('btn_wa')}
      </button>
      ${isCheckinReminderEligible ? `
      <button class="btn btn-primary btn-xs btn-open-wa-reminder" data-bid="${b.id}" title="${isBM ? 'Hantar peringatan daftar masuk' : 'Send check-in reminder'}">
        <i class="fa-regular fa-bell"></i> ${isBM ? 'Peringatan Masuk' : 'Check-In Reminder'}
      </button>
      ` : ''}
      <button class="btn btn-outline btn-xs btn-change-homestay" data-bid="${b.id}" title="${t('btn_change_homestay')}">
        <i class="fa-solid fa-arrow-right-arrow-left"></i> ${t('btn_change_homestay')}
      </button>
      <button class="btn btn-outline btn-xs btn-open-pdf-doc" data-bid="${b.id}" title="${isBM ? 'Jana Dokumen PDF Rasmi (Sebut Harga / Invois / Resit)' : 'Generate Official PDF (Quotation / Invoice / Receipt)'}" style="color:var(--primary); font-weight:700;">
        <i class="fa-solid fa-file-pdf"></i> PDF
      </button>
      <button class="btn btn-outline btn-xs btn-edit-booking" data-bid="${b.id}">
        <i class="fa-solid fa-pen"></i> ${t('btn_edit')}
      </button>
    </div>
  `;

  return card;
}

function getBookingProximityInfo(b, todayStr, isBM) {
  const checkInDate = new Date(b.checkIn + 'T00:00:00');
  const checkOutDate = new Date(b.checkOut + 'T00:00:00');
  const todayDate = new Date(todayStr + 'T00:00:00');

  const diffMs = checkInDate - todayDate;
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (b.checkIn <= todayStr && b.checkOut >= todayStr) {
    if (b.checkIn === todayStr) {
      return {
        label: isBM ? '🟢 Masuk Hari Ini' : '🟢 Check-In Today',
        badgeClass: 'cal-prox-today'
      };
    }
    if (b.checkOut === todayStr) {
      return {
        label: isBM ? '🔴 Keluar Hari Ini' : '🔴 Check-Out Today',
        badgeClass: 'cal-prox-checkout'
      };
    }
    const remDays = Math.round((checkOutDate - todayDate) / (1000 * 60 * 60 * 24));
    return {
      label: isBM ? `🔑 Menginap (Baki ${remDays} mlm)` : `🔑 In-Stay (${remDays} nights left)`,
      badgeClass: 'cal-prox-instay'
    };
  }

  if (diffDays === 1) {
    return {
      label: isBM ? '🟡 Esok (Daftar Masuk)' : '🟡 Tomorrow (Check-In)',
      badgeClass: 'cal-prox-tomorrow'
    };
  }
  if (diffDays === 2) {
    return {
      label: isBM ? '⏳ 2 Hari Lagi' : '⏳ In 2 Days',
      badgeClass: 'cal-prox-soon'
    };
  }
  if (diffDays > 2 && diffDays <= 7) {
    return {
      label: isBM ? `📅 ${diffDays} Hari Lagi` : `📅 In ${diffDays} Days`,
      badgeClass: 'cal-prox-soon'
    };
  }
  if (diffDays > 7) {
    return {
      label: isBM ? `📅 Dalam ${diffDays} Hari` : `📅 In ${diffDays} Days`,
      badgeClass: 'cal-prox-future'
    };
  }

  return {
    label: isBM ? 'Akan Datang' : 'Upcoming',
    badgeClass: 'cal-prox-future'
  };
}

function attachCalendarCardActions(container) {
  container.querySelectorAll('.btn-open-wa').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openWhatsAppModal(b);
    });
  });

  container.querySelectorAll('.btn-open-wa-reminder').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openWhatsAppModal(b, 'checkin_reminder');
    });
  });

  container.querySelectorAll('.btn-change-homestay').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openChangeHomestayModal(b);
    });
  });

  container.querySelectorAll('.btn-open-pdf-doc').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        const docType = (b.status === 'confirmed' || b.status === 'completed') ? 'receipt' : b.status === 'booked' ? 'deposit_receipt' : 'quotation';
        openPdfDocModal(b, docType);
      }
    });
  });

  container.querySelectorAll('.btn-edit-booking').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openBookingModal(b);
    });
  });

  container.querySelectorAll('.btn-book-vacating-unit').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pid = e.currentTarget.getAttribute('data-pid');
      const dStr = e.currentTarget.getAttribute('data-date');
      openBookingModal(null, dStr, pid);
    });
  });

  container.querySelectorAll('.btn-open-receipt-gallery').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openReceiptViewerModal(b);
    });
  });
}

function renderSelectedDayDetails() {
  renderCalendarListing();
}

// ==========================================================================
// 7. BOOKINGS (GUEST CRM) TAB
// ==========================================================================

function renderBookingsTab() {
  const container = document.getElementById('bookingsContainer');
  container.innerHTML = '';

  const query = (document.getElementById('bookingSearchInput')?.value || '').toLowerCase().trim();
  const activeFilterBtn = document.querySelector('#bookingStatusFilters .filter-pill.active');
  const filterType = activeFilterBtn ? activeFilterBtn.getAttribute('data-filter') : 'all';

  let bookings = getFilteredBookings();
  const todayStr = formatLocalDate(new Date());

  // Apply status filter
  if (filterType === 'all') {
    // Active operational workflow: completed historical monthly tenancies are archived
    bookings = bookings.filter(b => !isCompletedTenancy(b, todayStr));
  } else if (filterType === 'quotation') {
    bookings = bookings.filter(b => b.status === 'quotation');
  } else if (filterType === 'booked') {
    bookings = bookings.filter(b => b.status === 'booked');
  } else if (filterType === 'confirmed') {
    bookings = bookings.filter(b => b.status === 'confirmed');
  } else if (filterType === 'active') {
    bookings = bookings.filter(b => b.status === 'checked-in' || (b.checkIn <= todayStr && b.checkOut >= todayStr && b.status !== 'cancelled' && b.status !== 'quotation' && !isCompletedTenancy(b, todayStr)));
  } else if (filterType === 'completed') {
    bookings = bookings.filter(b => b.status === 'checked-out' || b.status === 'completed' || b.checkOut < todayStr);
  } else if (filterType === 'historical_tenancy') {
    bookings = bookings.filter(b => isCompletedTenancy(b, todayStr));
  } else if (filterType === 'blocked') {
    bookings = bookings.filter(b => b.status === 'blocked');
  }

  // Apply search query
  if (query) {
    bookings = bookings.filter(b => 
      (b.guestName && b.guestName.toLowerCase().includes(query)) ||
      (b.companyName && b.companyName.toLowerCase().includes(query)) ||
      (b.companyRegNo && b.companyRegNo.toLowerCase().includes(query)) ||
      (b.contactPerson && b.contactPerson.toLowerCase().includes(query)) ||
      (b.guestPhone && b.guestPhone.includes(query)) ||
      (b.contactPhone && b.contactPhone.includes(query)) ||
      (b.guestNric && b.guestNric.toLowerCase().includes(query)) ||
      (b.notes && b.notes.toLowerCase().includes(query))
    );
  }

  // Sort by check-in date descending
  bookings.sort((a, b) => new Date(b.checkIn) - new Date(a.checkIn));

  const isBM = appState.settings.language === 'bm';

  if (bookings.length === 0) {
    const isHist = filterType === 'historical_tenancy';
    container.innerHTML = `
      <div class="card" style="text-align:center; padding:32px 16px;">
        <i class="fa-solid ${isHist ? 'fa-clock-rotate-left' : 'fa-address-book'}" style="font-size:32px; color:var(--text-subtle); margin-bottom:8px;"></i>
        <h4 style="font-size:14px; font-weight:700;">${isHist ? (isBM ? 'Tiada Rekod Sejarah Sewaan' : 'No Historical Tenancies Found') : t('no_bookings_found')}</h4>
        <p class="card-subtitle">${isHist ? (isBM ? 'Semua sewaan bulanan yang telah tamat atau diselesaikan akan disimpan secara automatik di sini.' : 'All monthly tenancies that have completed or ended will be archived here automatically.') : t('no_bookings_hint')}</p>
      </div>
    `;
    return;
  }

  // If in 'All' active view and historical tenancies exist, show helpful access banner
  const allHistoricalTenancies = getFilteredBookings().filter(b => isCompletedTenancy(b, todayStr));
  if (filterType === 'all' && allHistoricalTenancies.length > 0 && !query) {
    const banner = document.createElement('div');
    banner.style.cssText = 'display:flex; align-items:center; justify-content:space-between; gap:10px; padding:10px 14px; background:var(--bg-surface-subtle); border:1px dashed var(--border-color); border-radius:var(--radius-md); margin-bottom:12px; font-size:12px;';
    banner.innerHTML = `
      <span style="color:var(--text-muted);"><i class="fa-solid fa-clock-rotate-left" style="color:var(--primary); margin-right:4px;"></i> ${isBM ? `<strong>${allHistoricalTenancies.length}</strong> sewaan bulanan tamat diarkibkan dalam Sejarah Sewaan.` : `<strong>${allHistoricalTenancies.length}</strong> completed monthly tenancies archived in Historical.`}</span>
      <button class="btn btn-outline btn-xs" id="btnBannerViewHistTenancies" style="font-weight:700; white-space:nowrap; border-radius:999px;">
        ${isBM ? 'Lihat Sejarah Sewaan' : 'View Historical'}
      </button>
    `;
    container.appendChild(banner);
    banner.querySelector('#btnBannerViewHistTenancies')?.addEventListener('click', () => {
      const histPill = document.querySelector('#bookingStatusFilters .filter-pill[data-filter="historical_tenancy"]');
      if (histPill) histPill.click();
    });
  }

  bookings.forEach(b => {
    const prop = getPropertyById(b.propertyId);
    const card = document.createElement('div');
    card.className = 'booking-card';
    card.style.borderLeft = `4px solid ${prop.color}`;

    const isHistTenancy = isCompletedTenancy(b, todayStr);

    const statusBadgeColors = {
      'quotation': 'background: var(--primary-light); color: var(--primary-text);',
      'booked': 'background: var(--warning-light); color: var(--warning-text); border: 1px solid rgba(245,158,11,0.4);',
      'confirmed': 'background: var(--success-light); color: var(--success-text); border: 1px solid rgba(16,185,129,0.4);',
      'checked-in': 'background: #dbeafe; color: #1e40af;',
      'checked-out': isHistTenancy ? 'background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1;' : 'background: var(--bg-surface-subtle); color: var(--text-muted);',
      'completed': 'background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1;',
      'blocked': 'background: var(--danger-light); color: var(--danger-text);',
      'cancelled': 'background: var(--danger-light); color: var(--danger-text);'
    };

    const statusLabels = isBM ? {
      'quotation': '📋 SEBUT HARGA',
      'booked': '🟡 DITEMPAH (DEPOSIT)',
      'confirmed': '🟢 DISAHKAN (PENUH)',
      'checked-in': '🔑 MENGINAP (CHECK-IN)',
      'checked-out': isHistTenancy ? '📜 SEJARAH SEWAAN (TAMAT)' : '🏁 SELESAI',
      'completed': isHistTenancy ? '📜 SEJARAH SEWAAN (SELESAI)' : '🏁 SELESAI',
      'blocked': '🚫 DISEKAT',
      'cancelled': '❌ DIBATALKAN'
    } : {
      'quotation': '📋 QUOTATION',
      'booked': '🟡 BOOKED (DEPOSIT PAID)',
      'confirmed': '🟢 CONFIRMED (PAID FULL)',
      'checked-in': '🔑 IN-HOUSE (CHECKED IN)',
      'checked-out': isHistTenancy ? '📜 HISTORICAL TENANCY (ENDED)' : '🏁 COMPLETED',
      'completed': isHistTenancy ? '📜 HISTORICAL TENANCY (COMPLETED)' : '🏁 COMPLETED',
      'blocked': '🚫 BLOCKED',
      'cancelled': '❌ CANCELLED'
    };

    const channelIcons = {
      'whatsapp': '<i class="fa-brands fa-whatsapp" style="color:var(--whatsapp)"></i> WhatsApp',
      'airbnb': '<i class="fa-solid fa-house" style="color:#ff385c"></i> Airbnb',
      'booking': '<i class="fa-solid fa-b" style="color:#003580"></i> Booking.com',
      'agoda': '<i class="fa-solid fa-globe" style="color:#7c3aed"></i> Agoda',
      'direct': '<i class="fa-solid fa-user-check"></i> Direct',
      'friends': '<i class="fa-solid fa-handshake"></i> Friends',
      'walkin': '<i class="fa-solid fa-person-walking"></i> Walk-In'
    };

    card.innerHTML = `
      <div class="booking-card-top">
        <span class="booking-prop-badge" style="background:${prop.color}20; color:${prop.color};">
          <span class="property-dot" style="background:${prop.color};"></span> ${prop.name}
        </span>
        <span class="booking-channel-badge">${channelIcons[b.channel] || b.channel}</span>
      </div>
      
      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:2px;">
        <div style="display:flex; flex-direction:column; gap:2px;">
          <h3 class="booking-guest-title" style="margin:0;">
            ${b.guestName}
            ${b.tenantType === 'company' ? `<span style="font-size:9.5px; font-weight:700; background:#f1f5f9; color:#475569; padding:2px 6px; border-radius:4px; border:1px solid #cbd5e1; margin-left:4px; vertical-align:middle;"><i class="fa-solid fa-building"></i> ${isBM ? 'Syarikat' : 'Company'}</span>` : ''}
          </h3>
          ${(b.tenantType === 'company' && b.contactPerson) ? `
            <div style="font-size:11px; color:var(--text-muted); display:flex; align-items:center; gap:4px;">
              <i class="fa-solid fa-user-tie" style="color:var(--primary); font-size:10px;"></i> <span>${escapeHtml(b.contactPerson)}${b.contactDesignation ? ` (${escapeHtml(b.contactDesignation)})` : ''}</span>
            </div>
          ` : ''}
        </div>
        <div style="display:flex; gap:4px; align-items:center; flex-wrap:wrap;">
          ${(b.payments && b.payments.length > 0) ? `
            <button type="button" class="btn-open-receipt-gallery" data-bid="${b.id}" style="font-size:10px; font-weight:800; padding:2px 7px; border-radius:999px; background:#eff6ff; color:#1d4ed8; border:1px solid #93c5fd; cursor:pointer; display:inline-flex; align-items:center; gap:4px;">
              <i class="fa-solid fa-receipt"></i> ${b.payments.length} ${isBM ? 'Resit' : (b.payments.length === 1 ? 'Receipt' : 'Receipts')}
            </button>
          ` : ''}
          ${b.rentalType === 'monthly' ? `<span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:999px; background:#e0e7ff; color:#3730a3;"><i class="fa-solid fa-calendar-days"></i> ${b.monthlyDuration || 6} ${t('months')}</span>` : ''}
          ${b.rentalType === 'monthly' ? (() => {
            const invs = getOrInitMonthlyInvoices(b);
            const paidCnt = invs.filter(x => x.status === 'paid').length;
            const totalCnt = invs.length;
            const allPaid = paidCnt === totalCnt;
            return `<span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:999px; background:${allPaid ? '#dcfce7; color:#166534;' : '#fef3c7; color:#92400e;'}"><i class="fa-solid fa-file-invoice-dollar"></i> ${paidCnt}/${totalCnt} ${isBM ? 'Bulan Berbayar' : 'Months Settled'}</span>`;
          })() : ''}
          <span style="font-size:10px; font-weight:800; padding:3px 8px; border-radius:999px; ${statusBadgeColors[b.status] || ''}">${statusLabels[b.status] || b.status.toUpperCase()}</span>
        </div>
      </div>

      <p class="booking-dates-row">
        <i class="fa-regular fa-calendar"></i> ${b.checkIn} → ${b.checkOut} (${b.rentalType === 'monthly' ? `${b.monthlyDuration || 6} ${t('months')}` : `${b.nights} ${t('nights')}`}) • ${b.guestCount} ${t('guests')}
      </p>

      ${b.notes ? `<p style="font-size:12px; color:var(--text-muted); font-style:italic;"><i class="fa-regular fa-note-sticky"></i> "${b.notes}"</p>` : ''}

      <div class="booking-financial-pill">
        <span>${t('total')}: <strong>${formatCurrency(b.totalAmount)}</strong></span>
        <span>${isBM ? 'Dibayar' : 'Paid'}: <strong style="color:var(--success);">${formatCurrency(b.depositPaid)}</strong></span>
        <span>${isBM ? 'Baki' : 'Due'}: <strong style="color:${b.balance > 0 ? 'var(--danger)' : 'var(--success)'};">${formatCurrency(b.balance)}</strong></span>
        ${b.lastPaymentRef ? `
          <span style="display:flex; align-items:center; gap:4px; font-size:11px; margin-left:auto;">
            <i class="fa-solid fa-receipt" style="color:var(--primary);"></i>
            <span>Ref: <strong><code>${b.lastPaymentRef}</code></strong></span>
          </span>
        ` : ''}
      </div>
      ${b.rentalType === 'monthly' ? `
        <div style="font-size:11px; font-weight:700; color:#166534; background:#dcfce7; border:1px solid #bbf7d0; padding:3px 8px; border-radius:6px; display:inline-flex; align-items:center; gap:5px; margin-top:4px;">
          <i class="fa-solid fa-circle-check"></i> ${isBM ? 'Sewa Bulan 1 Telah Dibayar Melalui Pakej Kemasukan' : 'Month 1 Rental Paid Via Move-In Package'}
        </div>
      ` : ''}

      <!-- Contextual Quick Action Workflow Bar -->
      <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:4px;">
        <button class="btn btn-outline btn-xs btn-open-receipt-gallery" data-bid="${b.id}" title="${t('receipt_gallery_title')}">
          <i class="fa-solid fa-receipt"></i> ${(b.payments && b.payments.length > 0) ? `${b.payments.length} ${isBM ? 'Resit' : 'Receipts'}` : (isBM ? '+ Resit' : '+ Receipt')}
        </button>
        ${b.rentalType === 'monthly' ? `
          <button class="btn btn-outline btn-xs btn-open-monthly-invoices" data-bid="${b.id}" style="color:var(--primary); font-weight:700; border-color:var(--primary);" title="${t('btn_view_invoices')}">
            <i class="fa-solid fa-file-invoice-dollar"></i> ${t('btn_view_invoices')}
          </button>
          <button class="btn btn-outline btn-xs btn-open-agreement-form" data-bid="${b.id}" onclick="openAgreementModal('${b.id}', 'form')" style="color:#0284c7; font-weight:700; border-color:#0284c7; background:rgba(2,132,199,0.08);" title="${isBM ? 'Buka Borang & Isi Butiran Perjanjian (Contact Person, SSM, NRIC)' : 'Open Agreement Details Form (Contact Person, SSM, NRIC)'}">
            <i class="fa-solid fa-pen-to-square"></i> ${isBM ? 'Borang Perjanjian' : 'Agreement Form'}
          </button>
          <button class="btn btn-outline btn-xs btn-open-agreement-preview" data-bid="${b.id}" onclick="openAgreementModal('${b.id}', 'preview')" style="color:#0369a1; font-weight:700; border-color:#0369a1; background:rgba(3,105,161,0.06);" title="${isBM ? 'Lihat Pra Tonton Dokumen A4 Rasmi' : 'Preview Official A4 Agreement'}">
            <i class="fa-solid fa-file-lines"></i> ${isBM ? 'Pra Tonton' : 'Preview'}
          </button>
          <button class="btn btn-primary btn-xs btn-quick-download-agreement" data-bid="${b.id}" onclick="openAgreementModal('${b.id}', 'preview'); setTimeout(downloadAgreementPdf, 400);" style="font-weight:700; background:linear-gradient(135deg, #0284c7, #0369a1); border-color:#0284c7;" title="${isBM ? 'Muat Turun Terus PDF Perjanjian ke Folder Downloads' : 'Download Agreement PDF directly to Downloads folder'}">
            <i class="fa-solid fa-file-arrow-down"></i> ${isBM ? 'PDF' : 'PDF'}
          </button>
        ` : `
          <button class="btn btn-outline btn-xs btn-open-agreement-preview" data-bid="${b.id}" onclick="openAgreementModal('${b.id}', 'preview')" style="color:#0369a1; font-weight:700; border-color:#0369a1; background:rgba(3,105,161,0.06);" title="${isBM ? 'Jana Surat Perjanjian Sewaan bagi Tempahan Ini' : 'Generate Tenancy Agreement for this booking'}">
            <i class="fa-solid fa-file-signature"></i> ${isBM ? 'Perjanjian' : 'Agreement'}
          </button>
        `}

        ${b.status === 'quotation' ? `
          <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="quotation">
            <i class="fa-solid fa-file-lines"></i> ${t('btn_send_quotation')}
          </button>
          <button class="btn btn-outline btn-xs btn-mark-booked" data-bid="${b.id}">
            <i class="fa-solid fa-hand-holding-dollar" style="color:var(--warning);"></i> ${t('btn_mark_booked')}
          </button>
        ` : ''}

        ${b.status === 'booked' ? `
          <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="deposit_receipt">
            <i class="fa-solid fa-receipt"></i> ${t('btn_send_deposit_receipt')}
          </button>
          <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="checkin_reminder" style="color:var(--primary); font-weight:700;">
            <i class="fa-solid fa-bell"></i> ${t('btn_checkin_reminder')}
          </button>
          ${b.rentalType === 'monthly' ? `
            <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="monthly_invoice">
              <i class="fa-solid fa-file-invoice"></i> ${t('btn_send_invoice')}
            </button>
          ` : `
            <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="invoice">
              <i class="fa-solid fa-file-invoice"></i> ${t('btn_send_invoice')}
            </button>
          `}
          <button class="btn btn-outline btn-xs btn-mark-confirmed" data-bid="${b.id}">
            <i class="fa-solid fa-key" style="color:var(--success);"></i> ${t('btn_mark_confirmed')}
          </button>
        ` : ''}

        ${b.status === 'confirmed' ? `
          <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="full_receipt">
            <i class="fa-solid fa-key"></i> ${t('btn_send_full_receipt')}
          </button>
          <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="checkin_reminder" style="color:var(--primary); font-weight:700;">
            <i class="fa-solid fa-bell"></i> ${t('btn_checkin_reminder')}
          </button>
          <button class="btn btn-outline btn-xs btn-mark-checkin" data-bid="${b.id}">
            <i class="fa-solid fa-door-open" style="color:var(--primary);"></i> ${t('btn_checkin')}
          </button>
          ${b.rentalType === 'monthly' ? `
            <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="monthly_invoice">
              <i class="fa-solid fa-file-invoice"></i> ${t('btn_send_invoice')}
            </button>
          ` : ''}
        ` : ''}

        ${b.status === 'checked-in' ? `
          ${b.rentalType === 'monthly' ? `
            <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="monthly_invoice">
              <i class="fa-solid fa-file-invoice"></i> ${t('btn_send_invoice')}
            </button>
            <button class="btn btn-outline btn-xs btn-open-refund" data-bid="${b.id}">
              <i class="fa-solid fa-money-bill-transfer" style="color:var(--success);"></i> ${isBM ? 'Tamat Sewa & Pulang Deposit' : 'End Tenancy & Refund Deposit'}
            </button>
          ` : `
            <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="checkout">
              <i class="fa-solid fa-flag-checkered"></i> ${t('btn_checkout_reminder')}
            </button>
            ${b.securityDeposit > 0 ? `
              <button class="btn btn-outline btn-xs btn-open-refund" data-bid="${b.id}">
                <i class="fa-solid fa-money-bill-transfer" style="color:var(--success);"></i> ${isBM ? 'Pulang Deposit Keselamatan' : 'Refund Security Deposit'}
              </button>
            ` : ''}
            <button class="btn btn-outline btn-xs btn-mark-checkout" data-bid="${b.id}">
              <i class="fa-solid fa-check"></i> ${t('btn_complete_checkout')}
            </button>
          `}
        ` : ''}

        ${(b.status === 'checked-out' || b.status === 'completed' || isHistTenancy) ? `
          ${(b.rentalDeposit || b.securityDeposit) ? `
            <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="refund_receipt">
              <i class="fa-solid fa-file-invoice-dollar"></i> ${isBM ? 'Lihat Penyata Pulangan' : 'View Refund Statement'}
            </button>
          ` : ''}
          ${isHistTenancy ? `
            <button class="btn btn-outline btn-xs btn-reopen-tenancy" data-bid="${b.id}" style="color:var(--primary); font-weight:700;">
              <i class="fa-solid fa-arrow-rotate-left"></i> ${isBM ? 'Aktifkan Semula' : 'Reactivate'}
            </button>
          ` : ''}
        ` : ''}

        <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="payment" title="${t('btn_wa')}">
          <i class="fa-brands fa-whatsapp"></i>
        </button>
        <button class="btn btn-outline btn-xs btn-change-homestay" data-bid="${b.id}" title="${t('btn_change_homestay')}">
          <i class="fa-solid fa-arrow-right-arrow-left"></i> ${t('btn_change_homestay')}
        </button>
        <button class="btn btn-outline btn-xs btn-open-pdf-doc" data-bid="${b.id}" title="${isBM ? 'Jana Dokumen PDF Rasmi (Sebut Harga / Invois / Resit)' : 'Generate Official PDF (Quotation / Invoice / Receipt)'}" style="color:var(--primary); font-weight:700;">
          <i class="fa-solid fa-file-pdf"></i> PDF
        </button>
        <button class="btn btn-outline btn-xs btn-edit-booking" data-bid="${b.id}" title="${t('edit')}">
          <i class="fa-solid fa-pen"></i> ${t('edit')}
        </button>
        <button class="btn btn-danger-outline btn-xs btn-delete-booking" data-bid="${b.id}" title="${t('delete')}">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </div>
    `;

    container.appendChild(card);
  });

  // Attach event handlers
  container.querySelectorAll('.btn-open-monthly-invoices').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => String(x.id) === String(bid));
      if (b) openMonthlyInvoicesModal(b);
    });
  });

  container.querySelectorAll('.btn-open-agreement-form').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => String(x.id) === String(bid));
      if (b) openAgreementModal(b, 'form');
    });
  });

  container.querySelectorAll('.btn-open-agreement-preview, .btn-open-agreement').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => String(x.id) === String(bid));
      if (b) openAgreementModal(b, 'preview');
    });
  });

  container.querySelectorAll('.btn-quick-download-agreement').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => String(x.id) === String(bid));
      if (b) {
        openAgreementModal(b, 'preview');
        setTimeout(() => { downloadAgreementPdf(); }, 400);
      }
    });
  });

  container.querySelectorAll('.btn-open-wa').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const bid = e.currentTarget.getAttribute('data-bid');
      const waTemplate = e.currentTarget.getAttribute('data-wa') || 'quotation';
      const b = appState.bookings.find(x => String(x.id) === String(bid));
      if (b) {
        // If monthly invoice template, pick first pending month >= 2 (invoicing begins from Month 2)
        if (b.rentalType === 'monthly' && waTemplate === 'monthly_invoice') {
          const invs = getOrInitMonthlyInvoices(b);
          const pendingInvs = invs.filter(x => x.monthIndex >= 2 && x.status === 'pending');
          const mIdx = pendingInvs.length > 0 ? pendingInvs[0].monthIndex : 2;
          openWhatsAppModal(b, waTemplate, mIdx);
        } else {
          openWhatsAppModal(b, waTemplate);
        }
      }
    });
  });

  container.querySelectorAll('.btn-open-refund').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openDepositRefundModal(b);
    });
  });

  container.querySelectorAll('.btn-mark-booked').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        const defaultDep = b.depositPaid > 0 ? b.depositPaid : Math.round(b.totalAmount * (appState.settings.defaultDepositPct || 30) / 100);
        openPaymentProofModal(b, 'deposit', null, defaultDep);
      }
    });
  });

  container.querySelectorAll('.btn-mark-confirmed').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        const defaultBal = b.balance > 0 ? b.balance : b.totalAmount;
        openPaymentProofModal(b, 'balance', null, defaultBal);
      }
    });
  });

  container.querySelectorAll('.btn-open-receipt-gallery').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openReceiptViewerModal(b);
    });
  });

  container.querySelectorAll('.btn-mark-checkin').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        b.status = 'checked-in';
        saveToStorage();
        renderBookingsTab();
        showToast(isBM ? 'Tetamu didaftar masuk!' : 'Guest checked in!');
      }
    });
  });

  container.querySelectorAll('.btn-mark-checkout').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        b.status = 'checked-out';
        if (b.rentalType === 'monthly') {
          b.isHistorical = true;
        }
        if (b.balance > 0) {
          b.depositPaid = b.totalAmount;
          b.balance = 0;
        }
        saveToStorage();
        renderBookingsTab();
        renderDashboardTab();
        showToast(isBM 
          ? (b.rentalType === 'monthly' ? 'Sewaan selesai & telah dimasukkan ke Sejarah Sewaan.' : 'Tempahan selesai & baki diselesaikan.') 
          : (b.rentalType === 'monthly' ? 'Tenancy completed & archived into Historical Tenancies.' : 'Booking marked as completed & balance settled.'));
      }
    });
  });

  container.querySelectorAll('.btn-reopen-tenancy').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        if (confirm(isBM ? `Adakah anda ingin mengaktifkan semula sewaan bagi ${b.guestName}?` : `Do you want to reactivate the tenancy for ${b.guestName}?`)) {
          b.status = 'confirmed';
          b.isHistorical = false;
          saveToStorage();
          renderBookingsTab();
          renderDashboardTab();
          showToast(isBM ? 'Sewaan berjaya diaktifkan semula!' : 'Tenancy reactivated successfully!');
        }
      }
    });
  });

  container.querySelectorAll('.btn-change-homestay').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openChangeHomestayModal(b);
    });
  });

  container.querySelectorAll('.btn-open-pdf-doc').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        const docType = (b.status === 'confirmed' || b.status === 'completed') ? 'receipt' : b.status === 'booked' ? 'deposit_receipt' : 'quotation';
        openPdfDocModal(b, docType);
      }
    });
  });

  container.querySelectorAll('.btn-edit-booking').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openBookingModal(b);
    });
  });

  container.querySelectorAll('.btn-delete-booking').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const confirmText = isBM ? 'Adakah anda pasti mahu memadamkan tempahan ini?' : 'Are you sure you want to delete this booking?';
      if (confirm(confirmText)) {
        appState.bookings = appState.bookings.filter(x => x.id !== bid);
        appState.turnovers = appState.turnovers.filter(tItem => tItem.bookingId !== bid);
        saveToStorage();
        renderBookingsTab();
        showToast(isBM ? 'Tempahan dipadamkan.' : 'Booking deleted successfully.');
      }
    });
  });
}

// ==========================================================================
// 8. TURNOVERS & CLEANING TAB
// ==========================================================================

function renderTurnoversTab() {
  const container = document.getElementById('turnoversContainer');
  container.innerHTML = '';

  const turnovers = getFilteredTurnovers();
  turnovers.sort((a, b) => new Date(a.date) - new Date(b.date));

  if (turnovers.length === 0) {
    container.innerHTML = `
      <div class="card" style="text-align:center; padding:32px 16px;">
        <i class="fa-solid fa-broom" style="font-size:32px; color:var(--text-subtle); margin-bottom:8px;"></i>
        <h4 style="font-size:14px; font-weight:700;">${t('no_turnovers')}</h4>
        <p class="card-subtitle">${t('all_clean_hint')}</p>
      </div>
    `;
    return;
  }

  const isBM = appState.settings.language === 'bm';

  turnovers.forEach(tItem => {
    const prop = getPropertyById(tItem.propertyId);
    const checklist = Array.isArray(tItem.checklist) ? tItem.checklist : [];
    const completedCount = checklist.filter(c => c.done).length;
    const isAllDone = completedCount === checklist.length && checklist.length > 0;

    const card = document.createElement('div');
    card.className = 'turnover-card';
    card.style.borderLeft = `4px solid ${isAllDone ? 'var(--success)' : prop.color}`;

    card.innerHTML = `
      <div class="card-header-flex">
        <div>
          <span class="booking-prop-badge" style="background:${prop.color}20; color:${prop.color};">
            <span class="property-dot" style="background:${prop.color};"></span> ${prop.name}
          </span>
          <h4 style="font-size:15px; font-weight:700; margin-top:4px;">${t('turnover')}: ${tItem.date}</h4>
          <p class="card-subtitle">${booking ? `${isBM ? 'Selepas tetamu' : 'After guest'}: ${booking.guestName}` : (isBM ? 'Pembersihan Menyeluruh Rutin' : 'Routine Deep Clean')}</p>
        </div>
        <span style="font-size:11px; font-weight:700; padding:3px 8px; border-radius:999px; ${isAllDone ? 'background:var(--success-light);color:var(--success-text);' : 'background:var(--warning-light);color:var(--warning-text);'}">
          ${isAllDone ? (isBM ? 'SEDIA UNTUK TETAMU' : 'READY FOR GUEST') : `${completedCount}/${checklist.length} ${isBM ? 'SIAP' : 'DONE'}`}
        </span>
      </div>

      <div class="turnover-checklist">
        ${checklist.map((item, idx) => `
          <label class="checklist-item">
            <input type="checkbox" data-tid="${tItem.id}" data-idx="${idx}" ${item.done ? 'checked' : ''}>
            <span style="${item.done ? 'text-decoration:line-through; opacity:0.6;' : ''}">${item.text}</span>
          </label>
        `).join('')}
      </div>

      <div class="card-header-flex" style="margin-top:8px; margin-bottom:0;">
        <button class="btn btn-whatsapp btn-xs btn-wa-cleaner" data-tid="${tItem.id}">
          <i class="fa-brands fa-whatsapp"></i> ${t('btn_wa_cleaner')}
        </button>
        <button class="btn btn-outline btn-xs btn-toggle-turnover" data-tid="${tItem.id}">
          ${isAllDone ? `<i class="fa-solid fa-rotate-left"></i> ${isBM ? 'Buka Semula' : 'Reopen'}` : `<i class="fa-solid fa-check"></i> ${isBM ? 'Tanda Selesai' : 'Mark Complete'}`}
        </button>
      </div>
    `;

    container.appendChild(card);
  });

  // Handle checklist checkboxes
  container.querySelectorAll('input[type="checkbox"]').forEach(chk => {
    chk.addEventListener('change', (e) => {
      const tid = e.target.getAttribute('data-tid');
      const idx = parseInt(e.target.getAttribute('data-idx'));
      const turnover = appState.turnovers.find(tItem => tItem.id === tid);
      if (turnover && turnover.checklist[idx]) {
        turnover.checklist[idx].done = e.target.checked;
        const allDone = turnover.checklist.every(c => c.done);
        turnover.status = allDone ? 'completed' : 'in_progress';
        saveToStorage();
        renderTurnoversTab();
      }
    });
  });

  // Handle cleaner WhatsApp & Mark complete buttons
  container.querySelectorAll('.btn-wa-cleaner').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tid = e.currentTarget.getAttribute('data-tid');
      const tItem = appState.turnovers.find(x => x.id === tid);
      if (tItem) openWhatsAppCleanerJob(tItem);
    });
  });

  container.querySelectorAll('.btn-toggle-turnover').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tid = e.currentTarget.getAttribute('data-tid');
      const tItem = appState.turnovers.find(x => x.id === tid);
      if (tItem) {
        const setDone = tItem.status !== 'completed';
        tItem.checklist.forEach(c => c.done = setDone);
        tItem.status = setDone ? 'completed' : 'pending';
        saveToStorage();
        renderTurnoversTab();
        showToast(setDone ? (isBM ? 'Pembersihan ditanda siap & sedia!' : 'Turnover marked as ready!') : (isBM ? 'Pembersihan dibuka semula.' : 'Turnover reopened.'));
      }
    });
  });
}

// ==========================================================================
// 9. FINANCES & REPORTS TAB
// ==========================================================================

function populateFinanceDateSelectors() {
  const monthSelect = document.getElementById('financeMonthSelect');
  const yearSelect = document.getElementById('financeYearSelect');
  if (!monthSelect || !yearSelect) return;
  
  const currentVal = monthSelect.value !== '' ? parseInt(monthSelect.value) : new Date().getMonth();
  monthSelect.innerHTML = '';

  const isBM = appState.settings.language === 'bm';
  const months = isBM 
    ? ['Januari', 'Februari', 'Mac', 'April', 'Mei', 'Jun', 'Julai', 'Ogos', 'September', 'Oktober', 'November', 'Disember']
    : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
  months.forEach((m, idx) => {
    const opt = document.createElement('option');
    opt.value = idx;
    opt.textContent = m;
    if (idx === currentVal) opt.selected = true;
    monthSelect.appendChild(opt);
  });

  const yearVal = yearSelect.value !== '' ? parseInt(yearSelect.value) : new Date().getFullYear();
  yearSelect.innerHTML = '';
  const currentYear = new Date().getFullYear();
  for (let y = currentYear - 2; y <= currentYear + 2; y++) {
    const opt = document.createElement('option');
    opt.value = y;
    opt.textContent = y;
    if (y === yearVal) opt.selected = true;
    yearSelect.appendChild(opt);
  }
}

function renderFinancesTab() {
  populateFinanceDateSelectors();
  
  const selMonth = parseInt(document.getElementById('financeMonthSelect').value);
  const selYear = parseInt(document.getElementById('financeYearSelect').value);

  const bookings = getFilteredBookings();
  const expenses = getFilteredExpenses();

  // Filter for selected month
  const monthBookings = bookings.filter(b => {
    if (b.status === 'cancelled') return false;
    const d = new Date(b.checkIn);
    return d.getMonth() === selMonth && d.getFullYear() === selYear;
  });

  const monthExpenses = expenses.filter(e => {
    const d = new Date(e.date);
    return d.getMonth() === selMonth && d.getFullYear() === selYear;
  });

  const totalRev = monthBookings.reduce((sum, b) => sum + (Number(b.totalAmount) || 0), 0);
  const totalExp = monthExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const netProfit = totalRev - totalExp;

  document.getElementById('finTotalRevenue').textContent = formatCurrency(totalRev);
  document.getElementById('finTotalExpenses').textContent = formatCurrency(totalExp);
  document.getElementById('finNetProfit').textContent = formatCurrency(netProfit);
  document.getElementById('finNetProfit').style.color = netProfit >= 0 ? 'var(--success-text)' : 'var(--danger-text)';

  // Revenue by Property breakdown
  const propRevList = document.getElementById('finPropertyRevenueList');
  propRevList.innerHTML = '';

  const displayProps = appState.selectedPropertyId === 'all' 
    ? appState.properties 
    : appState.properties.filter(p => p.id === appState.selectedPropertyId);

  displayProps.forEach(prop => {
    const pBookings = monthBookings.filter(b => b.propertyId === prop.id);
    const pRev = pBookings.reduce((sum, b) => sum + (Number(b.totalAmount) || 0), 0);
    const percentage = totalRev > 0 ? Math.round((pRev / totalRev) * 100) : 0;

    const row = document.createElement('div');
    row.className = 'property-rev-row';
    row.innerHTML = `
      <div class="property-rev-meta">
        <span style="display:flex; align-items:center; gap:6px;">
          <span class="property-dot" style="background:${prop.color};"></span> ${prop.name}
        </span>
        <span>${formatCurrency(pRev)} (${percentage}%)</span>
      </div>
      <div class="progress-bar-bg">
        <div class="progress-bar-fill" style="width:${percentage}%; background:${prop.color};"></div>
      </div>
    `;
    propRevList.appendChild(row);
  });

  // Expense Log List
  const expList = document.getElementById('finExpenseList');
  expList.innerHTML = '';

  if (monthExpenses.length === 0) {
    expList.innerHTML = `<p class="empty-hint">${t('no_expenses')}</p>`;
  } else {
    monthExpenses.forEach(exp => {
      const prop = getPropertyById(exp.propertyId);
      const row = document.createElement('div');
      row.className = 'expense-item-row';
      row.innerHTML = `
        <div>
          <strong style="font-size:13px;">${exp.description || exp.category.toUpperCase()}</strong>
          <p class="card-subtitle">${exp.date} • ${prop.name}</p>
        </div>
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-weight:700; color:var(--danger);">${formatCurrency(exp.amount)}</span>
          <button class="icon-btn btn-xs btn-delete-expense" data-eid="${exp.id}" style="width:24px; height:24px;">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
      `;
      expList.appendChild(row);
    });

    expList.querySelectorAll('.btn-delete-expense').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const eid = e.currentTarget.getAttribute('data-eid');
        appState.expenses = appState.expenses.filter(x => x.id !== eid);
        saveToStorage();
        renderFinancesTab();
        showToast(appState.settings.language === 'bm' ? 'Perbelanjaan dipadamkan.' : 'Expense removed.');
      });
    });
  }
}

// ==========================================================================
// 10. SETTINGS & PROPERTY MANAGEMENT
// ==========================================================================

function renderSettingsTab() {
  document.getElementById('settingBusinessNameInput').value = appState.settings.businessName || 'MyHomestay';
  const ssmInput = document.getElementById('settingBusinessSsmInput');
  if (ssmInput) ssmInput.value = appState.settings.businessSsm || '';
  const ownerLegalNameInput = document.getElementById('settingOwnerLegalNameInput');
  if (ownerLegalNameInput) ownerLegalNameInput.value = appState.settings.ownerLegalName || '';
  const ownerIcInput = document.getElementById('settingOwnerIcInput');
  if (ownerIcInput) ownerIcInput.value = appState.settings.ownerIc || '';
  const addrInput = document.getElementById('settingBusinessAddressInput');
  if (addrInput) addrInput.value = appState.settings.businessAddress || '';
  const emailInput = document.getElementById('settingBusinessEmailInput');
  if (emailInput) emailInput.value = appState.settings.businessEmail || '';
  document.getElementById('settingCurrencySelect').value = appState.settings.currency || 'RM';
  
  const ownerPhoneInput = document.getElementById('settingOwnerPhoneInput');
  if (ownerPhoneInput) ownerPhoneInput.value = appState.settings.ownerPhone || '';

  document.getElementById('settingDefaultDepositPctInput').value = appState.settings.defaultDepositPct || 30;
  const sstInput = document.getElementById('settingSstRateInput');
  if (sstInput) sstInput.value = appState.settings.sstRate || 0;
  
  const langSelect = document.getElementById('settingLanguageSelect');
  if (langSelect) langSelect.value = appState.settings.language || 'en';

  document.getElementById('settingBankNameInput').value = appState.settings.bankName || 'Maybank';
  document.getElementById('settingBankAccNumInput').value = appState.settings.bankAccNum || '';
  document.getElementById('settingBankAccHolderInput').value = appState.settings.bankAccHolder || '';
  document.getElementById('settingDuitNowInput').value = appState.settings.duitNow || '';

  const quotationValidityInput = document.getElementById('settingQuotationValidityInput');
  if (quotationValidityInput) quotationValidityInput.value = appState.settings.quotationValidityDays || 3;

  const standardNotesInput = document.getElementById('settingStandardNotesInput');
  if (standardNotesInput) standardNotesInput.value = appState.settings.standardNotes || '';

  const propList = document.getElementById('settingsPropertyList');
  propList.innerHTML = '';

  const isBM = appState.settings.language === 'bm';

  if (appState.properties.length === 0) {
    propList.innerHTML = `
      <div style="text-align:center; padding:24px 16px; background:var(--bg-surface-subtle); border-radius:var(--radius-md); border:1px dashed var(--border-color);">
        <i class="fa-solid fa-house-chimney" style="font-size:28px; color:var(--text-muted); margin-bottom:8px;"></i>
        <p style="font-size:13px; font-weight:700; color:var(--text-main); margin-bottom:4px;">${isBM ? 'Tiada unit homestay didaftarkan lagi' : 'No homestay units added yet'}</p>
        <p style="font-size:11px; color:var(--text-muted); margin-bottom:12px;">${isBM ? 'Tambah unit homestay atau bilik anda sendiri untuk mula merekod tempahan sebenar.' : 'Add your own homestays or room rentals to start recording real bookings.'}</p>
        <button class="btn btn-primary btn-sm" id="btnSettingsAddFirstProp"><i class="fa-solid fa-plus"></i> ${isBM ? 'Tambah Unit Pertama Anda' : 'Add Your First Unit'}</button>
      </div>
    `;
    const addFirstBtn = document.getElementById('btnSettingsAddFirstProp');
    if (addFirstBtn) addFirstBtn.addEventListener('click', () => openPropertyModal());
  } else {
    appState.properties.forEach(prop => {
      const card = document.createElement('div');
      card.className = 'settings-prop-card';
      const typeLabel = prop.propType === 'room_master' ? (isBM ? '🚪 Bilik Master' : '🚪 Master Room') :
                        prop.propType === 'room_medium' ? (isBM ? '🚪 Bilik Medium' : '🚪 Medium Room') :
                        prop.propType === 'room_single' ? (isBM ? '🚪 Bilik Single' : '🚪 Single Room') :
                        prop.propType === 'studio' ? '🏢 Studio' : (isBM ? '🏡 Seluruh Unit' : '🏡 Whole Unit');

      card.innerHTML = `
        <div class="settings-prop-details">
          <h4 style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
            <span class="property-dot" style="background:${prop.color};"></span>
            ${prop.name}
            <span style="font-size:10px; font-weight:700; background:var(--bg-surface-subtle); padding:2px 6px; border-radius:999px; color:var(--primary);">${typeLabel}</span>
          </h4>
          <p><i class="fa-solid fa-location-dot" style="color:var(--primary);"></i> ${prop.address || (isBM ? 'Alamat belum diisi' : 'No address set')}${prop.gpsLocation ? ` • <a href="${prop.gpsLocation}" target="_blank" style="color:var(--primary); font-weight:700; text-decoration:none;"><i class="fa-solid fa-map-location-dot"></i> GPS / Maps</a>` : ''}</p>
          <p>🔑 PIN: <strong>${prop.doorCode || (isBM ? 'Tiada' : 'None')}</strong> • 📶 WiFi: <strong>${prop.wifiName || (isBM ? 'Tiada' : 'None')}</strong></p>
          <p>${isBM ? 'Kadar' : 'Rate'}: ${formatCurrency(prop.defaultRate)}/${isBM ? 'malam' : 'night'} • ${isBM ? 'Pembersihan' : 'Clean fee'}: ${formatCurrency(prop.cleaningFee)}</p>
        </div>
        <div style="display:flex; gap:6px;">
          <button class="btn btn-outline btn-xs btn-edit-prop" data-pid="${prop.id}"><i class="fa-solid fa-pen"></i></button>
          <button class="btn btn-danger-outline btn-xs btn-delete-prop" data-pid="${prop.id}" title="${t('delete')}"><i class="fa-solid fa-trash"></i></button>
        </div>
      `;
      propList.appendChild(card);
    });

    propList.querySelectorAll('.btn-edit-prop').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pid = e.currentTarget.getAttribute('data-pid');
        const p = appState.properties.find(x => x.id === pid);
        if (p) openPropertyModal(p);
      });
    });

    propList.querySelectorAll('.btn-delete-prop').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pid = e.currentTarget.getAttribute('data-pid');
        const confirmDelete = isBM ? 'Padamkan unit ini? Rekod tempahan sedia ada akan kekal.' : 'Delete this homestay unit? All associated bookings will remain.';
        if (confirm(confirmDelete)) {
          appState.properties = appState.properties.filter(x => x.id !== pid);
          if (appState.selectedPropertyId === pid) appState.selectedPropertyId = 'all';
          saveToStorage();
          renderApp();
          showToast(isBM ? 'Unit homestay dipadamkan.' : 'Homestay removed.');
        }
      });
    });
  }

  // Render License Status in Settings
  const subTitle = document.getElementById('settingsLicenseSubtitle');
  const badge = document.getElementById('settingsLicenseBadge');
  const actions = document.getElementById('settingsLicenseActions');
  const adminGenCard = document.getElementById('adminLicenseGenCard');

  if (appState.isLicensed) {
    const boundPhone = appState.licensePayload?.phone || appState.settings.ownerPhone || '';
    const maskedDev = getOrCreateDeviceId().slice(0, 8) + '...';
    const daysLeft = appState.licenseDaysRemaining || 0;
    const nextCheckDateStr = formatLicenseDate((appState.licensePayload?.iat || 0) + 7 * 86400, isBM ? 'bm' : 'en');
    const renewalDateStr = formatLicenseDate(appState.licensePayload?.exp || 0, isBM ? 'bm' : 'en');

    subTitle.textContent = `${isBM ? 'Terkunci ke WhatsApp' : 'Tied to WhatsApp'}: +${boundPhone} • ${isBM ? 'Semakan' : 'Next check'}: ${nextCheckDateStr}`;
    badge.textContent = isBM ? '✨ LESEN PRO AKTIF' : '✨ PRO ACTIVE';
    badge.style.background = 'var(--success-light)';
    badge.style.color = 'var(--success-text)';
    if (adminGenCard) adminGenCard.classList.add('hidden');

    actions.innerHTML = `
      <div style="background:var(--bg-surface-subtle); padding:10px 12px; border-radius:var(--radius-sm); border:1px solid var(--border-color); margin-bottom:10px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
          <span style="font-size:12px; font-weight:700; color:var(--text-main);">
            <i class="fa-solid fa-shield-halved" style="color:var(--primary);"></i> ${isBM ? 'Sistem Pro Aktif' : 'StayManager Pro'}
          </span>
          <span style="font-size:11px; font-weight:800; padding:2px 8px; border-radius:999px; background:var(--primary-light); color:var(--primary-text);">
            v${APP_VERSION}
          </span>
        </div>
        <p style="font-size:11.5px; color:var(--text-muted); margin:0 0 10px 0;">
          <i class="fa-solid fa-circle-check" style="color:var(--success);"></i> ${isBM ? 'Akses penuh tanpa had & pengesahan kriptografi selamat aktif.' : 'Full unlimited access & secure cryptographic verification active.'}
        </p>
        <div style="font-size:11px; color:var(--text-muted); margin-bottom:10px; display:flex; flex-direction:column; gap:4px; line-height:1.4;">
          <div><i class="fa-solid fa-mobile-screen"></i> <strong>${isBM ? 'ID Peranti' : 'Device ID'}:</strong> <code>${maskedDev}</code></div>
          <div><i class="fa-solid fa-arrows-rotate"></i> <strong>${isBM ? 'Semakan Seterusnya' : 'Next Check'}:</strong> ${nextCheckDateStr}</div>
          <div><i class="fa-solid fa-calendar-check"></i> <strong>${isBM ? 'Tarikh Pembaharuan' : 'Renewal Date'}:</strong> ${renewalDateStr} (${daysLeft} ${isBM ? 'hari lagi' : 'days remaining'})</div>
        </div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <button type="button" class="btn btn-primary btn-sm" id="btnLicenseCheckUpdates" style="font-weight:700; flex:1; min-width:140px; justify-content:center;">
            <i class="fa-solid fa-rotate"></i> ${isBM ? 'Semak Kemas Kini' : 'Check for Updates'}
          </button>
          <button type="button" class="btn btn-outline btn-sm" id="btnLicenseOpenGuide" style="color:var(--primary); font-weight:700; border-color:var(--primary); flex:1; min-width:140px; justify-content:center;">
            <i class="fa-solid fa-book-open"></i> ${isBM ? 'Panduan Pengguna' : 'User Manual'}
          </button>
        </div>
        <div style="margin-top:8px; padding-top:8px; border-top:1px dashed var(--border-color); display:flex; justify-content:space-between; align-items:center;">
          <span style="font-size:11px; color:var(--text-muted);">
            <i class="fa-solid fa-shield-halved"></i> Cloudflare Workers KV
          </span>
          <button type="button" class="btn btn-outline btn-xs" id="btnChangeLicenseKey">
            <i class="fa-solid fa-arrows-rotate"></i> ${isBM ? 'Tukar Lesen' : 'Change Key'}
          </button>
        </div>
      </div>
    `;
    document.getElementById('btnLicenseCheckUpdates')?.addEventListener('click', () => checkForAppUpdates(true));
    document.getElementById('btnLicenseOpenGuide')?.addEventListener('click', () => openUserGuideModal());
    document.getElementById('btnChangeLicenseKey')?.addEventListener('click', openLicenseModal);
  } else {
    subTitle.textContent = isBM ? 'Tiada Lesen (Mod Demo)' : 'Unlicensed (Demo Mode)';
    badge.textContent = isBM ? 'DEMO' : 'DEMO';
    badge.style.background = 'var(--warning-light)';
    badge.style.color = 'var(--warning-text)';
    if (adminGenCard) adminGenCard.classList.add('hidden');

    actions.innerHTML = `
      <div style="display:flex; gap:8px;">
        <button class="btn btn-primary btn-sm" id="btnActivateFromSettings">
          <i class="fa-solid fa-key"></i> ${isBM ? 'Masukkan Kunci Lesen' : 'Enter License Key'}
        </button>
        <button class="btn btn-warning btn-sm" id="btnBuyFromSettings">
          <i class="fa-solid fa-cart-shopping"></i> ${isBM ? 'Beli Lesen' : 'Buy License'}
        </button>
      </div>
    `;
    document.getElementById('btnActivateFromSettings').addEventListener('click', openLicenseModal);
    document.getElementById('btnBuyFromSettings').addEventListener('click', handleBuyLicense);
  }

  const verBadge = document.getElementById('appCurrentVersionBadge');
  if (verBadge) verBadge.textContent = `v${APP_VERSION}`;

  // Render Maintenance Team & Suppliers Directory
  renderSettingsContactList();
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(new RegExp('"', 'g'), '&quot;')
    .replace(new RegExp("'", 'g'), '&#039;');
}

function getContactCategoryBadge(cat) {
  const isBM = appState.settings.language === 'bm';
  switch (cat) {
    case 'tenant':
      return { label: isBM ? '👤 Penyewa / Tetamu' : '👤 Tenant / Guest', class: 'cat-tenant badge-tenant' };
    case 'cleaner':
      return { label: isBM ? '🧹 Tukang Cuci' : '🧹 Cleaner', class: 'cat-cleaner' };
    case 'aircond':
      return { label: isBM ? '❄️ Juruteknik Aircond' : '❄️ Aircond Tech', class: 'cat-aircond' };
    case 'plumber':
      return { label: isBM ? '🔧 Tukang Paip' : '🔧 Plumber', class: 'cat-plumber' };
    case 'electrician':
      return { label: isBM ? '⚡ Juruelektrik' : '⚡ Electrician', class: 'cat-electrician' };
    case 'handyman':
      return { label: isBM ? '🔨 Baiki Am / Handyman' : '🔨 Handyman', class: 'cat-handyman' };
    case 'linen_supplier':
      return { label: isBM ? '🧺 Pembekal Linen & Dobi' : '🧺 Linen Supplier', class: 'cat-linen_supplier' };
    case 'gas_supplier':
      return { label: isBM ? '⛽ Pembekal Gas & Barang' : '⛽ Gas / Amenities', class: 'cat-gas_supplier' };
    case 'locksmith':
      return { label: isBM ? '🔐 Tukang Kunci' : '🔐 Locksmith', class: 'cat-locksmith' };
    default:
      return { label: isBM ? '📦 Vendor / Pembekal' : '📦 Contractor / Vendor', class: 'cat-other' };
  }
}

let currentContactStatusFilter = 'all';
let currentContactSearchQuery = '';

function renderSettingsContactList() {
  const container = document.getElementById('settingsContactList');
  if (!container) return;
  container.innerHTML = '';

  const isBM = appState.settings.language === 'bm';

  // Wire search and status filter pill listeners once
  const searchInput = document.getElementById('contactSearchInput');
  if (searchInput && !searchInput.dataset.listenerAttached) {
    searchInput.dataset.listenerAttached = 'true';
    searchInput.addEventListener('input', (e) => {
      currentContactSearchQuery = e.target.value.toLowerCase().trim();
      renderSettingsContactList();
    });
  }

  const pillsContainer = document.getElementById('contactStatusFilterPills');
  if (pillsContainer && !pillsContainer.dataset.listenerAttached) {
    pillsContainer.dataset.listenerAttached = 'true';
    pillsContainer.querySelectorAll('.filter-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        pillsContainer.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        currentContactStatusFilter = pill.getAttribute('data-contact-filter') || 'all';
        renderSettingsContactList();
      });
    });
  }

  let contacts = appState.contacts || [];

  // Filter by Lifecycle Status
  if (currentContactStatusFilter !== 'all') {
    contacts = contacts.filter(c => (c.status || 'active') === currentContactStatusFilter);
  }

  // Filter by Search Query
  if (currentContactSearchQuery) {
    const q = currentContactSearchQuery;
    contacts = contacts.filter(c => {
      return (c.name && c.name.toLowerCase().includes(q)) ||
             (c.phone && c.phone.includes(q)) ||
             (c.ic && c.ic.toLowerCase().includes(q)) ||
             (c.company && c.company.toLowerCase().includes(q)) ||
             (c.notes && c.notes.toLowerCase().includes(q));
    });
  }

  if (contacts.length === 0) {
    const isFiltered = (currentContactStatusFilter !== 'all' || !!currentContactSearchQuery);
    container.innerHTML = `
      <div style="text-align:center; padding:24px 16px; background:var(--bg-surface-subtle); border-radius:var(--radius-md); border:1px dashed var(--border-color);">
        <i class="fa-solid fa-users-gear" style="font-size:28px; color:var(--text-muted); margin-bottom:8px;"></i>
        <p style="font-size:13px; font-weight:700; color:var(--text-main); margin-bottom:4px;">${
          isFiltered 
            ? (isBM ? 'Tiada kenalan sepadan dengan carian / penapis' : 'No contacts matching filter / search')
            : (isBM ? 'Tiada kenalan / pembekal disimpan lagi' : 'No team members or suppliers added yet')
        }</p>
        <p style="font-size:11px; color:var(--text-muted); margin-bottom:12px;">${
          isFiltered
            ? (isBM ? 'Cuba tukar kata kunci carian atau pilih tab status "Semua Status".' : 'Try modifying your search query or switch back to "All Statuses".')
            : (isBM ? 'Simpan penyewa, tukang cuci, juruteknik aircond, tukang paip dan pembekal untuk notis pantas.' : 'Save tenants, cleaners, aircond techs, plumbers & supply vendors for quick alerts.')
        }</p>
        ${!isFiltered ? `<button class="btn btn-primary btn-sm" id="btnSettingsAddFirstContact"><i class="fa-solid fa-plus"></i> ${isBM ? 'Tambah Kenalan Pertama' : 'Add First Contact'}</button>` : ''}
      </div>
    `;
    const addFirst = document.getElementById('btnSettingsAddFirstContact');
    if (addFirst) addFirst.addEventListener('click', () => openContactModal());
    return;
  }

  contacts.forEach(contact => {
    const card = document.createElement('div');
    card.className = 'contact-card';
    const badgeInfo = getContactCategoryBadge(contact.category);
    const cleanPhone = (contact.phone || '').replace(/[^0-9]/g, '');

    // Status Badge
    const status = contact.status || 'active';
    let statusBadgeHtml = '';
    if (status === 'active') {
      statusBadgeHtml = `<span class="badge-status-active"><i class="fa-solid fa-circle" style="font-size:7px;"></i> ${t('status_active')}</span>`;
    } else if (status === 'completed') {
      statusBadgeHtml = `<span class="badge-status-completed"><i class="fa-solid fa-circle-check" style="font-size:7px;"></i> ${t('status_completed')}</span>`;
    } else if (status === 'prospect') {
      statusBadgeHtml = `<span class="badge-status-prospect"><i class="fa-solid fa-clock" style="font-size:7px;"></i> ${t('status_prospect')}</span>`;
    } else if (status === 'blacklisted') {
      statusBadgeHtml = `<span class="badge-status-blacklisted"><i class="fa-solid fa-ban" style="font-size:7px;"></i> ${t('status_blacklisted')}</span>`;
    }

    // Tenant Lifecycle Metrics (stays, revenue, last stay)
    const stats = getGuestStayStats(contact.phone, contact.ic);
    let metricsHtml = '';
    if (contact.category === 'tenant' || stats.totalStays > 0) {
      metricsHtml = `
        <div class="tenant-lifecycle-metrics">
          <span class="tenant-metric-pill" title="Total stays"><i class="fa-solid fa-repeat"></i> ${t('lbl_prev_stays')}: <strong>${stats.totalStays}</strong></span>
          <span class="tenant-metric-pill" title="Lifetime revenue"><i class="fa-solid fa-coins"></i> ${t('lbl_lifetime_rev')}: <strong>${formatCurrency(stats.lifetimeRevenue)}</strong></span>
          ${stats.lastStayDate ? `<span class="tenant-metric-pill" title="Last stay"><i class="fa-regular fa-calendar-check"></i> ${t('lbl_last_stay')}: <strong>${stats.lastStayDate}</strong></span>` : ''}
        </div>
      `;
    }

    card.innerHTML = `
      <div class="contact-card-header">
        <div>
          <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
            <div class="contact-card-title">${escapeHtml(contact.name)}</div>
            ${statusBadgeHtml}
          </div>
          ${contact.company ? `<div class="contact-company-text"><i class="fa-solid fa-briefcase"></i> ${escapeHtml(contact.company)}</div>` : ''}
          ${contact.ic ? `<div style="font-size:11px; color:var(--text-muted); margin-top:2px;"><i class="fa-regular fa-id-card"></i> ${escapeHtml(contact.ic)}</div>` : ''}
        </div>
        <span class="contact-category-badge ${badgeInfo.class}">
          ${badgeInfo.label}
        </span>
      </div>

      <div class="contact-card-body">
        <a href="https://wa.me/${cleanPhone}" target="_blank" class="contact-phone-link">
          <i class="fa-brands fa-whatsapp" style="color:var(--success);"></i> ${escapeHtml(contact.phone)}
        </a>
        ${contact.notes ? `<div class="contact-notes-text">${escapeHtml(contact.notes)}</div>` : ''}
        ${metricsHtml}
      </div>

      <div class="contact-card-actions">
        <button class="btn btn-whatsapp btn-xs btn-contact-dispatch" data-cid="${contact.id}" title="${isBM ? 'Hantar Notis Servis / Bekalan' : 'Dispatch Service / Supply'}">
          <i class="fa-brands fa-whatsapp"></i> ${isBM ? 'Hantar Notis' : 'Dispatch Alert'}
        </button>
        <div style="display:flex; gap:6px;">
          <button class="btn btn-outline btn-xs btn-edit-contact" data-cid="${contact.id}" title="${t('edit')}">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button class="btn btn-danger-outline btn-xs btn-delete-contact" data-cid="${contact.id}" title="${t('delete')}">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </div>
    `;

    container.appendChild(card);
  });

  // Action listeners
  container.querySelectorAll('.btn-contact-dispatch').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cid = e.currentTarget.getAttribute('data-cid');
      const c = appState.contacts.find(x => x.id === cid);
      if (c) openServiceDispatchModal(null, c.category, c.id);
    });
  });

  container.querySelectorAll('.btn-edit-contact').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cid = e.currentTarget.getAttribute('data-cid');
      openContactModal(cid);
    });
  });

  container.querySelectorAll('.btn-delete-contact').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cid = e.currentTarget.getAttribute('data-cid');
      handleDeleteContact(cid);
    });
  });
}

function openContactModal(contactId = null, prefillContact = null) {
  const isBM = appState.settings.language === 'bm';
  const modal = document.getElementById('contactModal');
  const title = document.getElementById('contactModalTitle');
  const idInput = document.getElementById('contactIdInput');
  const nameInput = document.getElementById('contactNameInput');
  const catSelect = document.getElementById('contactCategorySelect');
  const phoneInput = document.getElementById('contactPhoneInput');
  const compInput = document.getElementById('contactCompanyInput');
  const notesInput = document.getElementById('contactNotesInput');
  const statusSelect = document.getElementById('contactStatusSelect');
  const icInput = document.getElementById('contactIcInput');

  if (contactId) {
    const contact = (appState.contacts || []).find(c => c.id === contactId);
    if (contact) {
      if (title) title.textContent = isBM ? 'Kemaskini Butiran Kenalan' : 'Edit Contact Details';
      if (idInput) idInput.value = contact.id;
      if (nameInput) nameInput.value = contact.name || '';
      if (catSelect) catSelect.value = contact.category || 'cleaner';
      if (phoneInput) phoneInput.value = contact.phone || '';
      if (compInput) compInput.value = contact.company || '';
      if (notesInput) notesInput.value = contact.notes || '';
      if (statusSelect) statusSelect.value = contact.status || 'active';
      if (icInput) icInput.value = contact.ic || '';
    }
  } else {
    if (title) title.textContent = isBM ? 'Tambah Pasukan / Pembekal' : 'Add Team Member / Supplier';
    if (idInput) idInput.value = '';
    if (nameInput) nameInput.value = prefillContact ? (prefillContact.name || '') : '';
    if (catSelect) catSelect.value = prefillContact ? (prefillContact.category || 'tenant') : 'cleaner';
    if (phoneInput) phoneInput.value = prefillContact ? (prefillContact.phone || '') : '';
    if (compInput) compInput.value = prefillContact ? (prefillContact.company || '') : '';
    if (notesInput) notesInput.value = prefillContact ? (prefillContact.notes || '') : '';
    if (statusSelect) statusSelect.value = prefillContact ? (prefillContact.status || 'active') : 'active';
    if (icInput) icInput.value = prefillContact ? (prefillContact.ic || '') : '';
  }

  if (modal) modal.classList.add('active');
}

function handleSaveContact(e) {
  e.preventDefault();
  const idInput = document.getElementById('contactIdInput').value;
  const name = document.getElementById('contactNameInput').value.trim();
  const category = document.getElementById('contactCategorySelect').value;
  const phone = document.getElementById('contactPhoneInput').value.trim();
  const company = document.getElementById('contactCompanyInput').value.trim();
  const notes = document.getElementById('contactNotesInput').value.trim();
  const status = document.getElementById('contactStatusSelect') ? document.getElementById('contactStatusSelect').value : 'active';
  const ic = document.getElementById('contactIcInput') ? document.getElementById('contactIcInput').value.trim() : '';

  if (!name || !phone) {
    alert(appState.settings.language === 'bm' ? 'Sila masukkan nama dan nombor WhatsApp.' : 'Please enter contact name and WhatsApp phone number.');
    return;
  }

  if (!Array.isArray(appState.contacts)) appState.contacts = [];

  if (idInput) {
    // Update
    const idx = appState.contacts.findIndex(c => c.id === idInput);
    if (idx !== -1) {
      appState.contacts[idx] = {
        ...appState.contacts[idx],
        name,
        category,
        phone,
        company,
        notes,
        status,
        ic
      };
    }
  } else {
    // New
    const newContact = {
      id: 'c-' + Date.now(),
      name,
      category,
      phone,
      company,
      notes,
      status,
      ic
    };
    appState.contacts.push(newContact);
  }

  saveToStorage();
  renderSettingsContactList();
  closeAllModals();
  showToast(appState.settings.language === 'bm' ? 'Kenalan berjaya disimpan!' : 'Contact saved successfully!');
}

function handleDeleteContact(contactId) {
  const isBM = appState.settings.language === 'bm';
  const contact = (appState.contacts || []).find(c => c.id === contactId);
  if (!contact) return;

  const msg = isBM ? `Padamkan ${contact.name} daripada direktori pasukan?` : `Remove ${contact.name} from your team directory?`;
  if (confirm(msg)) {
    appState.contacts = appState.contacts.filter(c => c.id !== contactId);
    saveToStorage();
    renderSettingsContactList();
    showToast(isBM ? 'Kenalan telah dipadamkan.' : 'Contact removed.');
  }
}

function handleSavePreferences() {
  const newOwnerPhone = document.getElementById('settingOwnerPhoneInput') ? document.getElementById('settingOwnerPhoneInput').value.trim() : appState.settings.ownerPhone;
  const oldOwnerPhone = appState.settings.ownerPhone;

  appState.settings.businessName = document.getElementById('settingBusinessNameInput').value || 'MyHomestay';
  appState.settings.businessSsm = document.getElementById('settingBusinessSsmInput') ? document.getElementById('settingBusinessSsmInput').value.trim() : (appState.settings.businessSsm || '');
  appState.settings.ownerLegalName = document.getElementById('settingOwnerLegalNameInput') ? document.getElementById('settingOwnerLegalNameInput').value.trim() : (appState.settings.ownerLegalName || '');
  appState.settings.ownerIc = document.getElementById('settingOwnerIcInput') ? document.getElementById('settingOwnerIcInput').value.trim() : (appState.settings.ownerIc || '');
  appState.settings.businessAddress = document.getElementById('settingBusinessAddressInput') ? document.getElementById('settingBusinessAddressInput').value.trim() : (appState.settings.businessAddress || '');
  appState.settings.businessEmail = document.getElementById('settingBusinessEmailInput') ? document.getElementById('settingBusinessEmailInput').value.trim() : (appState.settings.businessEmail || '');
  appState.settings.currency = document.getElementById('settingCurrencySelect').value || 'RM';
  appState.settings.ownerPhone = newOwnerPhone || '';
  if (appState.settings.sellerPhone) delete appState.settings.sellerPhone;
  appState.settings.language = document.getElementById('settingLanguageSelect') ? document.getElementById('settingLanguageSelect').value : (appState.settings.language || 'en');
  appState.settings.defaultDepositPct = parseInt(document.getElementById('settingDefaultDepositPctInput').value) || 30;
  appState.settings.quotationValidityDays = parseInt(document.getElementById('settingQuotationValidityInput')?.value) || 3;
  appState.settings.sstRate = parseFloat(document.getElementById('settingSstRateInput')?.value) || 0;
  appState.settings.standardNotes = document.getElementById('settingStandardNotesInput') ? document.getElementById('settingStandardNotesInput').value.trim() : (appState.settings.standardNotes || '');

  saveToStorage();
  applyLanguageUI();
  renderApp();
  showToast(appState.settings.language === 'bm' ? 'Tetapan berjaya disimpan!' : 'Preferences & WhatsApp settings saved!');
}

// ==========================================================================
// 10B. BOOKING OVERLAP PREVENTION & CHANGE HOMESTAY (v2.6.3)
// ==========================================================================

function getBookingOverlaps(propertyId, checkIn, checkOut, excludeBookingId = null) {
  if (!propertyId || !checkIn || !checkOut) return [];
  if (checkIn >= checkOut) return [];

  const todayStr = formatLocalDate(new Date());

  return appState.bookings.filter(b => {
    if (b.propertyId !== propertyId) return false;
    if (excludeBookingId && b.id === excludeBookingId) return false;
    if (b.status === 'cancelled' || b.status === 'quotation') return false;
    // Completed historical tenancies and ended stays should not block future reservations
    if (b.status === 'checked-out' || b.status === 'completed' || isCompletedTenancy(b, todayStr)) return false;
    // Standard hotel interval overlap: (checkInA < checkOutB) && (checkOutA > checkInB)
    return (checkIn < b.checkOut) && (checkOut > b.checkIn);
  });
}

function checkBookingModalOverlap() {
  const alertEl = document.getElementById('bookingModalOverlapAlert');
  if (!alertEl) return;

  const modal = document.getElementById('bookingModal');
  if (!modal || !modal.classList.contains('active')) {
    alertEl.style.display = 'none';
    return;
  }

  const propertyId = document.getElementById('bookingPropertySelect')?.value;
  const rentalType = document.getElementById('bookingRentalType')?.value || 'daily';
  const id = document.getElementById('bookingIdInput')?.value || null;
  const status = document.getElementById('bookingStatusSelect')?.value || 'booked';

  if (status === 'cancelled' || status === 'quotation' || !propertyId) {
    alertEl.style.display = 'none';
    return;
  }

  let checkIn = '';
  let checkOut = '';

  if (rentalType === 'monthly') {
    const mStart = document.getElementById('bookingMonthlyStart')?.value;
    const mDuration = parseInt(document.getElementById('bookingMonthlyDuration')?.value) || 1;
    if (!mStart) {
      alertEl.style.display = 'none';
      return;
    }
    checkIn = mStart;
    const dStart = new Date(mStart + 'T00:00:00');
    const dEnd = new Date(dStart);
    dEnd.setMonth(dEnd.getMonth() + mDuration);
    checkOut = formatLocalDate(dEnd);
  } else {
    checkIn = document.getElementById('bookingCheckIn')?.value;
    checkOut = document.getElementById('bookingCheckOut')?.value;
  }

  if (!checkIn || !checkOut || checkIn >= checkOut) {
    alertEl.style.display = 'none';
    return;
  }

  const overlaps = getBookingOverlaps(propertyId, checkIn, checkOut, id);
  if (overlaps.length > 0) {
    const isBM = appState.settings.language === 'bm';
    const c = overlaps[0];
    const cDates = `${c.checkIn} → ${c.checkOut}`;
    
    document.getElementById('bookingModalOverlapTitle').textContent = isBM 
      ? '⚠️ Perhatian: Tarikh Bertindih dengan Tempahan Sedia Ada!' 
      : '⚠️ Warning: Clashes with an Existing Booking!';

    document.getElementById('bookingModalOverlapDetails').innerHTML = isBM
      ? `Unit ini telah ditempah oleh <strong>${c.guestName}</strong> (${cDates}). Sila pilih homestay lain atau tukar tarikh.`
      : `This unit is already booked by <strong>${c.guestName}</strong> (${cDates}). Please switch homestay or select different dates.`;

    const switchBtn = document.getElementById('btnModalSwitchHomestay');
    if (switchBtn) {
      const freeProps = appState.properties.filter(p => p.id !== propertyId && getBookingOverlaps(p.id, checkIn, checkOut, id).length === 0);
      if (freeProps.length > 0) {
        switchBtn.style.display = 'inline-flex';
        switchBtn.innerHTML = `<i class="fa-solid fa-arrow-right-arrow-left"></i> ${isBM ? `Tukar ke ${freeProps[0].name}` : `Switch to ${freeProps[0].name}`}`;
        switchBtn.onclick = () => {
          document.getElementById('bookingPropertySelect').value = freeProps[0].id;
          updateBookingModalPricing();
          checkBookingModalOverlap();
        };
      } else {
        switchBtn.style.display = 'none';
      }
    }

    alertEl.style.display = 'flex';
  } else {
    alertEl.style.display = 'none';
  }
}

function openOverlapWarningModal(overlaps, propertyId, checkIn, checkOut, guestName, currentBookingId) {
  const isBM = appState.settings.language === 'bm';
  const prop = getPropertyById(propertyId);

  document.getElementById('overlapModalPropName').textContent = `${prop.name}`;
  document.getElementById('overlapModalDatesText').textContent = `${checkIn} → ${checkOut} (${guestName || (isBM ? 'Tetamu Baru' : 'New Guest')})`;

  const conflictList = document.getElementById('overlapConflictDetailsList');
  conflictList.innerHTML = overlaps.map(c => {
    const statusLabels = isBM ? {
      'quotation': '📋 SEBUT HARGA',
      'booked': '🟡 DITEMPAH',
      'confirmed': '🟢 DISAHKAN',
      'checked-in': '🔑 MENGINAP',
      'checked-out': '🏁 SELESAI',
      'blocked': '🚫 DISEKAT'
    } : {
      'quotation': '📋 QUOTATION',
      'booked': '🟡 BOOKED',
      'confirmed': '🟢 CONFIRMED',
      'checked-in': '🔑 IN-HOUSE',
      'checked-out': '🏁 COMPLETED',
      'blocked': '🚫 BLOCKED'
    };
    return `
      <div class="overlap-conflict-item">
        <div>
          <div class="overlap-conflict-guest">
            <i class="fa-solid fa-user" style="color:var(--primary); font-size:11px; margin-right:4px;"></i>${c.guestName}
            ${c.guestPhone ? `<span style="font-weight:normal; font-size:11.5px; color:var(--text-muted); margin-left:6px;">(${c.guestPhone})</span>` : ''}
          </div>
          <div class="overlap-conflict-dates">
            <i class="fa-regular fa-calendar" style="margin-right:4px;"></i>${c.checkIn} → ${c.checkOut} (${c.rentalType === 'monthly' ? `${c.monthlyDuration} bln` : `${c.nights} mlm`})
          </div>
        </div>
        <div>
          <span style="font-size:10.5px; font-weight:800; padding:3px 8px; border-radius:999px; background:var(--bg-surface-subtle); border:1px solid var(--border-color); color:var(--text-main);">
            ${statusLabels[c.status] || c.status.toUpperCase()}
          </span>
        </div>
      </div>
    `;
  }).join('');

  // Find alternative properties available for this exact interval
  const availableProps = appState.properties.filter(p => {
    if (p.id === propertyId) return false;
    const clashing = getBookingOverlaps(p.id, checkIn, checkOut, currentBookingId);
    return clashing.length === 0;
  });

  const altContainer = document.getElementById('overlapAlternativesContainer');
  const altList = document.getElementById('overlapAvailablePropsList');
  const btnSwitchToAvail = document.getElementById('btnOverlapSwitchToAvailable');

  if (availableProps.length > 0) {
    altContainer.style.display = 'block';
    altList.innerHTML = availableProps.map(p => `
      <div class="avail-prop-item" data-pid="${p.id}">
        <div class="avail-prop-name">
          <span class="property-dot" style="background:${p.color};"></span>
          <span>${p.name}</span>
        </div>
        <div style="display:flex; align-items:center; gap:8px;">
          <span class="avail-prop-rate">${formatCurrency(p.defaultRate)}/mlm</span>
          <button type="button" class="btn btn-outline btn-xs btn-pick-alt-prop" data-pid="${p.id}" style="color:var(--primary); font-weight:700;">
            ${isBM ? 'Pilih Unit Ini' : 'Select Unit'}
          </button>
        </div>
      </div>
    `).join('');

    altList.querySelectorAll('.btn-pick-alt-prop').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pid = e.currentTarget.getAttribute('data-pid');
        document.getElementById('bookingPropertySelect').value = pid;
        updateBookingModalPricing();
        checkBookingModalOverlap();
        document.getElementById('overlapWarningModal').classList.remove('active');
        showToast(isBM ? `Unit ditukar ke ${getPropertyById(pid).name}` : `Unit changed to ${getPropertyById(pid).name}`);
      });
    });

    btnSwitchToAvail.style.display = 'block';
    btnSwitchToAvail.innerHTML = `<i class="fa-solid fa-arrow-right-arrow-left"></i> ${isBM ? `Tukar ke ${availableProps[0].name} (Tersedia)` : `Switch to ${availableProps[0].name} (Available)`}`;
    btnSwitchToAvail.onclick = () => {
      document.getElementById('bookingPropertySelect').value = availableProps[0].id;
      updateBookingModalPricing();
      checkBookingModalOverlap();
      document.getElementById('overlapWarningModal').classList.remove('active');
      showToast(isBM ? `Unit ditukar ke ${availableProps[0].name}` : `Unit changed to ${availableProps[0].name}`);
    };
  } else {
    altContainer.style.display = 'none';
    btnSwitchToAvail.style.display = 'none';
  }

  // Change dates action
  document.getElementById('btnOverlapChangeDates').onclick = () => {
    document.getElementById('overlapWarningModal').classList.remove('active');
    const dIn = document.getElementById('bookingCheckIn');
    if (dIn) dIn.focus();
  };

  document.getElementById('btnOverlapDismiss').onclick = () => {
    document.getElementById('overlapWarningModal').classList.remove('active');
  };

  document.getElementById('btnCloseOverlapModal').onclick = () => {
    document.getElementById('overlapWarningModal').classList.remove('active');
  };

  document.getElementById('overlapWarningModal').classList.add('active');
}

function openChangeHomestayModal(booking) {
  if (!booking) return;

  const isBM = appState.settings.language === 'bm';
  const currentProp = getPropertyById(booking.propertyId);

  document.getElementById('changeHomestayBookingId').value = booking.id;
  document.getElementById('changeHomestayGuestName').textContent = booking.guestName;
  document.getElementById('changeHomestayGuestMeta').textContent = 
    `${booking.guestPhone || '-'} • ${booking.guestNric ? `KP: ${booking.guestNric} • ` : ''}${booking.guestCount || 2} ${isBM ? 'Tetamu' : 'Guests'}`;

  const statusBadge = document.getElementById('changeHomestayStatusBadge');
  statusBadge.textContent = (booking.status || 'booked').toUpperCase();
  statusBadge.className = `badge badge-${booking.status || 'booked'}`;

  const durationStr = booking.rentalType === 'monthly' 
    ? `${booking.monthlyDuration || 1} ${isBM ? 'bulan' : 'months'}` 
    : `${booking.nights || 1} ${isBM ? 'malam' : 'nights'}`;

  document.getElementById('changeHomestayDatesText').textContent = 
    `${booking.checkIn} → ${booking.checkOut} (${durationStr})`;

  document.getElementById('changeHomestayCurrentPropName').textContent = currentProp.name;
  document.getElementById('changeHomestayCurrentTotal').textContent = 
    `${formatCurrency(booking.totalAmount)} (${isBM ? 'Dibayar' : 'Paid'}: ${formatCurrency(booking.depositPaid)})`;

  // Populate Target Homestay Select with live availability inspection
  const targetSelect = document.getElementById('changeHomestayTargetSelect');
  targetSelect.innerHTML = '';

  const otherProps = appState.properties.filter(p => p.id !== booking.propertyId);

  if (otherProps.length === 0) {
    alert(isBM 
      ? 'Anda perlu mempunyai sekurang-kurangnya 2 unit homestay berdaftar untuk membuat pertukaran unit.' 
      : 'You need at least 2 homestay units registered in the app to transfer bookings.');
    return;
  }

  let firstAvailableId = null;

  otherProps.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    const clashes = getBookingOverlaps(p.id, booking.checkIn, booking.checkOut, booking.id);
    const isFree = clashes.length === 0;

    if (isFree) {
      if (!firstAvailableId) firstAvailableId = p.id;
      opt.textContent = `✅ ${p.name} - ${isBM ? 'Tersedia' : 'Available'} (${formatCurrency(p.defaultRate)}/mlm)`;
    } else {
      const clashGuest = clashes[0].guestName;
      opt.textContent = `❌ ${p.name} - [${isBM ? 'Bertindih' : 'Conflict'}: ${clashGuest}]`;
      opt.disabled = true; // Cannot select occupied homestay
    }
    targetSelect.appendChild(opt);
  });

  // Select first available or first option
  if (firstAvailableId) {
    targetSelect.value = firstAvailableId;
  } else {
    targetSelect.selectedIndex = 0;
  }

  // Function to update live feedback and recalculation preview
  function updateTargetFeedback() {
    const selectedPropId = targetSelect.value;
    const selectedProp = getPropertyById(selectedPropId);
    const clashes = getBookingOverlaps(selectedPropId, booking.checkIn, booking.checkOut, booking.id);
    const feedbackEl = document.getElementById('changeHomestayTargetFeedback');
    const confirmBtn = document.getElementById('btnConfirmChangeHomestay');

    if (clashes.length > 0) {
      const c = clashes[0];
      feedbackEl.innerHTML = `
        <span style="color:var(--danger); font-weight:700;">
          <i class="fa-solid fa-circle-xmark"></i> ${isBM ? 'Tidak boleh dipindahkan: Bertindih dengan tempahan tetamu' : 'Cannot transfer: Clashes with booking for'} ${c.guestName} (${c.checkIn} → ${c.checkOut}).
        </span>
      `;
      confirmBtn.disabled = true;
    } else {
      feedbackEl.innerHTML = `
        <span style="color:var(--success); font-weight:700;">
          <i class="fa-solid fa-circle-check"></i> ${isBM ? 'Unit ini KOSONG & tersedia untuk tarikh tersebut.' : 'Unit is VACANT & available for these stay dates.'}
        </span>
      `;
      confirmBtn.disabled = false;
    }

    // Recalculate preview
    const previewEl = document.getElementById('changeHomestayRecalcPreview');
    if (previewEl && selectedProp) {
      if (booking.rentalType === 'monthly') {
        const mRate = selectedProp.defaultRate ? selectedProp.defaultRate * 10 : (booking.monthlyRate || 1200);
        const newTotal = mRate + (booking.rentalDeposit || mRate) + (booking.utilitiesDeposit || 300) + (booking.agreementFee || 150);
        previewEl.innerHTML = isBM
          ? `Kadar baru: <strong>${formatCurrency(mRate)}/bulan</strong> → Anggaran Jumlah Baru: <strong>${formatCurrency(newTotal)}</strong> (Deposit dibayar ${formatCurrency(booking.depositPaid)} kekal).`
          : `New rate: <strong>${formatCurrency(mRate)}/month</strong> → Est. New Total: <strong>${formatCurrency(newTotal)}</strong> (Deposit paid ${formatCurrency(booking.depositPaid)} preserved).`;
      } else {
        const nRate = selectedProp.defaultRate || booking.nightlyRate || 250;
        const cFee = selectedProp.cleaningFee || booking.cleaningFee || 0;
        const sDep = booking.securityDeposit || 0;
        const newRental = (booking.nights * nRate) + cFee;
        const newTotal = newRental + sDep;
        previewEl.innerHTML = isBM
          ? `Kadar baru: <strong>${formatCurrency(nRate)}/mlm</strong> + Pembersihan <strong>${formatCurrency(cFee)}</strong> → Jumlah Baru: <strong>${formatCurrency(newTotal)}</strong> (Deposit dibayar ${formatCurrency(booking.depositPaid)} kekal).`
          : `New rate: <strong>${formatCurrency(nRate)}/night</strong> + Cleaning <strong>${formatCurrency(cFee)}</strong> → New Total: <strong>${formatCurrency(newTotal)}</strong> (Deposit paid ${formatCurrency(booking.depositPaid)} preserved).`;
      }
    }
  }

  targetSelect.onchange = updateTargetFeedback;
  updateTargetFeedback();

  // Reset radio to 'keep' by default
  const keepRadio = document.querySelector('input[name="changePricingMode"][value="keep"]');
  if (keepRadio) keepRadio.checked = true;

  document.getElementById('changeHomestayModal').classList.add('active');
}

function handleConfirmChangeHomestay(e) {
  e.preventDefault();

  const bookingId = document.getElementById('changeHomestayBookingId').value;
  const targetPropId = document.getElementById('changeHomestayTargetSelect').value;
  const pricingMode = document.querySelector('input[name="changePricingMode"]:checked')?.value || 'keep';

  const booking = appState.bookings.find(b => b.id === bookingId);
  if (!booking) {
    alert('Booking not found!');
    return;
  }

  const oldProp = getPropertyById(booking.propertyId);
  const newProp = getPropertyById(targetPropId);

  // Validate overlap one more time for safety
  const clashes = getBookingOverlaps(targetPropId, booking.checkIn, booking.checkOut, booking.id);
  if (clashes.length > 0) {
    alert(appState.settings.language === 'bm'
      ? `Pertindihan dikesan! Unit ${newProp.name} telah ditempah oleh ${clashes[0].guestName}.`
      : `Overlap detected! Unit ${newProp.name} is already booked by ${clashes[0].guestName}.`);
    return;
  }

  // Transfer property ID
  booking.propertyId = targetPropId;

  // Pricing adjustment
  if (pricingMode === 'recalc') {
    if (booking.rentalType === 'monthly') {
      const mRate = newProp.defaultRate ? newProp.defaultRate * 10 : (booking.monthlyRate || 1200);
      booking.monthlyRate = mRate;
      booking.totalAmount = mRate + (booking.rentalDeposit || mRate) + (booking.utilitiesDeposit || 300) + (booking.agreementFee || 150);
      booking.balance = Math.max(0, booking.totalAmount - (booking.depositPaid || 0));
    } else {
      booking.nightlyRate = newProp.defaultRate || booking.nightlyRate || 250;
      booking.cleaningFee = newProp.cleaningFee || 0;
      const totalRental = (booking.nights * booking.nightlyRate) + booking.cleaningFee;
      booking.totalAmount = totalRental + (booking.securityDeposit || 0);
      booking.balance = Math.max(0, booking.totalAmount - (booking.depositPaid || 0));
    }
  }

  // Update turnover cleaning tasks associated with this booking
  appState.turnovers.forEach(t => {
    if (t.bookingId === booking.id) {
      t.propertyId = targetPropId;
    }
  });

  // Append audit note
  const isBM = appState.settings.language === 'bm';
  const timeStr = new Date().toLocaleDateString();
  const auditNote = isBM
    ? `[Tukar Homestay: ${oldProp.name} → ${newProp.name} pada ${timeStr}]`
    : `[Transferred Unit: ${oldProp.name} → ${newProp.name} on ${timeStr}]`;
  booking.notes = booking.notes ? `${booking.notes}\n${auditNote}` : auditNote;

  saveToStorage();
  closeAllModals();
  renderApp();

  const successMsg = isBM
    ? `Tempahan untuk ${booking.guestName} berjaya dipindahkan ke "${newProp.name}"!`
    : `Booking for ${booking.guestName} successfully transferred to "${newProp.name}"!`;
  showToast(successMsg);
}

// ==========================================================================
// 11. BOOKING MODAL LOGIC (DAILY & MONTHLY TENANCY)
// ==========================================================================

function syncSignatoryWithContactPerson() {
  const chk = document.getElementById('bookingSignatorySameAsContact');
  if (!chk || !chk.checked) return;

  const contactName = document.getElementById('bookingContactPerson')?.value || '';
  const contactDesig = document.getElementById('bookingContactDesignation')?.value || '';

  const sigName = document.getElementById('bookingSignatoryName');
  const sigDesig = document.getElementById('bookingSignatoryDesignation');

  if (sigName) sigName.value = contactName;
  if (sigDesig) sigDesig.value = contactDesig;
}

function applyTenantFormVisibility(rentalType, tenantType) {
  const isMonthly = rentalType === 'monthly';
  const isCompany = tenantType === 'company';

  const secIndiv = document.getElementById('sectionTenantIndividual');
  const secComp = document.getElementById('sectionTenantCompany');
  const secContact = document.getElementById('sectionContactPerson');
  const secSignatory = document.getElementById('sectionAuthorizedSignatory');
  const secMonthlyExtras = document.getElementById('sectionMonthlyExtras');

  // Role (a) TENANT: Individual vs Company
  if (secIndiv) secIndiv.style.display = isCompany ? 'none' : 'block';
  if (secComp) secComp.style.display = isCompany ? 'block' : 'none';

  // Role (b) CONTACT PERSON: Required for Company, Optional for Individual in Monthly mode, Hidden for Individual in Daily mode
  if (secContact) {
    if (isCompany) {
      secContact.style.display = 'block';
    } else if (isMonthly) {
      secContact.style.display = 'block';
    } else {
      secContact.style.display = 'none';
    }
  }

  // Role (c) AUTHORIZED SIGNATORY: Only for Company in Monthly Tenancy mode
  if (secSignatory) {
    secSignatory.style.display = (isCompany && isMonthly) ? 'block' : 'none';
  }

  // Monthly Tenancy Extras: Emergency Contact & Occupants
  if (secMonthlyExtras) {
    secMonthlyExtras.style.display = isMonthly ? 'block' : 'none';
  }

  // Dynamic required attributes to prevent browser validation blocking hidden fields
  const guestNameInput = document.getElementById('bookingGuestName');
  const guestPhoneInput = document.getElementById('bookingGuestPhone');
  const compNameInput = document.getElementById('bookingCompanyName');
  const compRegInput = document.getElementById('bookingCompanyRegNo');
  const contactPersonInput = document.getElementById('bookingContactPerson');
  const contactPhoneInput = document.getElementById('bookingContactPhone');

  if (guestNameInput) guestNameInput.required = !isCompany;
  if (guestPhoneInput) guestPhoneInput.required = (!isCompany && !isMonthly);

  if (compNameInput) compNameInput.required = isCompany;
  if (compRegInput) compRegInput.required = isCompany;
  if (contactPersonInput) contactPersonInput.required = isCompany;
  if (contactPhoneInput) contactPhoneInput.required = isCompany;
}

function setBookingTenantType(type) {
  const targetType = type === 'company' ? 'company' : 'individual';
  const hiddenInput = document.getElementById('bookingTenantType');
  if (hiddenInput) hiddenInput.value = targetType;

  // Update segmented control buttons UI
  document.querySelectorAll('#tenantTypeSegmented .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-tenant-type') === targetType);
  });

  const rentalType = document.getElementById('bookingRentalType')?.value || 'daily';
  applyTenantFormVisibility(rentalType, targetType);
  if (typeof checkBookingRepeatGuest === 'function') {
    checkBookingRepeatGuest();
  }
}

function setBookingFormRentalType(type) {
  const isMonthly = type === 'monthly';
  document.getElementById('bookingRentalType').value = type;

  // Toggle Section Visibility
  const dailySection = document.getElementById('sectionDailyPricing');
  const monthlySection = document.getElementById('sectionMonthlyPricing');
  
  if (dailySection) dailySection.classList.toggle('hidden', isMonthly);
  if (monthlySection) monthlySection.classList.toggle('hidden', !isMonthly);

  // Daily input elements to enable/disable
  const dailyInputs = [
    'bookingCheckIn', 'bookingCheckOut', 'bookingNightlyRate', 
    'bookingCleaningFee', 'bookingSecurityDeposit',
    'btnPresetDep30', 'btnPresetDep50', 'btnPresetDepFull', 'btnPresetDepZero'
  ];

  // Monthly input elements to enable/disable
  const monthlyInputs = [
    'bookingMonthlyStart', 'bookingMonthlyDuration', 'bookingMonthlyRate', 
    'bookingRentalDeposit', 'bookingUtilitiesDeposit', 'bookingAgreementFee'
  ];

  if (isMonthly) {
    // Completely BLOCK / DISABLE all Daily inputs
    dailyInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.disabled = true;
        el.required = false;
        el.setAttribute('tabindex', '-1');
        el.style.pointerEvents = 'none';
      }
    });

    // UNBLOCK / ENABLE all Monthly inputs
    monthlyInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.disabled = false;
        el.removeAttribute('tabindex');
        el.style.pointerEvents = 'auto';
      }
    });

    const mStart = document.getElementById('bookingMonthlyStart');
    if (mStart) mStart.required = true;
    const mRate = document.getElementById('bookingMonthlyRate');
    if (mRate) mRate.required = true;

  } else {
    // Completely BLOCK / DISABLE all Monthly inputs
    monthlyInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.disabled = true;
        el.required = false;
        el.setAttribute('tabindex', '-1');
        el.style.pointerEvents = 'none';
      }
    });

    // UNBLOCK / ENABLE all Daily inputs
    dailyInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.disabled = false;
        el.removeAttribute('tabindex');
        el.style.pointerEvents = 'auto';
      }
    });

    const bCheckIn = document.getElementById('bookingCheckIn');
    if (bCheckIn) bCheckIn.required = true;
    const bCheckOut = document.getElementById('bookingCheckOut');
    if (bCheckOut) bCheckOut.required = true;
  }

  // Update segmented control buttons UI
  document.querySelectorAll('#rentalTypeSegmented .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-type') === type);
  });

  // Re-evaluate Tenant section visibility based on rental type
  const currentTenantType = document.getElementById('bookingTenantType')?.value || 'individual';
  applyTenantFormVisibility(type, currentTenantType);
}

function openBookingModal(existingBooking = null, prefillDate = null, prefillPropertyId = null, prefillData = null) {
  if (appState.properties.length === 0) {
    alert(appState.settings.language === 'bm' 
      ? 'Sila tambah sekurang-kurangnya satu unit homestay atau bilik sebelum membuat tempahan.' 
      : 'Please add at least one homestay or room rental unit first before creating a quotation / booking.');
    openPropertyModal();
    return;
  }

  const form = document.getElementById('bookingForm');
  form.reset();

  // Populate Property Dropdown with Unit / Room Category
  const propSelect = document.getElementById('bookingPropertySelect');
  propSelect.innerHTML = '';
  appState.properties.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    const typeLabel = p.propType === 'room_master' ? '🚪 Master Room' : 
                      p.propType === 'room_medium' ? '🚪 Medium Room' :
                      p.propType === 'room_single' ? '🚪 Single Room' :
                      p.propType === 'studio' ? '🏢 Studio' : '🏡 Whole Unit';
    opt.textContent = `${p.name} [${typeLabel}]`;
    propSelect.appendChild(opt);
  });

  const todayStr = formatLocalDate(new Date());
  const tomorrowObj = new Date(); tomorrowObj.setDate(tomorrowObj.getDate() + 1);
  const tomorrowStr = formatLocalDate(tomorrowObj);

  if (existingBooking) {
    document.getElementById('bookingModalTitle').textContent = 'Edit Booking / Tenancy';
    document.getElementById('bookingIdInput').value = existingBooking.id;
    document.getElementById('bookingPropertySelect').value = existingBooking.propertyId;

    const rType = existingBooking.rentalType || 'daily';
    setBookingFormRentalType(rType);

    const tType = existingBooking.tenantType || (existingBooking.companyRegNo ? 'company' : 'individual');
    setBookingTenantType(tType);

    // Populate Role (a): TENANT (Individual)
    document.getElementById('bookingGuestName').value = existingBooking.guestName || '';
    document.getElementById('bookingGuestPhone').value = existingBooking.guestPhone || '';
    document.getElementById('bookingGuestNric').value = existingBooking.guestNric || '';
    document.getElementById('bookingGuestEmail').value = existingBooking.guestEmail || '';
    document.getElementById('bookingGuestAddress').value = existingBooking.guestAddress || '';

    // Populate Role (a): TENANT (Company)
    const elCompName = document.getElementById('bookingCompanyName');
    if (elCompName) elCompName.value = existingBooking.companyName || (tType === 'company' ? existingBooking.guestName : '') || '';
    const elReg = document.getElementById('bookingCompanyRegNo');
    if (elReg) elReg.value = existingBooking.companyRegNo || (tType === 'company' ? existingBooking.guestNric : '') || '';
    const elCompAddr = document.getElementById('bookingCompanyAddress');
    if (elCompAddr) elCompAddr.value = existingBooking.companyAddress || (tType === 'company' ? existingBooking.guestAddress : '') || '';

    // Populate Role (b): CONTACT PERSON
    const elCP = document.getElementById('bookingContactPerson');
    if (elCP) elCP.value = existingBooking.contactPerson || '';
    const elCD = document.getElementById('bookingContactDesignation');
    if (elCD) elCD.value = existingBooking.contactDesignation || '';
    const elCPH = document.getElementById('bookingContactPhone');
    if (elCPH) elCPH.value = existingBooking.contactPhone || (tType === 'company' ? existingBooking.guestPhone : '') || '';
    const elCE = document.getElementById('bookingContactEmail');
    if (elCE) elCE.value = existingBooking.contactEmail || (tType === 'company' ? existingBooking.guestEmail : '') || '';

    // Populate Role (c): AUTHORIZED SIGNATORY (Company)
    const elSigName = document.getElementById('bookingSignatoryName');
    if (elSigName) elSigName.value = existingBooking.signatoryName || '';
    const elSigDesig = document.getElementById('bookingSignatoryDesignation');
    if (elSigDesig) elSigDesig.value = existingBooking.signatoryDesignation || '';
    const elSigIc = document.getElementById('bookingSignatoryIc');
    if (elSigIc) elSigIc.value = existingBooking.signatoryIc || existingBooking.contactIc || '';
    const chkSigSame = document.getElementById('bookingSignatorySameAsContact');
    if (chkSigSame) {
      chkSigSame.checked = existingBooking.signatorySameAsContact !== undefined
        ? !!existingBooking.signatorySameAsContact
        : (tType === 'company' && !!existingBooking.signatoryName && existingBooking.signatoryName === existingBooking.contactPerson);
    }

    // Populate Monthly Extras: Emergency Contact & Occupants
    const elEmName = document.getElementById('bookingEmergencyContactName');
    if (elEmName) elEmName.value = existingBooking.emergencyContactName || '';
    const elEmPhone = document.getElementById('bookingEmergencyContactPhone');
    if (elEmPhone) elEmPhone.value = existingBooking.emergencyContactPhone || '';
    const elEmRel = document.getElementById('bookingEmergencyContactRelation');
    if (elEmRel) elEmRel.value = existingBooking.emergencyContactRelation || '';
    const elOccCount = document.getElementById('bookingOccupantsCount');
    if (elOccCount) elOccCount.value = existingBooking.occupantsCount || existingBooking.guestCount || 2;
    const elOccNotes = document.getElementById('bookingOccupantsNotes');
    if (elOccNotes) elOccNotes.value = existingBooking.occupantsNotes || '';

    document.getElementById('bookingGuestCount').value = existingBooking.guestCount || existingBooking.occupantsCount || 2;
    document.getElementById('bookingChannel').value = existingBooking.channel || 'whatsapp';
    document.getElementById('bookingDepositPaid').value = existingBooking.depositPaid || 0;
    const currentSt = existingBooking.status || 'booked';
    document.getElementById('bookingStatusSelect').value = currentSt;
    const isBM = appState.settings.language === 'bm';
    const hintEl = document.getElementById('bookingDepositPaidHint');
    if (hintEl) {
      if (currentSt === 'confirmed' || currentSt === 'checked-in' || currentSt === 'checked-out') {
        hintEl.textContent = isBM ? `✓ Bayaran penuh disahkan. Baki: ${formatCurrency(0)}` : `✓ Full payment confirmed. Balance: ${formatCurrency(0)}`;
        hintEl.style.color = 'var(--success)';
      } else if (currentSt === 'booked') {
        hintEl.textContent = isBM ? `Deposit: ${formatCurrency(existingBooking.depositPaid)}. Baki: ${formatCurrency(existingBooking.balance)}` : `Deposit: ${formatCurrency(existingBooking.depositPaid)}. Balance: ${formatCurrency(existingBooking.balance)}`;
        hintEl.style.color = 'var(--warning)';
      } else {
        hintEl.textContent = '';
      }
    }
    document.getElementById('bookingNotes').value = existingBooking.notes || '';

    const qVal = existingBooking.quotationValidityDays || appState.settings.quotationValidityDays || 3;
    const qValEl = document.getElementById('bookingQuotationValidity');
    if (qValEl) qValEl.value = qVal;
    const qGroup = document.getElementById('bookingQuotationValidityGroup');
    if (qGroup) {
      qGroup.style.display = (existingBooking.status === 'quotation') ? 'block' : 'none';
    }

    if (rType === 'monthly') {
      document.getElementById('bookingMonthlyStart').value = existingBooking.monthlyStart || existingBooking.checkIn;
      document.getElementById('bookingMonthlyDuration').value = existingBooking.monthlyDuration || 6;
      document.getElementById('bookingMonthlyRate').value = existingBooking.monthlyRate || 1200;
      document.getElementById('bookingRentalDeposit').value = existingBooking.rentalDeposit || 1200;
      document.getElementById('bookingUtilitiesDeposit').value = existingBooking.utilitiesDeposit || 300;
      document.getElementById('bookingAgreementFee').value = existingBooking.agreementFee || 150;
    } else {
      document.getElementById('bookingCheckIn').value = existingBooking.checkIn;
      document.getElementById('bookingCheckOut').value = existingBooking.checkOut;
      document.getElementById('bookingNightlyRate').value = existingBooking.nightlyRate || 250;
      document.getElementById('bookingCleaningFee').value = existingBooking.cleaningFee || 0;
      document.getElementById('bookingSecurityDeposit').value = existingBooking.securityDeposit || 0;
    }

    // Populate Attached Receipts Section
    const receiptsSec = document.getElementById('bookingReceiptsSection');
    const receiptsList = document.getElementById('bookingModalReceiptsList');
    if (receiptsSec && receiptsList) {
      receiptsSec.style.display = 'block';
      const payments = existingBooking.payments || [];
      if (payments.length === 0) {
        receiptsList.innerHTML = `<p style="font-size:11.5px; color:var(--text-muted); margin:0;">${t('no_receipts_recorded')}</p>`;
      } else {
        receiptsList.innerHTML = payments.map(p => `
          <div style="display:flex; justify-content:space-between; align-items:center; background:var(--bg-surface); padding:5px 8px; border-radius:4px; border:1px solid var(--border-color); margin-top:4px; font-size:12px;">
            <span><i class="fa-solid fa-building-columns" style="color:var(--primary); margin-right:4px;"></i><strong>${p.bankName || 'Bank'}</strong> • <code>${p.referenceNo || '-'}</code></span>
            <span style="font-weight:700; color:var(--success);">${formatCurrency(p.amount)}</span>
          </div>
        `).join('');
      }

      const btnAddReceipt = document.getElementById('btnBookingModalAddReceipt');
      if (btnAddReceipt) {
        btnAddReceipt.onclick = () => {
          openPaymentProofModal(existingBooking);
        };
      }
    }

    const btnChangeUnit = document.getElementById('btnBookingModalChangeUnit');
    if (btnChangeUnit) {
      btnChangeUnit.style.display = 'inline-flex';
      btnChangeUnit.onclick = () => {
        closeAllModals();
        openChangeHomestayModal(existingBooking);
      };
    }
  } else {
    const btnChangeUnit = document.getElementById('btnBookingModalChangeUnit');
    if (btnChangeUnit) btnChangeUnit.style.display = 'none';

    document.getElementById('bookingModalTitle').textContent = 'New Booking / Quotation';
    document.getElementById('bookingIdInput').value = '';

    // Clear Role (a): TENANT (Individual)
    document.getElementById('bookingGuestName').value = '';
    document.getElementById('bookingGuestPhone').value = '';
    document.getElementById('bookingGuestNric').value = '';
    document.getElementById('bookingGuestEmail').value = '';
    document.getElementById('bookingGuestAddress').value = '';

    // Clear Role (a): TENANT (Company)
    const elCompName = document.getElementById('bookingCompanyName'); if (elCompName) elCompName.value = '';
    const elReg = document.getElementById('bookingCompanyRegNo'); if (elReg) elReg.value = '';
    const elCompAddr = document.getElementById('bookingCompanyAddress'); if (elCompAddr) elCompAddr.value = '';

    // Clear Role (b): CONTACT PERSON
    const elCP = document.getElementById('bookingContactPerson'); if (elCP) elCP.value = '';
    const elCD = document.getElementById('bookingContactDesignation'); if (elCD) elCD.value = '';
    const elCPH = document.getElementById('bookingContactPhone'); if (elCPH) elCPH.value = '';
    const elCE = document.getElementById('bookingContactEmail'); if (elCE) elCE.value = '';

    // Clear Role (c): AUTHORIZED SIGNATORY (Company)
    const elSigName = document.getElementById('bookingSignatoryName'); if (elSigName) elSigName.value = '';
    const elSigDesig = document.getElementById('bookingSignatoryDesignation'); if (elSigDesig) elSigDesig.value = '';
    const elSigIc = document.getElementById('bookingSignatoryIc'); if (elSigIc) elSigIc.value = '';
    const chkSigSame = document.getElementById('bookingSignatorySameAsContact'); if (chkSigSame) chkSigSame.checked = false;

    // Clear Monthly Extras: Emergency Contact & Occupants
    const elEmName = document.getElementById('bookingEmergencyContactName'); if (elEmName) elEmName.value = '';
    const elEmPhone = document.getElementById('bookingEmergencyContactPhone'); if (elEmPhone) elEmPhone.value = '';
    const elEmRel = document.getElementById('bookingEmergencyContactRelation'); if (elEmRel) elEmRel.value = '';
    const elOccCount = document.getElementById('bookingOccupantsCount'); if (elOccCount) elOccCount.value = 2;
    const elOccNotes = document.getElementById('bookingOccupantsNotes'); if (elOccNotes) elOccNotes.value = '';

    const receiptsSec = document.getElementById('bookingReceiptsSection');
    if (receiptsSec) receiptsSec.style.display = 'none';
    
    if (prefillPropertyId) {
      document.getElementById('bookingPropertySelect').value = prefillPropertyId;
    } else if (appState.selectedPropertyId !== 'all') {
      document.getElementById('bookingPropertySelect').value = appState.selectedPropertyId;
    }

    setBookingFormRentalType('daily');
    setBookingTenantType('individual');

    const checkIn = prefillDate || todayStr;
    const dIn = new Date(checkIn + 'T00:00:00');
    const dOut = new Date(dIn); dOut.setDate(dIn.getDate() + 1);
    
    document.getElementById('bookingCheckIn').value = checkIn;
    document.getElementById('bookingCheckOut').value = formatLocalDate(dOut);

    document.getElementById('bookingMonthlyStart').value = checkIn;
    document.getElementById('bookingMonthlyDuration').value = 6;

    const prop = getPropertyById(document.getElementById('bookingPropertySelect').value);
    document.getElementById('bookingNightlyRate').value = prop.defaultRate || 250;
    document.getElementById('bookingCleaningFee').value = prop.cleaningFee || 50;
    document.getElementById('bookingSecurityDeposit').value = 100;

    document.getElementById('bookingMonthlyRate').value = prop.defaultRate ? prop.defaultRate * 10 : 1500;
    document.getElementById('bookingRentalDeposit').value = prop.defaultRate ? prop.defaultRate * 10 : 1500;
    document.getElementById('bookingUtilitiesDeposit').value = 300;
    document.getElementById('bookingAgreementFee').value = 150;

    document.getElementById('bookingDepositPaid').value = 0;
    document.getElementById('bookingStatusSelect').value = 'quotation';

    const qValEl = document.getElementById('bookingQuotationValidity');
    if (qValEl) qValEl.value = appState.settings.quotationValidityDays || 3;
    const qGroup = document.getElementById('bookingQuotationValidityGroup');
    if (qGroup) {
      qGroup.style.display = 'block';
    }

    if (prefillData) {
      if (prefillData.tenantType) {
        setBookingTenantType(prefillData.tenantType);
      }
      if (prefillData.companyName) {
        const el = document.getElementById('bookingCompanyName');
        if (el) el.value = prefillData.companyName;
      }
      if (prefillData.companyRegNo) {
        const el = document.getElementById('bookingCompanyRegNo');
        if (el) el.value = prefillData.companyRegNo;
      }
      if (prefillData.companyAddress) {
        const el = document.getElementById('bookingCompanyAddress');
        if (el) el.value = prefillData.companyAddress;
      }
      if (prefillData.contactPerson) {
        const el = document.getElementById('bookingContactPerson');
        if (el) el.value = prefillData.contactPerson;
      }
      if (prefillData.contactDesignation) {
        const el = document.getElementById('bookingContactDesignation');
        if (el) el.value = prefillData.contactDesignation;
      }
      if (prefillData.contactPhone) {
        const el = document.getElementById('bookingContactPhone');
        if (el) el.value = prefillData.contactPhone;
      }
      if (prefillData.contactEmail) {
        const el = document.getElementById('bookingContactEmail');
        if (el) el.value = prefillData.contactEmail;
      }
      if (prefillData.guestName) document.getElementById('bookingGuestName').value = prefillData.guestName;
      if (prefillData.guestPhone) document.getElementById('bookingGuestPhone').value = prefillData.guestPhone;
      if (prefillData.guestNric) document.getElementById('bookingGuestNric').value = prefillData.guestNric;
      if (prefillData.guestEmail) document.getElementById('bookingGuestEmail').value = prefillData.guestEmail;
      if (prefillData.guestAddress) document.getElementById('bookingGuestAddress').value = prefillData.guestAddress;
      if (prefillData.checkIn) document.getElementById('bookingCheckIn').value = prefillData.checkIn;
      if (prefillData.checkOut) document.getElementById('bookingCheckOut').value = prefillData.checkOut;
      if (prefillData.guestCount) {
        document.getElementById('bookingGuestCount').value = prefillData.guestCount;
        const occEl = document.getElementById('bookingOccupantsCount');
        if (occEl) occEl.value = prefillData.guestCount;
      }
      if (prefillData.occupantsNotes) {
        const occNotesEl = document.getElementById('bookingOccupantsNotes');
        if (occNotesEl) occNotesEl.value = prefillData.occupantsNotes;
      }
      if (prefillData.notes) {
        const notesEl = document.getElementById('bookingNotes');
        if (notesEl) notesEl.value = prefillData.notes;
      }
      if (prefillData.channel) {
        const chEl = document.getElementById('bookingChannel');
        if (chEl) chEl.value = prefillData.channel;
      }
    }
  }

  updateBookingModalPricing();
  checkBookingModalOverlap();
  if (typeof checkBookingRepeatGuest === 'function') {
    checkBookingRepeatGuest();
  }
  document.getElementById('bookingModal').classList.add('active');
}

function updateBookingModalPricing() {
  const rType = document.getElementById('bookingRentalType').value;

  if (rType === 'monthly') {
    const mRate = parseFloat(document.getElementById('bookingMonthlyRate').value) || 0;
    const rDep = parseFloat(document.getElementById('bookingRentalDeposit').value) || 0;
    const uDep = parseFloat(document.getElementById('bookingUtilitiesDeposit').value) || 0;
    const aFee = parseFloat(document.getElementById('bookingAgreementFee').value) || 0;

    const totalMoveIn = mRate + rDep + uDep + aFee;
    document.getElementById('calcMonthlyTotalAmount').textContent = formatCurrency(totalMoveIn);
  } else {
    const checkInVal = document.getElementById('bookingCheckIn').value;
    const checkOutVal = document.getElementById('bookingCheckOut').value;
    const rateVal = parseFloat(document.getElementById('bookingNightlyRate').value) || 0;
    const cleanVal = parseFloat(document.getElementById('bookingCleaningFee').value) || 0;
    const secDep = parseFloat(document.getElementById('bookingSecurityDeposit').value) || 0;

    let nights = 0;
    if (checkInVal && checkOutVal && checkInVal < checkOutVal) {
      nights = calcNightsBetween(checkInVal, checkOutVal);
    }

    document.getElementById('calcNightsCount').textContent = nights;
    const totalRental = (nights * rateVal) + cleanVal;
    const grandTotal = totalRental + secDep;
    document.getElementById('calcTotalAmount').textContent = formatCurrency(grandTotal);

    // Update 30% deposit label on rental portion
    const dep30 = Math.round(totalRental * 0.30 * 100) / 100;
    const txt30 = document.getElementById('txtPreset30');
    if (txt30) txt30.textContent = formatCurrency(dep30);
  }
}

function handleSaveBooking(e) {
  e.preventDefault();

  const isBM = appState.settings.language === 'bm';
  const id = document.getElementById('bookingIdInput').value;
  const propertyId = document.getElementById('bookingPropertySelect').value;
  const rentalType = document.getElementById('bookingRentalType').value || 'daily';
  const tenantType = document.getElementById('bookingTenantType')?.value || 'individual';
  const isCompany = tenantType === 'company';
  const isMonthly = rentalType === 'monthly';

  // Role (a) TENANT: Individual fields
  const rawGuestName = document.getElementById('bookingGuestName') ? document.getElementById('bookingGuestName').value.trim() : '';
  const rawGuestPhone = document.getElementById('bookingGuestPhone') ? document.getElementById('bookingGuestPhone').value.trim() : '';
  const guestNric = document.getElementById('bookingGuestNric') ? document.getElementById('bookingGuestNric').value.trim() : '';
  const guestEmail = document.getElementById('bookingGuestEmail') ? document.getElementById('bookingGuestEmail').value.trim() : '';
  const guestAddress = document.getElementById('bookingGuestAddress') ? document.getElementById('bookingGuestAddress').value.trim() : '';

  // Role (a) TENANT: Company fields
  const companyName = document.getElementById('bookingCompanyName') ? document.getElementById('bookingCompanyName').value.trim() : '';
  const companyRegNo = document.getElementById('bookingCompanyRegNo') ? document.getElementById('bookingCompanyRegNo').value.trim() : '';
  const companyAddress = document.getElementById('bookingCompanyAddress') ? document.getElementById('bookingCompanyAddress').value.trim() : '';

  // Role (b) CONTACT PERSON (Communication)
  const contactPerson = document.getElementById('bookingContactPerson') ? document.getElementById('bookingContactPerson').value.trim() : '';
  const contactDesignation = document.getElementById('bookingContactDesignation') ? document.getElementById('bookingContactDesignation').value.trim() : '';
  const contactPhone = document.getElementById('bookingContactPhone') ? document.getElementById('bookingContactPhone').value.trim() : '';
  const contactEmail = document.getElementById('bookingContactEmail') ? document.getElementById('bookingContactEmail').value.trim() : '';

  // Role (c) AUTHORIZED SIGNATORY (Company)
  const signatorySameAsContact = !!document.getElementById('bookingSignatorySameAsContact')?.checked;
  const signatoryName = document.getElementById('bookingSignatoryName') ? document.getElementById('bookingSignatoryName').value.trim() : '';
  const signatoryDesignation = document.getElementById('bookingSignatoryDesignation') ? document.getElementById('bookingSignatoryDesignation').value.trim() : '';
  const signatoryIc = document.getElementById('bookingSignatoryIc') ? document.getElementById('bookingSignatoryIc').value.trim() : '';

  // Extra Monthly Details: Emergency Contact & Occupants
  const emergencyContactName = document.getElementById('bookingEmergencyContactName') ? document.getElementById('bookingEmergencyContactName').value.trim() : '';
  const emergencyContactPhone = document.getElementById('bookingEmergencyContactPhone') ? document.getElementById('bookingEmergencyContactPhone').value.trim() : '';
  const emergencyContactRelation = document.getElementById('bookingEmergencyContactRelation') ? document.getElementById('bookingEmergencyContactRelation').value.trim() : '';
  const occupantsCount = parseInt(document.getElementById('bookingOccupantsCount')?.value) || 2;
  const occupantsNotes = document.getElementById('bookingOccupantsNotes') ? document.getElementById('bookingOccupantsNotes').value.trim() : '';

  const guestCount = isMonthly ? occupantsCount : (parseInt(document.getElementById('bookingGuestCount').value) || 2);
  const channel = document.getElementById('bookingChannel').value;
  const depositPaid = parseFloat(document.getElementById('bookingDepositPaid').value) || 0;
  let status = document.getElementById('bookingStatusSelect').value;
  const notes = document.getElementById('bookingNotes').value.trim();
  const quotationValidityDays = parseInt(document.getElementById('bookingQuotationValidity')?.value) || appState.settings.quotationValidityDays || 3;

  const phoneRegex = /^[\+]?[0-9\s\-]{6,20}$/;

  // Role-Specific Validations
  if (isCompany) {
    if (!companyName) {
      alert(isBM ? 'Sila masukkan nama berdaftar syarikat.' : 'Please enter corporate legal name.');
      return;
    }
    if (companyName.length > 120) {
      alert(isBM ? 'Nama syarikat terlalu panjang (maksimum 120 aksara).' : 'Company name is too long (maximum 120 characters).');
      return;
    }
    if (!companyRegNo) {
      alert(isBM ? 'Sila masukkan nombor SSM pendaftaran syarikat.' : 'Please enter company SSM registration number.');
      return;
    }
    if (!contactPerson) {
      alert(isBM ? 'Sila masukkan nama pegawai syarikat untuk dihubungi.' : 'Please enter company contact person name.');
      return;
    }
    if (!contactPhone) {
      alert(isBM ? 'Sila masukkan nombor telefon pegawai syarikat.' : 'Please enter company contact person phone number.');
      return;
    }
    if (!phoneRegex.test(contactPhone)) {
      alert(isBM ? 'Format nombor telefon pegawai syarikat tidak sah.' : 'Invalid contact person phone number format.');
      return;
    }
  } else {
    // Individual
    if (!rawGuestName) {
      alert(isBM ? 'Sila masukkan nama tetamu / penyewa.' : 'Please enter guest name.');
      return;
    }
    if (rawGuestName.length > 120) {
      alert(isBM ? 'Nama tetamu terlalu panjang (maksimum 120 aksara).' : 'Guest name is too long (maximum 120 characters).');
      return;
    }
    if (!isMonthly && !rawGuestPhone) {
      alert(isBM ? 'Sila masukkan nombor telefon tetamu.' : 'Please enter guest phone number.');
      return;
    }
    if (rawGuestPhone && !phoneRegex.test(rawGuestPhone)) {
      alert(isBM ? 'Format nombor telefon tetamu tidak sah (contoh: +60123456789 atau 012-3456789).' : 'Invalid guest phone number format (e.g. +60123456789 or 012-3456789).');
      return;
    }
    if (contactPhone && !phoneRegex.test(contactPhone)) {
      alert(isBM ? 'Format nombor telefon wakil tidak sah.' : 'Invalid contact phone number format.');
      return;
    }
  }

  if (emergencyContactPhone && !phoneRegex.test(emergencyContactPhone)) {
    alert(isBM ? 'Format nombor telefon kontak kecemasan tidak sah.' : 'Invalid emergency contact phone number format.');
    return;
  }
  if (guestAddress && guestAddress.length > 300) {
    alert(isBM ? 'Alamat tetamu terlalu panjang (maksimum 300 aksara).' : 'Guest address is too long (maximum 300 characters).');
    return;
  }
  if (notes && notes.length > 1000) {
    alert(isBM ? 'Nota terlalu panjang (maksimum 1000 aksara).' : 'Notes are too long (maximum 1000 characters).');
    return;
  }

  // Unified backward-compatible fields
  const guestName = isCompany ? companyName : rawGuestName;
  const guestPhone = isCompany ? contactPhone : (rawGuestPhone || contactPhone);
  const primaryNric = isCompany ? companyRegNo : guestNric;
  const primaryEmail = isCompany ? contactEmail : (guestEmail || contactEmail);
  const primaryAddress = isCompany ? (companyAddress || guestAddress) : guestAddress;

  let checkIn = '';
  let checkOut = '';
  let nights = 1;
  let nightlyRate = 0;
  let cleaningFee = 0;
  let securityDeposit = 0;

  let monthlyStart = '';
  let monthlyDuration = 1;
  let monthlyRate = 0;
  let rentalDeposit = 0;
  let utilitiesDeposit = 0;
  let agreementFee = 0;
  let totalAmount = 0;

  if (rentalType === 'monthly') {
    monthlyStart = document.getElementById('bookingMonthlyStart').value;
    monthlyDuration = parseInt(document.getElementById('bookingMonthlyDuration').value) || 1;
    monthlyRate = parseFloat(document.getElementById('bookingMonthlyRate').value) || 0;
    rentalDeposit = parseFloat(document.getElementById('bookingRentalDeposit').value) || 0;
    utilitiesDeposit = parseFloat(document.getElementById('bookingUtilitiesDeposit').value) || 0;
    agreementFee = parseFloat(document.getElementById('bookingAgreementFee').value) || 0;

    if (!monthlyStart) {
      alert(isBM ? 'Sila masukkan tarikh mula sewaan.' : 'Please enter tenancy start date.');
      return;
    }
    if (monthlyDuration < 1) {
      alert(isBM ? 'Tempoh sewaan minimum adalah 1 bulan.' : 'Minimum tenancy duration is 1 month.');
      return;
    }
    if (monthlyRate < 0 || rentalDeposit < 0 || utilitiesDeposit < 0 || agreementFee < 0 || depositPaid < 0) {
      alert(isBM ? 'Nilai kewangan tidak boleh negatif!' : 'Financial amounts cannot be negative!');
      return;
    }

    checkIn = monthlyStart;
    const dStart = new Date(monthlyStart + 'T00:00:00');
    const dEnd = new Date(dStart);
    dEnd.setMonth(dEnd.getMonth() + monthlyDuration);
    checkOut = formatLocalDate(dEnd);

    const dDiff = calcNightsBetween(checkIn, checkOut);
    nights = dDiff > 0 ? dDiff : monthlyDuration * 30;

    totalAmount = monthlyRate + rentalDeposit + utilitiesDeposit + agreementFee;
  } else {
    checkIn = document.getElementById('bookingCheckIn').value;
    checkOut = document.getElementById('bookingCheckOut').value;
    nightlyRate = parseFloat(document.getElementById('bookingNightlyRate').value) || 0;
    cleaningFee = parseFloat(document.getElementById('bookingCleaningFee').value) || 0;
    securityDeposit = parseFloat(document.getElementById('bookingSecurityDeposit').value) || 0;

    if (!checkIn || !checkOut || checkIn >= checkOut) {
      alert(isBM ? 'Tarikh daftar keluar mestilah selepas tarikh daftar masuk!' : 'Check-out date must be after check-in date!');
      return;
    }
    if (nightlyRate < 0 || cleaningFee < 0 || securityDeposit < 0 || depositPaid < 0) {
      alert(isBM ? 'Kadar atau fi tidak boleh bernilai negatif!' : 'Rates and fees cannot be negative!');
      return;
    }

    nights = calcNightsBetween(checkIn, checkOut);
    const totalRental = (nights * nightlyRate) + cleaningFee;
    totalAmount = totalRental + securityDeposit;
  }

  // Deposit cannot exceed total
  if (depositPaid > totalAmount && totalAmount > 0) {
    alert(isBM ? 'Bayaran deposit tidak boleh melebihi jumlah keseluruhan!' : 'Deposit paid cannot exceed total amount!');
    return;
  }

  let finalDepositPaid = depositPaid;

  // Auto-settle: If user picked Confirmed (Fully Paid), In-House, or Checked-Out (Ended), ensure depositPaid equals totalAmount and balance is 0
  if ((status === 'confirmed' || status === 'checked-in' || status === 'checked-out') && finalDepositPaid < totalAmount) {
    finalDepositPaid = totalAmount;
  }

  const balance = Math.max(0, totalAmount - finalDepositPaid);

  // Auto-refine status if user didn't manually pick a specific state
  if (!id) {
    if (finalDepositPaid >= totalAmount && totalAmount > 0) {
      status = 'confirmed';
    } else if (finalDepositPaid > 0) {
      status = 'booked';
    } else {
      status = 'quotation';
    }
  }

  // 1. STRICT OVERLAP CHECK: Prevent double-booking if status is not cancelled and not quotation
  if (status !== 'cancelled' && status !== 'quotation') {
    const overlaps = getBookingOverlaps(propertyId, checkIn, checkOut, id);
    if (overlaps.length > 0) {
      openOverlapWarningModal(overlaps, propertyId, checkIn, checkOut, guestName, id);
      return; // STRICTLY BLOCK SAVE!
    }
  }

  const existingBooking = id ? appState.bookings.find(b => b.id === id) : null;
  let finalNotes = notes;

  // If changing homestay property on existing booking, update turnover tasks & append audit note
  if (id && existingBooking && existingBooking.propertyId !== propertyId) {
    const oldProp = getPropertyById(existingBooking.propertyId);
    const newProp = getPropertyById(propertyId);
    const auditText = isBM 
      ? `[Tukar Homestay: ${oldProp.name} → ${newProp.name} pada ${new Date().toLocaleDateString()}]`
      : `[Transferred Unit: ${oldProp.name} → ${newProp.name} on ${new Date().toLocaleDateString()}]`;
    finalNotes = finalNotes ? `${finalNotes}\n${auditText}` : auditText;

    // Sync property on any associated turnover cleaning tasks
    appState.turnovers.forEach(t => {
      if (t.bookingId === id) {
        t.propertyId = propertyId;
      }
    });
  }

  // Quotation Number Assignment from real incrementing counter
  let quotationNo = id && existingBooking ? existingBooking.quotationNo : null;
  if (status === 'quotation' && !quotationNo) {
    appState.quotationCounter = (appState.quotationCounter || 0) + 1;
    const qYear = new Date().getFullYear();
    quotationNo = `QT-${qYear}-${String(appState.quotationCounter).padStart(4, '0')}`;
  }

  const bookingData = {
    id: id || `b-${Date.now()}`,
    propertyId,
    rentalType,
    tenantType,
    guestName,
    guestPhone,
    guestNric: primaryNric,
    guestEmail: primaryEmail,
    guestAddress: primaryAddress,
    companyName: isCompany ? companyName : '',
    companyRegNo: isCompany ? companyRegNo : '',
    companyAddress: isCompany ? (companyAddress || primaryAddress) : '',
    contactPerson,
    contactDesignation,
    contactIc: isCompany ? (signatoryIc || '') : (guestNric || ''),
    contactPhone,
    contactEmail,
    signatoryName: isCompany ? (signatoryName || (signatorySameAsContact ? contactPerson : '')) : '',
    signatoryDesignation: isCompany ? (signatoryDesignation || (signatorySameAsContact ? contactDesignation : '')) : '',
    signatoryIc: isCompany ? signatoryIc : '',
    signatorySameAsContact: isCompany ? signatorySameAsContact : false,
    emergencyContactName: isMonthly ? emergencyContactName : '',
    emergencyContactPhone: isMonthly ? emergencyContactPhone : '',
    emergencyContactRelation: isMonthly ? emergencyContactRelation : '',
    occupantsCount: isMonthly ? occupantsCount : (parseInt(document.getElementById('bookingGuestCount').value) || 2),
    occupantsNotes: isMonthly ? occupantsNotes : '',
    checkIn,
    checkOut,
    nights,
    guestCount: isMonthly ? occupantsCount : (parseInt(document.getElementById('bookingGuestCount').value) || 2),
    channel,
    nightlyRate,
    cleaningFee,
    securityDeposit,
    monthlyStart,
    monthlyDuration,
    monthlyRate,
    rentalDeposit,
    utilitiesDeposit,
    agreementFee,
    totalAmount,
    depositPaid: finalDepositPaid,
    balance,
    status,
    quotationNo,
    quotationValidityDays,
    notes: finalNotes,
    createdAt: new Date().toISOString()
  };

  if (id) {
    const idx = appState.bookings.findIndex(b => b.id === id);
    if (idx !== -1) appState.bookings[idx] = { ...appState.bookings[idx], ...bookingData };
  } else {
    // Initial deposit / payment receipt allocation (B2 Follow-up)
    if (finalDepositPaid > 0) {
      const year = new Date().getFullYear();
      const isFull = bookingData.balance <= 0 && bookingData.totalAmount > 0;
      let initReceiptNo = '';
      if (isFull) {
        appState.paymentReceiptCounter = (appState.paymentReceiptCounter || 1000) + 1;
        initReceiptNo = (rentalType === 'monthly' ? 'RCPT-M-' : 'RCPT-') + year + '-' + String(appState.paymentReceiptCounter).padStart(4, '0');
        bookingData.paymentReceiptNo = initReceiptNo;
      } else {
        appState.depositReceiptCounter = (appState.depositReceiptCounter || 1000) + 1;
        initReceiptNo = (rentalType === 'monthly' ? 'RCPT-BOOK-M-' : 'RCPT-DEP-') + year + '-' + String(appState.depositReceiptCounter).padStart(4, '0');
        bookingData.depositReceiptNo = initReceiptNo;
      }
      const initPayment = {
        id: 'pay-init-' + Date.now(),
        type: isFull ? 'full' : 'deposit',
        receiptNo: initReceiptNo,
        amount: finalDepositPaid,
        monthIndex: null,
        date: checkIn || formatLocalDate(new Date()),
        time: '12:00',
        dateTime: (checkIn || formatLocalDate(new Date())) + 'T12:00:00',
        bankName: 'Direct Payment / Deposit',
        referenceNo: 'INIT-DEP',
        notes: isFull ? 'Full payment on booking creation' : 'Deposit on booking creation',
        createdAt: new Date().toISOString()
      };
      bookingData.payments = [initPayment];
      bookingData.documents = Array.isArray(bookingData.documents) ? bookingData.documents : [];
      bookingData.documents.push({
        id: `doc-pay-${initPayment.id}`,
        paymentId: initPayment.id,
        docType: isFull ? 'receipt' : 'deposit_receipt',
        monthIndex: null,
        docNo: initReceiptNo,
        baseDocNo: initReceiptNo,
        revision: 0,
        status: 'issued',
        date: initPayment.date,
        amount: finalDepositPaid,
        issuedAt: initPayment.dateTime,
        replacesDocNo: null,
        replacedByDocNo: null,
        hasBeenPrintedOrDownloaded: false
      });
    }

    appState.bookings.push(bookingData);

    // Auto-create turnover task for check-out date
    const prop = getPropertyById(propertyId);
    appState.turnovers.push({
      id: `t-${Date.now()}`,
      propertyId,
      bookingId: bookingData.id,
      date: checkOut,
      status: 'pending',
      cleanerName: 'Cleaner Team',
      cleanerPhone: '',
      checklist: [
        { text: 'Wash bed linens & pillow covers', done: false },
        { text: 'Sanitize bathroom & provide fresh towels', done: false },
        { text: 'Restock amenities & coffee', done: false },
        { text: `Reset Smart Lock PIN (${prop.doorCode || 'PIN'})`, done: false },
        { text: 'Inspect appliances & air conditioner', done: false },
        { text: 'Dispose all trash', done: false }
      ]
    });
  }

  if (typeof syncTenantLifecycleStatus === 'function') {
    syncTenantLifecycleStatus();
  }

  saveToStorage();
  closeAllModals();
  renderApp();
  showToast(id ? 'Booking updated!' : `Booking saved as "${status.toUpperCase()}"!`);
}

// ==========================================================================
// 11B. TENANCY DEPOSIT REFUND MODAL LOGIC
// ==========================================================================

function openDepositRefundModal(booking) {
  appState.activeWaBooking = booking;
  const prop = getPropertyById(booking.propertyId);

  document.getElementById('refundBookingIdInput').value = booking.id;
  document.getElementById('refundTenantMeta').textContent = `Tenant: ${booking.guestName} (${booking.guestPhone || '-'}) • Unit: ${prop.name}`;

  const rentalDep = booking.rentalDeposit || 0;
  const utilitiesDep = booking.utilitiesDeposit || booking.securityDeposit || 0;

  document.getElementById('refundRentalDepInput').value = rentalDep;
  document.getElementById('refundUtilitiesDepInput').value = utilitiesDep;
  document.getElementById('refundDeductUtilitiesInput').value = 0;
  document.getElementById('refundDeductRepairsInput').value = 0;
  document.getElementById('refundNotesInput').value = '';

  updateDepositRefundCalculation();
  document.getElementById('depositRefundModal').classList.add('active');
}

function updateDepositRefundCalculation() {
  const rentalDep = parseFloat(document.getElementById('refundRentalDepInput').value) || 0;
  const utilDep = parseFloat(document.getElementById('refundUtilitiesDepInput').value) || 0;
  const dedUtil = parseFloat(document.getElementById('refundDeductUtilitiesInput').value) || 0;
  const dedRepair = parseFloat(document.getElementById('refundDeductRepairsInput').value) || 0;

  const netRefund = Math.max(0, (rentalDep + utilDep) - (dedUtil + dedRepair));
  document.getElementById('calcNetRefundAmount').textContent = formatCurrency(netRefund);
}

function handleProcessDepositRefund(e) {
  e.preventDefault();

  const bookingId = document.getElementById('refundBookingIdInput').value;
  const booking = appState.bookings.find(b => b.id === bookingId);
  if (!booking) return;

  const rentalDep = parseFloat(document.getElementById('refundRentalDepInput').value) || 0;
  const utilDep = parseFloat(document.getElementById('refundUtilitiesDepInput').value) || 0;
  const dedUtil = parseFloat(document.getElementById('refundDeductUtilitiesInput').value) || 0;
  const dedRepair = parseFloat(document.getElementById('refundDeductRepairsInput').value) || 0;
  const netRefund = Math.max(0, (rentalDep + utilDep) - (dedUtil + dedRepair));
  const notes = document.getElementById('refundNotesInput').value.trim();

  appState.refundCounter = (appState.refundCounter || 1000) + 1;
  const year = new Date().getFullYear();
  const refundNo = `REF-${year}-${String(appState.refundCounter).padStart(4, '0')}`;

  booking.refundDetails = {
    refundNo,
    rentalDep,
    utilDep,
    dedUtil,
    dedRepair,
    netRefund,
    notes,
    refundedAt: new Date().toISOString()
  };
  booking.status = 'checked-out';

  // Record into booking.documents for Document History & audit tracking (B2)
  booking.documents = Array.isArray(booking.documents) ? booking.documents : [];
  booking.documents.push({
    id: `doc-ref-${Date.now()}`,
    docType: 'refund',
    monthIndex: null,
    docNo: refundNo,
    baseDocNo: refundNo,
    revision: 0,
    status: 'issued',
    date: formatLocalDate(new Date()),
    amount: netRefund,
    issuedAt: new Date().toISOString(),
    replacesDocNo: null,
    replacedByDocNo: null,
    hasBeenPrintedOrDownloaded: false
  });

  saveToStorage();
  closeAllModals();
  renderApp();
  showToast('Deposit refund recorded! Opening WhatsApp statement...');
  openWhatsAppModal(booking, 'refund_receipt');
}

// ==========================================================================
// 11C. MULTI-MONTH TENANCY INVOICING ENGINE
// ==========================================================================

function getOrInitMonthlyInvoices(booking) {
  if (!booking) return [];
  // Enhancement applies ONLY to Long-Term Tenancy bookings (Daily stays return empty array)
  if (booking.rentalType !== 'monthly') return [];

  const duration = booking.monthlyDuration || 1;
  const bIdStr = String(booking.id || '');
  const idShort = bIdStr.slice(-5).toUpperCase() || '10001';

  if (!booking.monthlyInvoices || !Array.isArray(booking.monthlyInvoices) || booking.monthlyInvoices.length === 0) {
    const invoices = [];
    const checkInStr = booking.checkIn || formatLocalDate(new Date());
    const parsedStart = new Date(checkInStr.includes('T') ? checkInStr : checkInStr + 'T00:00:00');
    const startD = isNaN(parsedStart.getTime()) ? new Date() : parsedStart;
    
    for (let i = 1; i <= duration; i++) {
      const curStart = new Date(startD);
      curStart.setMonth(curStart.getMonth() + (i - 1));
      const curEnd = new Date(curStart);
      curEnd.setMonth(curEnd.getMonth() + 1);
      curEnd.setDate(curEnd.getDate() - 1);

      const dueDate = new Date(curStart);
      dueDate.setDate(dueDate.getDate() + 6); // 7th day of cycle

      // In long-term tenancy, Month 1 Advance Rental is collected upfront in the move-in package
      const isFirstMonth = (i === 1);

      invoices.push({
        monthIndex: i,
        invoiceNo: `INV-M${i}-${idShort}`,
        periodStart: formatLocalDate(curStart),
        periodEnd: formatLocalDate(curEnd),
        dueDate: formatLocalDate(dueDate),
        rentAmount: booking.monthlyRate || 0,
        utilityCharges: 0,
        totalAmount: booking.monthlyRate || 0,
        // Month 1 rental settled via Move-In Package; no Month 1 invoice required
        status: isFirstMonth ? 'paid' : 'pending',
        settledViaMoveIn: isFirstMonth,
        noInvoiceRequired: isFirstMonth,
        paidAt: isFirstMonth ? (booking.createdAt || new Date().toISOString()) : null,
        notes: isFirstMonth ? 'Month 1 Rental Paid Via Move-In Package' : ''
      });
    }
    booking.monthlyInvoices = invoices;
    if (typeof saveToStorage === 'function') saveToStorage();
  } else {
    // Backward compatibility: upgrade existing monthly bookings to ensure Month 1 is settled via move-in
    const m1 = booking.monthlyInvoices.find(x => x.monthIndex === 1);
    if (m1) {
      let needsSave = false;
      if (m1.status !== 'paid') {
        m1.status = 'paid';
        needsSave = true;
      }
      if (!m1.settledViaMoveIn) {
        m1.settledViaMoveIn = true;
        needsSave = true;
      }
      if (m1.noInvoiceRequired !== true) {
        m1.noInvoiceRequired = true;
        needsSave = true;
      }
      if (!m1.notes || m1.notes.includes('Settled in move-in package') || m1.notes === '') {
        m1.notes = 'Month 1 Rental Paid Via Move-In Package';
        needsSave = true;
      }
      if (!m1.paidAt) {
        m1.paidAt = booking.createdAt || new Date().toISOString();
        needsSave = true;
      }
      if (needsSave && typeof saveToStorage === 'function') {
        saveToStorage();
      }
    }
  }
  return booking.monthlyInvoices;
}

function openMonthlyInvoicesModal(booking) {
  if (!booking) return;
  appState.activeWaBooking = booking;
  const prop = getPropertyById(booking.propertyId);
  const isBM = appState.settings.language === 'bm';

  const tenantSubtitle = document.getElementById('monthlyInvoicesTenantSubtitle');
  if (tenantSubtitle) {
    tenantSubtitle.textContent = `${isBM ? 'Penyewa' : 'Tenant'}: ${booking.guestName || '-'} (${booking.guestPhone || '-'}) • ${prop.name || 'Homestay'}`;
  }
  const rateDisplay = document.getElementById('mInvRateDisplay');
  if (rateDisplay) {
    rateDisplay.textContent = `${formatCurrency(booking.monthlyRate || 0)} / ${isBM ? 'bulan' : 'month'}`;
  }
  const periodDisplay = document.getElementById('mInvPeriodDisplay');
  if (periodDisplay) {
    periodDisplay.textContent = `${booking.checkIn || '-'} → ${booking.checkOut || '-'} (${booking.monthlyDuration || 6} ${t('months')})`;
  }

  const btnEditAgr = document.getElementById('btnEditTenancyAgreementFromHub');
  if (btnEditAgr) {
    btnEditAgr.onclick = (e) => {
      e.stopPropagation();
      openAgreementModal(booking, 'form');
    };
  }

  const btnAgr = document.getElementById('btnOpenTenancyAgreementFromHub');
  if (btnAgr) {
    btnAgr.onclick = (e) => {
      e.stopPropagation();
      openAgreementModal(booking, 'preview');
    };
  }

  const btnQuickAgr = document.getElementById('btnQuickDownloadAgreementFromHub');
  if (btnQuickAgr) {
    btnQuickAgr.onclick = (e) => {
      e.stopPropagation();
      openAgreementModal(booking, 'preview');
      setTimeout(() => { downloadAgreementPdf(); }, 400);
    };
  }

  try {
    renderMonthlyInvoicesList(booking);
  } catch (err) {
    console.error('Error rendering monthly invoices list:', err);
  }
  const modal = document.getElementById('monthlyInvoicesModal');
  if (modal) modal.classList.add('active');
}

function renderMonthlyInvoicesList(booking) {
  const container = document.getElementById('monthlyInvoicesList');
  if (!container) return;
  container.innerHTML = '';

  const invoices = getOrInitMonthlyInvoices(booking);
  const isBM = appState.settings.language === 'bm';

  const paidCount = invoices.filter(x => x.status === 'paid').length;
  const totalMonths = invoices.length;
  const badge = document.getElementById('mInvPaidProgressBadge');
  if (badge) {
    badge.textContent = `${paidCount}/${totalMonths} ${isBM ? 'DIBAYAR' : 'PAID'}`;
    badge.style.background = paidCount === totalMonths ? 'var(--success-light)' : 'var(--primary-light)';
    badge.style.color = paidCount === totalMonths ? 'var(--success-text)' : 'var(--primary-text)';
  }

  invoices.forEach(inv => {
    const isFirstMonth = inv.monthIndex === 1;
    const isPaid = inv.status === 'paid';
    const card = document.createElement('div');
    card.className = 'card';
    card.style.padding = '10px 12px';
    card.style.marginBottom = '0';
    card.style.borderLeft = `4px solid ${isPaid ? 'var(--success)' : 'var(--warning)'}`;
    card.style.background = 'var(--bg-surface-subtle)';

    card.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">
        <div>
          <strong style="font-size:13px; color:var(--text-main); display:flex; align-items:center; gap:6px;">
            <i class="fa-solid fa-calendar-check" style="color:${isPaid ? 'var(--success)' : 'var(--warning)'};"></i>
            ${isBM ? `Bulan ke-${inv.monthIndex}` : `Month ${inv.monthIndex}`} (${inv.periodStart} → ${inv.periodEnd})
          </strong>
          <p style="font-size:11px; color:var(--text-muted); margin-top:2px; margin-bottom:0;">
            ${isFirstMonth ? `
              <span style="font-weight:700; color:var(--success-text, #166534);"><i class="fa-solid fa-circle-check"></i> ${isBM ? 'Sewa Bulan 1 Telah Dibayar Melalui Pakej Kemasukan' : 'Month 1 Rental Paid Via Move-In Package'}</span>
              <span style="color:var(--text-muted); font-size:10.5px; display:block; margin-top:2px;">${isBM ? 'Invois bermula dari Bulan ke-2 • Tiada invois diperlukan' : 'Invoicing begins from Month 2 • No invoice required'}</span>
            ` : `
              No: <code style="font-weight:700; color:var(--primary);">${inv.invoiceNo}</code> • ${isBM ? 'Tarikh Akhir' : 'Due'}: <strong>${inv.dueDate}</strong>
              ${inv.paidAt ? ` • <span style="color:var(--success);">Paid: ${inv.paidAt.split('T')[0]}</span>` : ''}
            `}
          </p>
        </div>
        <span style="font-size:10px; font-weight:800; padding:2px 8px; border-radius:999px; ${isFirstMonth ? 'background:#dcfce7;color:#166534;' : (isPaid ? 'background:var(--success-light);color:var(--success-text);' : 'background:var(--warning-light);color:var(--warning-text);')}">
          ${isFirstMonth ? (isBM ? 'LUNAS (PAKEJ KEMASUKAN)' : 'SETTLED VIA MOVE-IN') : (isPaid ? (isBM ? 'DIBAYAR' : 'PAID') : (isBM ? 'BELUM BAYAR' : 'PENDING'))}
        </span>
      </div>

      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px; padding-top:8px; border-top:1px dashed var(--border-color); flex-wrap:wrap; gap:6px;">
        <div style="font-size:12px; font-weight:800; color:var(--primary);">
          ${formatCurrency(inv.totalAmount || inv.rentAmount)}
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
          ${!isFirstMonth ? `
            <button class="btn btn-whatsapp btn-xs btn-send-month-inv" data-m="${inv.monthIndex}">
              <i class="fa-brands fa-whatsapp"></i> ${isBM ? 'Invois' : 'Invoice'}
            </button>
          ` : `
            <span style="font-size:10.5px; font-weight:600; color:var(--text-muted); padding:3px 6px; display:inline-flex; align-items:center; gap:4px;">
              <i class="fa-solid fa-ban" style="color:var(--text-muted);"></i> ${isBM ? 'Tiada Invois (Bulan 1)' : 'No Invoice (Month 1)'}
            </span>
          `}
          ${isPaid ? `
            <button class="btn btn-whatsapp btn-xs btn-send-month-rec" data-m="${inv.monthIndex}" title="${isBM ? 'Hantar Resit Bayaran' : 'Send Payment Receipt'}">
              <i class="fa-solid fa-receipt"></i> ${isBM ? 'Resit' : 'Receipt'}
            </button>
          ` : ''}
          <button class="btn btn-outline btn-xs btn-open-month-pdf" data-m="${inv.monthIndex}" title="${isBM ? 'Jana / Cetak Fail PDF Rasmi' : 'Generate / Print Official PDF'}">
            <i class="fa-solid fa-file-pdf" style="color:var(--danger, #dc2626);"></i> PDF
          </button>
          ${!isFirstMonth ? `
            <button class="btn btn-outline btn-xs btn-toggle-month-paid" data-m="${inv.monthIndex}">
              <i class="fa-solid fa-${isPaid ? 'rotate-left' : 'check'}" style="color:${isPaid ? 'var(--warning)' : 'var(--success)'};"></i>
              ${isPaid ? (isBM ? 'Batal Tanda' : 'Unmark') : (isBM ? 'Tanda Bayar' : 'Mark Paid')}
            </button>
          ` : `
            <span style="font-size:10.5px; font-weight:700; color:#166534; background:#dcfce7; padding:2px 8px; border-radius:4px; display:inline-flex; align-items:center; gap:4px;">
              <i class="fa-solid fa-lock"></i> ${isBM ? 'Pakej Kemasukan' : 'Move-In Package'}
            </span>
          `}
        </div>
      </div>
    `;

    container.appendChild(card);
  });

  // Attach handlers
  container.querySelectorAll('.btn-send-month-inv').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const mIdx = parseInt(e.currentTarget.getAttribute('data-m')) || 1;
      openWhatsAppModal(booking, 'monthly_invoice', mIdx);
    });
  });

  container.querySelectorAll('.btn-send-month-rec').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const mIdx = parseInt(e.currentTarget.getAttribute('data-m')) || 1;
      openWhatsAppModal(booking, 'monthly_rent_receipt', mIdx);
    });
  });

  container.querySelectorAll('.btn-open-month-pdf').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const mIdx = parseInt(e.currentTarget.getAttribute('data-m')) || 1;
      const inv = invoices.find(x => x.monthIndex === mIdx);
      const isPaid = inv && inv.status === 'paid';
      openPdfDocModal(booking, isPaid ? 'receipt' : 'invoice', mIdx);
    });
  });

  container.querySelectorAll('.btn-toggle-month-paid').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const mIdx = parseInt(e.currentTarget.getAttribute('data-m')) || 1;
      toggleMonthlyInvoicePaid(booking.id, mIdx);
    });
  });
}

function toggleMonthlyInvoicePaid(bookingId, monthIndex) {
  const booking = appState.bookings.find(b => String(b.id) === String(bookingId));
  if (!booking) return;

  const invoices = getOrInitMonthlyInvoices(booking);
  const inv = invoices.find(x => x.monthIndex === monthIndex);
  if (!inv) return;

  const isBM = appState.settings.language === 'bm';

  // Month 1 rental is collected upfront in the move-in package and cannot be marked pending
  if (monthIndex === 1) {
    showToast(isBM ? 'Sewa Bulan 1 telah diselesaikan melalui Pakej Kemasukan.' : 'Month 1 rental is settled via the Move-In Package.');
    return;
  }

  if (inv.status === 'paid') {
    inv.status = 'pending';
    inv.paidAt = null;
    showToast(isBM ? `Bulan ke-${monthIndex} ditanda sebagai belum dibayar.` : `Month ${monthIndex} marked as pending.`);
    saveToStorage();
    renderMonthlyInvoicesList(booking);
    if (appState.activeTab === 'bookings') renderBookingsTab();
  } else {
    // Open payment proof modal to attach the tenant's bank receipt!
    closeAllModals();
    openPaymentProofModal(booking, 'monthly_rent', monthIndex, inv.totalAmount || inv.rentAmount);
  }
}

// ==========================================================================
// 11D. DIGITAL PAYMENT RECEIPTS & PROOF CAPTURE ENGINE
// ==========================================================================

function compressReceiptImage(file, maxWidth = 900, maxHeight = 900, quality = 0.78) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error('No file provided'));

    if (file.type === 'application/pdf') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target.result;
        const sizeBytes = Math.round((dataUrl.length * 3) / 4);
        resolve({
          dataUrl,
          sizeBytes,
          isPdf: true,
          fileName: file.name
        });
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        const sizeBytes = Math.round((dataUrl.length * 3) / 4);

        resolve({
          dataUrl,
          sizeBytes,
          width,
          height,
          isPdf: false,
          fileName: file.name
        });
      };
      img.onerror = (err) => reject(err);
      img.src = e.target.result;
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

function handleReceiptFileSelected(file) {
  if (!file) return;
  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Memampatkan gambar resit...' : 'Compressing receipt slip...');

  compressReceiptImage(file, 900, 900, 0.78)
    .then(result => {
      document.getElementById('paymentProofImageData').value = result.dataUrl;
      document.getElementById('paymentProofImageName').value = result.fileName;

      const previewImg = document.getElementById('receiptPreviewImg');
      if (result.isPdf) {
        previewImg.src = 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Crect width=%22100%22 height=%22100%22 fill=%22%23ef4444%22/%3E%3Ctext x=%2250%22 y=%2255%22 font-size=%2218%22 font-weight=%22bold%22 text-anchor=%22middle%22 fill=%22%23ffffff%22%3EPDF%3C/text%3E%3C/svg%3E';
      } else {
        previewImg.src = result.dataUrl;
      }

      document.getElementById('receiptPreviewFileName').textContent = result.fileName;
      const sizeKb = Math.round(result.sizeBytes / 1024);
      document.getElementById('receiptPreviewSize').textContent = `${sizeKb} KB (Compressed & sharp)`;

      document.getElementById('receiptUploadPrompt').style.display = 'none';
      document.getElementById('receiptPreviewContainer').style.display = 'block';
    })
    .catch(err => {
      alert('Error reading receipt file: ' + err.message);
    });
}

function openPaymentProofModal(booking, defaultType = 'deposit', defaultMonth = null, defaultAmount = null) {
  if (!booking) return;
  const prop = getPropertyById(booking.propertyId);
  const isBM = appState.settings.language === 'bm';

  document.getElementById('paymentProofBookingId').value = booking.id;
  document.getElementById('paymentProofId').value = '';

  const titleEl = document.getElementById('paymentProofModalTitle');
  if (titleEl) titleEl.textContent = t('receipt_modal_title');

  document.getElementById('paymentProofGuestPropertyDisplay').textContent = `${prop.name} • ${booking.guestName} (${booking.guestPhone || '-'})`;
  document.getElementById('paymentProofFinancialSummary').textContent = `${t('total')}: ${formatCurrency(booking.totalAmount)} • ${isBM ? 'Dibayar' : 'Paid'}: ${formatCurrency(booking.depositPaid)} • ${isBM ? 'Baki' : 'Balance'}: ${formatCurrency(booking.balance)}`;

  const typeSelect = document.getElementById('paymentProofTypeSelect');
  typeSelect.value = defaultType;

  const monthGroup = document.getElementById('paymentProofMonthIndexGroup');
  const monthSelect = document.getElementById('paymentProofMonthIndexSelect');
  if (booking.rentalType === 'monthly') {
    monthSelect.innerHTML = '';
    const duration = booking.monthlyDuration || 6;
    for (let i = 1; i <= duration; i++) {
      const opt = document.createElement('option');
      opt.value = i;
      opt.textContent = isBM ? `Bulan ke-${i}` : `Month ${i}`;
      if (defaultMonth && i === defaultMonth) opt.selected = true;
      monthSelect.appendChild(opt);
    }
    monthGroup.style.display = (defaultType === 'monthly_rent') ? 'block' : 'none';
  } else {
    monthGroup.style.display = 'none';
  }

  let targetAmount = 0;
  if (defaultAmount !== null && defaultAmount !== undefined) {
    targetAmount = defaultAmount;
  } else if (defaultType === 'deposit') {
    targetAmount = booking.depositPaid > 0 ? booking.depositPaid : Math.round(booking.totalAmount * (appState.settings.defaultDepositPct || 30) / 100);
  } else if (defaultType === 'balance') {
    targetAmount = booking.balance > 0 ? booking.balance : booking.totalAmount;
  } else if (defaultType === 'full') {
    targetAmount = booking.totalAmount;
  } else if (defaultType === 'monthly_rent') {
    targetAmount = booking.monthlyRate || 0;
  } else {
    targetAmount = booking.balance > 0 ? booking.balance : 0;
  }
  document.getElementById('paymentProofAmountInput').value = targetAmount;

  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  document.getElementById('paymentProofDateTimeInput').value = `${year}-${month}-${day}T${hours}:${minutes}`;

  const defaultBank = booking.lastPaymentBank || appState.settings.bankName || 'Maybank';
  document.getElementById('paymentProofBankInput').value = defaultBank;
  document.querySelectorAll('#paymentProofBankPills .bank-pill').forEach(pill => {
    pill.classList.toggle('active', pill.getAttribute('data-bank').toLowerCase() === defaultBank.toLowerCase());
  });

  document.getElementById('paymentProofRefInput').value = '';
  document.getElementById('paymentProofNotesInput').value = '';

  document.getElementById('paymentProofFileInput').value = '';
  document.getElementById('paymentProofImageData').value = '';
  document.getElementById('paymentProofImageName').value = '';
  document.getElementById('receiptUploadPrompt').style.display = 'block';
  document.getElementById('receiptPreviewContainer').style.display = 'none';

  document.getElementById('paymentProofModal').classList.add('active');
}

function handleSavePaymentProof(e) {
  e.preventDefault();

  const bookingId = document.getElementById('paymentProofBookingId').value;
  const booking = appState.bookings.find(b => b.id === bookingId);
  if (!booking) {
    alert('Booking not found!');
    return;
  }

  const type = document.getElementById('paymentProofTypeSelect').value;
  const monthIndex = type === 'monthly_rent' ? parseInt(document.getElementById('paymentProofMonthIndexSelect').value) || 1 : null;
  const amount = parseFloat(document.getElementById('paymentProofAmountInput').value) || 0;
  const dateTime = document.getElementById('paymentProofDateTimeInput').value;
  const bankName = document.getElementById('paymentProofBankInput').value.trim() || 'Bank Transfer';
  const referenceNo = document.getElementById('paymentProofRefInput').value.trim();
  const receiptImage = document.getElementById('paymentProofImageData').value || null;
  const receiptFileName = document.getElementById('paymentProofImageName').value || null;
  const notes = document.getElementById('paymentProofNotesInput').value.trim();

  if (amount <= 0) {
    alert(appState.settings.language === 'bm' ? 'Sila masukkan jumlah bayaran yang sah.' : 'Please enter a valid payment amount.');
    return;
  }

  if (!referenceNo) {
    alert(appState.settings.language === 'bm' ? 'Sila masukkan No. Rujukan Bank / Resit Transaksi.' : 'Please enter the Bank Reference No. / Transaction ID.');
    return;
  }

  const year = new Date().getFullYear();
  let paymentReceiptNo = '';
  if (type === 'deposit') {
    appState.depositReceiptCounter = (appState.depositReceiptCounter || 1000) + 1;
    paymentReceiptNo = (booking.rentalType === 'monthly' ? 'RCPT-BOOK-M-' : 'RCPT-DEP-') + year + '-' + String(appState.depositReceiptCounter).padStart(4, '0');
    booking.depositReceiptNo = paymentReceiptNo;
  } else if (type === 'monthly_rent') {
    appState.paymentReceiptCounter = (appState.paymentReceiptCounter || 1000) + 1;
    paymentReceiptNo = 'RCPT-M' + (monthIndex || 1) + '-' + year + '-' + String(appState.paymentReceiptCounter).padStart(4, '0');
  } else {
    appState.paymentReceiptCounter = (appState.paymentReceiptCounter || 1000) + 1;
    paymentReceiptNo = (booking.rentalType === 'monthly' ? 'RCPT-M-' : 'RCPT-') + year + '-' + String(appState.paymentReceiptCounter).padStart(4, '0');
    if (booking.balance <= amount) {
      booking.paymentReceiptNo = paymentReceiptNo;
    }
  }

  const newPayment = {
    id: 'pay-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
    type,
    receiptNo: paymentReceiptNo,
    amount,
    monthIndex,
    date: dateTime ? dateTime.split('T')[0] : formatLocalDate(new Date()),
    time: dateTime ? dateTime.split('T')[1] : '',
    dateTime: dateTime || new Date().toISOString(),
    bankName,
    referenceNo,
    receiptImage,
    receiptFileName,
    notes,
    createdAt: new Date().toISOString()
  };

  booking.payments = booking.payments || [];
  booking.payments.push(newPayment);

  // Record into booking.documents for Document History & audit tracking (B2)
  booking.documents = Array.isArray(booking.documents) ? booking.documents : [];
  booking.documents.push({
    id: `doc-pay-${newPayment.id}`,
    docType: type === 'deposit' ? 'deposit_receipt' : 'receipt',
    monthIndex: monthIndex || null,
    docNo: paymentReceiptNo,
    baseDocNo: paymentReceiptNo,
    revision: 0,
    status: 'issued',
    date: newPayment.date,
    amount: amount,
    issuedAt: newPayment.dateTime,
    replacesDocNo: null,
    replacedByDocNo: null,
    hasBeenPrintedOrDownloaded: false
  });

  const totalPaid = booking.payments.reduce((sum, p) => sum + (p.amount || 0), 0);
  booking.depositPaid = totalPaid;
  booking.balance = Math.max(0, booking.totalAmount - totalPaid);
  booking.lastPaymentRef = referenceNo;
  booking.lastPaymentBank = bankName;

  const oldStatus = booking.status;
  if (booking.balance <= 0 && booking.totalAmount > 0) {
    booking.status = 'confirmed';
  } else if (booking.depositPaid > 0 && booking.status === 'quotation') {
    booking.status = 'booked';
  }

  if (type === 'monthly_rent' && monthIndex) {
    const invoices = getOrInitMonthlyInvoices(booking);
    const targetInv = invoices.find(x => x.monthIndex === monthIndex);
    if (targetInv) {
      targetInv.status = 'paid';
      targetInv.paidAt = dateTime || new Date().toISOString();
      targetInv.referenceNo = referenceNo;
      targetInv.bankName = bankName;
      booking.monthlyInvoices = invoices;
    }
  }

  saveToStorage();
  closeAllModals();
  renderApp();

  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? `Resit bayaran ${formatCurrency(amount)} berjaya disimpan!` : `Payment receipt of ${formatCurrency(amount)} recorded successfully!`);

  if (oldStatus === 'quotation' && booking.status === 'booked') {
    openWhatsAppModal(booking, 'deposit_receipt');
  } else if (booking.status === 'confirmed' && oldStatus !== 'confirmed') {
    openWhatsAppModal(booking, 'full_receipt');
  } else if (type === 'monthly_rent' && monthIndex) {
    openWhatsAppModal(booking, 'monthly_rent_receipt', monthIndex);
  }
}

function openReceiptViewerModal(booking) {
  if (!booking) return;
  const prop = getPropertyById(booking.propertyId);
  const isBM = appState.settings.language === 'bm';

  document.getElementById('receiptViewerSubtitle').textContent = `${booking.guestName} (${booking.guestPhone || '-'}) • ${prop.name}`;

  const banner = document.getElementById('receiptViewerFinancialBanner');
  const totalPaid = (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0);
  const pctPaid = booking.totalAmount > 0 ? Math.min(100, Math.round((totalPaid / booking.totalAmount) * 100)) : 100;

  banner.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px;">
      <div>
        <span style="font-size:11px; font-weight:700; color:var(--text-muted); text-transform:uppercase;">${t('total')}: <strong>${formatCurrency(booking.totalAmount)}</strong></span>
        <div style="font-size:16px; font-weight:800; color:var(--success-text); margin-top:1px;">
          ${isBM ? 'Telah Dibayar' : 'Total Paid'}: ${formatCurrency(totalPaid)}
        </div>
      </div>
      <div style="text-align:right;">
        <span style="font-size:11px; font-weight:700; color:${booking.balance > 0 ? 'var(--danger)' : 'var(--success)'};">
          ${isBM ? 'Baki Bayaran' : 'Balance Due'}: <strong>${formatCurrency(booking.balance)}</strong>
        </span>
        <div style="font-size:11px; font-weight:800; color:var(--text-muted); margin-top:2px;">
          ${pctPaid}% ${isBM ? 'Selesai' : 'Settled'}
        </div>
      </div>
    </div>
    <div class="progress-bar-bg" style="margin-top:8px; margin-bottom:0; height:6px;">
      <div class="progress-bar-fill" style="width:${pctPaid}%;"></div>
    </div>
  `;

  const listContainer = document.getElementById('receiptViewerList');
  listContainer.innerHTML = '';

  const payments = booking.payments || [];
  if (payments.length === 0) {
    listContainer.innerHTML = `
      <div class="empty-hint" style="padding:28px 16px; text-align:center;">
        <i class="fa-solid fa-receipt" style="font-size:32px; color:var(--text-muted); opacity:0.4; margin-bottom:8px; display:block;"></i>
        <p style="font-size:14px; font-weight:700; color:var(--text-main); margin-bottom:4px;">
          ${t('no_receipts_recorded')}
        </p>
        <p style="font-size:12.5px; color:var(--text-muted); margin-bottom:14px;">
          ${isBM ? 'Tangkap resit atau rekod rujukan pindahan bank yang dikongsi oleh tetamu.' : 'Capture receipt screenshots and record bank transfer references shared by the guest.'}
        </p>
        <button type="button" class="btn btn-primary btn-sm" id="btnEmptyAddReceipt">
          <i class="fa-solid fa-plus"></i> ${t('add_payment_receipt')}
        </button>
      </div>
    `;
    const emptyBtn = document.getElementById('btnEmptyAddReceipt');
    if (emptyBtn) emptyBtn.addEventListener('click', () => {
      closeAllModals();
      openPaymentProofModal(booking);
    });
  } else {
    payments.forEach((p, idx) => {
      const card = document.createElement('div');
      card.className = `receipt-record-card type-${p.type || 'deposit'}`;

      let typeBadge = '';
      if (p.type === 'deposit') {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:#fef3c7; color:#92400e; padding:2px 8px; border-radius:999px;">🟡 ${isBM ? 'Deposit Tempahan' : 'Booking Deposit'}</span>`;
      } else if (p.type === 'balance') {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:#ecfdf5; color:#065f46; padding:2px 8px; border-radius:999px;">⚖️ ${isBM ? 'Baki Bayaran' : 'Balance Settlement'}</span>`;
      } else if (p.type === 'full') {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:#eff6ff; color:#1e40af; padding:2px 8px; border-radius:999px;">💎 ${isBM ? 'Bayaran Penuh' : 'Full Payment'}</span>`;
      } else if (p.type === 'monthly_rent') {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:#e0e7ff; color:#3730a3; padding:2px 8px; border-radius:999px;">📑 ${isBM ? `Sewa Bulan ke-${p.monthIndex || 1}` : `Month ${p.monthIndex || 1} Rent`}</span>`;
      } else if (p.type === 'security_deposit') {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:#f3e8ff; color:#6b21a8; padding:2px 8px; border-radius:999px;">🔒 ${isBM ? 'Deposit Keselamatan' : 'Security Deposit'}</span>`;
      } else {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:var(--bg-surface-subtle); color:var(--text-main); padding:2px 8px; border-radius:999px;">📦 ${p.type}</span>`;
      }
      if (p.receiptNo) {
        typeBadge += `<span style="font-family:monospace; font-weight:800; font-size:10.5px; color:#475569; margin-left:6px; background:#f1f5f9; padding:2px 6px; border-radius:4px;">${p.receiptNo}</span>`;
      }

      const formattedDate = p.dateTime ? p.dateTime.replace('T', ' ') : (p.date || '-');

      card.innerHTML = `
        <div class="receipt-record-header">
          <div>
            ${typeBadge}
            <span style="font-size:11px; color:var(--text-muted); margin-left:6px;"><i class="fa-regular fa-clock"></i> ${formattedDate}</span>
          </div>
          <strong style="font-size:15px; font-weight:800; color:var(--success-text);">
            ${formatCurrency(p.amount)}
          </strong>
        </div>

        <div class="receipt-record-body">
          ${p.receiptImage ? `
            <img src="${p.receiptImage}" alt="Receipt Slip" class="receipt-record-thumb" data-idx="${idx}" title="${isBM ? 'Tekan untuk lihat resit penuh' : 'Click to zoom slip'}">
          ` : `
            <div style="width:56px; height:56px; border-radius:6px; background:var(--bg-surface-subtle); border:1px dashed var(--border-color); display:flex; flex-direction:column; align-items:center; justify-content:center; color:var(--text-muted); font-size:10px; text-align:center; padding:2px;">
              <i class="fa-solid fa-file-circle-xmark" style="font-size:16px; margin-bottom:2px;"></i> No Slip
            </div>
          `}
          <div style="flex:1; min-width:0;">
            <div style="font-size:12.5px; font-weight:700; color:var(--text-main); display:flex; align-items:center; gap:6px;">
              <i class="fa-solid fa-building-columns" style="color:var(--primary);"></i> ${p.bankName || 'Bank Transfer'}
            </div>
            <div style="margin-top:3px;">
              <span class="receipt-ref-pill">
                <code>${p.referenceNo || '-'}</code>
                <button type="button" class="btn-copy-ref-pill" data-ref="${p.referenceNo || ''}" title="${isBM ? 'Salin No. Rujukan' : 'Copy Reference No'}" style="background:none; border:none; color:var(--primary); cursor:pointer; padding:0 2px;">
                  <i class="fa-solid fa-copy"></i>
                </button>
              </span>
            </div>
            ${p.notes ? `<p style="font-size:11.5px; color:var(--text-muted); margin:4px 0 0 0; font-style:italic;"><i class="fa-regular fa-note-sticky"></i> ${p.notes}</p>` : ''}
          </div>
        </div>

        <div class="receipt-actions-row">
          <button type="button" class="btn btn-outline btn-xs btn-open-payment-receipt" data-pid="${p.id}" data-type="${p.type || 'deposit'}" data-mid="${p.monthIndex || ''}" style="color:var(--primary); border-color:var(--primary);">
            <i class="fa-solid fa-file-invoice"></i> ${isBM ? 'Lihat Resit Rasmi' : 'Official Receipt'}
          </button>
          ${p.receiptImage ? `
            <button type="button" class="btn btn-outline btn-xs btn-view-full-slip" data-idx="${idx}">
              <i class="fa-solid fa-magnifying-glass-plus"></i> ${isBM ? 'Lihat Penuh' : 'View Slip'}
            </button>
            <button type="button" class="btn btn-outline btn-xs btn-download-slip" data-idx="${idx}">
              <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun' : 'Download'}
            </button>
          ` : ''}
          <button type="button" class="btn btn-outline btn-xs btn-delete-receipt-record" data-pid="${p.id}" data-bid="${booking.id}" style="color:var(--danger); border-color:var(--danger); margin-left:auto;">
            <i class="fa-solid fa-trash"></i> ${isBM ? 'Padam' : 'Delete'}
          </button>
        </div>
      `;

      listContainer.appendChild(card);
    });

    listContainer.querySelectorAll('.btn-open-payment-receipt').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pType = e.currentTarget.getAttribute('data-type');
        const pMid = e.currentTarget.getAttribute('data-mid');
        const pId = e.currentTarget.getAttribute('data-pid');
        closeAllModals();
        openPdfDocModal(booking, pType === 'deposit' ? 'deposit_receipt' : 'receipt', pMid ? parseInt(pMid) : null, pId);
      });
    });

    listContainer.querySelectorAll('.btn-copy-ref-pill').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const ref = e.currentTarget.getAttribute('data-ref');
        if (ref) {
          navigator.clipboard.writeText(ref).then(() => {
            showToast(t('ref_copied'));
          }).catch(() => {
            showToast(`Copied: ${ref}`);
          });
        }
      });
    });

    listContainer.querySelectorAll('.btn-view-full-slip, .receipt-record-thumb').forEach(el => {
      el.addEventListener('click', (e) => {
        const idx = parseInt(e.currentTarget.getAttribute('data-idx'));
        const p = payments[idx];
        if (p && p.receiptImage) {
          openReceiptLightbox(p.receiptImage, `${p.bankName} • ${p.referenceNo} (${formatCurrency(p.amount)})`);
        }
      });
    });

    listContainer.querySelectorAll('.btn-download-slip').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.currentTarget.getAttribute('data-idx'));
        const p = payments[idx];
        if (p && p.receiptImage) {
          const a = document.createElement('a');
          a.href = p.receiptImage;
          a.download = p.receiptFileName || `Receipt_${p.referenceNo || 'Payment'}.jpg`;
          document.body.appendChild(a);
          a.click();
          a.remove();
        }
      });
    });

    listContainer.querySelectorAll('.btn-delete-receipt-record').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pId = e.currentTarget.getAttribute('data-pid');
        const bId = e.currentTarget.getAttribute('data-bid');
        deletePaymentReceipt(bId, pId);
      });
    });
  }

  const addBtn = document.getElementById('btnAddReceiptFromViewer');
  if (addBtn) {
    addBtn.onclick = () => {
      closeAllModals();
      openPaymentProofModal(booking, booking.balance > 0 ? 'balance' : 'deposit');
    };
  }

  document.getElementById('receiptViewerModal').classList.add('active');
}

function openReceiptLightbox(imageUrl, title = 'Bank Receipt Proof') {
  const modal = document.getElementById('receiptLightboxModal');
  const img = document.getElementById('lightboxImage');
  const titleEl = document.getElementById('lightboxTitle');
  const downloadBtn = document.getElementById('btnDownloadLightboxImg');

  if (!modal || !img) return;

  img.src = imageUrl;
  if (titleEl) titleEl.textContent = title;

  if (downloadBtn) {
    downloadBtn.onclick = () => {
      const a = document.createElement('a');
      a.href = imageUrl;
      a.download = `Receipt_${formatLocalDate(new Date())}.jpg`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    };
  }

  modal.classList.add('active');
}

function deletePaymentReceipt(bookingId, paymentId) {
  const isBM = appState.settings.language === 'bm';
  if (!confirm(t('delete_receipt_confirm'))) return;

  const booking = appState.bookings.find(b => b.id === bookingId);
  if (!booking || !booking.payments) return;

  booking.payments = booking.payments.filter(p => p.id !== paymentId);

  const totalPaid = booking.payments.reduce((sum, p) => sum + (p.amount || 0), 0);
  booking.depositPaid = totalPaid;
  booking.balance = Math.max(0, booking.totalAmount - totalPaid);

  if (booking.payments.length > 0) {
    const lastP = booking.payments[booking.payments.length - 1];
    booking.lastPaymentRef = lastP.referenceNo;
    booking.lastPaymentBank = lastP.bankName;
  } else {
    booking.lastPaymentRef = null;
    booking.lastPaymentBank = null;
    if (booking.depositPaid === 0 && booking.status === 'booked') {
      booking.status = 'quotation';
    }
  }

  saveToStorage();
  renderApp();
  openReceiptViewerModal(booking);
  showToast(isBM ? 'Rekod resit telah dipadam.' : 'Payment receipt record deleted.');
}

// ==========================================================================
// 11E. PROMOTIONAL MEDIA & MARKETING HUB ENGINE
// ==========================================================================

function compressPromoMediaImage(file, maxWidth = 1000, maxHeight = 1000, quality = 0.8) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error('No file provided'));

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        const sizeBytes = Math.round((dataUrl.length * 3) / 4);
        resolve({
          dataUrl,
          sizeBytes,
          fileName: file.name
        });
      };
      img.onerror = (err) => reject(err);
      img.src = e.target.result;
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

function openPromotionalMediaModal(defaultPropertyId = null) {
  if (defaultPropertyId) {
    appState.selectedPromoPropertyId = defaultPropertyId;
  }
  
  // Populate property filter
  const propSelect = document.getElementById('promoPropertyFilter');
  if (propSelect) {
    const isBM = appState.settings.language === 'bm';
    let options = `<option value="all">${isBM ? 'Semua Homestay & Umum' : 'All Homestays & General'}</option>`;
    appState.properties.forEach(p => {
      options += `<option value="${p.id}">${escapeHtml(p.name)}</option>`;
    });
    propSelect.innerHTML = options;
    propSelect.value = appState.selectedPromoPropertyId || 'all';
  }

  // Set category pills active state
  const pills = document.querySelectorAll('#promoCategoryFilter .cal-mode-pill');
  pills.forEach(p => {
    if (p.getAttribute('data-category') === (appState.selectedPromoCategory || 'all')) {
      p.classList.add('active');
    } else {
      p.classList.remove('active');
    }
  });

  const searchInput = document.getElementById('promoSearchInput');
  if (searchInput) searchInput.value = appState.promoSearchQuery || '';

  renderPromotionalMediaList();
  document.getElementById('promotionalMediaModal').classList.add('active');
}

function renderPromotionalMediaList() {
  const container = document.getElementById('promoMediaGrid');
  const emptyState = document.getElementById('promoMediaEmptyState');
  if (!container) return;

  const isBM = appState.settings.language === 'bm';
  const filterProp = appState.selectedPromoPropertyId || 'all';
  const filterCat = appState.selectedPromoCategory || 'all';
  const query = (appState.promoSearchQuery || '').trim().toLowerCase();

  const filtered = appState.promotionalMedia.filter(item => {
    // Property match
    if (filterProp !== 'all' && item.propertyId !== 'all' && item.propertyId !== filterProp) {
      return false;
    }
    // Category match
    if (filterCat !== 'all' && item.category !== filterCat) {
      return false;
    }
    // Search query match
    if (query) {
      const prop = item.propertyId !== 'all' ? getPropertyById(item.propertyId) : null;
      const propName = prop ? prop.name.toLowerCase() : '';
      const title = (item.title || '').toLowerCase();
      const caption = (item.caption || '').toLowerCase();
      if (!title.includes(query) && !caption.includes(query) && !propName.includes(query)) {
        return false;
      }
    }
    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';

  let html = '';
  filtered.forEach(item => {
    const prop = item.propertyId !== 'all' ? getPropertyById(item.propertyId) : null;
    const propLabel = prop ? prop.name : (isBM ? 'Umum / Semua' : 'General / All');
    const propColor = prop ? prop.color : '#0284c7';

    // Category badge label
    let catLabel = 'Photo';
    let catIcon = 'fa-image';
    if (item.category === 'photo') {
      catLabel = isBM ? 'Foto' : 'Photo';
      catIcon = 'fa-image';
    } else if (item.category === 'poster') {
      catLabel = isBM ? 'Poster' : 'Poster';
      catIcon = 'fa-bullhorn';
    } else if (item.category === 'video_tour') {
      catLabel = isBM ? 'Video Tour' : 'Video Tour';
      catIcon = 'fa-video';
    } else if (item.category === 'copywriting') {
      catLabel = isBM ? 'Ayat Iklan' : 'Copywriting';
      catIcon = 'fa-pen-nib';
    }

    // Thumbnail area
    let thumbArea = '';
    if (item.imageData) {
      thumbArea = `
        <div class="promo-thumb-container" data-action="lightbox" data-id="${item.id}" title="${isBM ? 'Ketik untuk lihat saiz penuh' : 'Tap to view full-size'}">
          <img src="${item.imageData}" alt="${escapeHtml(item.title)}" class="promo-thumb-img" loading="lazy">
          <div class="promo-badge-overlay">
            <span class="promo-cat-badge cat-${item.category}"><i class="fa-solid ${catIcon}"></i> ${catLabel}</span>
            <span class="promo-prop-badge" style="border-left: 3px solid ${propColor};"><i class="fa-solid fa-house"></i> ${escapeHtml(propLabel)}</span>
          </div>
        </div>
      `;
    } else if (item.mediaUrl) {
      thumbArea = `
        <div class="promo-thumb-container" data-action="link" data-url="${escapeHtml(item.mediaUrl)}" style="background:linear-gradient(135deg, #1e293b, #0f172a);" title="${isBM ? 'Buka pautan' : 'Open external link'}">
          <div class="promo-thumb-placeholder" style="color:#38bdf8;">
            <i class="fa-solid ${item.category === 'video_tour' ? 'fa-circle-play' : 'fa-arrow-up-right-from-square'}" style="font-size:36px;"></i>
            <span style="font-size:11px; font-weight:700; color:#e2e8f0;">${isBM ? 'Pautan Video / Awan' : 'Video / Cloud Link'}</span>
          </div>
          <div class="promo-badge-overlay">
            <span class="promo-cat-badge cat-${item.category}"><i class="fa-solid ${catIcon}"></i> ${catLabel}</span>
            <span class="promo-prop-badge" style="border-left: 3px solid ${propColor};"><i class="fa-solid fa-house"></i> ${escapeHtml(propLabel)}</span>
          </div>
        </div>
      `;
    } else {
      thumbArea = `
        <div class="promo-thumb-container" style="background:linear-gradient(135deg, #f8fafc, #e2e8f0);">
          <div class="promo-thumb-placeholder" style="color:#d97706;">
            <i class="fa-solid fa-quote-left" style="font-size:32px; opacity:0.8;"></i>
            <span style="font-size:11px; font-weight:700; color:var(--text-muted);">${isBM ? 'Teks Iklan' : 'Marketing Pitch'}</span>
          </div>
          <div class="promo-badge-overlay">
            <span class="promo-cat-badge cat-${item.category}"><i class="fa-solid ${catIcon}"></i> ${catLabel}</span>
            <span class="promo-prop-badge" style="border-left: 3px solid ${propColor};"><i class="fa-solid fa-house"></i> ${escapeHtml(propLabel)}</span>
          </div>
        </div>
      `;
    }

    html += `
      <div class="promo-card" data-id="${item.id}">
        ${thumbArea}
        <div class="promo-card-body">
          <h4 class="promo-card-title">${escapeHtml(item.title)}</h4>
          <div class="promo-card-caption-preview">${escapeHtml(item.caption)}</div>
          
          <div class="promo-card-actions">
            <button type="button" class="btn btn-sm btn-promo-wa" data-action="wa" data-id="${item.id}" title="${isBM ? 'Hantar ke WhatsApp' : 'Send via WhatsApp'}">
              <i class="fa-brands fa-whatsapp"></i> <span>WhatsApp</span>
            </button>
            <button type="button" class="btn btn-sm btn-promo-share" data-action="native-share" data-id="${item.id}" title="${isBM ? 'Kongsi ke Apps' : 'Share to apps'}">
              <i class="fa-solid fa-share-nodes"></i>
            </button>
            <button type="button" class="btn btn-outline btn-xs" data-action="copy-pitch" data-id="${item.id}" title="${isBM ? 'Salin Ayat' : 'Copy Pitch'}">
              <i class="fa-solid fa-copy"></i>
            </button>
            ${item.mediaUrl ? `
              <button type="button" class="btn btn-outline btn-xs" data-action="copy-link" data-id="${item.id}" title="${isBM ? 'Salin Pautan' : 'Copy Link'}">
                <i class="fa-solid fa-link"></i>
              </button>
            ` : ''}
            <div style="margin-left:auto; display:flex; gap:2px;">
              <button type="button" class="promo-menu-btn" data-action="edit" data-id="${item.id}" title="${isBM ? 'Kemas Kini' : 'Edit'}">
                <i class="fa-solid fa-pen-to-square"></i>
              </button>
              <button type="button" class="promo-menu-btn" data-action="delete" data-id="${item.id}" title="${isBM ? 'Padam' : 'Delete'}">
                <i class="fa-solid fa-trash-can"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;

  // Attach card interaction listeners
  container.querySelectorAll('[data-action="lightbox"]').forEach(el => {
    el.addEventListener('click', () => {
      const id = el.getAttribute('data-id');
      openPromoLightbox(id);
    });
  });

  container.querySelectorAll('[data-action="link"]').forEach(el => {
    el.addEventListener('click', () => {
      const url = el.getAttribute('data-url');
      if (url) window.open(url, '_blank');
    });
  });

  container.querySelectorAll('[data-action="wa"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      openPromoWaQuickModal(id);
    });
  });

  container.querySelectorAll('[data-action="native-share"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      sharePromoMediaNative(id);
    });
  });

  container.querySelectorAll('[data-action="copy-pitch"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      copyPromoCaption(id);
    });
  });

  container.querySelectorAll('[data-action="copy-link"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      copyPromoLink(id);
    });
  });

  container.querySelectorAll('[data-action="edit"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      openPromoMediaEditModal(id);
    });
  });

  container.querySelectorAll('[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      deletePromoMediaItem(id);
    });
  });
}

function openPromoMediaEditModal(mediaId = null) {
  const isBM = appState.settings.language === 'bm';
  const modal = document.getElementById('promoMediaEditModal');
  const titleEl = document.getElementById('promoMediaEditTitle');
  const idInput = document.getElementById('promoMediaIdInput');
  const propSelect = document.getElementById('promoMediaPropertySelect');
  const catSelect = document.getElementById('promoMediaCategorySelect');
  const titleInput = document.getElementById('promoMediaTitleInput');
  const urlInput = document.getElementById('promoMediaUrlInput');
  const captionInput = document.getElementById('promoMediaCaptionInput');
  const imgDataInput = document.getElementById('promoMediaImageData');
  const fileInput = document.getElementById('promoMediaFileInput');
  const promptEl = document.getElementById('promoImageDropPrompt');
  const previewContainer = document.getElementById('promoImagePreviewContainer');
  const previewImg = document.getElementById('promoImagePreviewImg');
  const fileNameEl = document.getElementById('promoImageFileName');
  const fileSizeEl = document.getElementById('promoImageFileSize');

  // Populate property select
  let propOptions = `<option value="all">${isBM ? 'Umum / Semua Homestay' : 'General / All Homestays'}</option>`;
  appState.properties.forEach(p => {
    propOptions += `<option value="${p.id}">${escapeHtml(p.name)}</option>`;
  });
  propSelect.innerHTML = propOptions;

  fileInput.value = '';

  const existing = mediaId ? appState.promotionalMedia.find(m => m.id === mediaId) : null;
  if (existing) {
    if (titleEl) titleEl.textContent = isBM ? 'Kemaskini Media Promosi' : 'Edit Promotional Media';
    idInput.value = existing.id;
    propSelect.value = existing.propertyId || 'all';
    catSelect.value = existing.category || 'photo';
    titleInput.value = existing.title || '';
    urlInput.value = existing.mediaUrl || '';
    captionInput.value = existing.caption || '';
    imgDataInput.value = existing.imageData || '';

    if (existing.imageData) {
      previewImg.src = existing.imageData;
      fileNameEl.textContent = 'Current Image';
      const approxKb = Math.round((existing.imageData.length * 3) / 4096);
      fileSizeEl.textContent = `~${approxKb} KB`;
      promptEl.style.display = 'none';
      previewContainer.style.display = 'block';
    } else {
      promptEl.style.display = 'block';
      previewContainer.style.display = 'none';
    }
  } else {
    if (titleEl) titleEl.textContent = isBM ? 'Tambah Media Promosi' : 'Add Promotional Media';
    idInput.value = '';
    propSelect.value = appState.selectedPromoPropertyId !== 'all' ? appState.selectedPromoPropertyId : 'all';
    catSelect.value = appState.selectedPromoCategory !== 'all' ? appState.selectedPromoCategory : 'photo';
    titleInput.value = '';
    urlInput.value = '';
    captionInput.value = '';
    imgDataInput.value = '';
    promptEl.style.display = 'block';
    previewContainer.style.display = 'none';
  }

  modal.classList.add('active');
}

function handlePromoImageFileSelected(file) {
  if (!file) return;

  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Memampatkan gambar...' : 'Optimizing & compressing image...');

  compressPromoMediaImage(file, 1000, 1000, 0.8)
    .then(res => {
      document.getElementById('promoMediaImageData').value = res.dataUrl;
      document.getElementById('promoImagePreviewImg').src = res.dataUrl;
      document.getElementById('promoImageFileName').textContent = res.fileName;
      document.getElementById('promoImageFileSize').textContent = `${Math.round(res.sizeBytes / 1024)} KB (Compressed)`;
      document.getElementById('promoImageDropPrompt').style.display = 'none';
      document.getElementById('promoImagePreviewContainer').style.display = 'block';
      showToast(isBM ? 'Gambar sedia disimpan!' : 'Image optimized for storage!');
    })
    .catch(err => {
      console.error('Compression error:', err);
      alert(isBM ? 'Gagal memproses gambar.' : 'Failed to compress image.');
    });
}

function savePromoMediaItem(e) {
  e.preventDefault();

  const isBM = appState.settings.language === 'bm';
  const idInput = document.getElementById('promoMediaIdInput').value;
  const propertyId = document.getElementById('promoMediaPropertySelect').value;
  const category = document.getElementById('promoMediaCategorySelect').value;
  const title = document.getElementById('promoMediaTitleInput').value.trim();
  const mediaUrl = document.getElementById('promoMediaUrlInput').value.trim();
  const caption = document.getElementById('promoMediaCaptionInput').value.trim();
  const imageData = document.getElementById('promoMediaImageData').value;

  if (!title || !caption) {
    alert(isBM ? 'Sila isikan tajuk dan teks promosi.' : 'Please provide a title and promo copywriting text.');
    return;
  }

  const existingIndex = idInput ? appState.promotionalMedia.findIndex(m => m.id === idInput) : -1;
  const mediaObj = {
    id: idInput || `promo-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    propertyId,
    category,
    title,
    caption,
    mediaUrl,
    imageData,
    createdAt: existingIndex >= 0 ? (appState.promotionalMedia[existingIndex].createdAt || new Date().toISOString()) : new Date().toISOString()
  };

  if (existingIndex >= 0) {
    appState.promotionalMedia[existingIndex] = mediaObj;
  } else {
    appState.promotionalMedia.unshift(mediaObj);
  }

  saveToStorage();
  renderPromotionalMediaList();
  document.getElementById('promoMediaEditModal').classList.remove('active');
  showToast(isBM ? 'Media promosi berjaya disimpan!' : 'Promotional media asset saved!');
}

function deletePromoMediaItem(mediaId) {
  if (!confirm(t('delete_promo_confirm'))) return;

  appState.promotionalMedia = appState.promotionalMedia.filter(m => m.id !== mediaId);
  saveToStorage();
  renderPromotionalMediaList();
  showToast(appState.settings.language === 'bm' ? 'Media promosi telah dipadam.' : 'Promotional media deleted.');
}

function openPromoLightbox(mediaId) {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (item && item.imageData) {
    openReceiptLightbox(item.imageData, item.title);
  }
}

function copyPromoCaption(mediaId) {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item) return;

  let textToCopy = item.caption;
  if (item.mediaUrl && !textToCopy.includes(item.mediaUrl)) {
    textToCopy += `\n\n🔗 ${item.mediaUrl}`;
  }

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(textToCopy).then(() => {
      showToast(t('pitch_copied'));
    }).catch(() => {
      copyViaFallback(textToCopy, t('pitch_copied'));
    });
  } else {
    copyViaFallback(textToCopy, t('pitch_copied'));
  }
}

function copyPromoLink(mediaId) {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item || !item.mediaUrl) return;

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(item.mediaUrl).then(() => {
      showToast(t('link_copied'));
    }).catch(() => {
      copyViaFallback(item.mediaUrl, t('link_copied'));
    });
  } else {
    copyViaFallback(item.mediaUrl, t('link_copied'));
  }
}

function copyViaFallback(text, successMsg) {
  const ta = document.createElement('textarea');
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  document.execCommand('copy');
  document.body.removeChild(ta);
  showToast(successMsg);
}

function sharePromoMediaNative(mediaId) {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item) return;

  let shareText = item.caption;
  const shareUrl = item.mediaUrl || '';

  if (navigator.share) {
    navigator.share({
      title: item.title,
      text: shareText,
      url: shareUrl || undefined
    }).catch(err => {
      if (err.name !== 'AbortError') {
        openPromoWaQuickModal(mediaId);
      }
    });
  } else {
    openPromoWaQuickModal(mediaId);
  }
}

function openPromoWaQuickModal(mediaId, defaultPhone = '') {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item) return;

  const isBM = appState.settings.language === 'bm';
  document.getElementById('promoWaQuickMediaId').value = mediaId;

  // Populate recipients dropdown with recent bookings
  const recipientSelect = document.getElementById('promoWaRecipientSelect');
  const customPhoneGroup = document.getElementById('promoWaCustomPhoneGroup');
  const customPhoneInput = document.getElementById('promoWaCustomPhoneInput');

  let opts = `<option value="custom">${isBM ? '✏️ Masukkan / Pilih Nombor WhatsApp' : '✏️ Enter / Custom Phone Number'}</option>`;
  
  // Get unique recent guests with phone numbers
  const recentGuests = [];
  const seenPhones = new Set();

  appState.bookings.forEach(b => {
    if (b.guestPhone && !seenPhones.has(b.guestPhone)) {
      seenPhones.add(b.guestPhone);
      const prop = getPropertyById(b.propertyId);
      recentGuests.push({
        name: b.guestName,
        phone: b.guestPhone,
        property: prop ? prop.name : ''
      });
    }
  });

  recentGuests.slice(0, 8).forEach(g => {
    opts += `<option value="${escapeHtml(g.phone)}">👤 ${escapeHtml(g.name)} (${g.phone}) • ${escapeHtml(g.property)}</option>`;
  });

  recipientSelect.innerHTML = opts;

  if (defaultPhone) {
    recipientSelect.value = 'custom';
    customPhoneInput.value = defaultPhone;
    customPhoneGroup.style.display = 'block';
  } else if (recentGuests.length > 0) {
    recipientSelect.value = recentGuests[0].phone;
    customPhoneInput.value = recentGuests[0].phone;
    customPhoneGroup.style.display = 'none';
  } else {
    recipientSelect.value = 'custom';
    customPhoneInput.value = '';
    customPhoneGroup.style.display = 'block';
  }

  // Format message text
  let msg = item.caption;
  if (item.mediaUrl && !msg.includes(item.mediaUrl)) {
    msg += `\n\n🔗 ${item.mediaUrl}`;
  }

  document.getElementById('promoWaMessagePreview').textContent = msg;
  document.getElementById('promoWaQuickModal').classList.add('active');
}

function executePromoWaSend() {
  const isBM = appState.settings.language === 'bm';
  const mediaId = document.getElementById('promoWaQuickMediaId').value;
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item) return;

  const recipientSelect = document.getElementById('promoWaRecipientSelect');
  const customPhoneInput = document.getElementById('promoWaCustomPhoneInput');
  
  let rawPhone = recipientSelect.value === 'custom' ? customPhoneInput.value.trim() : recipientSelect.value;
  let cleanPhone = rawPhone.replace(/[^\d+]/g, '');
  if (cleanPhone.startsWith('0')) {
    cleanPhone = '60' + cleanPhone.slice(1);
  } else if (cleanPhone.startsWith('+')) {
    cleanPhone = cleanPhone.slice(1);
  }

  let text = item.caption;
  if (item.mediaUrl && !text.includes(item.mediaUrl)) {
    text += `\n\n🔗 ${item.mediaUrl}`;
  }

  const encoded = encodeURIComponent(text);
  let waUrl = '';
  if (cleanPhone && cleanPhone.length >= 8) {
    waUrl = `https://wa.me/${cleanPhone}?text=${encoded}`;
  } else {
    waUrl = `https://wa.me/?text=${encoded}`;
  }

  window.open(waUrl, '_blank');
  document.getElementById('promoWaQuickModal').classList.remove('active');
  showToast(isBM ? 'Membuka WhatsApp...' : 'Opening WhatsApp...');
}

function insertPromoPitchTemplate() {
  const isBM = appState.settings.language === 'bm';
  const cat = document.getElementById('promoMediaCategorySelect').value;
  const propId = document.getElementById('promoMediaPropertySelect').value;
  const prop = propId !== 'all' ? getPropertyById(propId) : null;
  const propName = prop ? prop.name : (isBM ? 'Homestay Eksklusif Kami' : 'Our Exclusive Homestay');
  const rate = prop ? (prop.defaultRate || 200) : 200;

  let template = '';
  if (cat === 'photo' || cat === 'poster') {
    if (isBM) {
      template = `✨ *${propName}* ✨\nPercutian selesa & mendamaikan untuk anda sekeluarga!\n\n🏡 *Kemudahan Lengkap:*\n• Bilik tidur luas & selesa berhawa dingin\n• Dapur lengkap memasak & ruang tamu selesa\n• WiFi laju & Smart TV\n• Lokasi strategik berdekatan tempat menarik\n\n💰 *Kadar dari:* RM ${rate} / malam\n📲 WhatsApp kami untuk semak kekosongan tarikh pilihan anda!`;
    } else {
      template = `✨ *${propName}* ✨\nThe perfect retreat for your relaxing getaway!\n\n🏡 *Key Amenities:*\n• Fully air-conditioned & sparkling clean\n• High-speed WiFi & Smart Entertainment\n• Equipped kitchen & dining area\n• Prime location near local attractions\n\n💰 *Rates from:* RM ${rate} / night\n📲 Message us now to reserve your dates!`;
    }
  } else if (cat === 'video_tour') {
    if (isBM) {
      template = `🎥 *Video Tour Maya: ${propName}*\nLihat sendiri suasana selesa unit kami sebelum anda menempah!\n\n👇 *Tonton Video di sini:*\nhttps://youtu.be/sample-tour\n\n💬 Hubungi kami segera untuk tempahan & tawaran istimewa!`;
    } else {
      template = `🎥 *Virtual Tour: ${propName}*\nTake an exclusive walkthrough inside our cozy unit!\n\n👇 *Watch the video here:*\nhttps://youtu.be/sample-tour\n\n💬 Send us a message today to secure your stay!`;
    }
  } else {
    if (isBM) {
      template = `🎉 *Tawaran Terhad: Diskaun Khas Homestay!* 🌟\nTempah awal untuk percutian seterusnya dan nikmati diskaun eksklusif.\n\n• Sesuai untuk keluarga & rakan\n• Suasana tenang & privasi terjamin\n• Tempah terus tanpa caj tersembunyi\n\n📲 Balas mesej ini dengan tarikh pilihan anda untuk dapatkan diskaun!`;
    } else {
      template = `🎉 *Limited-Time Special Offer!* 🌟\nBook your upcoming getaway early and enjoy exclusive rates.\n\n• Ideal for families & group getaways\n• Total comfort, cleanliness & privacy\n• Direct booking guaranteed best price\n\n📲 Reply to this message with your dates to lock in your discount!`;
    }
  }

  const captionInput = document.getElementById('promoMediaCaptionInput');
  if (captionInput) {
    captionInput.value = template;
    captionInput.focus();
  }
}

function attachPromoMediaToWaMessage() {
  const isBM = appState.settings.language === 'bm';
  if (!appState.activeWaBooking) return;

  const bPropId = appState.activeWaBooking.propertyId;
  const available = appState.promotionalMedia.filter(m => m.propertyId === 'all' || m.propertyId === bPropId);

  if (available.length === 0) {
    alert(isBM ? 'Tiada media promosi dijumpai bagi unit ini. Sila tambah media dalam Hab Media.' : 'No promo media found for this unit. Please add media in the Media Hub.');
    return;
  }

  // Pick the first relevant media item
  const chosen = available[0];
  let extraText = `\n\n📸 *${chosen.title}*:\n${chosen.caption}`;
  if (chosen.mediaUrl && !extraText.includes(chosen.mediaUrl)) {
    extraText += `\n🔗 ${chosen.mediaUrl}`;
  }

  const previewEl = document.getElementById('waMessagePreviewText');
  if (previewEl) {
    previewEl.textContent += extraText;
    showToast(isBM ? 'Media promosi disertakan!' : 'Promo media attached to message!');
  }
}

// ==========================================================================
// 12. PROPERTY MODAL LOGIC
// ==========================================================================

function openPropertyModal(existingProp = null) {
  const form = document.getElementById('propertyForm');
  form.reset();

  if (existingProp) {
    document.getElementById('propertyModalTitle').textContent = 'Edit Rental Unit / Homestay';
    document.getElementById('propertyIdInput').value = existingProp.id;
    document.getElementById('propertyNameInput').value = existingProp.name;
    document.getElementById('propertyRoomNoInput').value = existingProp.roomNo || '';
    document.getElementById('propertyTypeSelect').value = existingProp.propType || 'entire';
    document.getElementById('propertyAddressInput').value = existingProp.address || '';
    document.getElementById('propertyGpsInput').value = existingProp.gpsLocation || '';
    document.getElementById('propertyWifiNameInput').value = existingProp.wifiName || '';
    document.getElementById('propertyWifiPassInput').value = existingProp.wifiPass || '';
    document.getElementById('propertyDoorPinInput').value = existingProp.doorCode || '';
    document.getElementById('propertyDefaultRateInput').value = existingProp.defaultRate || 250;
    document.getElementById('propertyCleaningFeeInput').value = existingProp.cleaningFee || 50;
    document.getElementById('propertyCheckInTimeInput').value = existingProp.checkInTime || '15:00';
    document.getElementById('propertyCheckOutTimeInput').value = existingProp.checkOutTime || '12:00';
    document.getElementById('propertyRulesInput').value = existingProp.rules || '';
  } else {
    document.getElementById('propertyModalTitle').textContent = 'Add Rental Unit / Homestay';
    document.getElementById('propertyIdInput').value = '';
    document.getElementById('propertyRoomNoInput').value = '';
    document.getElementById('propertyTypeSelect').value = 'entire';
    document.getElementById('propertyAddressInput').value = '';
    document.getElementById('propertyGpsInput').value = '';
    document.getElementById('propertyDefaultRateInput').value = 250;
    document.getElementById('propertyCleaningFeeInput').value = 50;
  }

  document.getElementById('propertyModal').classList.add('active');
}

function handleSaveProperty(e) {
  e.preventDefault();

  const id = document.getElementById('propertyIdInput').value;
  const name = document.getElementById('propertyNameInput').value.trim();
  const roomNo = document.getElementById('propertyRoomNoInput') ? document.getElementById('propertyRoomNoInput').value.trim() : '';
  const propType = document.getElementById('propertyTypeSelect') ? document.getElementById('propertyTypeSelect').value : 'entire';
  const address = document.getElementById('propertyAddressInput').value.trim();
  const gpsLocation = document.getElementById('propertyGpsInput') ? document.getElementById('propertyGpsInput').value.trim() : '';
  const wifiName = document.getElementById('propertyWifiNameInput').value.trim();
  const wifiPass = document.getElementById('propertyWifiPassInput').value.trim();
  const doorCode = document.getElementById('propertyDoorPinInput').value.trim();
  const defaultRate = parseFloat(document.getElementById('propertyDefaultRateInput').value) || 250;
  const cleaningFee = parseFloat(document.getElementById('propertyCleaningFeeInput').value) || 50;
  const checkInTime = document.getElementById('propertyCheckInTimeInput').value || '15:00';
  const checkOutTime = document.getElementById('propertyCheckOutTimeInput').value || '12:00';
  const rules = document.getElementById('propertyRulesInput').value.trim();

  const colorRadio = document.querySelector('input[name="propColor"]:checked');
  const color = colorRadio ? colorRadio.value : '#0284c7';

  const propData = {
    id: id || `prop-${Date.now()}`,
    name,
    roomNo,
    propType,
    address,
    gpsLocation,
    wifiName,
    wifiPass,
    doorCode,
    color,
    defaultRate,
    cleaningFee,
    checkInTime,
    checkOutTime,
    rules
  };

  if (id) {
    const idx = appState.properties.findIndex(p => p.id === id);
    if (idx !== -1) appState.properties[idx] = { ...appState.properties[idx], ...propData };
  } else {
    appState.properties.push(propData);
  }

  saveToStorage();
  closeAllModals();
  renderApp();
  showToast(id ? 'Rental unit updated!' : 'New rental unit added!');
}

// ==========================================================================
// ==========================================================================
// 13. EXPENSE MODAL LOGIC
// ==========================================================================

function openExpenseModal(prefillData = null) {
  const form = document.getElementById('expenseForm');
  if (form && typeof form.reset === 'function') form.reset();

  const propSelect = document.getElementById('expensePropertySelect');
  if (propSelect) {
    propSelect.innerHTML = '';
    appState.properties.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name;
      propSelect.appendChild(opt);
    });
  }

  const receiptFileInput = document.getElementById('expenseReceiptFileInput');
  if (receiptFileInput) receiptFileInput.value = '';
  const receiptDataInput = document.getElementById('expenseReceiptImageData');
  if (receiptDataInput) receiptDataInput.value = '';
  const receiptNameInput = document.getElementById('expenseReceiptImageName');
  if (receiptNameInput) receiptNameInput.value = '';
  const uploadPrompt = document.getElementById('expenseReceiptUploadPrompt');
  if (uploadPrompt) uploadPrompt.style.display = 'block';
  const previewContainer = document.getElementById('expenseReceiptPreviewContainer');
  if (previewContainer) previewContainer.style.display = 'none';
  const ocrStatus = document.getElementById('expenseOcrStatusBadge');
  if (ocrStatus) ocrStatus.style.display = 'none';

  if (prefillData) {
    if (prefillData.propertyId && propSelect) propSelect.value = prefillData.propertyId;
    if (prefillData.amount) document.getElementById('expenseAmountInput').value = prefillData.amount;
    if (prefillData.date) document.getElementById('expenseDateInput').value = prefillData.date;
    if (prefillData.category) document.getElementById('expenseCategorySelect').value = prefillData.category;
    if (prefillData.description) document.getElementById('expenseDescInput').value = prefillData.description;
    if (prefillData.receiptImageData) {
      if (receiptDataInput) receiptDataInput.value = prefillData.receiptImageData;
      if (receiptNameInput) receiptNameInput.value = prefillData.receiptImageName || 'bill.jpg';
      const previewImg = document.getElementById('expenseReceiptPreviewImg');
      if (previewImg) previewImg.src = prefillData.receiptImageData;
      if (uploadPrompt) uploadPrompt.style.display = 'none';
      if (previewContainer) previewContainer.style.display = 'block';
    }
    if (prefillData.ocrNotice && ocrStatus) {
      ocrStatus.style.display = 'block';
      const ocrText = document.getElementById('expenseOcrStatusText');
      if (ocrText) ocrText.textContent = prefillData.ocrNotice;
    }
  } else {
    const dateInput = document.getElementById('expenseDateInput');
    if (dateInput) dateInput.value = formatLocalDate(new Date());
  }

  const modal = document.getElementById('expenseModal');
  if (modal) modal.classList.add('active');
}

function handleExpenseReceiptFileSelected(file) {
  if (!file) return;
  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Memampatkan salinan bil...' : 'Compressing bill slip...');

  compressReceiptImage(file, 900, 900, 0.78)
    .then(result => {
      document.getElementById('expenseReceiptImageData').value = result.dataUrl;
      document.getElementById('expenseReceiptImageName').value = result.fileName;

      const previewImg = document.getElementById('expenseReceiptPreviewImg');
      if (result.isPdf) {
        previewImg.src = 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Crect width=%22100%22 height=%22100%22 fill=%22%23ef4444%22/%3E%3Ctext x=%2250%22 y=%2255%22 font-size=%2218%22 font-weight=%22bold%22 text-anchor=%22middle%22 fill=%22%23ffffff%22%3EPDF%3C/text%3E%3C/svg%3E';
      } else {
        previewImg.src = result.dataUrl;
      }

      document.getElementById('expenseReceiptPreviewFileName').textContent = result.fileName;
      const sizeKb = Math.round(result.sizeBytes / 1024);
      document.getElementById('expenseReceiptPreviewSize').textContent = `${sizeKb} KB (Compressed)`;

      document.getElementById('expenseReceiptUploadPrompt').style.display = 'none';
      document.getElementById('expenseReceiptPreviewContainer').style.display = 'block';

      // Auto-scan the bill!
      scanExpenseSlipOcr(result.dataUrl);
    })
    .catch(err => {
      alert('Error reading bill file: ' + err.message);
    });
}

async function handleSaveExpense(e) {
  e.preventDefault();

  const propertyId = document.getElementById('expensePropertySelect').value;
  const amount = parseFloat(document.getElementById('expenseAmountInput').value) || 0;
  const date = document.getElementById('expenseDateInput').value;
  const category = document.getElementById('expenseCategorySelect').value;
  const description = document.getElementById('expenseDescInput').value.trim();

  const receiptImageData = document.getElementById('expenseReceiptImageData')?.value || null;
  const receiptImageName = document.getElementById('expenseReceiptImageName')?.value || null;

  const expId = `exp-${Date.now()}`;
  let receiptImageId = null;

  if (receiptImageData && receiptImageData.startsWith('data:image')) {
    receiptImageId = `img-exp-${expId}`;
    try {
      if (typeof saveImageToDB === 'function') {
        await saveImageToDB(receiptImageId, receiptImageData);
      }
    } catch (imgErr) {
      console.warn('Could not save expense image to IndexedDB:', imgErr);
    }
  }

  appState.expenses.push({
    id: expId,
    propertyId,
    amount,
    date,
    category,
    description: description || category.toUpperCase(),
    receiptImageId,
    receiptFileName: receiptImageName
  });

  saveToStorage();
  closeAllModals();
  if (appState.activeTab === 'finances') renderFinancesTab();
  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Perbelanjaan berjaya direkodkan!' : 'Expense logged successfully!');
}

// ==========================================================================
// 13B. MALAYSIAN OCR RECEIPT & UTILITY BILL SCANNER ENGINE
// ==========================================================================

let activeUniversalOcrResult = null;
let activeUniversalOcrImageData = null;

function preprocessReceiptImageForOCR(canvasOrImage) {
  try {
    const canvas = document.createElement('canvas');
    let width = canvasOrImage.width || canvasOrImage.videoWidth || 1200;
    let height = canvasOrImage.height || canvasOrImage.videoHeight || 1600;

    if (width > 1600) {
      height = Math.round((height * 1600) / width);
      width = 1600;
    } else if (width < 900 && width > 0) {
      height = Math.round((height * 1200) / width);
      width = 1200;
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(canvasOrImage, 0, 0, width, height);

    const imgData = ctx.getImageData(0, 0, width, height);
    const d = imgData.data;
    for (let i = 0; i < d.length; i += 4) {
      const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      const highContrast = gray > 140 ? Math.min(255, gray * 1.15) : Math.max(0, gray * 0.85);
      d[i] = highContrast;
      d[i + 1] = highContrast;
      d[i + 2] = highContrast;
    }
    ctx.putImageData(imgData, 0, 0);
    return canvas;
  } catch (e) {
    return canvasOrImage;
  }
}

function parseReceiptText(rawText) {
  if (!rawText || typeof rawText !== 'string') {
    return {
      documentType: 'unknown',
      confidence: 0,
      rawText: rawText || ''
    };
  }

  const text = rawText.trim();

  const result = {
    documentType: 'unknown', // 'bank_transfer' | 'utility_bill' | 'general_expense'
    bankName: null,
    amount: null,
    referenceNo: null,
    dateTime: null,
    dateOnly: null,
    timeOnly: null,
    accountNo: null,
    recipient: null,
    sender: null,
    billCategory: 'other', // 'utilities' | 'supplies' | 'maintenance' | 'cleaning' | 'other'
    suggestedDescription: '',
    confidence: 0,
    rawText: text
  };

  // 1. BANK / PAYMENT CHANNEL DETECTION
  const bankPatterns = [
    { name: 'Maybank', regex: /\b(maybank|mae\b|m2u\b|malayan banking)\b/i },
    { name: 'CIMB', regex: /\b(cimb|octo\b)\b/i },
    { name: 'Bank Islam', regex: /\b(bank islam|bimb\b)\b/i },
    { name: 'Public Bank', regex: /\b(public bank|pbe\b|pbebank)\b/i },
    { name: 'RHB', regex: /\b(rhb\b|rhb now)\b/i },
    { name: 'Hong Leong', regex: /\b(hong leong|hlb\b)\b/i },
    { name: 'AmBank', regex: /\b(ambank|amonline)\b/i },
    { name: 'Bank Muamalat', regex: /\b(muamalat)\b/i },
    { name: 'Agrobank', regex: /\b(agrobank|agro bank)\b/i },
    { name: 'Affin Bank', regex: /\b(affin|affinonline)\b/i },
    { name: 'Alliance Bank', regex: /\b(alliance bank)\b/i },
    { name: 'Touch \'n Go eWallet', regex: /\b(touch\s*['’]?n\s*go|tng\b|tng ewallet|tng digital)\b/i },
    { name: 'ShopeePay', regex: /\b(shopeepay|shopee pay)\b/i },
    { name: 'GrabPay', regex: /\b(grabpay|grab pay)\b/i },
    { name: 'DuitNow Transfer', regex: /\b(duitnow|duit now)\b/i }
  ];

  for (const b of bankPatterns) {
    if (b.regex.test(text)) {
      result.bankName = b.name;
      break;
    }
  }

  // 2. UTILITY & EXPENSE PROVIDER DETECTION
  const isTNB = /\b(tenaga nasional|tnb\b|bil elektrik|electricity bill)\b/i.test(text);
  const isWater = /\b(air selangor|syabas|pba\b|bekalan air|ranhill saj|saj\b|samb\b|sesb\b|laku\b|water bill|bil air)\b/i.test(text);
  const isSewerage = /\b(indah water|iwk\b|pembentungan)\b/i.test(text);
  const isTelecom = /\b(unifi|telekom malaysia|\btm\b|maxis|celcom|digi\b|celcomdigi|time dotcom|time internet|wifi bill|internet bill)\b/i.test(text);
  const isSupplies = /\b(mr\.?\s*d\.?i\.?y|lotus|mydin|econsave|99\s*speedmart|speedmart|supermarket|groceries|hardware|stationery)\b/i.test(text);
  const isMaintenance = /\b(aircond?|service|servis|repair|pembaikan|plumbing|paip|wiring|bocor|cat\b|tukang)\b/i.test(text);
  const isCleaning = /\b(cleaning|dobi|laundry|cucian|kemas|cleaner|sabun|detergent)\b/i.test(text);

  if (isTNB) {
    result.documentType = 'utility_bill';
    result.billCategory = 'utilities';
    result.suggestedDescription = 'TNB Electricity Bill';
  } else if (isWater) {
    result.documentType = 'utility_bill';
    result.billCategory = 'utilities';
    result.suggestedDescription = 'Water Utility Bill';
  } else if (isSewerage) {
    result.documentType = 'utility_bill';
    result.billCategory = 'utilities';
    result.suggestedDescription = 'Indah Water (IWK) Sewerage Bill';
  } else if (isTelecom) {
    result.documentType = 'utility_bill';
    result.billCategory = 'utilities';
    result.suggestedDescription = 'WiFi / Internet Bill';
  } else if (isSupplies) {
    result.documentType = 'general_expense';
    result.billCategory = 'supplies';
    result.suggestedDescription = 'Homestay Supplies & Amenities';
  } else if (isMaintenance) {
    result.documentType = 'general_expense';
    result.billCategory = 'maintenance';
    result.suggestedDescription = 'Maintenance & Repairs';
  } else if (isCleaning) {
    result.documentType = 'general_expense';
    result.billCategory = 'cleaning';
    result.suggestedDescription = 'Cleaning & Laundry';
  } else if (result.bankName || /\b(transfer|successful|berjaya|pindahan|bayaran|receipt|resit|reference|rujukan)\b/i.test(text)) {
    result.documentType = 'bank_transfer';
    if (!result.bankName && /\b(duitnow)\b/i.test(text)) {
      result.bankName = 'DuitNow Transfer';
    }
  }

  // 3. ACCOUNT NUMBER EXTRACTION (especially for utility bills)
  const accMatch = text.match(/(?:No\.?\s*Akaun|Account\s*(?:No\.?|Number|#)|No\s*Pelanggan|Bill\s*Acc(?:ount)?)\s*[:#=]?\s*([0-9\s-]{7,24})/i);
  if (accMatch) {
    const cleanAcc = accMatch[1].replace(/[\s-]/g, '');
    if (cleanAcc.length >= 7) {
      result.accountNo = cleanAcc;
      if (result.suggestedDescription && !result.suggestedDescription.includes('Acc:')) {
        result.suggestedDescription += ` (Acc: ${cleanAcc})`;
      }
    }
  }

  // 4. REFERENCE / TRANSACTION ID EXTRACTION
  const refMatches = [
    /(?:Reference\s*(?:ID|No\.?|Number|#)?|Rujukan(?:\s*(?:Transaksi|Ref))?|Ref(?:\s*(?:No\.?|ID|#))?|Transaction\s*(?:ID|No\.?|Ref|Number)|Trans\s*ID)\s*[:#=]?\s*([A-Za-z0-9_-]{6,35})/i,
    /(?:DuitNow\s*(?:Ref|Reference|ID)?)\s*[:#=]?\s*([A-Za-z0-9_-]{6,35})/i,
    /\b(20[2-3][0-9]{11,18})\b/
  ];

  for (const rx of refMatches) {
    const match = text.match(rx);
    if (match && match[1]) {
      const val = match[1].trim();
      if (!/^(successful|berjaya|failed|gagal|pending|amount|total|tarikh|date)$/i.test(val)) {
        result.referenceNo = val;
        break;
      }
    }
  }

  // 5. AMOUNT DETECTION
  const amountPatterns = [
    /(?:Jumlah\s*(?:Perlu\s*Dibayar|Kena\s*Dibayar|Bayaran|Bersih|Keseluruhan|Pindahan)?|Total\s*(?:Amount\s*Due|Due|Paid|Amount)?|Amount(?:\s*Paid)?|Amaun)\s*[:=]?\s*(?:RM|MYR)?\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})|[0-9]+(?:\.[0-9]{2}))/i,
    /(?:RM|MYR)\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})|[0-9]+(?:\.[0-9]{2}))/i,
    /(?:Total|Jumlah|Amount)\s*[:=]?\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})|[0-9]+(?:\.[0-9]{2}))/i
  ];

  for (const rx of amountPatterns) {
    const match = text.match(rx);
    if (match && match[1]) {
      const cleanNum = parseFloat(match[1].replace(/,/g, ''));
      if (!isNaN(cleanNum) && cleanNum > 0 && cleanNum < 1000000) {
        result.amount = cleanNum;
        break;
      }
    }
  }

  // 6. DATE & TIME EXTRACTION
  let detectedDate = null;
  let detectedTime = null;

  const monNames = {
    jan: '01', januari: '01', january: '01',
    feb: '02', februari: '02', february: '02',
    mar: '03', mac: '03', march: '03',
    apr: '04', april: '04',
    may: '05', mei: '05',
    jun: '06', june: '06',
    jul: '07', july: '07', julai: '07',
    aug: '08', ogos: '08', august: '08',
    sep: '09', sept: '09', september: '09',
    oct: '10', okt: '10', oktober: '10', october: '10',
    nov: '11', november: '11',
    dec: '12', dis: '12', disember: '12', december: '12'
  };

  const textDateMatch = text.match(/\b([0-3]?[0-9])\s+([A-Za-z]{3,9})\s+(20[2-3][0-9])\b/);
  if (textDateMatch) {
    const d = textDateMatch[1].padStart(2, '0');
    const mStr = textDateMatch[2].toLowerCase();
    const y = textDateMatch[3];
    const m = monNames[mStr];
    if (m) {
      detectedDate = `${y}-${m}-${d}`;
    }
  }

  if (!detectedDate) {
    const numDateMatch = text.match(/\b([0-3]?[0-9])[\/\-]([0-1]?[0-9])[\/\-](20[2-3][0-9])\b/);
    if (numDateMatch) {
      const d = numDateMatch[1].padStart(2, '0');
      const m = numDateMatch[2].padStart(2, '0');
      const y = numDateMatch[3];
      detectedDate = `${y}-${m}-${d}`;
    }
  }

  if (!detectedDate) {
    const isoDateMatch = text.match(/\b(20[2-3][0-9])-([0-1][0-9])-([0-3][0-9])\b/);
    if (isoDateMatch) {
      detectedDate = `${isoDateMatch[1]}-${isoDateMatch[2]}-${isoDateMatch[3]}`;
    }
  }

  const timeMatch = text.match(/\b([0-2]?[0-9]):([0-5][0-9])(?::([0-5][0-9]))?\s*(am|pm|p\.m\.|a\.m\.)?\b/i);
  if (timeMatch) {
    let hh = parseInt(timeMatch[1], 10);
    const mm = timeMatch[2];
    const meridiem = timeMatch[4] ? timeMatch[4].toLowerCase().replace(/\./g, '') : null;
    if (meridiem === 'pm' && hh < 12) hh += 12;
    if (meridiem === 'am' && hh === 12) hh = 0;
    detectedTime = `${String(hh).padStart(2, '0')}:${mm}`;
  }

  if (detectedDate) {
    result.dateOnly = detectedDate;
    result.timeOnly = detectedTime || '12:00';
    result.dateTime = `${detectedDate}T${result.timeOnly}`;
  } else {
    const today = new Date();
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');
    const hh = String(today.getHours()).padStart(2, '0');
    const mm = String(today.getMinutes()).padStart(2, '0');
    result.dateOnly = `${y}-${m}-${d}`;
    result.timeOnly = `${hh}:${mm}`;
    result.dateTime = `${y}-${m}-${d}T${hh}:${mm}`;
  }

  // 7. RECIPIENT & SENDER DETECTION
  const recipMatch = text.match(/(?:To|Penerima|Recipient|Paid\s*to|Beneficiary)\s*[:=]?\s*([A-Za-z0-9\s&.,'’-]{3,40})/i);
  if (recipMatch) {
    result.recipient = recipMatch[1].trim().replace(/\n.*$/, '');
  }

  const senderMatch = text.match(/(?:From|Daripada|Sender|Penyumbang)\s*[:=]?\s*([A-Za-z0-9\s&.,'’-]{3,40})/i);
  if (senderMatch) {
    result.sender = senderMatch[1].trim().replace(/\n.*$/, '');
  }

  // 8. CONFIDENCE SCORE CALCULATION
  let score = 0;
  if (result.amount !== null) score += 40;
  if (result.referenceNo !== null) score += 25;
  if (result.bankName !== null) score += 20;
  if (result.documentType === 'utility_bill') score += 25;
  if (detectedDate !== null) score += 15;
  result.confidence = Math.min(100, score);

  return result;
}

async function extractTextFromImage(fileOrDataUrl, options = {}) {
  let dataUrl = typeof fileOrDataUrl === 'string' ? fileOrDataUrl : null;
  if (!dataUrl && fileOrDataUrl && typeof FileReader !== 'undefined') {
    dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsDataURL(fileOrDataUrl);
    });
  }

  const apiKey = appState.settings.geminiApiKey;
  const preferredEngine = appState.settings.ocrEngine || 'auto';

  // 1. Google Gemini 1.5 Flash Vision (if key configured and online)
  if (apiKey && preferredEngine !== 'tesseract' && typeof fetch !== 'undefined') {
    try {
      const base64Data = dataUrl ? dataUrl.replace(/^data:image\/[a-zA-Z]+;base64,/, '') : '';
      if (base64Data) {
        const prompt = `You are an expert Malaysian receipt and bill scanner. Analyze this document.
Extract:
1. documentType ('bank_transfer' | 'utility_bill' | 'general_expense')
2. bankName (e.g. Maybank, CIMB, Bank Islam, Public Bank, RHB, Touch 'n Go eWallet, DuitNow)
3. amount (number in RM, e.g. 350.00)
4. referenceNo (transaction ref or DuitNow ID)
5. dateTime (YYYY-MM-DDTHH:mm)
6. accountNo (for utility bills like TNB, Air Selangor, Indah Water)
7. billCategory ('utilities' | 'supplies' | 'maintenance' | 'cleaning' | 'other')
8. suggestedDescription (e.g. 'TNB Electricity Bill', 'Air Selangor Water Bill')
Return ONLY a valid JSON object matching these keys.`;

        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              parts: [
                { text: prompt },
                { inlineData: { mimeType: 'image/jpeg', data: base64Data } }
              ]
            }]
          })
        });

        if (response.ok) {
          const resJson = await response.json();
          const candidate = resJson.candidates?.[0]?.content?.parts?.[0]?.text;
          if (candidate) {
            const cleanJsonStr = candidate.replace(/```json/g, '').replace(/```/g, '').trim();
            const parsedAi = JSON.parse(cleanJsonStr);
            if (parsedAi && (parsedAi.amount || parsedAi.bankName || parsedAi.referenceNo)) {
              return {
                documentType: parsedAi.documentType || 'bank_transfer',
                bankName: parsedAi.bankName || null,
                amount: parseFloat(parsedAi.amount) || null,
                referenceNo: parsedAi.referenceNo || null,
                dateTime: parsedAi.dateTime || formatLocalDate(new Date()) + 'T12:00',
                dateOnly: parsedAi.dateTime ? parsedAi.dateTime.split('T')[0] : formatLocalDate(new Date()),
                timeOnly: parsedAi.dateTime ? parsedAi.dateTime.split('T')[1] : '12:00',
                accountNo: parsedAi.accountNo || null,
                billCategory: parsedAi.billCategory || 'utilities',
                suggestedDescription: parsedAi.suggestedDescription || 'AI Scanned Document',
                confidence: 98,
                rawText: candidate
              };
            }
          }
        }
      }
    } catch (aiErr) {
      console.warn('[OCR Engine] Gemini Vision notice, falling back to local OCR:', aiErr);
    }
  }

  // 2. Native Web Shape Detection API (window.TextDetector)
  if (typeof window !== 'undefined' && 'TextDetector' in window && dataUrl) {
    try {
      const img = new Image();
      await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = dataUrl; });
      const processedCanvas = preprocessReceiptImageForOCR(img);
      const detector = new window.TextDetector();
      const detected = await detector.detect(processedCanvas);
      if (detected && detected.length > 0) {
        const rawText = detected.map(b => b.rawValue).join('\n');
        return parseReceiptText(rawText);
      }
    } catch (tdErr) {
      console.warn('[OCR Engine] Native TextDetector notice:', tdErr);
    }
  }

  // 3. Tesseract.js (On-Device WebAssembly)
  if (typeof window !== 'undefined' && dataUrl) {
    try {
      if (!window.Tesseract && typeof document !== 'undefined') {
        await new Promise((resolve, reject) => {
          const script = document.createElement('script');
          script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
          script.onload = resolve;
          script.onerror = () => resolve(false);
          document.head.appendChild(script);
        });
      }

      if (window.Tesseract) {
        const img = new Image();
        await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = dataUrl; });
        const processedCanvas = preprocessReceiptImageForOCR(img);
        const { data } = await window.Tesseract.recognize(processedCanvas, 'eng');
        if (data && data.text) {
          return parseReceiptText(data.text);
        }
      }
    } catch (tessErr) {
      console.warn('[OCR Engine] Tesseract recognition notice:', tessErr);
    }
  }

  return parseReceiptText(typeof fileOrDataUrl === 'string' && !fileOrDataUrl.startsWith('data:') ? fileOrDataUrl : '');
}

async function scanPaymentProofSlipOcr(dataUrl = null) {
  const isBM = appState.settings.language === 'bm';
  const imgData = dataUrl || document.getElementById('paymentProofImageData')?.value;
  if (!imgData) {
    alert(isBM ? 'Sila muat naik atau tangkap gambar resit terlebih dahulu.' : 'Please upload or capture a receipt slip first.');
    return;
  }

  const badge = document.getElementById('paymentProofOcrStatusBadge');
  const badgeText = document.getElementById('paymentProofOcrStatusText');
  if (badge && badgeText) {
    badge.style.display = 'block';
    badge.style.background = 'rgba(2, 132, 199, 0.1)';
    badge.style.color = 'var(--primary)';
    badge.style.borderColor = 'var(--primary)';
    badgeText.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> ${isBM ? 'Menganalisis resit dengan OCR...' : 'Scanning slip with OCR...'}`;
  }

  try {
    const ocrResult = await extractTextFromImage(imgData);
    if (!ocrResult || (!ocrResult.amount && !ocrResult.referenceNo && !ocrResult.bankName)) {
      if (badge && badgeText) {
        badge.style.display = 'block';
        badge.style.background = 'rgba(245, 158, 11, 0.1)';
        badge.style.color = '#b45309';
        badge.style.borderColor = '#f59e0b';
        badgeText.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${isBM ? 'OCR: Sesetengah butiran tidak jelas. Sila sahkan manual.' : 'OCR: Text unclear. Please verify fields manually.'}`;
      }
      return;
    }

    if (ocrResult.amount && ocrResult.amount > 0) {
      document.getElementById('paymentProofAmountInput').value = ocrResult.amount;
    }
    if (ocrResult.referenceNo) {
      document.getElementById('paymentProofRefInput').value = ocrResult.referenceNo;
    }
    if (ocrResult.bankName) {
      document.getElementById('paymentProofBankInput').value = ocrResult.bankName;
      document.querySelectorAll('#paymentProofBankPills .bank-pill').forEach(pill => {
        pill.classList.toggle('active', pill.getAttribute('data-bank').toLowerCase() === ocrResult.bankName.toLowerCase());
      });
    }
    if (ocrResult.dateTime) {
      document.getElementById('paymentProofDateTimeInput').value = ocrResult.dateTime;
    }

    if (badge && badgeText) {
      badge.style.display = 'block';
      badge.style.background = 'rgba(16, 185, 129, 0.1)';
      badge.style.color = '#059669';
      badge.style.borderColor = '#10b981';
      const summaryParts = [];
      if (ocrResult.bankName) summaryParts.push(ocrResult.bankName);
      if (ocrResult.amount) summaryParts.push(`RM ${ocrResult.amount.toFixed(2)}`);
      if (ocrResult.referenceNo) summaryParts.push(`Ref: ${ocrResult.referenceNo}`);
      badgeText.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${isBM ? 'Auto-isi berjaya' : 'Auto-filled'}: ${summaryParts.join(' • ')}`;
    }

    showToast(isBM ? '✨ Resit berjaya diimbas & diisi automatik!' : '✨ Receipt scanned & auto-filled!');
  } catch (err) {
    console.warn('OCR Scan notice:', err);
    if (badge && badgeText) {
      badge.style.display = 'block';
      badge.style.background = 'rgba(239, 68, 68, 0.1)';
      badge.style.color = 'var(--danger)';
      badge.style.borderColor = 'var(--danger)';
      badgeText.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> OCR: ${err.message || 'Scan error'}`;
    }
  }
}

async function scanExpenseSlipOcr(dataUrl = null) {
  const isBM = appState.settings.language === 'bm';
  const imgData = dataUrl || document.getElementById('expenseReceiptImageData')?.value;
  if (!imgData) {
    alert(isBM ? 'Sila muat naik atau tangkap gambar bil terlebih dahulu.' : 'Please upload or capture a bill first.');
    return;
  }

  const badge = document.getElementById('expenseOcrStatusBadge');
  const badgeText = document.getElementById('expenseOcrStatusText');
  if (badge && badgeText) {
    badge.style.display = 'block';
    badge.style.background = 'rgba(2, 132, 199, 0.1)';
    badge.style.color = 'var(--primary)';
    badge.style.borderColor = 'var(--primary)';
    badgeText.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> ${isBM ? 'Menganalisis bil dengan OCR...' : 'Scanning bill with OCR...'}`;
  }

  try {
    const ocrResult = await extractTextFromImage(imgData);
    if (!ocrResult || (!ocrResult.amount && !ocrResult.billCategory)) {
      if (badge && badgeText) {
        badge.style.display = 'block';
        badge.style.background = 'rgba(245, 158, 11, 0.1)';
        badge.style.color = '#b45309';
        badge.style.borderColor = '#f59e0b';
        badgeText.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${isBM ? 'OCR: Maklumat bil tidak jelas. Sila isi manual.' : 'OCR: Bill unclear. Please enter manually.'}`;
      }
      return;
    }

    if (ocrResult.amount && ocrResult.amount > 0) {
      document.getElementById('expenseAmountInput').value = ocrResult.amount;
    }
    if (ocrResult.dateOnly) {
      document.getElementById('expenseDateInput').value = ocrResult.dateOnly;
    }
    if (ocrResult.billCategory) {
      document.getElementById('expenseCategorySelect').value = ocrResult.billCategory;
    }
    if (ocrResult.suggestedDescription) {
      document.getElementById('expenseDescInput').value = ocrResult.suggestedDescription;
    }

    if (badge && badgeText) {
      badge.style.display = 'block';
      badge.style.background = 'rgba(16, 185, 129, 0.1)';
      badge.style.color = '#059669';
      badge.style.borderColor = '#10b981';
      const summaryParts = [];
      if (ocrResult.suggestedDescription) summaryParts.push(ocrResult.suggestedDescription);
      if (ocrResult.amount) summaryParts.push(`RM ${ocrResult.amount.toFixed(2)}`);
      badgeText.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${isBM ? 'Auto-isi bil berjaya' : 'Auto-filled'}: ${summaryParts.join(' • ')}`;
    }

    showToast(isBM ? '✨ Bil berjaya diimbas & diisi!' : '✨ Bill scanned & auto-filled!');
  } catch (err) {
    console.warn('OCR Expense Notice:', err);
    if (badge && badgeText) {
      badge.style.display = 'block';
      badge.style.background = 'rgba(239, 68, 68, 0.1)';
      badge.style.color = 'var(--danger)';
      badge.style.borderColor = 'var(--danger)';
      badgeText.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> OCR: ${err.message || 'Scan error'}`;
    }
  }
}

function openUniversalOcrModal(preselectedBooking = null, preselectedProperty = null) {
  closeAllModals();
  activeUniversalOcrResult = null;
  activeUniversalOcrImageData = null;

  const modal = document.getElementById('universalOcrModal');
  if (!modal) return;

  const fileInput = document.getElementById('universalOcrFileInput');
  if (fileInput) fileInput.value = '';
  const textInput = document.getElementById('universalOcrTextInput');
  if (textInput) textInput.value = '';

  const dropzone = document.getElementById('universalOcrDropzone');
  if (dropzone) dropzone.style.display = 'block';
  const preview = document.getElementById('universalOcrPreviewContainer');
  if (preview) preview.style.display = 'none';
  const resultCard = document.getElementById('universalOcrResultCard');
  if (resultCard) resultCard.style.display = 'none';
  const progBar = document.getElementById('universalOcrProgressBar');
  if (progBar) progBar.style.display = 'none';

  const bSelect = document.getElementById('universalOcrBookingSelect');
  if (bSelect) {
    bSelect.innerHTML = '';
    const activeBookings = [...appState.bookings]
      .filter(b => b.status !== 'cancelled')
      .sort((a, b) => new Date(b.checkIn) - new Date(a.checkIn));

    activeBookings.forEach(b => {
      const p = getPropertyById(b.propertyId);
      const opt = document.createElement('option');
      opt.value = b.id;
      opt.textContent = `${b.guestName} (${p ? p.name : '-'}) • ${b.checkIn}`;
      if (preselectedBooking && b.id === preselectedBooking.id) opt.selected = true;
      bSelect.appendChild(opt);
    });
  }

  const pSelect = document.getElementById('universalOcrPropertySelect');
  if (pSelect) {
    pSelect.innerHTML = '';
    appState.properties.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name;
      if (preselectedProperty && p.id === preselectedProperty.id) opt.selected = true;
      pSelect.appendChild(opt);
    });
  }

  switchUniversalOcrTab('camera');
  modal.classList.add('active');
}

function closeUniversalOcrModal() {
  const modal = document.getElementById('universalOcrModal');
  if (modal) modal.classList.remove('active');
}

function switchUniversalOcrTab(tabName) {
  document.querySelectorAll('.ocr-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
  });
  const cameraPane = document.getElementById('ocrCameraPane');
  const pastePane = document.getElementById('ocrPastePane');
  if (cameraPane) cameraPane.style.display = tabName === 'camera' ? 'block' : 'none';
  if (pastePane) pastePane.style.display = tabName === 'paste' ? 'block' : 'none';
}

function handleUniversalOcrFileSelected(file) {
  if (!file) return;
  const isBM = appState.settings.language === 'bm';

  const prog = document.getElementById('universalOcrProgressBar');
  const progText = document.getElementById('universalOcrProgressText');
  if (prog) prog.style.display = 'block';
  if (progText) progText.textContent = isBM ? 'Memampatkan gambar...' : 'Compressing image...';

  compressReceiptImage(file, 900, 900, 0.78)
    .then(async (result) => {
      activeUniversalOcrImageData = result.dataUrl;

      const dropzone = document.getElementById('universalOcrDropzone');
      if (dropzone) dropzone.style.display = 'none';
      const previewCard = document.getElementById('universalOcrPreviewContainer');
      if (previewCard) previewCard.style.display = 'block';
      const prevImg = document.getElementById('universalOcrPreviewImg');
      if (prevImg) prevImg.src = result.dataUrl;
      const prevName = document.getElementById('universalOcrPreviewFileName');
      if (prevName) prevName.textContent = result.fileName;

      if (progText) progText.textContent = isBM ? 'Mengekstrak teks dengan OCR...' : 'Extracting text with OCR...';

      const parsed = await extractTextFromImage(result.dataUrl);
      if (prog) prog.style.display = 'none';
      displayUniversalOcrResult(parsed);
    })
    .catch(err => {
      if (prog) prog.style.display = 'none';
      alert('Error reading receipt file: ' + err.message);
    });
}

function handleUniversalOcrTextParse() {
  const text = document.getElementById('universalOcrTextInput')?.value?.trim();
  const isBM = appState.settings.language === 'bm';
  if (!text) {
    alert(isBM ? 'Sila tampal teks mesej resit WhatsApp terlebih dahulu.' : 'Please paste the WhatsApp receipt text first.');
    return;
  }

  const parsed = parseReceiptText(text);
  displayUniversalOcrResult(parsed);
}

function displayUniversalOcrResult(res) {
  if (!res) return;
  activeUniversalOcrResult = res;
  const isBM = appState.settings.language === 'bm';

  const card = document.getElementById('universalOcrResultCard');
  if (!card) return;
  card.style.display = 'block';

  const badgeEl = document.getElementById('universalOcrTypeBadge');
  if (badgeEl) {
    if (res.documentType === 'bank_transfer') {
      badgeEl.textContent = isBM ? '💳 Resit Pindahan Bank' : '💳 Bank Transfer Slip';
      badgeEl.style.background = 'rgba(16, 185, 129, 0.15)';
      badgeEl.style.color = '#059669';
      badgeEl.style.borderColor = '#10b981';
    } else if (res.documentType === 'utility_bill') {
      badgeEl.textContent = isBM ? '⚡ Bil Utiliti (Elektrik / Air / WiFi)' : '⚡ Utility Bill (Electric / Water / WiFi)';
      badgeEl.style.background = 'rgba(245, 158, 11, 0.15)';
      badgeEl.style.color = '#b45309';
      badgeEl.style.borderColor = '#f59e0b';
    } else {
      badgeEl.textContent = isBM ? '🧾 Resit Perbelanjaan Homestay' : '🧾 Homestay Expense Receipt';
      badgeEl.style.background = 'rgba(139, 92, 246, 0.15)';
      badgeEl.style.color = '#6d28d9';
      badgeEl.style.borderColor = '#8b5cf6';
    }
  }

  const amtInput = document.getElementById('universalOcrAmountInput');
  if (amtInput) amtInput.value = res.amount || '';
  const bankInput = document.getElementById('universalOcrBankInput');
  if (bankInput) bankInput.value = res.bankName || (res.documentType === 'bank_transfer' ? 'Maybank' : '');
  const refInput = document.getElementById('universalOcrRefInput');
  if (refInput) refInput.value = res.referenceNo || res.accountNo || '';
  const dateInput = document.getElementById('universalOcrDateInput');
  if (dateInput) dateInput.value = res.dateTime || formatLocalDate(new Date()) + 'T12:00';

  const bookingSec = document.getElementById('universalOcrBookingSection');
  const expenseSec = document.getElementById('universalOcrExpenseSection');
  const applyBtn = document.getElementById('btnApplyUniversalOcr');

  if (res.documentType === 'bank_transfer') {
    if (bookingSec) bookingSec.style.display = 'block';
    if (expenseSec) expenseSec.style.display = 'none';
    if (applyBtn) applyBtn.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${isBM ? 'Rekod ke Bayaran Tempahan' : 'Save to Booking Payment'}`;
  } else {
    if (bookingSec) bookingSec.style.display = 'none';
    if (expenseSec) expenseSec.style.display = 'block';
    const catSelect = document.getElementById('universalOcrCategorySelect');
    if (catSelect && res.billCategory) {
      catSelect.value = res.billCategory;
    }
    const descInput = document.getElementById('universalOcrDescInput');
    if (descInput) descInput.value = res.suggestedDescription || '';
    if (applyBtn) applyBtn.innerHTML = `<i class="fa-solid fa-receipt"></i> ${isBM ? 'Rekod sebagai Perbelanjaan' : 'Log as Homestay Expense'}`;
  }

  card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function handleApplyUniversalOcr() {
  if (!activeUniversalOcrResult) return;
  const isBM = appState.settings.language === 'bm';

  const amount = parseFloat(document.getElementById('universalOcrAmountInput')?.value) || activeUniversalOcrResult.amount || 0;
  const bankName = document.getElementById('universalOcrBankInput')?.value?.trim() || activeUniversalOcrResult.bankName || 'Bank Transfer';
  const refNo = document.getElementById('universalOcrRefInput')?.value?.trim() || activeUniversalOcrResult.referenceNo || '';
  const dt = document.getElementById('universalOcrDateInput')?.value || activeUniversalOcrResult.dateTime || formatLocalDate(new Date()) + 'T12:00';

  if (activeUniversalOcrResult.documentType === 'bank_transfer') {
    const bookingId = document.getElementById('universalOcrBookingSelect')?.value;
    const booking = appState.bookings.find(b => b.id === bookingId);
    if (!booking) {
      alert(isBM ? 'Sila pilih tempahan tetamu untuk direkodkan bayaran.' : 'Please select a booking to link payment.');
      return;
    }

    closeUniversalOcrModal();
    openPaymentProofModal(booking, 'balance', null, amount);

    document.getElementById('paymentProofAmountInput').value = amount;
    document.getElementById('paymentProofBankInput').value = bankName;
    document.getElementById('paymentProofRefInput').value = refNo;
    document.getElementById('paymentProofDateTimeInput').value = dt;

    if (activeUniversalOcrImageData) {
      document.getElementById('paymentProofImageData').value = activeUniversalOcrImageData;
      document.getElementById('paymentProofImageName').value = 'scanned_receipt.jpg';
      const prevImg = document.getElementById('receiptPreviewImg');
      if (prevImg) prevImg.src = activeUniversalOcrImageData;
      document.getElementById('receiptUploadPrompt').style.display = 'none';
      document.getElementById('receiptPreviewContainer').style.display = 'block';
    }

    const badge = document.getElementById('paymentProofOcrStatusBadge');
    const badgeText = document.getElementById('paymentProofOcrStatusText');
    if (badge && badgeText) {
      badge.style.display = 'block';
      badge.style.background = 'rgba(16, 185, 129, 0.1)';
      badge.style.color = '#059669';
      badge.style.borderColor = '#10b981';
      badgeText.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${isBM ? 'Auto-isi dari Pengimbas' : 'Auto-filled from Scanner'}: ${bankName} • RM ${amount.toFixed(2)}`;
    }
  } else {
    const propertyId = document.getElementById('universalOcrPropertySelect')?.value;
    const category = document.getElementById('universalOcrCategorySelect')?.value || activeUniversalOcrResult.billCategory || 'utilities';
    const description = document.getElementById('universalOcrDescInput')?.value?.trim() || activeUniversalOcrResult.suggestedDescription || 'Utility Bill';

    closeUniversalOcrModal();
    openExpenseModal({
      propertyId,
      amount,
      date: dt.split('T')[0],
      category,
      description,
      receiptImageData: activeUniversalOcrImageData,
      receiptImageName: 'scanned_bill.jpg',
      ocrNotice: `${isBM ? 'Auto-isi dari Pengimbas' : 'Auto-filled from Scanner'}: ${description} • RM ${amount.toFixed(2)}`
    });
  }
}

function handleSaveOcrSettings() {
  const engine = document.getElementById('settingOcrEngineSelect')?.value || 'auto';
  const apiKey = document.getElementById('settingGeminiApiKeyInput')?.value?.trim() || '';

  appState.settings.ocrEngine = engine;
  appState.settings.geminiApiKey = apiKey;
  saveToStorage();

  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Tetapan pengimbas OCR berjaya disimpan!' : 'OCR scanner preferences saved!');
}

function setupOcrEventListeners() {
  document.getElementById('btnOpenUniversalOcr')?.addEventListener('click', () => openUniversalOcrModal());
  document.getElementById('btnScanReceiptUniversalFin')?.addEventListener('click', () => openUniversalOcrModal());
  document.getElementById('btnCloseUniversalOcrModal')?.addEventListener('click', closeUniversalOcrModal);
  document.getElementById('btnCancelUniversalOcrModal')?.addEventListener('click', closeUniversalOcrModal);

  document.querySelectorAll('.ocr-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      switchUniversalOcrTab(btn.getAttribute('data-tab'));
    });
  });

  const uDropzone = document.getElementById('universalOcrDropzone');
  const uFileInput = document.getElementById('universalOcrFileInput');
  if (uDropzone && uFileInput) {
    uDropzone.addEventListener('click', () => uFileInput.click());
    uFileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files.length > 0) {
        handleUniversalOcrFileSelected(e.target.files[0]);
      }
    });
  }

  document.getElementById('btnParseUniversalOcrText')?.addEventListener('click', handleUniversalOcrTextParse);
  document.getElementById('btnApplyUniversalOcr')?.addEventListener('click', handleApplyUniversalOcr);

  document.getElementById('btnRetakeUniversalOcr')?.addEventListener('click', () => {
    const dropzone = document.getElementById('universalOcrDropzone');
    if (dropzone) dropzone.style.display = 'block';
    const preview = document.getElementById('universalOcrPreviewContainer');
    if (preview) preview.style.display = 'none';
    const resCard = document.getElementById('universalOcrResultCard');
    if (resCard) resCard.style.display = 'none';
    const fileInput = document.getElementById('universalOcrFileInput');
    if (fileInput) fileInput.value = '';
    activeUniversalOcrImageData = null;
    activeUniversalOcrResult = null;
  });

  document.getElementById('btnScanPaymentProofOcr')?.addEventListener('click', () => scanPaymentProofSlipOcr());
  document.getElementById('btnScanExpenseReceipt')?.addEventListener('click', () => {
    document.getElementById('expenseReceiptFileInput')?.click();
  });

  const expDropzone = document.getElementById('expenseReceiptDropzone');
  const expFileInput = document.getElementById('expenseReceiptFileInput');
  if (expDropzone && expFileInput) {
    expDropzone.addEventListener('click', (e) => {
      if (e.target.closest('#btnRemoveExpenseReceipt')) return;
      expFileInput.click();
    });
    expFileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files.length > 0) {
        handleExpenseReceiptFileSelected(e.target.files[0]);
      }
    });
  }

  document.getElementById('btnRemoveExpenseReceipt')?.addEventListener('click', (e) => {
    e.stopPropagation();
    const dataInput = document.getElementById('expenseReceiptImageData');
    if (dataInput) dataInput.value = '';
    const nameInput = document.getElementById('expenseReceiptImageName');
    if (nameInput) nameInput.value = '';
    const fileInp = document.getElementById('expenseReceiptFileInput');
    if (fileInp) fileInp.value = '';
    const prevImg = document.getElementById('expenseReceiptPreviewImg');
    if (prevImg) prevImg.src = '';
    const uploadPrompt = document.getElementById('expenseReceiptUploadPrompt');
    if (uploadPrompt) uploadPrompt.style.display = 'block';
    const prevCont = document.getElementById('expenseReceiptPreviewContainer');
    if (prevCont) prevCont.style.display = 'none';
    const badge = document.getElementById('expenseOcrStatusBadge');
    if (badge) badge.style.display = 'none';
  });

  document.getElementById('settingOcrEngineSelect')?.addEventListener('change', (e) => {
    const keyGrp = document.getElementById('settingGeminiApiKeyGroup');
    if (keyGrp) keyGrp.style.display = e.target.value === 'gemini' ? 'block' : 'none';
  });
  document.getElementById('btnSaveOcrSettings')?.addEventListener('click', handleSaveOcrSettings);
}

// ==========================================================================
// 13C. SMART WHATSAPP CHAT IMPORT & TENANT EXTRACTION ENGINE
// ==========================================================================

let activeTenantChatDestination = 'booking';
let activeTenantChatExtracted = null;
let activeTenantChatBookingType = 'individual';

function setTenantChatBookingType(type) {
  activeTenantChatBookingType = type === 'company' ? 'company' : 'individual';

  // Update segmented control buttons UI
  document.querySelectorAll('#tenantChatBookingTypeSegmented .segment-btn').forEach(btn => {
    const btnType = btn.getAttribute('data-chat-booking-type');
    btn.classList.toggle('active', btnType === activeTenantChatBookingType);
  });

  // Toggle field sections in result card
  const indFields = document.getElementById('tenantChatFieldsIndividual');
  const compFields = document.getElementById('tenantChatFieldsCompany');
  if (indFields) indFields.style.display = activeTenantChatBookingType === 'individual' ? 'grid' : 'none';
  if (compFields) compFields.style.display = activeTenantChatBookingType === 'company' ? 'grid' : 'none';

  // Sync common values between forms if user switches
  if (activeTenantChatBookingType === 'company') {
    const checkIn = document.getElementById('tenantChatResultCheckIn')?.value;
    const checkOut = document.getElementById('tenantChatResultCheckOut')?.value;
    const compIn = document.getElementById('tenantChatResultCompanyCheckIn');
    const compOut = document.getElementById('tenantChatResultCompanyCheckOut');
    if (checkIn && compIn && !compIn.value) compIn.value = checkIn;
    if (checkOut && compOut && !compOut.value) compOut.value = checkOut;

    const adults = parseInt(document.getElementById('tenantChatResultAdults')?.value, 10) || 1;
    const kids = parseInt(document.getElementById('tenantChatResultChildren')?.value, 10) || 0;
    const compGuests = document.getElementById('tenantChatResultCompanyGuests');
    if (compGuests && (!compGuests.value || compGuests.value === '1')) compGuests.value = adults + kids;
  } else {
    const compIn = document.getElementById('tenantChatResultCompanyCheckIn')?.value;
    const compOut = document.getElementById('tenantChatResultCompanyCheckOut')?.value;
    const indIn = document.getElementById('tenantChatResultCheckIn');
    const indOut = document.getElementById('tenantChatResultCheckOut');
    if (compIn && indIn && !indIn.value) indIn.value = compIn;
    if (compOut && indOut && !indOut.value) indOut.value = compOut;
  }
}

function parseTenantChat(rawChat, options = {}) {
  if (!rawChat || typeof rawChat !== 'string') {
    return {
      bookingType: options.bookingType || 'individual',
      name: '',
      phone: '',
      ic: '',
      passport: '',
      email: '',
      vehicle: '',
      adults: 1,
      children: 0,
      guestCount: 1,
      checkIn: '',
      checkOut: '',
      address: '',
      companyName: '',
      companyRegNo: '',
      picName: '',
      contactPerson: '',
      picPosition: '',
      contactDesignation: '',
      picPhone: '',
      contactPhone: '',
      picEmail: '',
      contactEmail: '',
      companyAddress: '',
      companyIndicators: [],
      confidence: 0,
      fieldConfidence: {},
      originalChat: rawChat || ''
    };
  }

  const text = rawChat.trim();
  const lines = text.split(/[\r\n]+/);

  const result = {
    bookingType: 'individual',
    name: '',
    phone: '',
    ic: '',
    passport: '',
    email: '',
    vehicle: '',
    adults: 0,
    children: 0,
    guestCount: 0,
    checkIn: '',
    checkOut: '',
    address: '',
    companyName: '',
    companyRegNo: '',
    picName: '',
    contactPerson: '',
    picPosition: '',
    contactDesignation: '',
    picPhone: '',
    contactPhone: '',
    picEmail: '',
    contactEmail: '',
    companyAddress: '',
    companyIndicators: [],
    confidence: 0,
    fieldConfidence: {},
    originalChat: text
  };

  // Helper to remove WhatsApp timestamp/sender prefixes
  const cleanLine = (str) => {
    return str
      .replace(/^\[[0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?(?:,\s*[0-9\/\-\.]*)?\]\s*[^:]*:\s*/i, '')
      .replace(/^[0-9\/\-\.]*,\s*[0-9]{1,2}:[0-9]{2}\s*(?:AM|PM|am|pm)?\s*-\s*[^:]*:\s*/i, '')
      .trim();
  };

  const cleanedText = lines.map(cleanLine).join('\n');

  // Detect company indicators (Sdn Bhd, SSM, Enterprise, Holdings, Resources, Industries, Manufacturing, PIC)
  const detectedCompanyIndicators = [];
  if (/\b(?:sdn\.?\s*bhd\.?|sendirian\s*berhad)\b/i.test(cleanedText)) detectedCompanyIndicators.push('Sdn Bhd');
  if (/\b(?:ssm|suruhanjaya\s*syarikat\s*malaysia|roc|rob|co\.?\s*reg|company\s*reg|registration\s*no)\b/i.test(cleanedText)) detectedCompanyIndicators.push('SSM');
  if (/\benterprise\b/i.test(cleanedText)) detectedCompanyIndicators.push('Enterprise');
  if (/\bholdings?\b/i.test(cleanedText)) detectedCompanyIndicators.push('Holdings');
  if (/\bresources?\b/i.test(cleanedText)) detectedCompanyIndicators.push('Resources');
  if (/\bindustries?\b/i.test(cleanedText)) detectedCompanyIndicators.push('Industries');
  if (/\bmanufacturing\b/i.test(cleanedText)) detectedCompanyIndicators.push('Manufacturing');
  if (/\b(?:pic|person\s*in\s*charge|pegawai\s*dihubungi|contact\s*person)\b/i.test(cleanedText)) detectedCompanyIndicators.push('PIC');

  result.companyIndicators = detectedCompanyIndicators;

  // Determine booking type: explicit option takes priority, otherwise auto-detected from indicators
  let bookingType = 'individual';
  if (options.bookingType === 'company' || options.bookingType === 'individual') {
    bookingType = options.bookingType;
  } else if (detectedCompanyIndicators.length > 0) {
    bookingType = 'company';
  }
  result.bookingType = bookingType;

  // 1. PHONE NUMBER
  const phoneLabelMatch = cleanedText.match(/(?:Phone|No\.?\s*Tel(?:efon)?|No\.?\s*Phone|Tel|Mobile|WhatsApp|Contact|Hp|Wasap)\s*[:=]?\s*(\+?[0-9\s-]{9,20})/i);
  if (phoneLabelMatch) {
    const rawDigits = phoneLabelMatch[1].replace(/[\s-]/g, '');
    if (rawDigits.length >= 9) {
      result.phone = phoneLabelMatch[1].trim();
      result.fieldConfidence.phone = 'high';
    }
  }

  // Fallback: Malaysian mobile numbers (+601x or 01x)
  if (!result.phone) {
    const phoneRegex = /\b(\+?60[\s-]?1[0-9][\s-]?[0-9]{3,4}[\s-]?[0-9]{4}|01[0-9][\s-]?[0-9]{3,4}[\s-]?[0-9]{4})\b/;
    const phoneMatch = cleanedText.match(phoneRegex);
    if (phoneMatch) {
      result.phone = phoneMatch[1].trim();
      result.fieldConfidence.phone = 'medium';
    }
  }

  // Fallback 2: WhatsApp chat sender phone header
  if (!result.phone) {
    const waSenderMatch = rawChat.match(/[-–]\s*(\+?[0-9\s-]{9,20})\s*:/);
    if (waSenderMatch) {
      const digits = waSenderMatch[1].replace(/[\s-]/g, '');
      if (digits.length >= 9) {
        result.phone = waSenderMatch[1].trim();
        result.fieldConfidence.phone = 'medium';
      }
    }
  }

  // 2. MALAYSIAN IC (MyKad)
  const icLabelMatch = cleanedText.match(/(?:No\.?\s*(?:K\/?P|Kad\s*Pengenalan|IC|MyKad)|NRIC|IC\s*(?:No\.?)?)\s*[:=]?\s*([0-9]{6}[-\s]?[0-9]{2}[-\s]?[0-9]{4}|[0-9]{12})/i);
  if (icLabelMatch) {
    const rawIc = icLabelMatch[1].replace(/[\s-]/g, '');
    if (rawIc.length === 12) {
      result.ic = `${rawIc.slice(0, 6)}-${rawIc.slice(6, 8)}-${rawIc.slice(8, 12)}`;
      result.fieldConfidence.ic = 'high';
    }
  }

  if (!result.ic) {
    const icPattern = /\b([0-9]{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12][0-9]|3[01])[-][0-9]{2}[-][0-9]{4})\b/;
    const icMatch = cleanedText.match(icPattern);
    if (icMatch) {
      result.ic = icMatch[1];
      result.fieldConfidence.ic = 'medium';
    }
  }

  // 3. PASSPORT NUMBER
  const passLabelMatch = cleanedText.match(/(?:Passport(?:\s*(?:No\.?|Number))?|No\.?\s*Pasport)\s*[:=]?\s*([A-Za-z][0-9A-Za-z]{6,12})/i);
  if (passLabelMatch) {
    result.passport = passLabelMatch[1].trim().toUpperCase();
    result.fieldConfidence.passport = 'high';
  }

  // Constraint 7: For foreign guests, Passport Number populates the Identification Number (IC) field
  if (!result.ic && result.passport) {
    result.ic = result.passport;
    if (!result.fieldConfidence.ic) {
      result.fieldConfidence.ic = result.fieldConfidence.passport || 'high';
    }
  }

  // 4. EMAIL ADDRESS
  const emailMatch = cleanedText.match(/\b([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})\b/);
  if (emailMatch) {
    result.email = emailMatch[1].trim().toLowerCase();
    result.fieldConfidence.email = 'high';
  }

  // 5. VEHICLE / CAR PLATE
  const vehicleLabelMatch = cleanedText.match(/(?:No\.?\s*Plat(?:\s*(?:Kereta|Kenderaan))?|No\.?\s*(?:Kereta|Kenderaan)|Vehicle(?:\s*(?:No\.?|Plate))?|Car(?:\s*(?:Plate|No\.?))?|Plat(?:\s*(?:No\.?|Kereta|Kenderaan))?|Plate\s*No\.?|No\.?\s*Pendaftaran)\s*[:=]?\s*([^\n\r,;]{3,45})/i);
  if (vehicleLabelMatch) {
    let vVal = vehicleLabelMatch[1].trim();
    vVal = vVal.replace(/^(?:kereta|car|kenderaan|plat|plate)\s*[:=]?\s*/i, '').trim();
    if (!/^(tiada|none|na|nil|tak ada)$/i.test(vVal)) {
      result.vehicle = vVal;
      result.fieldConfidence.vehicle = 'high';
    }
  }

  if (!result.vehicle) {
    const convoVehicleMatch = cleanedText.match(/(?:kereta|car|kete|plat|plate)\s+([A-Za-z0-9\s]{3,20}\b[A-Za-z]{1,3}\s*[0-9]{1,4}\s*[A-Za-z]?)/i);
    if (convoVehicleMatch) {
      result.vehicle = convoVehicleMatch[1].trim();
      result.fieldConfidence.vehicle = 'medium';
    } else {
      const plateRegex = /\b([A-Z]{1,3}\s*[0-9]{1,4}\s*[A-Z]?)\b/;
      const potentialPlates = cleanedText.match(new RegExp(plateRegex, 'g'));
      if (potentialPlates) {
        for (const p of potentialPlates) {
          const cleanP = p.trim();
          if (!/^(RM|MYR|AM|PM|IC|SSM|NO|KL|PASSPORT|CHECK|BILL)$/i.test(cleanP) && /\d/.test(cleanP)) {
            result.vehicle = cleanP;
            result.fieldConfidence.vehicle = 'low';
            break;
          }
        }
      }
    }
  }

  // 6. NAME EXTRACTION
  const nameLabelMatch = cleanedText.match(/(?:Nama(?:\s*(?:Penuh|Pelanggan|Tetamu|Penyewa|saya))?|Full\s*Name|Name|Guest\s*Name|Tenant\s*Name)\s*[:=]?\s*([^\n\r,;:]{2,50})/i);
  if (nameLabelMatch) {
    let cand = nameLabelMatch[1].trim().replace(/\s{2,}/g, ' ');
    cand = cand.replace(/^(?:saya|adalah|is)\s+/i, '').trim();
    if (cand.length >= 3 && !/^(saya|awak|tuan|puan|homestay|villa)$/i.test(cand)) {
      result.name = cand;
      result.fieldConfidence.name = 'high';
    }
  }

  if (!result.name) {
    const convoNameMatch = cleanedText.match(/(?:Nama\s*saya|My\s*name\s*is|I\s*am|Saya)\s+([A-Za-z\s'’@\/.]{3,40})/i);
    if (convoNameMatch) {
      const cand = convoNameMatch[1].trim().replace(/\s+(nak|ingin|mahu|book|tempah|tanya|berminat).*$/i, '').trim();
      if (cand.length >= 3 && !/\b(nak|tanya|book|homestay)\b/i.test(cand)) {
        result.name = cand;
        result.fieldConfidence.name = 'medium';
      }
    }
  }

  // 7. OCCUPANTS: ADULTS, CHILDREN & TOTAL GUESTS
  const adultsMatch = cleanedText.match(/(?:([0-9]{1,2})\s*(?:Adults?|Dewasa|Pax\s*Dewasa|Orang\s*Dewasa)|(?:Adults?|Dewasa)\s*[:=]?\s*([0-9]{1,2}))/i);
  if (adultsMatch) {
    result.adults = parseInt(adultsMatch[1] || adultsMatch[2], 10);
    result.fieldConfidence.adults = 'high';
  }

  const childrenMatch = cleanedText.match(/(?:([0-9]{1,2})\s*(?:Children|Child|Kids?|Kanak[-\s]?kanak|Kanak2|Budak)|(?:Children|Child|Kids?|Kanak[-\s]?kanak)\s*[:=]?\s*([0-9]{1,2}))/i);
  if (childrenMatch) {
    result.children = parseInt(childrenMatch[1] || childrenMatch[2], 10);
    result.fieldConfidence.children = 'high';
  }

  const totalPaxMatch = cleanedText.match(/(?:([0-9]{1,2})\s*(?:Pax|Guests?|Orang|Tetamu|Penghuni)|(?:Pax|Guests?|Tetamu|Occupants?|Number\s*of\s*Guests?|Bilangan\s*(?:Tetamu|Pax))\s*[:=]?\s*([0-9]{1,2}))/i);
  if (totalPaxMatch) {
    const total = parseInt(totalPaxMatch[1] || totalPaxMatch[2], 10);
    if (!result.adults && !result.children) {
      result.adults = total;
      result.guestCount = total;
      result.fieldConfidence.adults = 'medium';
    } else if (total > 0 && !result.guestCount) {
      result.guestCount = total;
    }
  }

  if (result.adults || result.children) {
    result.guestCount = (result.adults || 0) + (result.children || 0);
  } else if (!result.guestCount) {
    result.adults = 1;
    result.guestCount = 1;
  }

  // 8. CHECK-IN & CHECK-OUT DATES
  const monNames = {
    jan: '01', januari: '01', january: '01',
    feb: '02', februari: '02', february: '02',
    mar: '03', mac: '03', march: '03',
    apr: '04', april: '04',
    may: '05', mei: '05',
    jun: '06', june: '06',
    jul: '07', july: '07', julai: '07',
    aug: '08', ogos: '08', august: '08',
    sep: '09', sept: '09', september: '09',
    oct: '10', okt: '10', oktober: '10', october: '10',
    nov: '11', november: '11',
    dec: '12', dis: '12', disember: '12', december: '12'
  };

  const parseDateStr = (str) => {
    if (!str) return null;
    const s = str.trim();
    const isoM = s.match(/\b(20[2-3][0-9])-([0-1][0-9])-([0-3][0-9])\b/);
    if (isoM) return `${isoM[1]}-${isoM[2]}-${isoM[3]}`;

    const dmyM = s.match(/\b([0-3]?[0-9])[\/\-]([0-1]?[0-9])[\/\-](20[2-3][0-9])\b/);
    if (dmyM) return `${dmyM[3]}-${dmyM[2].padStart(2, '0')}-${dmyM[1].padStart(2, '0')}`;

    const dmyShort = s.match(/\b([0-3]?[0-9])[\/\-]([0-1]?[0-9])[\/\-]([2-3][0-9])\b/);
    if (dmyShort) return `20${dmyShort[3]}-${dmyShort[2].padStart(2, '0')}-${dmyShort[1].padStart(2, '0')}`;

    const textM = s.match(/\b([0-3]?[0-9])\s+([A-Za-z]{3,9})\s+(20[2-3][0-9])\b/);
    if (textM) {
      const mNum = monNames[textM[2].toLowerCase()];
      if (mNum) return `${textM[3]}-${mNum}-${textM[1].padStart(2, '0')}`;
    }

    return null;
  };

  const inMatch = cleanedText.match(/(?:Tarikh\s*(?:Masuk|Daftar\s*Masuk|Check[-\s]?in)|Check[-\s]?in(?:\s*Date)?|Masuk|Arrival)\s*[:=]?\s*([^\n\r,;]{5,30})/i);
  if (inMatch) {
    const d = parseDateStr(inMatch[1]);
    if (d) {
      result.checkIn = d;
      result.fieldConfidence.checkIn = 'high';
    }
  }

  const outMatch = cleanedText.match(/(?:Tarikh\s*(?:Keluar|Daftar\s*Keluar|Check[-\s]?out)|Check[-\s]?out(?:\s*Date)?|Keluar|Departure)\s*[:=]?\s*([^\n\r,;]{5,30})/i);
  if (outMatch) {
    const d = parseDateStr(outMatch[1]);
    if (d) {
      result.checkOut = d;
      result.fieldConfidence.checkOut = 'high';
    }
  }

  if (!result.checkIn || !result.checkOut) {
    const dayToDayMatch = cleanedText.match(/\b([0-3]?[0-9])\s*(?:to|hingga|-|sampai)\s*([0-3]?[0-9])\s+([A-Za-z]{3,9})\s+(20[2-3][0-9])\b/i);
    if (dayToDayMatch) {
      const d1 = dayToDayMatch[1].padStart(2, '0');
      const d2 = dayToDayMatch[2].padStart(2, '0');
      const mNum = monNames[dayToDayMatch[3].toLowerCase()];
      const y = dayToDayMatch[4];
      if (mNum) {
        result.checkIn = `${y}-${mNum}-${d1}`;
        result.checkOut = `${y}-${mNum}-${d2}`;
        result.fieldConfidence.checkIn = 'high';
        result.fieldConfidence.checkOut = 'high';
      }
    }
  }

  if (!result.checkIn || !result.checkOut) {
    const numRangeMatch = cleanedText.match(/\b([0-3]?[0-9][\/\-][0-1]?[0-9][\/\-](?:20)?[2-3][0-9])\s*(?:to|hingga|-|sampai)\s*([0-3]?[0-9][\/\-][0-1]?[0-9][\/\-](?:20)?[2-3][0-9])\b/i);
    if (numRangeMatch) {
      const d1 = parseDateStr(numRangeMatch[1]);
      const d2 = parseDateStr(numRangeMatch[2]);
      if (d1 && d2) {
        result.checkIn = d1;
        result.checkOut = d2;
        result.fieldConfidence.checkIn = 'medium';
        result.fieldConfidence.checkOut = 'medium';
      }
    }
  }

  // 9. ADDRESS EXTRACTION (Residential)
  const addrMatch = cleanedText.match(/(?:Alamat(?:\s*(?:Kediaman|Rumah|Penuh))?|Address|Home\s*Address|Residential\s*Address|Add)\s*[:=]?\s*([^\n\r]{8,150})/i);
  if (addrMatch) {
    const rawAddr = addrMatch[1].trim();
    if (rawAddr.length >= 8 && !/^(tiada|none|na|nil)$/i.test(rawAddr)) {
      result.address = rawAddr;
      result.fieldConfidence.address = 'high';
    }
  }

  // 10. COMPANY SPECIFIC EXTRACTIONS
  // Company Name
  const compNameMatch = cleanedText.match(/(?:Company(?:\s*Name)?|Nama\s*Syarikat|Syarikat|Organisasi|Organization|Majikan|Employer)\s*[:=]?\s*([^\n\r]{2,80})/i);
  if (compNameMatch) {
    result.companyName = compNameMatch[1].trim();
    result.fieldConfidence.companyName = 'high';
  } else if (detectedCompanyIndicators.length > 0 || bookingType === 'company') {
    const compLineMatch = cleanedText.match(/\b([A-Za-z0-9&.,\s'-]+(?:\s+(?:Sdn\.?\s*Bhd\.?|Sendirian\s*Berhad|Enterprise|Holdings?|Resources?|Industries?|Manufacturing|LLP|Plt|Bhd\.?)))\b/i);
    if (compLineMatch) {
      let cand = compLineMatch[1].trim().replace(/^[^a-zA-Z0-9]+/, '');
      result.companyName = cand;
      result.fieldConfidence.companyName = 'medium';
    }
  }

  // SSM Registration Number
  const ssmLabelMatch = cleanedText.match(/(?:No\.?\s*(?:Pendaftaran\s*Syarikat|SSM|ROC|ROB)|SSM(?:\s*(?:No\.?|Number|Reg(?:istration)?))?|Co\.?\s*Reg(?:\s*No\.?)?|Company\s*(?:Reg(?:istration)?(?:\s*No\.?)?|Number)|Business\s*Reg(?:\s*No\.?)?)\s*[:=]?\s*([^\n\r,;]{3,40})/i);
  if (ssmLabelMatch) {
    result.companyRegNo = ssmLabelMatch[1].trim();
    result.fieldConfidence.companyRegNo = 'high';
  } else {
    const ssmPatternMatch = cleanedText.match(/\b(20[0-2][0-9]{9}(?:\s*\([0-9]{6,7}-[A-Z]\))?|[0-9]{5,7}-[A-Za-z])\b/);
    if (ssmPatternMatch) {
      result.companyRegNo = ssmPatternMatch[1].trim();
      result.fieldConfidence.companyRegNo = 'medium';
    }
  }

  // PIC Name
  const picNameMatch = cleanedText.match(/(?:Nama\s*PIC|PIC(?:\s*Name)?|Person\s*in\s*Charge|Pegawai\s*(?:Dihubungi|Bertanggungjawab)|Contact\s*Person)\s*[:=]?\s*([^\n\r,;:]{2,60})/i);
  if (picNameMatch) {
    let cand = picNameMatch[1].trim().replace(/\s{2,}/g, ' ');
    result.picName = cand;
    result.contactPerson = cand;
    result.fieldConfidence.picName = 'high';
  } else if (bookingType === 'company' && result.name && result.name !== result.companyName) {
    result.picName = result.name;
    result.contactPerson = result.name;
    result.fieldConfidence.picName = result.fieldConfidence.name || 'medium';
  }

  // PIC Position / Designation
  const picPosMatch = cleanedText.match(/(?:PIC\s*(?:Position|Designation|Jawatan)|Jawatan(?:\s*PIC)?|Position|Designation|Title)\s*[:=]?\s*([^\n\r,;]{2,50})/i);
  if (picPosMatch) {
    result.picPosition = picPosMatch[1].trim();
    result.contactDesignation = result.picPosition;
    result.fieldConfidence.picPosition = 'high';
  }

  // PIC Phone
  const picPhoneMatch = cleanedText.match(/(?:PIC\s*(?:Phone|Tel(?:efon)?|Mobile|Contact|No\.?)|No\.?\s*Tel(?:efon)?\s*PIC)\s*[:=]?\s*(\+?[0-9 -]{9,20})/i);
  if (picPhoneMatch) {
    result.picPhone = picPhoneMatch[1].trim();
    result.contactPhone = result.picPhone;
    result.fieldConfidence.picPhone = 'high';
  } else if (bookingType === 'company' && result.phone) {
    result.picPhone = result.phone;
    result.contactPhone = result.phone;
    result.fieldConfidence.picPhone = result.fieldConfidence.phone || 'medium';
  }

  // PIC Email
  const picEmailMatch = cleanedText.match(/(?:PIC\s*Email|Email\s*PIC)\s*[:=]?\s*([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/i);
  if (picEmailMatch) {
    result.picEmail = picEmailMatch[1].trim().toLowerCase();
    result.contactEmail = result.picEmail;
    result.fieldConfidence.picEmail = 'high';
  } else if (bookingType === 'company' && result.email) {
    result.picEmail = result.email;
    result.contactEmail = result.email;
    result.fieldConfidence.picEmail = result.fieldConfidence.email || 'medium';
  }

  // Company Address
  const compAddrMatch = cleanedText.match(/(?:Company\s*Address|Alamat\s*Syarikat|Office\s*Address|Business\s*Address|Alamat\s*Pejabat)\s*[:=]?\s*([^\n\r]{8,150})/i);
  if (compAddrMatch) {
    result.companyAddress = compAddrMatch[1].trim();
    result.fieldConfidence.companyAddress = 'high';
  } else if (bookingType === 'company' && result.address) {
    result.companyAddress = result.address;
    result.fieldConfidence.companyAddress = result.fieldConfidence.address || 'medium';
  }

  // Ensure Role Aliases
  result.contactPerson = result.picName || '';
  result.contactDesignation = result.picPosition || '';
  result.contactPhone = result.picPhone || result.phone || '';
  result.contactEmail = result.picEmail || result.email || '';

  if (bookingType === 'company') {
    if (!result.name && result.picName) result.name = result.picName;
    if (!result.phone && result.picPhone) result.phone = result.picPhone;
    if (!result.email && result.picEmail) result.email = result.picEmail;
    if (!result.address && result.companyAddress) result.address = result.companyAddress;
  }

  // 11. CONFIDENCE SCORE (0-100)
  let score = 0;
  if (result.bookingType === 'company') {
    if (result.companyName) score += 25;
    if (result.companyRegNo) score += 15;
    if (result.picName) score += 15;
    if (result.picPhone || result.phone) score += 20;
    if (result.checkIn && result.checkOut) score += 15;
    else if (result.checkIn || result.checkOut) score += 8;
    if (result.picEmail || result.email) score += 5;
    if (result.companyAddress || result.address) score += 5;
  } else {
    if (result.name) score += 20;
    if (result.phone) score += 20;
    if (result.ic || result.passport) score += 15;
    if (result.checkIn && result.checkOut) score += 20;
    else if (result.checkIn || result.checkOut) score += 10;
    if (result.vehicle) score += 10;
    if (result.email) score += 5;
    if (result.adults > 0) score += 5;
    if (result.address) score += 5;
  }

  result.confidence = Math.min(100, score);
  return result;
}

// Future Gemini AI-enhanced extraction mode structure
async function extractTenantChatViaGemini(chatText, apiKey) {
  if (!apiKey || !chatText) return null;
  const prompt = `You are an AI assistant for a Malaysian homestay and property management system.
Extract the guest/tenant booking particulars from this WhatsApp conversation transcript or message.
Return ONLY a valid JSON object matching these exact keys:
{
  "bookingType": "individual" or "company",
  "name": string (full name of tenant/guest or PIC, e.g. "Mohd Hafiz bin Abdullah"),
  "phone": string (Malaysian or international phone number, e.g. "019-3829102" or "+601128919201"),
  "ic": string (12-digit Malaysian MyKad in format "YYMMDD-PB-####", or passport number if foreigner),
  "passport": string (passport number or empty if none),
  "email": string (email address or empty if none),
  "vehicle": string (vehicle license plate number and model, e.g. "VAA 8892 (Proton X50)"),
  "adults": number (number of adults, default 1),
  "children": number (number of children, default 0),
  "checkIn": string (check-in date in YYYY-MM-DD format or empty),
  "checkOut": string (check-out date in YYYY-MM-DD format or empty),
  "address": string (full residential or company address or empty),
  "companyName": string (company name if corporate booking, e.g. "Gamuda Engineering Sdn Bhd"),
  "companyRegNo": string (SSM registration number or empty),
  "picName": string (person in charge name or empty),
  "picPosition": string (person in charge job title or designation),
  "picPhone": string (contact number of PIC),
  "picEmail": string (email of PIC)
}
Conversation text:
${chatText}`;

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: prompt }]
        }]
      })
    });
    if (response.ok) {
      const resJson = await response.json();
      const rawText = resJson.candidates?.[0]?.content?.parts?.[0]?.text;
      if (rawText) {
        const jsonMatch = rawText.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          const bType = parsed.bookingType === 'company' ? 'company' : (parsed.companyName ? 'company' : 'individual');
          return {
            bookingType: bType,
            name: parsed.name || parsed.picName || '',
            phone: parsed.phone || parsed.picPhone || '',
            ic: parsed.ic || parsed.passport || '',
            passport: parsed.passport || '',
            email: parsed.email || parsed.picEmail || '',
            vehicle: parsed.vehicle || '',
            adults: typeof parsed.adults === 'number' ? parsed.adults : 1,
            children: typeof parsed.children === 'number' ? parsed.children : 0,
            guestCount: (parsed.adults || 1) + (parsed.children || 0),
            checkIn: parsed.checkIn || '',
            checkOut: parsed.checkOut || '',
            address: parsed.address || '',
            companyName: parsed.companyName || '',
            companyRegNo: parsed.companyRegNo || '',
            picName: parsed.picName || parsed.name || '',
            contactPerson: parsed.picName || parsed.name || '',
            picPosition: parsed.picPosition || '',
            contactDesignation: parsed.picPosition || '',
            picPhone: parsed.picPhone || parsed.phone || '',
            contactPhone: parsed.picPhone || parsed.phone || '',
            picEmail: parsed.picEmail || parsed.email || '',
            contactEmail: parsed.picEmail || parsed.email || '',
            companyAddress: parsed.companyAddress || parsed.address || '',
            companyIndicators: bType === 'company' ? ['Gemini AI'] : [],
            confidence: 98,
            fieldConfidence: {
              name: parsed.name ? 'high' : 'low',
              phone: parsed.phone ? 'high' : 'low',
              ic: parsed.ic ? 'high' : 'low',
              passport: parsed.passport ? 'high' : 'low',
              vehicle: parsed.vehicle ? 'high' : 'low',
              checkIn: parsed.checkIn ? 'high' : 'low',
              checkOut: parsed.checkOut ? 'high' : 'low',
              companyName: parsed.companyName ? 'high' : 'low',
              companyRegNo: parsed.companyRegNo ? 'high' : 'low'
            },
            originalChat: chatText,
            engine: 'gemini'
          };
        }
      }
    }
  } catch (err) {
    console.warn('Gemini chat extraction notice:', err);
  }
  return null;
}

async function extractTenantChat(rawChat, options = {}) {
  const mode = options.mode || appState?.settings?.ocrEngine || 'auto';
  const apiKey = options.apiKey || appState?.settings?.geminiApiKey;

  if ((mode === 'gemini' || mode === 'auto') && apiKey) {
    const geminiResult = await extractTenantChatViaGemini(rawChat, apiKey);
    if (geminiResult && (geminiResult.name || geminiResult.phone || geminiResult.companyName)) {
      return geminiResult;
    }
  }

  // Pure client-side offline parser
  const offlineResult = parseTenantChat(rawChat, options);
  offlineResult.engine = 'offline';
  return offlineResult;
}

function openTenantChatImportModal(destination = 'booking') {
  activeTenantChatDestination = destination;
  activeTenantChatExtracted = null;
  setTenantChatBookingType('individual');

  const isBM = appState.settings.language === 'bm';
  const noticeEl = document.getElementById('tenantChatDestinationNotice');
  if (noticeEl) {
    noticeEl.textContent = destination === 'contact'
      ? (isBM ? 'Mod: Menyimpan ke Direktori Kenalan' : 'Mode: Saving to Contacts Directory')
      : (isBM ? 'Mod: Mengisi Borang Tempahan' : 'Mode: Pre-filling Booking Form');
  }

  const resCard = document.getElementById('tenantChatResultCard');
  if (resCard) resCard.style.display = 'none';

  const modal = document.getElementById('tenantChatImportModal');
  if (modal) modal.classList.add('active');
}

function closeTenantChatImportModal() {
  const modal = document.getElementById('tenantChatImportModal');
  if (modal) modal.classList.remove('active');
}

function insertSampleTenantChat(type) {
  const input = document.getElementById('tenantChatInput');
  if (!input) return;

  if (type === 'bm') {
    setTenantChatBookingType('individual');
    input.value = `Nama: Mohd Hafiz bin Abdullah\nNo Tel: 019-3829102\nIC: 880415-08-5431\nEmail: hafiz.abd@gmail.com\nNo Plat Kereta: VAA 8892 (Proton X50)\nBilangan Tetamu: 4 Dewasa, 2 Kanak-kanak\nTarikh Masuk: 15/12/2026\nTarikh Keluar: 17/12/2026\nAlamat: No 25 Jalan Melor 3, Taman Melor, 43000 Kajang, Selangor`;
  } else if (type === 'en') {
    setTenantChatBookingType('individual');
    input.value = `Name: Johnathan David Smith\nPassport: A12893456\nMobile: +601128919201\nEmail: jdsmith@outlook.com\nCheck-in: 2026-12-20\nCheck-out: 2026-12-24\nGuests: 2 adults and 1 child\nCar: WRA 1234\nHome address: 42 Elm Street, Melbourne VIC 3000, Australia`;
  } else if (type === 'convo') {
    setTenantChatBookingType('individual');
    input.value = `[10:15, 03/11/2026] Guest: Salam tuan, nak tanya homestay Villa Pantai available tak 5 to 7 Dec 2026?\n[10:18, 03/11/2026] Host: Salam encik, available. Berapa orang ya?\n[10:20, 03/11/2026] Guest: Kami 3 dewasa 2 kanak2. Boleh book terus?\nNama saya Siti Nurhaliza binti Ramli\nNo phone 0124567890\nIC: 920314025678\nKereta Honda City plate WYY 9821\nEmail: siti.ramli@yahoo.com\nAlamat di No 14, Lorong Sentosa 2, Bayan Lepas, 11900 Pulau Pinang`;
  } else if (type === 'company') {
    setTenantChatBookingType('company');
    input.value = `Company Name: Gamuda Engineering Sdn Bhd\nSSM: 202101008899 (1409123-T)\nPIC Name: Ts. Ir. Azman bin Mokhtar\nPIC Position: Senior Project Director\nPIC Phone: 013-9876543\nPIC Email: azman.mokhtar@gamuda.com.my\nCompany Address: Menara Gamuda, PJ Trade Centre, No. 8 Jalan PJU 8/8A, Bandar Damansara Perdana, 47820 Petaling Jaya, Selangor\nNumber of Guests: 6\nCheck-In Date: 2026-12-01\nCheck-Out Date: 2026-12-05`;
  }
}

async function handleTenantChatParse() {
  const input = document.getElementById('tenantChatInput');
  const chatText = input ? input.value.trim() : '';
  const isBM = appState.settings.language === 'bm';

  if (!chatText) {
    alert(isBM ? 'Sila tampal mesej WhatsApp tetamu terlebih dahulu.' : 'Please paste the guest WhatsApp message first.');
    return;
  }

  const result = await extractTenantChat(chatText, { bookingType: activeTenantChatBookingType });
  displayTenantChatResult(result);
}

function displayTenantChatResult(res) {
  if (!res) return;
  activeTenantChatExtracted = res;
  const isBM = appState.settings.language === 'bm';

  const resCard = document.getElementById('tenantChatResultCard');
  if (!resCard) return;
  resCard.style.display = 'block';

  // Sync booking type
  const targetType = res.bookingType === 'company' ? 'company' : 'individual';
  setTenantChatBookingType(targetType);

  // Confidence Badge
  const badge = document.getElementById('tenantChatConfidenceBadge');
  if (badge) {
    const conf = res.confidence || 0;
    let badgeClass = 'high';
    let label = `${conf}% ${isBM ? 'Ketepatan Tinggi' : 'High Confidence'}`;
    if (conf < 50) {
      badgeClass = 'low';
      label = `${conf}% ${isBM ? 'Perlu Pengesahan' : 'Review Needed'}`;
    } else if (conf < 80) {
      badgeClass = 'medium';
      label = `${conf}% ${isBM ? 'Ketepatan Sederhana' : 'Medium Confidence'}`;
    }
    badge.className = `tenant-chat-confidence-badge ${badgeClass}`;
    badge.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${label}`;
  }

  // Editable Input Fields
  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val !== undefined && val !== null ? val : '';
  };

  // Populate Individual Fields
  setVal('tenantChatResultName', res.name);
  setVal('tenantChatResultPhone', res.phone);
  setVal('tenantChatResultIc', res.ic || res.passport);
  setVal('tenantChatResultPassport', res.passport);
  setVal('tenantChatResultEmail', res.email);
  setVal('tenantChatResultVehicle', res.vehicle);
  setVal('tenantChatResultAdults', res.adults || 1);
  setVal('tenantChatResultChildren', res.children || 0);
  setVal('tenantChatResultCheckIn', res.checkIn);
  setVal('tenantChatResultCheckOut', res.checkOut);
  setVal('tenantChatResultAddress', res.address);

  // Populate Company Fields
  setVal('tenantChatResultCompanyName', res.companyName);
  setVal('tenantChatResultCompanyRegNo', res.companyRegNo);
  setVal('tenantChatResultPicName', res.picName || res.contactPerson || res.name);
  setVal('tenantChatResultPicPosition', res.picPosition || res.contactDesignation);
  setVal('tenantChatResultPicPhone', res.picPhone || res.contactPhone || res.phone);
  setVal('tenantChatResultPicEmail', res.picEmail || res.contactEmail || res.email);
  setVal('tenantChatResultCompanyAddress', res.companyAddress || res.address);
  setVal('tenantChatResultCompanyGuests', res.guestCount || (res.adults || 1) + (res.children || 0));
  setVal('tenantChatResultCompanyCheckIn', res.checkIn);
  setVal('tenantChatResultCompanyCheckOut', res.checkOut);

  // Original Conversation Accordion
  const origText = document.getElementById('tenantChatOriginalText');
  if (origText) origText.textContent = res.originalChat || '';

  showToast(t('chat_extracted_success'));
}

function getEditedTenantChatData() {
  const getVal = (id) => {
    const el = document.getElementById(id);
    return el ? el.value.trim() : '';
  };

  const bookingType = activeTenantChatBookingType || 'individual';
  const originalChat = activeTenantChatExtracted?.originalChat || document.getElementById('tenantChatInput')?.value || '';

  if (bookingType === 'company') {
    const guestCount = parseInt(getVal('tenantChatResultCompanyGuests'), 10) || 1;
    return {
      bookingType: 'company',
      companyName: getVal('tenantChatResultCompanyName'),
      companyRegNo: getVal('tenantChatResultCompanyRegNo'),
      picName: getVal('tenantChatResultPicName'),
      contactPerson: getVal('tenantChatResultPicName'),
      picPosition: getVal('tenantChatResultPicPosition'),
      contactDesignation: getVal('tenantChatResultPicPosition'),
      picPhone: getVal('tenantChatResultPicPhone'),
      contactPhone: getVal('tenantChatResultPicPhone'),
      picEmail: getVal('tenantChatResultPicEmail'),
      contactEmail: getVal('tenantChatResultPicEmail'),
      companyAddress: getVal('tenantChatResultCompanyAddress'),
      guestCount: guestCount,
      adults: guestCount,
      children: 0,
      checkIn: getVal('tenantChatResultCompanyCheckIn'),
      checkOut: getVal('tenantChatResultCompanyCheckOut'),
      name: getVal('tenantChatResultPicName') || getVal('tenantChatResultCompanyName'),
      phone: getVal('tenantChatResultPicPhone'),
      email: getVal('tenantChatResultPicEmail'),
      address: getVal('tenantChatResultCompanyAddress'),
      ic: '',
      passport: '',
      vehicle: '',
      originalChat: originalChat
    };
  }

  const adults = parseInt(getVal('tenantChatResultAdults'), 10) || 1;
  const children = parseInt(getVal('tenantChatResultChildren'), 10) || 0;
  const icVal = getVal('tenantChatResultIc');
  const passVal = getVal('tenantChatResultPassport') || icVal;

  return {
    bookingType: 'individual',
    name: getVal('tenantChatResultName'),
    phone: getVal('tenantChatResultPhone'),
    ic: icVal,
    passport: passVal,
    email: getVal('tenantChatResultEmail'),
    vehicle: getVal('tenantChatResultVehicle'),
    adults: adults,
    children: children,
    guestCount: adults + children,
    checkIn: getVal('tenantChatResultCheckIn'),
    checkOut: getVal('tenantChatResultCheckOut'),
    address: getVal('tenantChatResultAddress'),
    companyName: '',
    companyRegNo: '',
    picName: '',
    contactPerson: '',
    picPosition: '',
    contactDesignation: '',
    picPhone: '',
    contactPhone: '',
    picEmail: '',
    contactEmail: '',
    companyAddress: '',
    originalChat: originalChat
  };
}

function handleApplyChatToBooking() {
  const data = getEditedTenantChatData();
  const isBM = appState.settings.language === 'bm';
  const todayStr = formatLocalDate(new Date());
  const bookingModalEl = document.getElementById('bookingModal');
  const isBookingModalOpen = bookingModalEl && bookingModalEl.classList.contains('active');

  if (data.bookingType === 'company') {
    let notes = `[WhatsApp Chat Import - ${todayStr}]`;
    notes += `\n[Company Booking] ${data.companyName || ''}`;
    if (data.companyRegNo) notes += ` (SSM: ${data.companyRegNo})`;
    if (data.picName) notes += `\nPIC: ${data.picName}`;
    if (data.picPosition) notes += ` (${data.picPosition})`;
    if (data.picPhone) notes += ` • Tel: ${data.picPhone}`;
    if (data.picEmail) notes += ` • Email: ${data.picEmail}`;
    if (data.originalChat) notes += `\n\n--- ${isBM ? 'Mesej Perbualan Asal' : 'Original Conversation'} ---\n${data.originalChat}`;

    if (isBookingModalOpen) {
      setBookingTenantType('company');
      const elCompName = document.getElementById('bookingCompanyName');
      if (elCompName && data.companyName) elCompName.value = data.companyName;
      const elReg = document.getElementById('bookingCompanyRegNo');
      if (elReg && data.companyRegNo) elReg.value = data.companyRegNo;
      const elCompAddr = document.getElementById('bookingCompanyAddress');
      if (elCompAddr && data.companyAddress) elCompAddr.value = data.companyAddress;
      const elCP = document.getElementById('bookingContactPerson');
      if (elCP && data.picName) elCP.value = data.picName;
      const elCD = document.getElementById('bookingContactDesignation');
      if (elCD && data.picPosition) elCD.value = data.picPosition;
      const elCPH = document.getElementById('bookingContactPhone');
      if (elCPH && data.picPhone) elCPH.value = data.picPhone;
      const elCE = document.getElementById('bookingContactEmail');
      if (elCE && data.picEmail) elCE.value = data.picEmail;
      const elGuestName = document.getElementById('bookingGuestName');
      if (elGuestName && (data.companyName || data.picName)) elGuestName.value = data.companyName || data.picName;
      const elGuestPhone = document.getElementById('bookingGuestPhone');
      if (elGuestPhone && data.picPhone) elGuestPhone.value = data.picPhone;
      const elGuestEmail = document.getElementById('bookingGuestEmail');
      if (elGuestEmail && data.picEmail) elGuestEmail.value = data.picEmail;
      const elGuestAddr = document.getElementById('bookingGuestAddress');
      if (elGuestAddr && data.companyAddress) elGuestAddr.value = data.companyAddress;
      if (data.checkIn) {
        const inEl = document.getElementById('bookingCheckIn');
        if (inEl) inEl.value = data.checkIn;
      }
      if (data.checkOut) {
        const outEl = document.getElementById('bookingCheckOut');
        if (outEl) outEl.value = data.checkOut;
      }
      if (data.guestCount) {
        const cntEl = document.getElementById('bookingGuestCount');
        if (cntEl) cntEl.value = data.guestCount;
        const occEl = document.getElementById('bookingOccupantsCount');
        if (occEl) occEl.value = data.guestCount;
      }
      const occNotesEl = document.getElementById('bookingOccupantsNotes');
      if (occNotesEl) occNotesEl.value = `${data.guestCount} ${isBM ? 'Tetamu Syarikat' : 'Company Guests'}`;
      const notesEl = document.getElementById('bookingNotes');
      if (notesEl) {
        notesEl.value = notesEl.value ? (notesEl.value + '\n\n' + notes) : notes;
      }
      const chEl = document.getElementById('bookingChannel');
      if (chEl) chEl.value = 'whatsapp';

      closeTenantChatImportModal();
      bookingModalEl.classList.add('active');
      updateBookingModalPricing();
      checkBookingModalOverlap();
      if (typeof checkBookingRepeatGuest === 'function') checkBookingRepeatGuest();
    } else {
      closeTenantChatImportModal();
      openBookingModal(null, data.checkIn || null, null, {
        tenantType: 'company',
        companyName: data.companyName,
        companyRegNo: data.companyRegNo,
        companyAddress: data.companyAddress,
        contactPerson: data.picName,
        contactDesignation: data.picPosition,
        contactPhone: data.picPhone,
        contactEmail: data.picEmail,
        guestName: data.companyName || data.picName,
        guestPhone: data.picPhone,
        guestEmail: data.picEmail,
        guestAddress: data.companyAddress,
        checkIn: data.checkIn,
        checkOut: data.checkOut,
        guestCount: data.guestCount,
        occupantsNotes: `${data.guestCount} ${isBM ? 'Tetamu Syarikat' : 'Company Guests'}`,
        notes: notes,
        channel: 'whatsapp'
      });
    }
  } else {
    // Individual
    const occParts = [];
    if (data.adults) occParts.push(`${data.adults} ${isBM ? 'Dewasa' : 'Adults'}`);
    if (data.children) occParts.push(`${data.children} ${isBM ? 'Kanak-kanak' : 'Children'}`);
    if (data.vehicle) occParts.push(`${isBM ? 'Plat Kereta' : 'Vehicle'}: ${data.vehicle}`);
    const occupantsNotes = occParts.join(' • ');

    let notes = `[WhatsApp Chat Import - ${todayStr}]`;
    if (data.vehicle) notes += `\nVehicle / Kenderaan: ${data.vehicle}`;
    if (data.originalChat) notes += `\n\n--- ${isBM ? 'Mesej Perbualan Asal' : 'Original Conversation'} ---\n${data.originalChat}`;

    if (isBookingModalOpen) {
      setBookingTenantType('individual');
      if (data.name) {
        const el = document.getElementById('bookingGuestName');
        if (el) el.value = data.name;
      }
      if (data.phone) {
        const el = document.getElementById('bookingGuestPhone');
        if (el) el.value = data.phone;
      }
      if (data.ic || data.passport) {
        const el = document.getElementById('bookingGuestNric');
        if (el) el.value = data.ic || data.passport;
      }
      if (data.email) {
        const el = document.getElementById('bookingGuestEmail');
        if (el) el.value = data.email;
      }
      if (data.address) {
        const el = document.getElementById('bookingGuestAddress');
        if (el) el.value = data.address;
      }
      if (data.checkIn) {
        const el = document.getElementById('bookingCheckIn');
        if (el) el.value = data.checkIn;
      }
      if (data.checkOut) {
        const el = document.getElementById('bookingCheckOut');
        if (el) el.value = data.checkOut;
      }
      if (data.guestCount) {
        const el = document.getElementById('bookingGuestCount');
        if (el) el.value = data.guestCount;
        const occEl = document.getElementById('bookingOccupantsCount');
        if (occEl) occEl.value = data.guestCount;
      }
      if (occupantsNotes) {
        const el = document.getElementById('bookingOccupantsNotes');
        if (el) el.value = occupantsNotes;
      }
      const notesEl = document.getElementById('bookingNotes');
      if (notesEl) {
        notesEl.value = notesEl.value ? (notesEl.value + '\n\n' + notes) : notes;
      }
      const chEl = document.getElementById('bookingChannel');
      if (chEl) chEl.value = 'whatsapp';

      closeTenantChatImportModal();
      bookingModalEl.classList.add('active');
      updateBookingModalPricing();
      checkBookingModalOverlap();
      if (typeof checkBookingRepeatGuest === 'function') checkBookingRepeatGuest();
    } else {
      closeTenantChatImportModal();
      openBookingModal(null, data.checkIn || null, null, {
        tenantType: 'individual',
        guestName: data.name,
        guestPhone: data.phone,
        guestNric: data.ic || data.passport,
        guestEmail: data.email,
        guestAddress: data.address,
        checkIn: data.checkIn,
        checkOut: data.checkOut,
        guestCount: data.guestCount,
        occupantsNotes: occupantsNotes,
        notes: notes,
        channel: 'whatsapp'
      });
    }
  }

  showToast(isBM ? '🎉 Butiran tempahan telah diisi ke dalam Borang Tempahan!' : '🎉 Booking details pre-filled into Booking Form!');
}

function handleApplyChatToContact() {
  const data = getEditedTenantChatData();
  const isBM = appState.settings.language === 'bm';

  if (!Array.isArray(appState.contacts)) {
    appState.contacts = [];
  }

  if (data.bookingType === 'company') {
    if (!data.companyName && !data.picName && !data.picPhone) {
      alert(isBM ? 'Sila pastikan sekurang-kurangnya nama syarikat atau nombor telefon PIC diekstrak.' : 'Please ensure at least a company name or PIC phone is extracted.');
      return;
    }

    const noteLines = [];
    noteLines.push(isBM ? 'Penyewa Syarikat (Korporat)' : 'Company Tenant (Corporate)');
    if (data.companyRegNo) noteLines.push(`SSM: ${data.companyRegNo}`);
    if (data.picName) noteLines.push(`PIC: ${data.picName}${data.picPosition ? ' (' + data.picPosition + ')' : ''}`);
    if (data.picPhone) noteLines.push(`PIC Tel: ${data.picPhone}`);
    if (data.picEmail) noteLines.push(`PIC Email: ${data.picEmail}`);
    if (data.companyAddress) noteLines.push(`Alamat: ${data.companyAddress}`);
    if (data.originalChat) {
      noteLines.push(`\n--- ${isBM ? 'Mesej Perbualan Asal' : 'Original Conversation'} ---\n${data.originalChat}`);
    }

    const newContact = {
      id: 'c-' + Date.now(),
      name: data.companyName || data.picName || (isBM ? 'Syarikat WhatsApp' : 'WhatsApp Company'),
      category: 'tenant',
      phone: data.picPhone || data.phone || '',
      email: data.picEmail || data.email || '',
      company: data.companyName || '',
      notes: noteLines.join('\n'),
      ic: data.companyRegNo || '',
      vehicle: '',
      address: data.companyAddress || '',
      originalChatText: data.originalChat
    };

    appState.contacts.unshift(newContact);
    saveToStorage();
    renderSettingsContactList();
    closeTenantChatImportModal();

    showToast(isBM ? `Kenalan ${newContact.name} berjaya disimpan ke direktori!` : `Contact ${newContact.name} saved to directory!`);
  } else {
    if (!data.name && !data.phone) {
      alert(isBM ? 'Sila pastikan sekurang-kurangnya nama atau nombor telefon diekstrak.' : 'Please ensure at least a name or phone number is extracted.');
      return;
    }

    const noteLines = [];
    noteLines.push(isBM ? 'Penyewa / Tetamu Tetap' : 'Tenant / Regular Guest');
    if (data.ic) noteLines.push(`IC: ${data.ic}`);
    if (data.passport && data.passport !== data.ic) noteLines.push(`Passport: ${data.passport}`);
    if (data.vehicle) noteLines.push(`Plat: ${data.vehicle}`);
    if (data.address) noteLines.push(`Alamat: ${data.address}`);
    if (data.originalChat) {
      noteLines.push(`\n--- ${isBM ? 'Mesej Perbualan Asal' : 'Original Conversation'} ---\n${data.originalChat}`);
    }

    const newContact = {
      id: 'c-' + Date.now(),
      name: data.name || (isBM ? 'Tetamu WhatsApp' : 'WhatsApp Guest'),
      category: 'tenant',
      phone: data.phone || '',
      email: data.email || '',
      company: '',
      notes: noteLines.join('\n'),
      ic: data.ic || data.passport || '',
      vehicle: data.vehicle || '',
      address: data.address || '',
      originalChatText: data.originalChat
    };

    appState.contacts.unshift(newContact);
    saveToStorage();
    renderSettingsContactList();
    closeTenantChatImportModal();

    showToast(isBM ? `Kenalan ${newContact.name} berjaya disimpan ke direktori!` : `Contact ${newContact.name} saved to directory!`);
  }
}

function handleApplyChatToBoth() {
  handleApplyChatToContact();
  handleApplyChatToBooking();
}

function setupTenantChatEventListeners() {
  document.getElementById('btnBookingModalImportChat')?.addEventListener('click', () => openTenantChatImportModal('booking'));
  document.getElementById('btnImportTenantChatBooking')?.addEventListener('click', () => openTenantChatImportModal('booking'));
  document.getElementById('btnImportTenantChatContact')?.addEventListener('click', () => openTenantChatImportModal('contact'));
  document.getElementById('btnCloseTenantChatImportModal')?.addEventListener('click', closeTenantChatImportModal);
  document.getElementById('btnCancelTenantChatImportModal')?.addEventListener('click', closeTenantChatImportModal);

  document.getElementById('btnSampleChatBM')?.addEventListener('click', () => insertSampleTenantChat('bm'));
  document.getElementById('btnSampleChatEN')?.addEventListener('click', () => insertSampleTenantChat('en'));
  document.getElementById('btnSampleChatConvo')?.addEventListener('click', () => insertSampleTenantChat('convo'));
  document.getElementById('btnSampleChatCompany')?.addEventListener('click', () => insertSampleTenantChat('company'));

  document.querySelectorAll('#tenantChatBookingTypeSegmented .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetType = btn.getAttribute('data-chat-booking-type') || 'individual';
      setTenantChatBookingType(targetType);
    });
  });

  document.getElementById('btnPasteClipboardTenantChat')?.addEventListener('click', async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        const input = document.getElementById('tenantChatInput');
        if (input && text) {
          input.value = text;
          showToast(appState.settings.language === 'bm' ? 'Teks perbualan ditampal!' : 'Conversation pasted!');
        }
      } else {
        alert(appState.settings.language === 'bm' ? 'Sila gunakan Ctrl+V untuk menampal teks.' : 'Please use Ctrl+V to paste text.');
      }
    } catch (err) {
      alert(appState.settings.language === 'bm' ? 'Sila gunakan Ctrl+V untuk menampal teks.' : 'Please use Ctrl+V to paste text.');
    }
  });

  document.getElementById('btnExtractTenantChat')?.addEventListener('click', handleTenantChatParse);
  document.getElementById('btnApplyChatToBooking')?.addEventListener('click', handleApplyChatToBooking);
  document.getElementById('btnApplyChatToContact')?.addEventListener('click', handleApplyChatToContact);
  document.getElementById('btnApplyChatToBoth')?.addEventListener('click', handleApplyChatToBoth);
}

// ==========================================================================
// 14. 1-TAP WHATSAPP AUTOMATION ENGINE
// ==========================================================================

function openWhatsAppModal(booking, templateType = 'quotation', monthIndex = 1) {
  if (!booking) return;
  closeAllModals();

  const isMonthly = booking.rentalType === 'monthly';

  // For monthly tenancies, Month 1 is settled via Move-In Package; invoice generation begins from Month 2
  let targetMonthIndex = monthIndex || 1;
  if (isMonthly && templateType === 'monthly_invoice' && targetMonthIndex === 1) {
    const invs = getOrInitMonthlyInvoices(booking);
    const pendingInv = invs.find(x => x.monthIndex >= 2 && x.status === 'pending');
    targetMonthIndex = pendingInv ? pendingInv.monthIndex : 2;
  }

  appState.activeWaBooking = booking;
  appState.activeWaTemplate = templateType;
  appState.activeWaMonthIndex = targetMonthIndex;

  const prop = getPropertyById(booking.propertyId);
  const guestRecip = document.getElementById('waGuestRecipient');
  if (guestRecip) {
    guestRecip.textContent = `${t('wa_to')}: ${booking.guestName || '-'} (${booking.guestPhone || 'No Phone Entered'})`;
  }

  // Toggle visible tabs based on rental type
  document.querySelectorAll('.wa-tab-btn').forEach(btn => {
    const tmpl = btn.getAttribute('data-template');
    btn.classList.toggle('active', tmpl === templateType);
    if (tmpl === 'monthly_invoice' || tmpl === 'monthly_rent_receipt') {
      btn.style.display = isMonthly ? 'inline-flex' : 'none';
    } else if (tmpl === 'refund_receipt') {
      btn.style.display = (isMonthly || (booking.securityDeposit && booking.securityDeposit > 0)) ? 'inline-flex' : 'none';
    } else {
      btn.style.display = 'inline-flex';
    }
  });

  // Setup monthly dropdown if monthly booking
  const monthlyControls = document.getElementById('waMonthlyControls');
  const monthSelect = document.getElementById('waInvoiceMonthSelect');
  
  if (isMonthly && (templateType === 'monthly_invoice' || templateType === 'monthly_rent_receipt')) {
    if (monthlyControls) monthlyControls.classList.remove('hidden');
    if (monthSelect) {
      monthSelect.innerHTML = '';
      const invs = getOrInitMonthlyInvoices(booking);
      invs.forEach(inv => {
        const opt = document.createElement('option');
        opt.value = inv.monthIndex;
        const isBM = appState.settings.language === 'bm';
        if (inv.monthIndex === 1) {
          if (templateType === 'monthly_invoice') {
            opt.textContent = `${isBM ? 'Bulan ke-1' : 'Month 1'} (${inv.periodStart} → ${inv.periodEnd}) [${isBM ? 'LUNAS PAKEJ KEMASUKAN - TIADA INVOIS' : 'PAID VIA MOVE-IN - NO INVOICE'}]`;
            opt.disabled = true;
          } else {
            opt.textContent = `${isBM ? 'Bulan ke-1' : 'Month 1'} (${inv.periodStart} → ${inv.periodEnd}) [${isBM ? 'LUNAS PAKEJ KEMASUKAN' : 'PAID VIA MOVE-IN'}]`;
          }
        } else {
          opt.textContent = `${isBM ? 'Bulan ke-' : 'Month '}${inv.monthIndex} (${inv.periodStart} → ${inv.periodEnd}) [${inv.status === 'paid' ? (isBM ? 'DIBAYAR' : 'PAID') : (isBM ? 'BELUM' : 'DUE')}]`;
        }
        if (inv.monthIndex === appState.activeWaMonthIndex) opt.selected = true;
        monthSelect.appendChild(opt);
      });
    }
  } else {
    if (monthlyControls) monthlyControls.classList.add('hidden');
  }

  // Setup quotation validity input if quotation template
  const waQuotationControls = document.getElementById('waQuotationControls');
  const waQuotationValidityInput = document.getElementById('waQuotationValidityInput');
  if (waQuotationControls) {
    waQuotationControls.classList.toggle('hidden', templateType !== 'quotation');
  }
  if (waQuotationValidityInput) {
    waQuotationValidityInput.value = booking.quotationValidityDays || appState.settings.quotationValidityDays || 3;
  }

  try {
    renderWhatsAppPreview();
  } catch (err) {
    console.error('Error rendering WhatsApp preview:', err);
  }
  const modal = document.getElementById('whatsappModal');
  if (modal) modal.classList.add('active');
}

function populateDispatchRecipients(selectedContactId = null, preselectedCategory = null) {
  const select = document.getElementById('dispatchRecipientSelect');
  if (!select) return;
  select.innerHTML = '';

  const contacts = appState.contacts || [];
  const isBM = appState.settings.language === 'bm';

  if (contacts.length === 0) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = isBM ? '-- Tiada Kenalan (Tambah di Tetapan) --' : '-- No Contacts Saved (Add in Settings) --';
    select.appendChild(opt);
    return;
  }

  contacts.forEach(c => {
    const opt = document.createElement('option');
    opt.value = c.id;
    const badge = getContactCategoryBadge(c.category);
    opt.textContent = `${c.name} (${badge.label})${c.company ? ' - ' + c.company : ''}`;
    select.appendChild(opt);
  });

  if (selectedContactId && contacts.some(c => c.id === selectedContactId)) {
    select.value = selectedContactId;
  } else if (preselectedCategory) {
    const matched = contacts.find(c => c.category === preselectedCategory);
    if (matched) {
      select.value = matched.id;
    } else {
      select.value = contacts[0].id;
    }
  } else {
    select.value = contacts[0].id;
  }
}

function populateDispatchProperties(selectedPropId = null) {
  const select = document.getElementById('dispatchPropertySelect');
  if (!select) return;
  select.innerHTML = '';

  const props = appState.properties || [];
  props.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.name;
    select.appendChild(opt);
  });

  if (selectedPropId && props.some(p => p.id === selectedPropId)) {
    select.value = selectedPropId;
  } else if (appState.selectedPropertyId && appState.selectedPropertyId !== 'all' && props.some(p => p.id === appState.selectedPropertyId)) {
    select.value = appState.selectedPropertyId;
  } else if (props.length > 0) {
    select.value = props[0].id;
  }
}

function openServiceDispatchModal(turnover = null, preselectedCategory = null, preselectedContactId = null) {
  appState.activeDispatchTurnover = turnover;
  const isBM = appState.settings.language === 'bm';

  const tidInput = document.getElementById('dispatchTurnoverId');
  if (tidInput) tidInput.value = turnover ? turnover.id : '';

  const targetPropId = turnover ? turnover.propertyId : null;
  populateDispatchProperties(targetPropId);

  let cat = preselectedCategory;
  if (turnover) {
    cat = 'cleaner';
    const sType = document.getElementById('dispatchServiceTypeSelect');
    if (sType) sType.value = 'turnover_clean';
    const sUrg = document.getElementById('dispatchUrgencySelect');
    if (sUrg) sUrg.value = 'normal';
    const details = document.getElementById('dispatchDetailsInput');
    if (details) {
      details.value = isBM
        ? `Pembersihan unit homestay dijadualkan pada ${turnover.date}. Sila pastikan cadar ditukar dan tuala bersih disediakan.`
        : `Turnover cleaning scheduled for ${turnover.date}. Please ensure fresh linens and towels are provided.`;
    }
  } else if (preselectedCategory) {
    const catToType = {
      cleaner: 'turnover_clean',
      aircond: 'aircond_service',
      plumber: 'plumbing_repair',
      electrician: 'electrical_repair',
      handyman: 'handyman_repair',
      linen_supplier: 'linen_order',
      gas_supplier: 'gas_order',
      locksmith: 'inspection',
      other: 'other_task'
    };
    const sType = document.getElementById('dispatchServiceTypeSelect');
    if (sType && catToType[preselectedCategory]) {
      sType.value = catToType[preselectedCategory];
    }
  }

  populateDispatchRecipients(preselectedContactId, cat);
  renderServiceDispatchPreview();
  const modal = document.getElementById('serviceDispatchModal');
  if (modal) modal.classList.add('active');
}

function openWhatsAppCleanerJob(turnover) {
  openServiceDispatchModal(turnover, 'cleaner');
}

function generateServiceDispatchMessage() {
  const isBM = appState.settings.language === 'bm';
  const recipientId = document.getElementById('dispatchRecipientSelect')?.value;
  const propId = document.getElementById('dispatchPropertySelect')?.value;
  const serviceType = document.getElementById('dispatchServiceTypeSelect')?.value || 'turnover_clean';
  const urgency = document.getElementById('dispatchUrgencySelect')?.value || 'normal';
  const customDetails = document.getElementById('dispatchDetailsInput')?.value.trim() || '';
  const includePin = document.getElementById('dispatchIncludePinCheck')?.checked;

  const contact = (appState.contacts || []).find(c => c.id === recipientId);
  const prop = getPropertyById(propId) || (appState.properties[0] || { name: 'Homestay Unit', address: '' });
  const turnover = appState.activeDispatchTurnover;
  const settings = appState.settings;

  let headerTitle = '';
  let defaultTaskDesc = '';

  switch (serviceType) {
    case 'turnover_clean':
      headerTitle = isBM ? '🧹 *ARAHAN KERJA PEMBERSIHAN / TURNOVER*' : '🧹 *TURNOVER CLEANING JOB ALERT*';
      defaultTaskDesc = isBM ? 'Pembersihan unit menyeluruh, tukar cadar, basuh tuala dan kemas bilik.' : 'Full turnover cleaning, fresh bed linens, sanitized towels & amenities restock.';
      break;
    case 'aircond_service':
      headerTitle = isBM ? '❄️ *NOTIS SERVIS & BAIKI AIRCOND*' : '❄️ *AIRCOND SERVICE & REPAIR REQUEST*';
      defaultTaskDesc = isBM ? 'Servis aircond tidak sejuk / cuci filter / pemeriksaan kebocoran.' : 'Aircond servicing, filter cleaning, or cooling troubleshooting.';
      break;
    case 'plumbing_repair':
      headerTitle = isBM ? '🔧 *NOTIS BAIKI PAIP & SALIRAN*' : '🔧 *PLUMBING REPAIR REQUEST*';
      defaultTaskDesc = isBM ? 'Baiki paip bocor, mangkuk tandas tersumbat atau water heater.' : 'Plumbing inspection, leak repair, or toilet drain troubleshooting.';
      break;
    case 'electrical_repair':
      headerTitle = isBM ? '⚡ *NOTIS PENDAWAIAN & ELEKTRIK*' : '⚡ *ELECTRICAL REPAIR REQUEST*';
      defaultTaskDesc = isBM ? 'Periksa masalah elektrik, suis rosak atau trip elektrik.' : 'Electrical wiring check, power trip, socket or lighting issue.';
      break;
    case 'handyman_repair':
      headerTitle = isBM ? '🔨 *NOTIS KERJA BAIKI AM (HANDYMAN)*' : '🔨 *GENERAL HANDYMAN REPAIR REQUEST*';
      defaultTaskDesc = isBM ? 'Kerja baiki kerosakan am pintu, perabot atau perkakasan unit.' : 'General repair for doors, hinges, furniture, or fixture maintenance.';
      break;
    case 'linen_order':
      headerTitle = isBM ? '🧺 *PESANAN BEKALAN LINEN & DOBI*' : '🧺 *LINEN & LAUNDRY SUPPLY ORDER*';
      defaultTaskDesc = isBM ? 'Pesanan tambahan cadar, sarung bantal, duvet dan tuala putih.' : 'Restock order for bedsheet sets, duvet covers, and bath towels.';
      break;
    case 'gas_order':
      headerTitle = isBM ? '⛽ *PESANAN TONG GAS & KEPERLUAN UNIT*' : '⛽ *GAS / AMENITIES RESTOCK ORDER*';
      defaultTaskDesc = isBM ? 'Penghantaran tong gas memasak atau stok sabun / syampu / kopi.' : 'Delivery order for cooking gas cylinder, toiletries, or guest amenities.';
      break;
    case 'inspection':
      headerTitle = isBM ? '🔍 *NOTIS PEMERIKSAAN UNIT*' : '🔍 *UNIT INSPECTION REQUEST*';
      defaultTaskDesc = isBM ? 'Pemeriksaan status unit, kunci pintu, peralatan dan kebersihan.' : 'General inspection of unit condition, appliances, and access.';
      break;
    default:
      headerTitle = isBM ? '📝 *ARAHAN TUGASAN KHAS*' : '📝 *SERVICE / MAINTENANCE REQUEST*';
      defaultTaskDesc = isBM ? 'Tugasan perkhidmatan berkaitan unit homestay.' : 'Service task for homestay property.';
  }

  let urgencyText = '';
  if (urgency === 'urgent') {
    urgencyText = isBM ? '🔴 *Tahap Keperluan:* SEGERA / KECEMASAN (Sila hadir secepat mungkin)\n' : '🔴 *Urgency:* URGENT / IMMEDIATE (Please attend ASAP)\n';
  } else if (urgency === 'high') {
    urgencyText = isBM ? '🟡 *Tahap Keperluan:* KEUTAMAAN TINGGI (Hari ini)\n' : '🟡 *Urgency:* HIGH PRIORITY (Today)\n';
  } else {
    urgencyText = isBM ? '🟢 *Tahap Keperluan:* Jadual Biasa\n' : '🟢 *Urgency:* Normal Schedule\n';
  }

  const recipientGreeting = contact ? (isBM ? `Salam ${contact.name}` : `Hello ${contact.name}`) : (isBM ? 'Salam sejahtera' : 'Hello');

  let body = `${headerTitle}\n\n` +
    `${recipientGreeting}, ${isBM ? 'kami memerlukan bantuan anda bagi perkhidmatan berikut:' : 'we require your service for the following property:'}\n\n` +
    `🏠 *${isBM ? 'Unit / Homestay' : 'Property'}:* ${prop.name}\n` +
    `📍 *${isBM ? 'Alamat' : 'Address'}:* ${prop.address || (isBM ? 'Alamat unit standard' : 'Standard Address')}\n` +
    (prop.gpsLocation ? `🗺️ *${isBM ? 'Peta Google Maps' : 'Google Maps GPS'}:* ${prop.gpsLocation}\n` : '') +
    urgencyText;

  if (serviceType === 'turnover_clean' || turnover) {
    const targetDate = turnover ? turnover.date : formatLocalDate(new Date());
    body += `📅 *${isBM ? 'Tarikh Tugasan' : 'Target Date'}:* ${targetDate}\n` +
            `⏰ *${isBM ? 'Waktu Pembersihan' : 'Cleaning Window'}:* ${prop.checkOutTime || '12:00 PM'} - ${prop.checkInTime || '3:00 PM'}\n`;
  }

  if (includePin && prop.doorCode) {
    body += `🔑 *${isBM ? 'Kod PIN Pintu (Smart Lock)' : 'Smart Lock Door PIN'}:* ${prop.doorCode}\n`;
  }

  const detailsText = customDetails || defaultTaskDesc;
  body += `\n📋 *${isBM ? 'ARAHAN / PERINCIAN' : 'TASK DETAILS / INSTRUCTIONS'}:*\n${detailsText}\n\n`;

  body += isBM
    ? `Sila sahkan penerimaan mesej ini dan maklumkan waktu kehadiran/penghantaran anda. Terima kasih! 🙏\n_${settings.businessName || 'Pengurusan Homestay'}_`
    : `Please acknowledge receipt and advise your estimated arrival/delivery time. Thank you! 🙏\n_${settings.businessName || 'Homestay Management'}_`;

  return body;
}

function renderServiceDispatchPreview() {
  const bubble = document.getElementById('dispatchPreviewText');
  const badge = document.getElementById('dispatchRecipientBadge');
  const time = document.getElementById('dispatchTimestamp');
  if (!bubble) return;

  const msg = generateServiceDispatchMessage();
  bubble.textContent = msg;

  const recipientId = document.getElementById('dispatchRecipientSelect')?.value;
  const contact = (appState.contacts || []).find(c => c.id === recipientId);
  if (badge) {
    if (contact) {
      badge.textContent = `To: ${contact.name} (${contact.phone})`;
    } else {
      badge.textContent = 'To: Unspecified Contact';
    }
  }

  if (time) {
    const now = new Date();
    const hrs = String(now.getHours()).padStart(2, '0');
    const mins = String(now.getMinutes()).padStart(2, '0');
    time.textContent = `${hrs}:${mins} ✓✓`;
  }
}

function handleSendServiceDispatchWa() {
  const recipientId = document.getElementById('dispatchRecipientSelect')?.value;
  const contact = (appState.contacts || []).find(c => c.id === recipientId);
  const msg = generateServiceDispatchMessage();

  let phone = '';
  if (contact && contact.phone) {
    phone = contact.phone.replace(/[^0-9]/g, '');
  }

  const waUrl = phone ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}` : `https://wa.me/?text=${encodeURIComponent(msg)}`;
  window.open(waUrl, '_blank');
  closeAllModals();
  showToast(appState.settings.language === 'bm' ? 'Mesej WhatsApp dihantar!' : 'WhatsApp dispatch opened!');
}

function handleCopyServiceDispatchText() {
  const msg = generateServiceDispatchMessage();
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(msg).then(() => {
      showToast(appState.settings.language === 'bm' ? 'Teks notis disalin!' : 'Message text copied to clipboard!');
    }).catch(() => {
      showToast('Copied to clipboard');
    });
  } else {
    showToast('Copied to clipboard');
  }
}

function generateWhatsAppMessage(booking, templateType, langOverride = null) {
  const todayStr = formatLocalDate(new Date());
  const prop = getPropertyById(booking.propertyId);
  const currency = appState.settings.currency || 'RM';
  const settings = appState.settings;
  const isBM = langOverride ? (langOverride === 'bm') : ((appState.activeWaLang || settings.language || 'bm') === 'bm');
  const isMonthly = booking.rentalType === 'monthly';
  const isRoom = prop.propType && prop.propType.startsWith('room');

  const unitTitleBM = isRoom ? `🚪 *Bilik / Unit:* ${prop.name} ${prop.roomNo ? `(${prop.roomNo})` : ''}` : `🏠 *Homestay:* ${prop.name}`;
  const unitTitleEN = isRoom ? `🚪 *Homestay Room:* ${prop.name} ${prop.roomNo ? `(${prop.roomNo})` : ''}` : `🏠 *Homestay:* ${prop.name}`;

  const tenantParticularsBM = (booking.guestNric || booking.guestEmail || booking.guestAddress)
    ? `👤 *BUTIRAN PENYEWA:*\n• Nama: *${booking.guestName}*\n` +
      (booking.guestNric ? `• No. KP / Pasport: *${booking.guestNric}*\n` : '') +
      (booking.guestPhone ? `• No. Telefon / WA: *${booking.guestPhone}*\n` : '') +
      (booking.guestEmail ? `• Emel: *${booking.guestEmail}*\n` : '') +
      (booking.guestAddress ? `• Alamat: *${booking.guestAddress}*\n` : '') + `\n`
    : `*Kepada:* ${booking.guestName} (${booking.guestPhone || 'Penyewa'})\n\n`;

  const tenantParticularsEN = (booking.guestNric || booking.guestEmail || booking.guestAddress)
    ? `👤 *TENANT PARTICULARS:*\n• Name: *${booking.guestName}*\n` +
      (booking.guestNric ? `• NRIC / Passport: *${booking.guestNric}*\n` : '') +
      (booking.guestPhone ? `• Phone / WA: *${booking.guestPhone}*\n` : '') +
      (booking.guestEmail ? `• Email: *${booking.guestEmail}*\n` : '') +
      (booking.guestAddress ? `• Address: *${booking.guestAddress}*\n` : '') + `\n`
    : `*Bill To:* ${booking.guestName} (${booking.guestPhone || 'Tenant'})\n\n`;

  const bankInfoEN = (settings.bankName && settings.bankAccNum) 
    ? `\n🏦 *BANK PAYMENT DETAILS:*\n• Bank: *${settings.bankName}*\n• Account No: *${settings.bankAccNum}*\n• Name: *${settings.bankAccHolder || settings.businessName}*${settings.duitNow ? `\n• DuitNow ID: *${settings.duitNow}*` : ''}\n` 
    : '';

  const bankInfoBM = (settings.bankName && settings.bankAccNum) 
    ? `\n🏦 *MAKLUMAT PEMBAYARAN BANK / DUITNOW:*\n• Bank: *${settings.bankName}*\n• No Akaun: *${settings.bankAccNum}*\n• Nama Pemegang: *${settings.bankAccHolder || settings.businessName}*${settings.duitNow ? `\n• DuitNow ID: *${settings.duitNow}*` : ''}\n` 
    : '';

  // Daily calculations
  const totalRental = ((booking.nights || 1) * (booking.nightlyRate || 0)) + (booking.cleaningFee || 0);
  const secDep = booking.securityDeposit || 0;
  const dep30 = Math.round(totalRental * (settings.defaultDepositPct || 30) / 100 * 100) / 100;
  const bookingFee = booking.depositPaid > 0 ? booking.depositPaid : dep30;

  // Monthly calculations
  const mRate = booking.monthlyRate || 0;
  const rDep = booking.rentalDeposit || 0;
  const uDep = booking.utilitiesDeposit || 0;
  const aFee = booking.agreementFee || 0;
  const totalMoveIn = mRate + rDep + uDep + aFee;

  // Dynamic multi-month period calculation
  const mIndex = appState.activeWaMonthIndex || 1;
  const rawDateStr = booking.checkIn || booking.monthlyStart || formatLocalDate(new Date());
  const parsedStart = new Date(rawDateStr.includes('T') ? rawDateStr : rawDateStr + 'T00:00:00');
  const startD = isNaN(parsedStart.getTime()) ? new Date() : parsedStart;
  const curMonthStart = new Date(startD);
  curMonthStart.setMonth(curMonthStart.getMonth() + (mIndex - 1));
  const curMonthEnd = new Date(curMonthStart);
  curMonthEnd.setMonth(curMonthEnd.getMonth() + 1);
  curMonthEnd.setDate(curMonthEnd.getDate() - 1);

  const startStr = formatLocalDate(curMonthStart);
  const endStr = formatLocalDate(curMonthEnd);

  const dueDate = new Date(curMonthStart);
  dueDate.setDate(dueDate.getDate() + 6);
  const dueStr = formatLocalDate(dueDate);

  const extraUtility = parseFloat(document.getElementById('waInvoiceExtraInput')?.value) || 0;
  const rentAmt = booking.monthlyRate || 0;
  const totalMonthDue = rentAmt + extraUtility;
  const bIdStr = String(booking.id || '');
  const idShort = bIdStr.slice(-5).toUpperCase() || '10001';
  const idQuoShort = bIdStr.slice(-6).toUpperCase() || '100001';
  const invNo = `INV-M${mIndex}-${idShort}`;
  const recNo = `REC-RENT-M${mIndex}-${idShort}`;

  // Quotation Validity Calculation
  const validityDays = parseInt(booking.quotationValidityDays) || parseInt(settings.quotationValidityDays) || 3;
  const expDateObj = new Date();
  expDateObj.setDate(expDateObj.getDate() + validityDays);
  const expDateStr = formatLocalDate(expDateObj);

  let msg = '';

  if (isBM) {
    switch (templateType) {
      case 'quotation':
        if (isMonthly) {
          msg = `📋 *SEBUT HARGA SEWAAN BULANAN - ${prop.name.toUpperCase()}*\n` +
            `No Rujukan: QUO-M-${idQuoShort}\n\n` +
            `Salam sejahtera *${booking.guestName}*, terima kasih atas pertanyaan sewaan bulanan anda! Berikut adalah perincian pakej sewaan:\n\n` +
            `${unitTitleBM}\n` +
            `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
            (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
            `📅 *Tarikh Mula:* ${booking.checkIn}\n` +
            `⏳ *Tempoh Sewaan:* ${booking.monthlyDuration || 6} Bulan\n` +
            `⏳ *Tempoh Sah Sebut Harga:* *${validityDays} Hari* (Sah sehingga: *${expDateStr}*)\n\n` +
            tenantParticularsBM +
            `💰 *PERINCIAN PAKEJ KEMASUKAN (MOVE-IN):*\n` +
            `• Sewa Bulan Pertama (Pendahuluan): ${currency} ${mRate.toFixed(2)}\n` +
            `• Deposit Keselamatan Sewaan (1 Bulan Sewa): ${currency} ${rDep.toFixed(2)}\n` +
            `• Deposit Utiliti / Air & Elektrik (Dipulangkan): ${currency} ${uDep.toFixed(2)}\n` +
            (aFee > 0 ? `• Yuran Perjanjian Sewa & Duti Setem: ${currency} ${aFee.toFixed(2)}\n` : '') +
            `----------------------------------------\n` +
            `💵 *JUMLAH BAYARAN KEMASUKAN:* *${currency} ${totalMoveIn.toFixed(2)}*\n` +
            `🔒 *Bayaran Booking Diperlukan untuk Kunci Unit:* *${currency} ${(booking.depositPaid > 0 ? booking.depositPaid : Math.round(mRate * 0.5)).toFixed(2)}*\n` +
            `⏳ *Baki Bayaran Sebelum Serahan Kunci:* ${currency} ${(totalMoveIn - (booking.depositPaid > 0 ? booking.depositPaid : Math.round(mRate * 0.5))).toFixed(2)}\n` +
            bankInfoBM +
            `\n📌 *SYARAT & POLISI SEWAAN BULANAN:*\n` +
            `1. Bayaran sewa bulanan dikutip secara pendahuluan (advance) pada awal setiap bulan sewaan melalui Invois Rasmi.\n` +
            `2. Bagi sewaan jangka panjang melebihi 1 bulan, bil utiliti (elektrik & air) adalah mengikut kadar penggunaan bulanan sebenar (dibayar terus oleh penyewa atau dimasukkan ke dalam invois sewa bulanan).\n` +
            `3. Deposit Keselamatan (1 bulan sewa: ${currency} ${rDep.toFixed(2)}) dan Deposit Utiliti (${currency} ${uDep.toFixed(2)}) akan dipulangkan sepenuhnya pada akhir tempoh sewaan tertakluk kepada penyelesaian bil utiliti dan pemeriksaan unit.\n` +
            `4. Sebut harga ini sah selama *${validityDays} hari* sehingga *${expDateStr}*. ✨🏡`;
        } else {
          msg = `📋 *SEBUT HARGA RASMI - ${prop.name.toUpperCase()}*\n` +
            `No Rujukan: QUO-${idQuoShort}\n\n` +
            `Salam sejahtera *${booking.guestName}*, terima kasih atas pertanyaan anda! Berikut adalah perincian harga bagi penginapan anda:\n\n` +
            `${unitTitleBM}\n` +
            `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
            (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
            `📅 *Daftar Masuk (Check-In):* ${booking.checkIn} (${prop.checkInTime || '3:00 PM'})\n` +
            `🏁 *Daftar Keluar (Check-Out):* ${booking.checkOut} (${prop.checkOutTime || '12:00 PM'})\n` +
            `🌙 *Tempoh:* ${booking.nights} Malam • ${booking.guestCount} Tetamu\n` +
            `⏳ *Tempoh Sah Sebut Harga:* *${validityDays} Hari* (Sah sehingga: *${expDateStr}*)\n\n` +
            `💰 *PERINCIAN HARGA:*\n` +
            `• Kadar Sewa: ${currency} ${(booking.nightlyRate || 0).toFixed(2)} × ${booking.nights} malam = ${currency} ${(booking.nights * booking.nightlyRate).toFixed(2)}\n` +
            `• Yuran Pembersihan: ${currency} ${(booking.cleaningFee || 0).toFixed(2)}\n` +
            (secDep > 0 ? `• Deposit Keselamatan (Dipulangkan): ${currency} ${secDep.toFixed(2)}\n` : '') +
            `----------------------------------------\n` +
            `💵 *JUMLAH KESELURUHAN:* *${currency} ${booking.totalAmount.toFixed(2)}*\n` +
            `🔒 *Bayaran Booking Diperlukan (${settings.defaultDepositPct || 30}%):* *${currency} ${bookingFee.toFixed(2)}*\n` +
            `⏳ *Baki Bayaran Sebelum Serahan Kunci:* ${currency} ${(booking.totalAmount - bookingFee).toFixed(2)}\n` +
            bankInfoBM +
            `\n📌 *Nota:* Tarikh akan ditanda sebagai *"DITEMPAH"* selepas slip bayaran booking diterima. Sebut harga ini sah selama *${validityDays} hari* sehingga *${expDateStr}*. ✨🏡`;
        }
        break;

      case 'deposit_receipt':
        if (isMonthly) {
          msg = `🧾 *RESIT BAYARAN BOOKING & DEPOSIT SEWAAN - ${prop.name.toUpperCase()}*\n` +
            `No Resit: REC-BOOK-M-${idQuoShort}\n\n` +
            `Salam *${booking.guestName}*, bayaran booking sewaan bulanan anda telah disahkan! 🎉\n` +
            `Unit kini berstatus *DITEMPAH & DIKUNCI* untuk kemasukan anda.\n\n` +
            `${unitTitleBM}\n` +
            `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
            (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
            `📅 *Tarikh Kemasukan:* ${booking.checkIn}\n` +
            `⏳ *Tempoh Sewaan:* ${booking.monthlyDuration || 6} Bulan\n\n` +
            tenantParticularsBM +
            `💰 *REKOD BAYARAN:*\n` +
            `• Jumlah Pakej Kemasukan: ${currency} ${totalMoveIn.toFixed(2)}\n` +
            `• ✅ *Bayaran Booking Diterima:* *${currency} ${booking.depositPaid.toFixed(2)}*\n` +
            (booking.lastPaymentRef ? `• 🔖 *No. Rujukan Bank:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Pindahan Bank'})\n` : '') +
            `----------------------------------------\n` +
            `💳 *Baki Perlu Dibayar Sebelum Serahan Kunci:* *${currency} ${booking.balance.toFixed(2)}*\n\n` +
            `🔑 *Kunci & Smart Lock PIN:* Akan diserahkan selepas baki pakej kemasukan dijelaskan sepenuhnya. Terima kasih! 🙏`;
        } else {
          msg = `🧾 *RESIT BAYARAN BOOKING & DEPOSIT - ${prop.name.toUpperCase()}*\n` +
            `No Resit: REC-DEP-${idQuoShort}\n\n` +
            `Salam *${booking.guestName}*, bayaran booking dan deposit anda telah diterima! 🎉\n` +
            `Unit anda kini secara rasmi berstatus *DITEMPAH & DIKUNCI* di kalendar kami.\n\n` +
            `${unitTitleBM}\n` +
            `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
            (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
            `📅 *Daftar Masuk:* ${booking.checkIn} (${prop.checkInTime || '3:00 PM'})\n` +
            `🏁 *Daftar Keluar:* ${booking.checkOut} (${prop.checkOutTime || '12:00 PM'})\n\n` +
            `💰 *REKOD BAYARAN:*\n` +
            `• Jumlah Penginapan: ${currency} ${booking.totalAmount.toFixed(2)}\n` +
            `• ✅ *Deposit / Booking Diterima:* *${currency} ${booking.depositPaid.toFixed(2)}*\n` +
            (booking.lastPaymentRef ? `• 🔖 *No. Rujukan Bank:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Pindahan Bank'})\n` : '') +
            `----------------------------------------\n` +
            `💳 *Baki Bayaran Sebelum Daftar Masuk:* *${currency} ${booking.balance.toFixed(2)}*\n\n` +
            `🔑 *Kod PIN Kunci Pintu:* Akan diberikan selepas pengesahan bayaran penuh sebelum waktu daftar masuk. Terima kasih! 🏡✨`;
        }
        break;

      case 'checkin_reminder':
        msg = `📅 *PERINGATAN DAFTAR MASUK (CHECK-IN) - ${prop.name.toUpperCase()}*\n\n` +
          `Salam mesra *${booking.guestName}*, kami menantikan kehadiran anda tidak lama lagi! Berikut adalah maklumat penting bagi persediaan daftar masuk anda:\n\n` +
          `${unitTitleBM}\n` +
          `📅 *Tarikh Daftar Masuk:* ${booking.checkIn}\n` +
          `⏰ *Waktu Masuk:* Mulai jam *${prop.checkInTime || '3:00 PM'}* ke atas\n` +
          `🏁 *Tarikh Daftar Keluar:* ${booking.checkOut} (sebelum ${prop.checkOutTime || '12:00 PM'})\n\n` +
          `📍 *Alamat Homestay:* ${prop.address || 'Alamat Unit'}\n` +
          (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `\n🔑 *MAKLUMAT AKSES & KUNCI:*\n` +
          (booking.status === 'confirmed' || booking.balance <= 0 
            ? `• Kod PIN Smart Lock Pintu: *${prop.doorCode || '123456#'}*\n• Nama WiFi: *${prop.wifiName || 'Homestay_WiFi'}*\n• Kata Laluan WiFi: *${prop.wifiPass || 'welcome123'}*\n` 
            : `• Kod PIN pintu & kata laluan WiFi akan diserahkan serta-merta selepas baki bayaran dijelaskan.\n`) +
          (booking.balance > 0 
            ? `\n💳 *Peringatan Baki Bayaran:* *${currency} ${booking.balance.toFixed(2)}* (Sila jelaskan sebelum waktu masuk).\n` + bankInfoBM 
            : `\n✅ *Status Bayaran:* Selesai Dibayar Penuh (${currency} ${booking.totalAmount.toFixed(2)})\n`) +
          `\n📜 *Peraturan Homestay:* ${prop.rules || 'Dilarang merokok di dalam unit, jaga ketenteraman selepas 10 malam.'}\n\n` +
          `Jika anda memerlukan sebarang bantuan atau panduan arah, sila balas mesej ini pada bila-bila masa. Selamat bertolak dan semoga perjalanan anda lancar & selamat! ✨🏡`;
        break;

      case 'full_receipt':
        msg = `🔑 *RESIT BAYARAN PENUH & PANDUAN MASUK - ${prop.name.toUpperCase()}*\n` +
          `No Resit: REC-FULL-${idQuoShort}\n\n` +
          `Salam *${booking.guestName}*! Bayaran penuh telah disahkan dan tempahan anda kini *100% DISAHKAN*. Berikut adalah maklumat akses masuk anda:\n\n` +
          `${unitTitleBM}\n` +
          `💰 *STATUS BAYARAN: SELESAI DIBAYAR PENUH (100%) ✅*\n` +
          `• Jumlah Dibayar: ${currency} ${booking.totalAmount.toFixed(2)}\n` +
          (booking.lastPaymentRef ? `• 🔖 *No. Rujukan Bank:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Pindahan Bank'})\n` : '') +
          `• Baki Bayaran: ${currency} 0.00\n\n` +
          `========================================\n` +
          `🔑 *MAKLUMAT AKSES & KUNCI PINTU PINTAR:*\n` +
          `========================================\n` +
          `📍 *Alamat:* ${prop.address || 'Alamat Unit'}\n` +
          (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `⏰ *Waktu Daftar Masuk:* Hari ini dari jam ${prop.checkInTime || '3:00 PM'} ke atas\n` +
          `🔐 *Kod PIN Smart Lock Pintu:* *${prop.doorCode || '123456#'}*\n` +
          `📶 *Nama WiFi:* ${prop.wifiName || 'Homestay_WiFi'}\n` +
          `🔑 *Kata Laluan WiFi:* *${prop.wifiPass || 'welcome123'}*\n\n` +
          `📜 *Peraturan:* ${prop.rules || 'Dilarang merokok di dalam rumah, jaga ketenteraman selepas 10 malam.'}\n\n` +
          `Selamat menikmati penginapan anda! Sila hubungi kami bila-bila masa jika memerlukan bantuan. ✨🏡`;
        break;

      case 'monthly_invoice':
        msg = `📑 *INVOIS SEWAAN BULANAN (BULAN KE-${mIndex} DRPD ${booking.monthlyDuration || 6})*\n` +
          `No. Invois: *${invNo}*\n` +
          `Tarikh Invois: *${todayStr}*\n` +
          `Tarikh Akhir Bayaran: *${dueStr}*\n\n` +
          tenantParticularsBM +
          `${unitTitleBM}\n` +
          `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
          (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') + `\n` +
          `📅 *TEMPOH BIL SEWAAN:*\n` +
          `• Dari: *${startStr}* Hingga: *${endStr}* (Bulan ke-${mIndex})\n\n` +
          `💵 *PERINCIAN BAYARAN:*\n` +
          `• Sewa Bulanan: *${currency} ${rentAmt.toFixed(2)}*\n` +
          (extraUtility > 0 ? `• Caj Utiliti / Tambahan: *${currency} ${extraUtility.toFixed(2)}*\n` : '') +
          `----------------------------------------\n` +
          `💳 *JUMLAH PERLU DIBAYAR:* *${currency} ${totalMonthDue.toFixed(2)}*\n` +
          bankInfoBM +
          `\n📌 *Nota:* Sila jelaskan bayaran sebelum *${dueStr}* dan hantar salinan resit transaksi ke WhatsApp ini. Terima kasih atas kerjasama anda! 🙏✨`;
        break;

      case 'monthly_rent_receipt':
        msg = `🧾 *RESIT RASMI BAYARAN SEWA (BULAN KE-${mIndex})*\n` +
          `No. Resit: *${recNo}*\n` +
          `Tarikh: *${todayStr}*\n\n` +
          `Salam *${booking.guestName}*, bayaran sewa bulanan anda bagi *Bulan ke-${mIndex}* telah diterima dan disahkan! 🎉\n\n` +
          tenantParticularsBM +
          `${unitTitleBM}\n` +
          `📅 *Tempoh Sewaan:* ${startStr} hingga ${endStr} (Bulan ke-${mIndex})\n` +
          `💰 *Jumlah Diterima:* *${currency} ${totalMonthDue.toFixed(2)}*\n` +
          (booking.lastPaymentRef ? `• 🔖 *No. Rujukan Bank:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Pindahan Bank'})\n` : '') +
          `✅ *Status Bayaran:* SELESAI DIBAYAR (PAID)\n\n` +
          `Terima kasih atas pembayaran anda yang tepat pada masanya! 🙏✨`;
        break;

      case 'refund_receipt':
        const ref = booking.refundDetails || {
          rentalDep: booking.rentalDeposit || 0,
          utilDep: booking.utilitiesDeposit || booking.securityDeposit || 0,
          dedUtil: 0,
          dedRepair: 0,
          netRefund: (booking.rentalDeposit || 0) + (booking.utilitiesDeposit || booking.securityDeposit || 0),
          notes: 'Deposit dipulangkan sepenuhnya.'
        };
        msg = `💰 *PENYATA PEMULANGAN DEPOSIT SEWAAN - ${prop.name.toUpperCase()}*\n` +
          `No Rujukan: REF-${idQuoShort}\n\n` +
          tenantParticularsBM +
          `${unitTitleBM}\n` +
          `📅 *Tarikh Tamat Sewaan:* ${booking.checkOut}\n\n` +
          `📊 *RINGKASAN DEPOSIT:*\n` +
          `• Deposit Sewa Dipegang: ${currency} ${ref.rentalDep.toFixed(2)}\n` +
          `• Deposit Utiliti Dipegang: ${currency} ${ref.utilDep.toFixed(2)}\n` +
          `----------------------------------------\n` +
          `➕ *Jumlah Deposit Dipegang:* ${currency} ${(ref.rentalDep + ref.utilDep).toFixed(2)}\n\n` +
          `📉 *TOLAKAN / DEDUCTIONS:*\n` +
          `• Tunggakan Bil Utiliti (TNB/Air): - ${currency} ${ref.dedUtil.toFixed(2)}\n` +
          `• Kos Pembaikan / Pembersihan: - ${currency} ${ref.dedRepair.toFixed(2)}\n` +
          `----------------------------------------\n` +
          `💵 *JUMLAH BERSIH DIPULANGKAN:* *${currency} ${ref.netRefund.toFixed(2)}* ✅\n\n` +
          `📝 *Catatan Tolakan:* ${ref.notes || 'Tiada'}\n\n` +
          `Terima kasih kerana menyewa bersama kami dan menjaga unit dengan baik! Semoga maju jaya. 🙏✨`;
        break;

      case 'checkout':
        msg = `🏁 *Peringatan Daftar Keluar / Tamat Sewaan - ${prop.name}*\n\n` +
          `Salam *${booking.guestName}*, semoga anda menikmati penginapan yang menyenangkan bersama kami!\n\n` +
          `⏰ *Waktu Daftar Keluar:* Hari ini sebelum jam ${prop.checkOutTime || '12:00 PM'}\n\n` +
          `Sebelum bertolak, mohon kerjasama untuk:\n` +
          `1. Padamkan semua suis lampu dan penyaman udara (air-cond)\n` +
          `2. Pastikan semua pintu dan tingkap dikunci rapi\n` +
          `3. Serahkan kembali kunci atau masukkan ke dalam peti kunci pintar\n\n` +
          `Pemeriksaan unit dan pemulangan baki deposit keselamatan akan diproses selepas pemeriksaan selesai. Terima kasih! ⭐⭐⭐⭐⭐`;
        break;

      case 'cleaner':
        msg = `🧹 *Notis Pembersihan / Turnover - ${prop.name}*\n\n` +
          `Kerja pembersihan diperlukan untuk ${prop.name} pada ${booking.checkOut}.\n` +
          `Tetamu ${booking.guestName} daftar keluar jam ${prop.checkOutTime || '12:00 PM'}.\n` +
          (prop.address ? `Alamat: ${prop.address}\n` : '') +
          (prop.gpsLocation ? `Lokasi GPS: ${prop.gpsLocation}\n` : '') +
          `Kod PIN Smart Lock untuk diset: ${prop.doorCode || '1234'}.`;
        break;

      case 'payment':
        msg = `💳 *Peringatan Baki Bayaran - ${prop.name}*\n\n` +
          `Salam *${booking.guestName}*, ini adalah peringatan mesra bagi baki bayaran penginapan anda:\n\n` +
          `📅 *Tarikh:* ${booking.checkIn} hingga ${booking.checkOut}\n` +
          `💰 *Baki Bayaran:* *${currency} ${booking.balance.toFixed(2)}*\n` +
          bankInfoBM +
          `\nSila jelaskan baki sebelum daftar masuk untuk menerima kod akses masuk. Terima kasih! 🙏`;
        break;

      default:
        msg = '';
        break;
    }
    return msg;
  }

  // English Templates
  switch (templateType) {
    case 'quotation':
      if (isMonthly) {
        msg = `📋 *MONTHLY TENANCY QUOTATION - ${prop.name.toUpperCase()}*\n` +
          `Ref: QUO-M-${idQuoShort}\n\n` +
          `Hi *${booking.guestName}*, thank you for your monthly rental enquiry! Here is the tenancy move-in package breakdown:\n\n` +
          `${unitTitleEN}\n` +
          `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
          (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `📅 *Tenancy Start Date:* ${booking.checkIn}\n` +
          `⏳ *Duration:* ${booking.monthlyDuration || 6} Months\n` +
          `⏳ *Quotation Validity:* *${validityDays} Day(s)* (Valid until: *${expDateStr}*)\n\n` +
          tenantParticularsEN +
          `💰 *MOVE-IN INITIAL PACKAGE BREAKDOWN:*\n` +
          `• 1st Month Advance Rent: ${currency} ${mRate.toFixed(2)}\n` +
          `• Rental Security Deposit (1 Month Rent): ${currency} ${rDep.toFixed(2)}\n` +
          `• Utilities Deposit (Water & Electricity): ${currency} ${uDep.toFixed(2)}\n` +
          (aFee > 0 ? `• Tenancy Agreement & Stamp Duty: ${currency} ${aFee.toFixed(2)}\n` : '') +
          `----------------------------------------\n` +
          `💵 *TOTAL MOVE-IN PACKAGE:* *${currency} ${totalMoveIn.toFixed(2)}*\n` +
          `🔒 *Booking Fee Required to Reserve Unit:* *${currency} ${(booking.depositPaid > 0 ? booking.depositPaid : Math.round(mRate * 0.5)).toFixed(2)}*\n` +
          `⏳ *Balance Due upon Key Handover:* ${currency} ${(totalMoveIn - (booking.depositPaid > 0 ? booking.depositPaid : Math.round(mRate * 0.5))).toFixed(2)}\n` +
          bankInfoEN +
          `\n📌 *MONTHLY TENANCY TERMS & POLICIES:*\n` +
          `1. Monthly rental is collected in advance at the beginning of each rental month via official invoice.\n` +
          `2. For long-term rentals exceeding 1 month, utilities (electricity & water) are charged based on actual monthly usage (paid directly by tenant or added into monthly rental invoice).\n` +
          `3. Rental Deposit (1 month rent: ${currency} ${rDep.toFixed(2)}) and Utilities Deposit (${currency} ${uDep.toFixed(2)}) are fully refundable at the end of tenancy subject to utility clearance and unit inspection.\n` +
          `4. Quotation is valid for *${validityDays} day(s)* until *${expDateStr}*. ✨🏡`;
      } else {
        msg = `📋 *OFFICIAL QUOTATION - ${prop.name.toUpperCase()}*\n` +
          `Ref: QUO-${idQuoShort}\n\n` +
          `Hi *${booking.guestName}*, thank you for your enquiry! Here is the price breakdown for your stay:\n\n` +
          `${unitTitleEN}\n` +
          `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
          (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `📅 *Check-In:* ${booking.checkIn} (${prop.checkInTime || '3:00 PM'})\n` +
          `🏁 *Check-Out:* ${booking.checkOut} (${prop.checkOutTime || '12:00 PM'})\n` +
          `🌙 *Stay Duration:* ${booking.nights} Night(s) • ${booking.guestCount} Guest(s)\n` +
          `⏳ *Quotation Validity:* *${validityDays} Day(s)* (Valid until: *${expDateStr}*)\n\n` +
          `💰 *PRICE BREAKDOWN:*\n` +
          `• Nightly Rate: ${currency} ${(booking.nightlyRate || 0).toFixed(2)} × ${booking.nights} nights = ${currency} ${(booking.nights * booking.nightlyRate).toFixed(2)}\n` +
          `• Cleaning Fee: ${currency} ${(booking.cleaningFee || 0).toFixed(2)}\n` +
          (secDep > 0 ? `• Security Deposit (Refundable): ${currency} ${secDep.toFixed(2)}\n` : '') +
          `----------------------------------------\n` +
          `💵 *TOTAL STAY PRICE:* *${currency} ${booking.totalAmount.toFixed(2)}*\n` +
          `🔒 *Booking Fee Required to Lock Dates (${settings.defaultDepositPct || 30}%):* *${currency} ${bookingFee.toFixed(2)}*\n` +
          `⏳ *Balance Due upon Key Handover:* ${currency} ${(booking.totalAmount - bookingFee).toFixed(2)}\n` +
          bankInfoEN +
          `\n📌 *Next Step:* Unit will be reserved and labelled *"BOOKED"* immediately upon booking fee receipt. Quotation valid for *${validityDays} day(s)* until *${expDateStr}*. Let us know to secure your dates! ✨🏡`;
      }
      break;

    case 'deposit_receipt':
      if (isMonthly) {
        msg = `🧾 *TENANCY BOOKING & DEPOSIT RECEIPT - ${prop.name.toUpperCase()}*\n` +
          `Receipt No: REC-BOOK-M-${idQuoShort}\n\n` +
          `Hi *${booking.guestName}*, your tenancy booking fee has been received! 🎉\n` +
          `The property is now officially *BOOKED & RESERVED* for your move-in.\n\n` +
          `${unitTitleEN}\n` +
          `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
          (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `📅 *Move-In Date:* ${booking.checkIn}\n` +
          `⏳ *Tenancy Period:* ${booking.monthlyDuration || 6} Months\n\n` +
          tenantParticularsEN +
          `💰 *PAYMENT RECORD:*\n` +
          `• Total Move-In Package: ${currency} ${totalMoveIn.toFixed(2)}\n` +
          `• ✅ *Booking Fee Received:* *${currency} ${booking.depositPaid.toFixed(2)}*\n` +
          (booking.lastPaymentRef ? `• 🔖 *Bank Reference No:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Bank Transfer'})\n` : '') +
          `----------------------------------------\n` +
          `💳 *Remaining Balance Due Before Keys Handover:* *${currency} ${booking.balance.toFixed(2)}*\n\n` +
          `🔑 *Keys & Smart Lock PIN:* Will be released upon full settlement of the remaining move-in balance. Thank you! 🙏`;
      } else {
        msg = `🧾 *BOOKING & DEPOSIT PAYMENT RECEIPT - ${prop.name.toUpperCase()}*\n` +
          `Receipt No: REC-DEP-${idQuoShort}\n\n` +
          `Hi *${booking.guestName}*, we have received your booking fee & deposit! 🎉\n` +
          `Your unit is now officially *BOOKED & RESERVED* on our calendar.\n\n` +
          `${unitTitleEN}\n` +
          `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
          (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `📅 *Check-In:* ${booking.checkIn} (${prop.checkInTime || '3:00 PM'})\n` +
          `🏁 *Check-Out:* ${booking.checkOut} (${prop.checkOutTime || '12:00 PM'})\n\n` +
          `💰 *PAYMENT RECORD:*\n` +
          `• Total Stay Amount: ${currency} ${booking.totalAmount.toFixed(2)}\n` +
          `• ✅ *Deposit / Booking Received:* *${currency} ${booking.depositPaid.toFixed(2)}*\n` +
          (booking.lastPaymentRef ? `• 🔖 *Bank Reference No:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Bank Transfer'})\n` : '') +
          `----------------------------------------\n` +
          `💳 *Remaining Balance to Pay Before Check-In:* *${currency} ${booking.balance.toFixed(2)}*\n\n` +
          `🔑 *Smart Lock Access Code:* Will be released upon full payment confirmation before check-in. Thank you! 🏡✨`;
      }
      break;

    case 'checkin_reminder':
      msg = `📅 *CHECK-IN REMINDER & ARRIVAL GUIDE - ${prop.name.toUpperCase()}*\n\n` +
        `Hi *${booking.guestName}*, we look forward to welcoming you soon! Here are the essential details for your upcoming stay:\n\n` +
        `${unitTitleEN}\n` +
        `📅 *Check-In Date:* ${booking.checkIn}\n` +
        `⏰ *Check-In Time:* From *${prop.checkInTime || '3:00 PM'}* onwards\n` +
        `🏁 *Check-Out Date:* ${booking.checkOut} (by ${prop.checkOutTime || '12:00 PM'})\n\n` +
        `📍 *Address:* ${prop.address || 'Standard Address'}\n` +
        (prop.gpsLocation ? `🗺️ *GPS / Google Maps Link:* ${prop.gpsLocation}\n` : '') +
        `\n🔑 *SELF CHECK-IN & ACCESS:*\n` +
        (booking.status === 'confirmed' || booking.balance <= 0
          ? `• Door Smart Lock PIN: *${prop.doorCode || '123456#'}*\n• WiFi Network: *${prop.wifiName || 'Homestay_WiFi'}*\n• WiFi Password: *${prop.wifiPass || 'welcome123'}*\n`
          : `• Door access PIN and WiFi credentials will be released immediately upon balance settlement before check-in.\n`) +
        (booking.balance > 0
          ? `\n💳 *Remaining Balance Due:* *${currency} ${booking.balance.toFixed(2)}* (Kindly settle before arrival).\n` + bankInfoEN
          : `\n✅ *Payment Status:* Paid in Full (${currency} ${booking.totalAmount.toFixed(2)})\n`) +
        `\n📜 *House Rules:* ${prop.rules || 'No smoking indoors, quiet hours after 10 PM.'}\n\n` +
        `If you need any assistance or driving directions, feel free to message us here anytime. Safe travels and see you soon! ✨🏡`;
      break;

    case 'full_receipt':
      msg = `🔑 *FULL PAYMENT RECEIPT & ACCESS GUIDE - ${prop.name.toUpperCase()}*\n` +
        `Receipt No: REC-FULL-${idQuoShort}\n\n` +
        `Hi *${booking.guestName}*! Full payment has been received and your booking is *100% CONFIRMED*. Here are your self check-in access keys:\n\n` +
        `${unitTitleEN}\n` +
        `💰 *PAYMENT STATUS: PAID IN FULL (100%) ✅*\n` +
        `• Total Paid: ${currency} ${booking.totalAmount.toFixed(2)}\n` +
        (booking.lastPaymentRef ? `• 🔖 *Bank Reference No:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Bank Transfer'})\n` : '') +
        `• Balance Due: ${currency} 0.00\n\n` +
        `========================================\n` +
        `🔑 *YOUR ACCESS & DOOR LOCK DETAILS:*\n` +
        `========================================\n` +
        `📍 *Address:* ${prop.address || 'Standard Address'}\n` +
        (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
        `⏰ *Check-In Time:* Today from ${prop.checkInTime || '3:00 PM'} onwards\n` +
        `🔐 *Door Smart Lock PIN:* *${prop.doorCode || '123456#'}*\n` +
        `📶 *WiFi Name:* ${prop.wifiName || 'Homestay_WiFi'}\n` +
        `🔑 *WiFi Password:* *${prop.wifiPass || 'welcome123'}*\n\n` +
        `📜 *House Rules:* ${prop.rules || 'No smoking inside, quiet hours after 10 PM.'}\n\n` +
        `Have a wonderful stay with us! If you need anything, message us anytime. ✨🏡`;
      break;

    case 'monthly_invoice':
      msg = `📑 *MONTHLY RENTAL INVOICE (MONTH ${mIndex} OF ${booking.monthlyDuration || 6})*\n` +
        `Invoice No: *${invNo}*\n` +
        `Invoice Date: *${todayStr}*\n` +
        `Payment Due Date: *${dueStr}*\n\n` +
        tenantParticularsEN +
        `${unitTitleEN}\n` +
        `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
        (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') + `\n` +
        `📅 *BILLING PERIOD:*\n` +
        `• Period: *${startStr} to ${endStr}* (Month ${mIndex})\n\n` +
        `💵 *PAYMENT BREAKDOWN:*\n` +
        `• Monthly Rental: *${currency} ${rentAmt.toFixed(2)}*\n` +
        (extraUtility > 0 ? `• Utilities / Extra Surcharge: *${currency} ${extraUtility.toFixed(2)}*\n` : '') +
        `----------------------------------------\n` +
        `💳 *TOTAL AMOUNT DUE:* *${currency} ${totalMonthDue.toFixed(2)}*\n` +
        bankInfoEN +
        `\n📌 *Note:* Please settle payment on or before *${dueStr}* and forward the transfer receipt. Thank you for your cooperation! 🙏✨`;
      break;

    case 'monthly_rent_receipt':
      msg = `🧾 *OFFICIAL RENT PAYMENT RECEIPT (MONTH ${mIndex})*\n` +
        `Receipt No: *${recNo}*\n` +
        `Date: *${todayStr}*\n\n` +
        `Dear *${booking.guestName}*, your monthly rent payment for *Month ${mIndex}* has been received and verified! 🎉\n\n` +
        tenantParticularsEN +
        `${unitTitleEN}\n` +
        `📅 *Rental Period:* ${startStr} to ${endStr} (Month ${mIndex})\n` +
        `💰 *Amount Received:* *${currency} ${totalMonthDue.toFixed(2)}*\n` +
        (booking.lastPaymentRef ? `• 🔖 *Bank Reference No:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Bank Transfer'})\n` : '') +
        `✅ *Status:* PAID IN FULL\n\n` +
        `Thank you for your prompt payment! 🙏✨`;
      break;

    case 'refund_receipt':
      const refEN = booking.refundDetails || {
        rentalDep: booking.rentalDeposit || 0,
        utilDep: booking.utilitiesDeposit || booking.securityDeposit || 0,
        dedUtil: 0,
        dedRepair: 0,
        netRefund: (booking.rentalDeposit || 0) + (booking.utilitiesDeposit || booking.securityDeposit || 0),
        notes: 'Full deposit refunded.'
      };
      msg = `💰 *TENANCY DEPOSIT REFUND STATEMENT - ${prop.name.toUpperCase()}*\n` +
        `Ref: REF-${idQuoShort}\n\n` +
        tenantParticularsEN +
        `${unitTitleEN}\n` +
        `📅 *Tenancy End Date:* ${booking.checkOut}\n\n` +
        `📊 *DEPOSITS HELD:*\n` +
        `• Rental Deposit Held: ${currency} ${refEN.rentalDep.toFixed(2)}\n` +
        `• Utilities Deposit Held: ${currency} ${refEN.utilDep.toFixed(2)}\n` +
        `----------------------------------------\n` +
        `➕ *Total Deposits Held:* ${currency} ${(refEN.rentalDep + refEN.utilDep).toFixed(2)}\n\n` +
        `📉 *DEDUCTIONS:*\n` +
        `• Utility Arrears (TNB/Water): - ${currency} ${refEN.dedUtil.toFixed(2)}\n` +
        `• Repairs / Cleaning Costs: - ${currency} ${refEN.dedRepair.toFixed(2)}\n` +
        `----------------------------------------\n` +
        `💵 *NET REFUND TO TENANT:* *${currency} ${refEN.netRefund.toFixed(2)}* ✅\n\n` +
        `📝 *Deduction Notes:* ${refEN.notes || 'None'}\n\n` +
        `Thank you for staying with us and taking care of the property! Wishing you all the best. 🙏✨`;
      break;

    case 'checkout':
      msg = `🏁 *Check-Out / Tenancy End Reminder - ${prop.name}*\n\n` +
        `Hi *${booking.guestName}*, we hope you had a fantastic stay with us!\n\n` +
        `⏰ *Check-Out Time:* Today by ${prop.checkOutTime || '12:00 PM'}\n\n` +
        `Before you depart, kindly:\n` +
        `1. Turn off all lights and air-conditioners\n` +
        `2. Ensure doors/windows are safely locked\n` +
        `3. Return keys or lock in the smart lockbox\n\n` +
        `Deposit refunds will be inspected and processed promptly after key return. Thank you! ⭐⭐⭐⭐⭐`;
      break;

    case 'cleaner':
      msg = `🧹 *Turnover Notice - ${prop.name}*\n\n` +
        `Turnover required for ${prop.name} on ${booking.checkOut}.\n` +
        `Guest ${booking.guestName} checking out at ${prop.checkOutTime || '12:00 PM'}.\n` +
        (prop.address ? `Address: ${prop.address}\n` : '') +
        (prop.gpsLocation ? `GPS Location: ${prop.gpsLocation}\n` : '') +
        `Smart Lock PIN to reset: ${prop.doorCode || '1234'}.`;
      break;

    case 'payment':
      msg = `💳 *Payment Reminder - ${prop.name}*\n\n` +
        `Hi *${booking.guestName}*, gentle reminder regarding the remaining balance for your stay:\n\n` +
        `📅 *Dates:* ${booking.checkIn} to ${booking.checkOut}\n` +
        `💰 *Balance Due:* *${currency} ${booking.balance.toFixed(2)}*\n` +
        bankInfoEN +
        `\nKindly settle the balance before check-in to receive your door access PIN. Thank you! 🙏`;
      break;

    default:
      msg = '';
      break;
  }

  // Append Standard Notes / Footer (Customer-facing templates only)
  if (msg) {
    const stdNotes = (settings.standardNotes || '').trim();
    if (stdNotes && templateType !== 'cleaner') {
      const header = isBM ? '\n\n📝 *NOTA PENTING:*' : '\n\n📝 *IMPORTANT NOTES:*';
      msg = msg.trim() + `${header}\n${stdNotes}`;
    }
  }

  return msg;
}

function renderWhatsAppPreview() {
  if (!appState.activeWaBooking) return;
  const msg = generateWhatsAppMessage(appState.activeWaBooking, appState.activeWaTemplate);
  document.getElementById('waMessagePreviewText').textContent = msg;

  const now = new Date();
  document.getElementById('waTimestamp').textContent = `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')} ✓✓`;
}

function handleCopyWaText() {
  const text = document.getElementById('waMessagePreviewText').textContent;
  navigator.clipboard.writeText(text).then(() => {
    showToast('Message copied to clipboard!');
  }).catch(() => {
    showToast('Copied text!');
  });
}

function handleSendWaDirect() {
  if (!appState.activeWaBooking) return;
  const text = document.getElementById('waMessagePreviewText').textContent;
  const phone = (appState.activeWaBooking.guestPhone || '').replace(/[^0-9]/g, '');
  const url = phone ? `https://wa.me/${phone}?text=${encodeURIComponent(text)}` : `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

// ==========================================================================
// 14B. CORPORATE & OFFICE PDF DOCUMENT GENERATION (v2.6.5)
// ==========================================================================

const PDF_DOC_I18N = {
  bm: {
    docBadgeQuotation: 'SEBUT HARGA RASMI',
    docTitleQuotation: 'Sebut Harga',
    docBadgeInvoice: 'INVOIS RASMI',
    docTitleInvoice: 'Invois',
    docBadgeDepositReceipt: 'RESIT DEPOSIT DITERIMA',
    docTitleDepositReceipt: 'Resit Bayaran Deposit',
    docBadgeReceipt: 'RESIT RASMI PEMBAYARAN',
    docTitleReceipt: 'Resit Rasmi Bayaran Penuh',

    lblPdfDocNoTitleQuotation: 'No. Sebut Harga:',
    lblPdfDocNoTitleInvoice: 'No. Invois:',
    lblPdfDocNoTitleDepositReceipt: 'No. Resit Deposit:',
    lblPdfDocNoTitleReceipt: 'No. Resit Rasmi:',
    lblPdfDocDateTitleQuotation: 'Tarikh Sebut Harga:',
    lblPdfDocDateTitleInvoice: 'Tarikh Invois:',
    lblPdfDocDateTitleDepositReceipt: 'Tarikh Resit:',
    lblPdfDocDateTitleReceipt: 'Tarikh Resit:',
    lblPdfValidityTitle: 'Tempoh Sah:',
    lblPdfLpoTitle: 'No. LPO / Ruj:',
    lblPdfPayMethodTitle: 'Kaedah Bayaran:',
    lblPdfBillTo: 'Dikeluarkan Kepada',

    thPdfItem: 'Perkara / Huraian',
    thPdfQty: 'Kuantiti',
    thPdfRate: 'Kadar Seunit',
    thPdfTax: 'Cukai / SST',
    thPdfAmount: 'Jumlah',

    lblPdfSubTotalTable: 'Jumlah Kasar Pakej',
    lblPdfExtraCharges: 'Caj Tambahan (+)',
    lblPdfTaxableAmount: 'Jumlah Kasar Pakej Penginapan',
    lblPdfSst: 'SST / Cukai Perkhidmatan',
    lblPdfHostSsmTitle: 'No. Pendaftaran SSM:',
    lblPdfDepositReq: 'Deposit Komitmen Diperlukan:',
    lblPdfDepositPaidRow: 'Bayaran Deposit Diterima (+):',
    lblPdfDepositDeductedRow: 'Tolak: Deposit Telah Dibayar (-):',
    lblPdfPaid: 'Jumlah Telah Dibayar:',
    lblPdfBalance: 'Baki Belum Jelas (Sebelum Masuk):',
    lblPdfDiscount: 'Diskaun (-)',
    
    lblPdfGrandTotalQuotation: 'Jumlah Anggaran Keseluruhan',
    lblPdfGrandTotalInvoice: 'Baki Perlu Dijelaskan (Amount Due)',
    lblPdfGrandTotalInvoiceNoDep: 'Jumlah Invois Keseluruhan',
    lblPdfGrandTotalDepositReceipt: 'JUMLAH BAYARAN DEPOSIT DITERIMA',
    lblPdfGrandTotalReceipt: 'JUMLAH BAYARAN PENUH DITERIMA',

    lblPdfWordsTitleDeposit: 'Jumlah Bayaran Deposit Diterima Dalam Perkataan',
    lblPdfWordsTitleGeneral: 'Jumlah Keseluruhan Dalam Perkataan',
    lblPdfAuthorized: 'Tandatangan Pengurus',

    lblPdfBankTitle: 'Butiran Akaun Bank',
    lblPdfAccHolder: 'Penama Akaun:',
    lblPdfAccNum: 'Nombor Akaun:',
    lblPdfBankName: 'Nama Bank:',
    lblPdfBranch: 'Cawangan:',
    lblPdfDuitNow: 'DuitNow ID:',
    lblPdfTermsTitle: 'Syarat & Catatan Dokumen',

    txtWaPromptTitle: 'Hantar Dokumen ini ke WhatsApp Tetamu?',
    txtWaPromptSub: 'Fail PDF rasmi ini sedia untuk dihantar dan dilampirkan terus ke perbualan WhatsApp tetamu.',
    txtBtnPromptYes: 'Ya, Hantar ke WhatsApp',
    txtBtnPromptNo: 'Hanya Lihat / Muat Turun',

    termsQuotation: [
      'Sila kemukakan dokumen ini ke bahagian kewangan / pentadbiran bagi tujuan kelulusan atau pesanan tempatan (LPO).',
      'Kadar dan tarikh tertakluk kepada kekosongan semasa pengesahan deposit dibuat.',
      'Waktu Daftar Masuk: 3:00 PM | Daftar Keluar: 12:00 PM.'
    ],
    termsInvoice: [
      'Invois ini dikeluarkan untuk tujuan pembayaran sewaan penginapan homestay bagi urusan rasmi.',
      'Sila jelaskan baki sewaan selewat-lewatnya sebelum atau semasa pendaftaran masuk.',
      'Resit rasmi akan dikeluarkan serta-merta sebaik sahaja baki bayaran diterima.'
    ],
    termsDepositReceipt: [
      'Resit rasmi pengesahan penerimaan bayaran deposit / tempahan awal bagi penginapan homestay seperti butiran di atas.',
      'Tarikh penginapan anda kini telah dikunci dan disahkan di sistem kami.',
      'Baki bayaran sewaan hendaklah dijelaskan selewat-lewatnya sebelum atau semasa penyerahan kunci / pendaftaran masuk.'
    ],
    termsReceipt: [
      'Pengesahan rasmi penerimaan bayaran penuh untuk penginapan homestay bagi urusan rasmi seperti butiran di atas.',
      'Deposit keselamatan (jika berkenaan) akan dipulangkan selepas semakan daftar keluar.',
      'Terima kasih kerana memilih homestay kami untuk urusan rasmi organisasi anda.'
    ],
    docBadgeQuotationMonthly: 'SEBUT HARGA SEWAAN BULANAN',
    docTitleQuotationMonthly: 'Sebut Harga Sewaan Bulanan',
    docBadgeInvoiceMonthly: 'INVOIS SEWAAN BULANAN',
    docTitleInvoiceMonthly: 'Invois Sewaan Bulanan',
    docBadgeDepositReceiptMonthly: 'RESIT BAYARAN BOOKING SEWAAN',
    docTitleDepositReceiptMonthly: 'Resit Bayaran Booking Sewaan',
    docBadgeReceiptMonthly: 'RESIT RASMI BAYARAN KEMASUKAN',
    docTitleReceiptMonthly: 'Resit Rasmi Bayaran Kemasukan',

    termsQuotationMonthly: [
      'Bayaran Sewa Pendahuluan: Sewa bulanan dikutip secara pendahuluan bagi setiap bulan (bukan bayaran sekaligus bagi keseluruhan tempoh sewaan).',
      'Invois Sewaan Bulanan: Invois sewaan bulanan bagi bulan-bulan seterusnya akan dikeluarkan pada setiap awal bulan sebelum tarikh akhir bayaran.',
      'Caj Bil Utiliti: Bagi sewaan jangka panjang melebihi 1 bulan, penyewa membayar bil utiliti (elektrik & air) terus kepada pembekal atau ditambah ke dalam invois sewa bulanan mengikut kadar penggunaan bulanan sebenar.',
      'Pemulangan Deposit: Deposit Sewaan (1 bulan sewa) dan Deposit Utiliti akan dipulangkan sepenuhnya dalam tempoh 14 hari selepas tamat tempoh sewaan dan penyerahan kunci, tertakluk kepada penyelesaian bil utiliti tertunggak dan pemeriksaan keadaan unit yang baik.',
      'Pengesahan Tempahan: Dokumen ini sah selama tempoh yang dinyatakan. Unit hanya disahkan dan dikunci selepas bayaran tempahan/booking awal diterima.'
    ],
    termsInvoiceMonthly: [
      'Invois ini dikeluarkan untuk bayaran sewaan bulanan bagi kitaran bulan yang dinyatakan di atas.',
      'Sila jelaskan bayaran selewat-lewatnya sebelum atau pada tarikh akhir bayaran (Due Date).',
      'Caj bil utiliti (elektrik & air) dicaj secara berasingan mengikut penggunaan bulanan sebenar.',
      'Resit rasmi pembayaran sewaan bulanan akan dikeluarkan serta-merta sebaik sahaja transaksi bank disahkan.'
    ]
  },
  en: {
    docBadgeQuotation: 'OFFICIAL QUOTATION',
    docTitleQuotation: 'Quotation',
    docBadgeInvoice: 'OFFICIAL INVOICE',
    docTitleInvoice: 'Invoice',
    docBadgeDepositReceipt: 'DEPOSIT PAYMENT RECEIPT',
    docTitleDepositReceipt: 'Deposit Payment Receipt',
    docBadgeReceipt: 'OFFICIAL RECEIPT',
    docTitleReceipt: 'Official Payment Receipt',

    lblPdfDocNoTitleQuotation: 'Quotation No:',
    lblPdfDocNoTitleInvoice: 'Invoice No:',
    lblPdfDocNoTitleDepositReceipt: 'Deposit Receipt No:',
    lblPdfDocNoTitleReceipt: 'Receipt No:',
    lblPdfDocDateTitleQuotation: 'Quotation Date:',
    lblPdfDocDateTitleInvoice: 'Invoice Date:',
    lblPdfDocDateTitleDepositReceipt: 'Receipt Date:',
    lblPdfDocDateTitleReceipt: 'Receipt Date:',
    lblPdfValidityTitle: 'Validity Date:',
    lblPdfLpoTitle: 'LPO / Ref No:',
    lblPdfPayMethodTitle: 'Payment Mode / Ref:',
    lblPdfBillTo: 'Bill To',

    thPdfItem: 'Items',
    thPdfQty: 'Quantity',
    thPdfRate: 'Rate Per Unit',
    thPdfTax: 'Tax / SST',
    thPdfAmount: 'Amount',

    lblPdfSubTotalTable: 'Package Sub Total',
    lblPdfExtraCharges: 'Extra Charges (+)',
    lblPdfTaxableAmount: 'Total Accommodation Package',
    lblPdfSst: 'SST / Service Tax',
    lblPdfHostSsmTitle: 'SSM Reg No:',
    lblPdfDepositReq: 'Deposit Required:',
    lblPdfDepositPaidRow: 'Deposit Payment Received (+):',
    lblPdfDepositDeductedRow: 'Less: Deposit Paid (-):',
    lblPdfPaid: 'Amount Paid:',
    lblPdfBalance: 'Outstanding Balance Due:',
    lblPdfDiscount: 'Discount (-)',

    lblPdfGrandTotalQuotation: 'Total Estimated Amount',
    lblPdfGrandTotalInvoice: 'Balance Amount Due',
    lblPdfGrandTotalInvoiceNoDep: 'Total Invoice Amount',
    lblPdfGrandTotalDepositReceipt: 'TOTAL DEPOSIT RECEIVED',
    lblPdfGrandTotalReceipt: 'TOTAL AMOUNT SETTLED',

    lblPdfWordsTitleDeposit: 'Total Deposit Received in Words',
    lblPdfWordsTitleGeneral: 'Total Amount in Words',
    lblPdfAuthorized: 'Authorized Signature',

    lblPdfBankTitle: 'Bank Details',
    lblPdfAccHolder: 'Account holder:',
    lblPdfAccNum: 'Account number:',
    lblPdfBankName: 'Bank:',
    lblPdfBranch: 'Branch:',
    lblPdfDuitNow: 'DuitNow ID:',
    lblPdfTermsTitle: 'Terms & Conditions',

    txtWaPromptTitle: 'Send this Document to Guest via WhatsApp?',
    txtWaPromptSub: 'This official PDF document is ready to be sent and attached directly to guest\'s WhatsApp.',
    txtBtnPromptYes: 'Yes, Send to WhatsApp',
    txtBtnPromptNo: 'View / Download Only',

    termsQuotation: [
      'Please submit this formal quotation to your accounts/finance department for LPO or disbursement processing.',
      'Rates and dates remain subject to availability until booking deposit is confirmed.',
      'Standard Check-In: 3:00 PM | Check-Out: 12:00 PM.'
    ],
    termsInvoice: [
      'This invoice is rendered for official corporate/department homestay accommodation claims.',
      'Full settlement is respectfully requested prior to or upon guest check-in arrival.',
      'An official payment receipt will be issued immediately upon receipt of bank remittance.'
    ],
    termsDepositReceipt: [
      'Official acknowledgement of booking deposit payment received for the homestay stay stated above.',
      'Your reservation dates are now officially locked and secured in our calendar.',
      'The remaining balance is due prior to or upon guest arrival / keys handover.'
    ],
    termsReceipt: [
      'Official acknowledgement of full payment received for accommodation particulars stated above.',
      'Refundable security deposit (if applicable) will be refunded within 24 hours following checkout inspection.',
      'Thank you for staying with us for your official corporate engagement.'
    ],
    docBadgeQuotationMonthly: 'MONTHLY TENANCY QUOTATION',
    docTitleQuotationMonthly: 'Monthly Tenancy Quotation',
    docBadgeInvoiceMonthly: 'MONTHLY RENTAL INVOICE',
    docTitleInvoiceMonthly: 'Monthly Rental Invoice',
    docBadgeDepositReceiptMonthly: 'TENANCY BOOKING RECEIPT',
    docTitleDepositReceiptMonthly: 'Tenancy Booking Receipt',
    docBadgeReceiptMonthly: 'MOVE-IN PAYMENT RECEIPT',
    docTitleReceiptMonthly: 'Move-in Payment Receipt',

    termsQuotationMonthly: [
      'Advance Monthly Rental: Rental is collected in advance for each month and not as a lump sum for the entire tenancy duration.',
      'Subsequent Monthly Invoices: Rental invoice for each subsequent month will be issued at the beginning of each month prior to payment due date.',
      'Utility Usage Policy: For long-term rental exceeding 1 month, tenant will pay utility bills (electricity & water) directly to utility providers or added into the monthly rental invoice based on actual usage charges.',
      'Refundable Deposits: Rental Deposit (1 month rental) and Utilities Deposit are fully refundable at the end of tenancy subject to utility arrears settlement and satisfactory unit condition.',
      'Reservation Confirmation: Unit is secured and confirmed only upon receipt of the initial booking commitment fee.'
    ],
    termsInvoiceMonthly: [
      'This invoice is issued for monthly rental charges covering the billing period stated above.',
      'Please settle payment on or before the specified due date.',
      'Utility charges (electricity & water) are billed based on actual monthly consumption.',
      'An official payment receipt will be issued immediately upon payment verification.'
    ]
  }
};

/**
 * Convert numeric currency into words respecting the chosen currency
 */
function numberToWords(amount, currency = 'RM', lang = 'bm') {
  amount = parseFloat(amount) || 0;
  if (amount < 0) amount = Math.abs(amount);
  const whole = Math.floor(amount);
  const cents = Math.round((amount - whole) * 100);

  const unitsBM = ['', 'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Lapan', 'Sembilan'];
  const unitsEN = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const teensEN = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tensEN = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertBM(n) {
    if (n === 0) return '';
    if (n < 10) return unitsBM[n];
    if (n === 10) return 'Sepuluh';
    if (n === 11) return 'Sebelas';
    if (n < 20) return unitsBM[n - 10] + ' Belas';
    if (n < 100) {
      const ten = Math.floor(n / 10);
      const rem = n % 10;
      return (ten === 1 ? 'Sepuluh' : unitsBM[ten] + ' Puluh') + (rem > 0 ? ' ' + unitsBM[rem] : '');
    }
    if (n < 1000) {
      const hundred = Math.floor(n / 100);
      const rem = n % 100;
      return (hundred === 1 ? 'Seratus' : unitsBM[hundred] + ' Ratus') + (rem > 0 ? ' ' + convertBM(rem) : '');
    }
    if (n < 1000000) {
      const thousand = Math.floor(n / 1000);
      const rem = n % 1000;
      return (thousand === 1 ? 'Seribu' : convertBM(thousand) + ' Ribu') + (rem > 0 ? ' ' + convertBM(rem) : '');
    }
    if (n < 1000000000) {
      const million = Math.floor(n / 1000000);
      const rem = n % 1000000;
      return convertBM(million) + ' Juta' + (rem > 0 ? ' ' + convertBM(rem) : '');
    }
    return n.toString();
  }

  function convertEN(n) {
    if (n === 0) return '';
    if (n < 10) return unitsEN[n];
    if (n < 20) return teensEN[n - 10];
    if (n < 100) {
      const ten = Math.floor(n / 10);
      const rem = n % 10;
      return tensEN[ten] + (rem > 0 ? '-' + unitsEN[rem] : '');
    }
    if (n < 1000) {
      const hundred = Math.floor(n / 100);
      const rem = n % 100;
      return unitsEN[hundred] + ' Hundred' + (rem > 0 ? ' ' + convertEN(rem) : '');
    }
    if (n < 1000000) {
      const thousand = Math.floor(n / 1000);
      const rem = n % 1000;
      return convertEN(thousand) + ' Thousand' + (rem > 0 ? ' ' + convertEN(rem) : '');
    }
    if (n < 1000000000) {
      const million = Math.floor(n / 1000000);
      const rem = n % 1000000;
      return convertEN(million) + ' Million' + (rem > 0 ? ' ' + convertEN(rem) : '');
    }
    return n.toString();
  }

  const curUpper = (currency || 'RM').toUpperCase().trim();
  let majorBM = 'Ringgit', minorBM = 'Sen', majorEN = 'Ringgit', minorEN = 'Cents';

  if (curUpper === 'RM' || curUpper === 'MYR') {
    majorBM = 'Ringgit Malaysia';
    minorBM = 'Sen';
    majorEN = 'Malaysian Ringgit';
    minorEN = 'Cents';
  } else if (curUpper === '$' || curUpper === 'USD' || curUpper === 'AUD' || curUpper === 'CAD' || curUpper === 'NZD') {
    majorBM = 'Dolar';
    minorBM = 'Sen';
    majorEN = 'Dollars';
    minorEN = 'Cents';
  } else if (curUpper === 'SGD' || curUpper === 'S$') {
    majorBM = 'Dolar Singapura';
    minorBM = 'Sen';
    majorEN = 'Singapore Dollars';
    minorEN = 'Cents';
  } else if (curUpper === '£' || curUpper === 'GBP') {
    majorBM = 'Pound Sterling';
    minorBM = 'Pence';
    majorEN = 'Pounds';
    minorEN = 'Pence';
  } else if (curUpper === '€' || curUpper === 'EUR') {
    majorBM = 'Euro';
    minorBM = 'Sen';
    majorEN = 'Euros';
    minorEN = 'Cents';
  } else if (curUpper === 'RP' || curUpper === 'IDR') {
    majorBM = 'Rupiah';
    minorBM = 'Sen';
    majorEN = 'Rupiah';
    minorEN = 'Sen';
  } else if (curUpper === '฿' || curUpper === 'THB') {
    majorBM = 'Baht';
    minorBM = 'Satang';
    majorEN = 'Baht';
    minorEN = 'Satang';
  } else {
    majorBM = curUpper;
    minorBM = 'Sen';
    majorEN = curUpper;
    minorEN = 'Cents';
  }

  if (lang === 'bm') {
    let result = '';
    if (whole === 0) {
      result = 'Sifar ' + majorBM;
    } else {
      result = majorBM + ' ' + convertBM(whole);
    }
    if (cents > 0) {
      result += ' Dan ' + convertBM(cents) + ' ' + minorBM;
    }
    result += ' Sahaja';
    return result.toUpperCase();
  } else {
    let result = '';
    if (whole === 0) {
      result = 'Zero ' + majorEN;
    } else {
      result = convertEN(whole) + ' ' + majorEN;
    }
    if (cents > 0) {
      result += ' And ' + convertEN(cents) + ' ' + minorEN;
    }
    result += ' Only';
    return result.toUpperCase();
  }
}

function numberToWordsMYR(amount, lang = 'bm') {
  return numberToWords(amount, appState?.settings?.currency || 'RM', lang);
}

function formatTime12H(timeStr) {
  if (!timeStr) return '12:00 PM';
  if (timeStr.toUpperCase().includes('AM') || timeStr.toUpperCase().includes('PM')) return timeStr;
  const parts = timeStr.split(':');
  if (parts.length < 2) return timeStr;
  let h = parseInt(parts[0], 10);
  const m = parts[1].slice(0, 2);
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  if (h === 0) h = 12;
  return `${h}:${m} ${ampm}`;
}

function openPdfDocModal(booking, defaultDocType = 'quotation', monthIndex = null, paymentId = null) {
  if (!booking) {
    booking = appState.bookings && appState.bookings[0];
    if (!booking) {
      showToast(appState.settings.language === 'bm' ? 'Tiada rekod tempahan untuk dijana dokumen.' : 'No booking record available to generate document.');
      return;
    }
  }

  // Ensure any other open backdrops (e.g. WhatsApp modal) are cleanly closed first
  closeAllModals();

  appState.activePdfBooking = booking;
  appState.activePdfMonthIndex = monthIndex ? parseInt(monthIndex) : null;
  appState.activePdfPaymentId = paymentId || null;
  const isMonthly = booking.rentalType === 'monthly';

  // Default active payment for non-monthly bookings
  if (!isMonthly && Array.isArray(booking.payments) && booking.payments.length > 0) {
    if (!appState.activePdfPaymentId) {
      if (defaultDocType === 'deposit_receipt') {
        const depP = booking.payments.find(p => p.type === 'deposit');
        appState.activePdfPaymentId = depP ? depP.id : booking.payments[0].id;
      } else {
        appState.activePdfPaymentId = booking.payments[booking.payments.length - 1].id;
      }
    }
  }

  // Intelligently select default document type
  const paidAmt = Number(booking.depositPaid || (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0) || 0);
  const totalAmt = Number(booking.totalAmount || 0);

  if (monthIndex) {
    const invs = getOrInitMonthlyInvoices(booking);
    const targetInv = invs.find(x => x.monthIndex === parseInt(monthIndex));
    if (parseInt(monthIndex) === 1 || (targetInv && targetInv.status === 'paid' && defaultDocType !== 'invoice')) {
      defaultDocType = 'receipt';
    } else {
      defaultDocType = 'invoice';
    }
  } else {
    if (defaultDocType === 'deposit_receipt' || (booking.status === 'booked' && defaultDocType !== 'invoice' && defaultDocType !== 'quotation')) {
      defaultDocType = 'deposit_receipt';
    } else if (defaultDocType === 'receipt') {
      if (paidAmt > 0 && paidAmt < totalAmt) {
        defaultDocType = 'deposit_receipt';
      } else {
        defaultDocType = 'receipt';
      }
    }
  }

  appState.activePdfDocType = defaultDocType || 'quotation';
  appState.activePdfLang = appState.settings.language || 'bm';

  // Setup monthly tenancy scope controls
  const monthlyGroup = document.getElementById('pdfMonthlyTenancyGroup');
  const scopeSelect = document.getElementById('pdfMonthlyDocScopeSelect');
  const utilityWrap = document.getElementById('pdfMonthlyUtilityExtraWrap');
  const utilityInput = document.getElementById('pdfMonthlyUtilityExtraInput');

  const btnPdfAgrTab = document.getElementById('btnPdfTabAgreement');
  if (btnPdfAgrTab) {
    btnPdfAgrTab.style.display = isMonthly ? 'inline-flex' : 'none';
  }

  if (monthlyGroup && scopeSelect) {
    if (isMonthly) {
      monthlyGroup.style.display = 'block';
      scopeSelect.innerHTML = '';

      const optMoveIn = document.createElement('option');
      optMoveIn.value = 'move_in';
      optMoveIn.textContent = appState.activePdfLang === 'bm'
        ? '📋 Pakej Kemasukan Awal (Sebut Harga / Move-In Package)'
        : '📋 Move-In Initial Package (Quotation Statement)';
      scopeSelect.appendChild(optMoveIn);

      const invs = getOrInitMonthlyInvoices(booking);
      invs.forEach(inv => {
        const opt = document.createElement('option');
        opt.value = inv.monthIndex;
        const isPaid = inv.status === 'paid';
        if (inv.monthIndex === 1) {
          opt.textContent = appState.activePdfLang === 'bm'
            ? `📅 Bulan ke-1 (${inv.periodStart} → ${inv.periodEnd}) [LUNAS PAKEJ KEMASUKAN]`
            : `📅 Month 1 (${inv.periodStart} → ${inv.periodEnd}) [SETTLED VIA MOVE-IN]`;
        } else {
          opt.textContent = appState.activePdfLang === 'bm'
            ? `📅 Invois Bulan ke-${inv.monthIndex} (${inv.periodStart} → ${inv.periodEnd}) [${isPaid ? 'DIBAYAR' : 'BELUM'}]`
            : `📅 Month ${inv.monthIndex} Invoice (${inv.periodStart} → ${inv.periodEnd}) [${isPaid ? 'PAID' : 'DUE'}]`;
        }
        scopeSelect.appendChild(opt);
      });

      const optAgr = document.createElement('option');
      optAgr.value = 'tenancy_agreement';
      optAgr.textContent = appState.activePdfLang === 'bm'
        ? '📜 Surat Perjanjian Sewaan (Buka Penjana Tenancy Agreement)'
        : '📜 Residential Tenancy Agreement (Open Agreement Generator)';
      scopeSelect.appendChild(optAgr);

      if (monthIndex) {
        scopeSelect.value = String(monthIndex);
        if (utilityWrap) utilityWrap.style.display = 'block';
        const targetInv = invs.find(x => x.monthIndex === parseInt(monthIndex));
        if (utilityInput && targetInv) utilityInput.value = targetInv.utilityCharges || 0;
      } else {
        scopeSelect.value = 'move_in';
        if (utilityWrap) utilityWrap.style.display = 'none';
      }

      scopeSelect.onchange = () => {
        if (scopeSelect.value === 'tenancy_agreement') {
          closePdfDocModal();
          openAgreementModal(booking, 'preview');
          return;
        }
        if (scopeSelect.value === 'move_in') {
          appState.activePdfMonthIndex = null;
          if (utilityWrap) utilityWrap.style.display = 'none';
          if (appState.activePdfDocType !== 'quotation') {
            setPdfDocType('quotation');
            return;
          }
        } else {
          appState.activePdfMonthIndex = parseInt(scopeSelect.value);
          if (utilityWrap) utilityWrap.style.display = 'block';
          const targetInv = invs.find(x => x.monthIndex === appState.activePdfMonthIndex);
          if (utilityInput && targetInv) utilityInput.value = targetInv.utilityCharges || 0;
          if (appState.activePdfMonthIndex === 1 && appState.activePdfDocType === 'invoice') {
            setPdfDocType('receipt');
            return;
          }
          if (appState.activePdfDocType === 'quotation') {
            setPdfDocType(appState.activePdfMonthIndex === 1 ? 'receipt' : 'invoice');
            return;
          }
        }
        updatePdfDocView();
      };

      if (utilityInput) {
        utilityInput.oninput = () => {
          if (appState.activePdfMonthIndex) {
            const targetInv = invs.find(x => x.monthIndex === appState.activePdfMonthIndex);
            if (targetInv) {
              targetInv.utilityCharges = parseFloat(utilityInput.value) || 0;
              targetInv.totalAmount = (targetInv.rentAmount || 0) + targetInv.utilityCharges;
              saveToStorage();
              updatePdfDocView();
            }
          }
        };
      }
    } else {
      monthlyGroup.style.display = 'none';
      if (utilityWrap) utilityWrap.style.display = 'none';
    }
  }

  // Quotation validity days
  const valDays = booking.quotationValidityDays || appState.settings.quotationValidityDays || 3;
  const valInput = document.getElementById('pdfQuotationValidityInput');
  if (valInput) valInput.value = valDays;

  // Deposit amount input
  const depAmt = paidAmt > 0 
    ? paidAmt 
    : (isMonthly ? (booking.depositAmount || Math.round((booking.monthlyRate || 1200) * 0.5)) : Math.round(totalAmt * (appState.settings.defaultDepositPct || 30) / 100));
  const depInput = document.getElementById('pdfDepositAmountInput');
  if (depInput) depInput.value = depAmt;

  // Payment Reference input
  const payRefInput = document.getElementById('pdfPaymentRefInput');
  if (payRefInput) {
    payRefInput.value = booking.lastPaymentRef ? `${booking.lastPaymentBank || 'Pindahan Bank'} - ${booking.lastPaymentRef}` : '';
  }

  // Client company and LPO
  const compInput = document.getElementById('pdfClientCompanyInput');
  if (compInput) compInput.value = booking.guestCompany || '';

  const lpoInput = document.getElementById('pdfLpoRefInput');
  if (lpoInput) lpoInput.value = booking.lpoRef || '';

  // Show WhatsApp prompt banner asking user if they want to send the file
  const banner = document.getElementById('pdfWaPromptBanner');
  if (banner) banner.style.display = 'flex';

  const statusCard = document.getElementById('pdfActionStatusCard');
  if (statusCard) {
    statusCard.style.display = 'none';
    statusCard.innerHTML = '';
  }

  // Highlight active doc tab
  updatePdfTypeTabsUI();
  updatePdfLangButtonsUI();
  updatePdfValidityPresetsUI(valDays);

  // Render preview with error boundary
  try {
    updatePdfDocView();
  } catch (err) {
    console.error('Error updating PDF document view:', err);
  }

  // Open modal
  const modal = document.getElementById('pdfDocModal');
  if (modal) modal.classList.add('active');
}

function closePdfDocModal() {
  const modal = document.getElementById('pdfDocModal');
  if (modal) modal.classList.remove('active');
}

function setPdfDocType(type) {
  appState.activePdfDocType = type;
  const booking = appState.activePdfBooking;
  if (booking && !isMonthlyBooking(booking) && Array.isArray(booking.payments) && booking.payments.length > 0) {
    if (type === 'deposit_receipt') {
      const depP = booking.payments.find(p => p.type === 'deposit');
      appState.activePdfPaymentId = depP ? depP.id : booking.payments[0].id;
    } else if (type === 'receipt') {
      appState.activePdfPaymentId = booking.payments[booking.payments.length - 1].id;
    }
  }
  updatePdfTypeTabsUI();
  updatePdfDocView();
}

function setPdfLanguage(lang) {
  appState.activePdfLang = lang;
  updatePdfLangButtonsUI();
  updatePdfDocView();
}

function setPdfQuotationValidity(days) {
  const cleanDays = Math.max(1, parseInt(days) || 3);
  const valInput = document.getElementById('pdfQuotationValidityInput');
  if (valInput) valInput.value = cleanDays;

  if (appState.activePdfBooking) {
    appState.activePdfBooking.quotationValidityDays = cleanDays;
    saveToStorage();
  }

  updatePdfValidityPresetsUI(cleanDays);
  updatePdfDocView();
}

function updatePdfTypeTabsUI() {
  const type = appState.activePdfDocType || 'quotation';
  const tabs = [
    { id: 'btnPdfTabQuotation', type: 'quotation' },
    { id: 'btnPdfTabInvoice', type: 'invoice' },
    { id: 'btnPdfTabDeposit', type: 'deposit_receipt' },
    { id: 'btnPdfTabReceipt', type: 'receipt' },
    { id: 'btnPdfTabHistory', type: 'history' }
  ];

  tabs.forEach(t => {
    const el = document.getElementById(t.id);
    if (el) el.classList.toggle('active', t.type === type);
  });

  // Toggle visibility of customization controls based on active doc type
  const validityGroup = document.getElementById('pdfQuotationValidityGroup');
  if (validityGroup) {
    validityGroup.style.display = type === 'quotation' ? 'block' : 'none';
  }

  const depositGroup = document.getElementById('pdfDepositAmountGroup');
  if (depositGroup) {
    depositGroup.style.display = (type === 'deposit_receipt' || type === 'invoice') ? 'block' : 'none';
  }

  const payRefGroup = document.getElementById('pdfPaymentRefGroup');
  if (payRefGroup) {
    payRefGroup.style.display = (type === 'deposit_receipt' || type === 'receipt') ? 'block' : 'none';
  }
}

function updatePdfLangButtonsUI() {
  const lang = appState.activePdfLang || 'bm';
  const btnBM = document.getElementById('btnPdfLangBM');
  const btnEN = document.getElementById('btnPdfLangEN');
  if (btnBM) btnBM.classList.toggle('active', lang === 'bm');
  if (btnEN) btnEN.classList.toggle('active', lang === 'en');
}

function updatePdfValidityPresetsUI(days) {
  document.querySelectorAll('.pdf-validity-preset').forEach(btn => {
    const d = parseInt(btn.getAttribute('data-days'));
    btn.classList.toggle('active', d === days);
  });
}

function updatePdfDocView() {
  const booking = appState.activePdfBooking;
  if (!booking) return;

  const prop = getPropertyById(booking.propertyId) || { name: 'Homestay Unit', address: '' };
  const settings = appState.settings || {};
  let docType = appState.activePdfDocType || 'quotation';
  const lang = appState.activePdfLang || 'bm';
  const t = PDF_DOC_I18N[lang] || PDF_DOC_I18N.bm;
  const currency = settings.currency || 'RM';

  // Check if viewing Document History tab (B2)
  if (docType === 'history') {
    const sheet = document.getElementById('printablePdfSheet');
    const waPrompt = document.getElementById('pdfWaPromptBanner');
    const histContainer = document.getElementById('pdfHistoryContainer');
    const actionCard = document.getElementById('pdfActionStatusCard');
    const statusBar = document.getElementById('pdfDocStatusBar');
    const bankWarn = document.getElementById('pdfBankWarningBanner');
    if (sheet) sheet.style.display = 'none';
    if (waPrompt) waPrompt.style.display = 'none';
    if (actionCard) actionCard.style.display = 'none';
    if (statusBar) statusBar.style.display = 'none';
    if (bankWarn) bankWarn.style.display = 'none';
    if (histContainer) {
      histContainer.style.display = 'block';
      renderDocumentHistoryTab(booking);
    }
    return;
  } else {
    const sheet = document.getElementById('printablePdfSheet');
    const histContainer = document.getElementById('pdfHistoryContainer');
    const statusBar = document.getElementById('pdfDocStatusBar');
    if (sheet) sheet.style.display = 'block';
    if (histContainer) histContainer.style.display = 'none';
    if (statusBar) statusBar.style.display = 'flex';
  }

  // Missing Bank Details Warning Banner (B1)
  const bankWarnBanner = document.getElementById('pdfBankWarningBanner');
  if (bankWarnBanner) {
    if (docType === 'quotation' || docType === 'invoice') {
      const hasBank = !!((settings.bankAccNum && settings.bankAccNum.trim()) || (settings.duitNow && settings.duitNow.trim()));
      bankWarnBanner.style.display = hasBank ? 'none' : 'flex';
    } else {
      bankWarnBanner.style.display = 'none';
    }
  }

  // 1. Host Information
  const bizNameEl = document.getElementById('pdfHostBizName');
  if (bizNameEl) bizNameEl.textContent = settings.businessName || prop.name || 'HOMESTAY';

  const ssmEl = document.getElementById('pdfHostSsm');
  const ssmRow = document.getElementById('pdfHostSsmRow');
  const lblSsmTitle = document.getElementById('lblPdfHostSsmTitle');
  if (lblSsmTitle) lblSsmTitle.textContent = t.lblPdfHostSsmTitle || 'SSM Reg No:';
  if (ssmRow && ssmEl) {
    if (settings.businessSsm && settings.businessSsm.trim()) {
      ssmRow.style.display = 'block';
      ssmEl.textContent = settings.businessSsm.trim();
    } else {
      ssmRow.style.display = 'none';
    }
  }

  const addrEl = document.getElementById('pdfHostAddress');
  if (addrEl) {
    const fullAddr = settings.businessAddress || prop.address || '';
    if (fullAddr.trim()) {
      addrEl.style.display = 'block';
      addrEl.textContent = fullAddr.trim();
    } else {
      addrEl.style.display = 'none';
    }
  }

  const phoneEl = document.getElementById('pdfHostPhone');
  const phoneRow = phoneEl ? phoneEl.parentElement : null;
  const hostPhone = settings.ownerPhone || prop.contactPhone || '';
  if (phoneRow && phoneEl) {
    if (hostPhone.trim()) {
      phoneRow.style.display = 'block';
      phoneEl.textContent = hostPhone.trim();
    } else {
      phoneRow.style.display = 'none';
    }
  }

  const emailEl = document.getElementById('pdfHostEmail');
  const emailRow = emailEl ? emailEl.parentElement : null;
  if (emailRow && emailEl) {
    if (settings.businessEmail && settings.businessEmail.trim()) {
      emailRow.style.display = 'block';
      emailEl.textContent = settings.businessEmail.trim();
    } else {
      emailRow.style.display = 'none';
    }
  }

  const premisIdEl = document.getElementById('pdfHostPremisId');
  const premisIdRow = document.getElementById('pdfHostIdRow');
  if (premisIdRow && premisIdEl) {
    if (prop.id && prop.id.toString().trim()) {
      premisIdRow.style.display = 'block';
      premisIdEl.textContent = `HM-${prop.id.toString().replace(/\D/g, '') || prop.id}`;
    } else {
      premisIdRow.style.display = 'none';
    }
  }

  // 2. Tenancy & Rental Type Determination
  const isMonthly = booking.rentalType === 'monthly';
  const mRate = Number(booking.monthlyRate || 0);
  const rDep = (booking.rentalDeposit !== undefined && booking.rentalDeposit !== null && booking.rentalDeposit !== '') 
    ? Number(booking.rentalDeposit) 
    : mRate;
  const uDep = (booking.utilitiesDeposit !== undefined && booking.utilitiesDeposit !== null && booking.utilitiesDeposit !== '') 
    ? Number(booking.utilitiesDeposit) 
    : 300;
  const aFee = Number(booking.agreementFee || 0);
  const totalMoveIn = mRate + rDep + uDep + aFee;

  const activeMonthIdx = appState.activePdfMonthIndex;
  const monthlyInvoices = isMonthly ? getOrInitMonthlyInvoices(booking) : [];
  const currentMonthInv = (isMonthly && activeMonthIdx) 
    ? monthlyInvoices.find(x => x.monthIndex === activeMonthIdx) 
    : null;

  // Financial figures calculation
  let grandTotal = 0;
  let depositPaidAmt = 0;
  let balAmt = 0;

  if (isMonthly) {
    if (currentMonthInv) {
      const curMonthTotal = Number((currentMonthInv.rentAmount || mRate) + (currentMonthInv.utilityCharges || 0));
      grandTotal = curMonthTotal;
      const isPaid = currentMonthInv.status === 'paid';
      depositPaidAmt = isPaid ? curMonthTotal : 0;
      balAmt = isPaid ? 0 : curMonthTotal;
    } else {
      grandTotal = totalMoveIn;
      depositPaidAmt = parseFloat(document.getElementById('pdfDepositAmountInput')?.value);
      if (isNaN(depositPaidAmt)) {
        depositPaidAmt = Number(booking.depositPaid || (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0) || 0);
      }
      if (depositPaidAmt === 0 && (docType === 'deposit_receipt' || booking.status === 'booked')) {
        depositPaidAmt = Number(booking.depositAmount || Math.round(mRate * 0.5));
      }
      balAmt = Math.max(0, grandTotal - depositPaidAmt);
    }
  } else {
    const nights = booking.nights || 1;
    const ratePerNight = nights > 0 ? (booking.baseRate ? booking.baseRate / nights : (booking.totalAmount - (booking.cleaningFee || 0)) / nights) : booking.totalAmount;
    const accommodationTotal = ratePerNight * nights;
    grandTotal = booking.totalAmount || (accommodationTotal + (booking.cleaningFee || 0));

    depositPaidAmt = parseFloat(document.getElementById('pdfDepositAmountInput')?.value);
    if (isNaN(depositPaidAmt)) {
      depositPaidAmt = Number(booking.depositPaid || (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0) || 0);
    }
    if (depositPaidAmt === 0 && (docType === 'deposit_receipt' || booking.status === 'booked')) {
      depositPaidAmt = Number(booking.depositAmount || Math.round(grandTotal * (settings.defaultDepositPct || 30) / 100));
    }
    balAmt = Math.max(0, grandTotal - depositPaidAmt);
  }

  // Resolve selected payment and running summary figures for per-payment receipts
  const payments = Array.isArray(booking.payments) ? booking.payments : [];
  let selectedPayment = null;
  let pIdx = -1;
  let cumulativePaid = 0;
  let balanceAfter = 0;

  if (!isMonthly && (docType === 'receipt' || docType === 'deposit_receipt')) {
    if (payments.length > 0) {
      if (appState.activePdfPaymentId) {
        selectedPayment = payments.find(p => p.id === appState.activePdfPaymentId) || null;
      }
      if (!selectedPayment) {
        if (docType === 'deposit_receipt') {
          selectedPayment = payments.find(p => p.type === 'deposit') || payments[0];
        } else {
          selectedPayment = payments[payments.length - 1];
        }
        appState.activePdfPaymentId = selectedPayment ? selectedPayment.id : null;
      }
      pIdx = payments.findIndex(p => p.id === selectedPayment.id);
      if (pIdx === -1) pIdx = payments.length - 1;
      const paymentsUpTo = payments.slice(0, pIdx + 1);
      cumulativePaid = paymentsUpTo.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      balanceAfter = Math.max(0, grandTotal - cumulativePaid);
    } else {
      cumulativePaid = depositPaidAmt;
      balanceAfter = Math.max(0, grandTotal - cumulativePaid);
    }
  } else {
    cumulativePaid = depositPaidAmt;
    balanceAfter = balAmt;
  }

  // Populate & toggle payment selector dropdown (Per-Payment Receipts)
  const paymentSelectGroup = document.getElementById('pdfPaymentSelectGroup');
  const paymentSelect = document.getElementById('pdfPaymentSelect');
  const paymentBadge = document.getElementById('pdfPaymentCountBadge');
  const paymentHint = document.getElementById('pdfPaymentRunningSummaryHint');

  const showPaymentDropdown = !isMonthly && (docType === 'receipt' || docType === 'deposit_receipt') && payments.length > 1;
  if (paymentSelectGroup) {
    if (showPaymentDropdown) {
      paymentSelectGroup.style.display = 'block';
      if (paymentBadge) {
        paymentBadge.textContent = lang === 'bm' ? `${payments.length} Bayaran Direkod` : `${payments.length} Payments Recorded`;
      }
      if (paymentSelect) {
        paymentSelect.innerHTML = '';
        payments.forEach((p, idx) => {
          const opt = document.createElement('option');
          opt.value = p.id;
          const pNum = idx + 1;
          const pTypeLabel = p.type === 'deposit' 
            ? (lang === 'bm' ? 'Deposit' : 'Deposit') 
            : (p.type === 'balance' ? (lang === 'bm' ? 'Baki' : 'Balance') : (p.type === 'full' ? (lang === 'bm' ? 'Penuh' : 'Full') : (lang === 'bm' ? 'Bayaran' : 'Payment')));
          const pRef = (p.reference || p.ref || p.referenceNo) ? ` [${(p.bank || p.bankName) ? (p.bank || p.bankName) + ': ' : ''}${p.reference || p.ref || p.referenceNo}]` : ((p.bank || p.bankName) ? ` [${p.bank || p.bankName}]` : '');
          const pRcpt = p.receiptNo ? ` (${p.receiptNo})` : '';
          opt.textContent = `${pNum}. ${p.date || '-'} • ${currency} ${Number(p.amount || 0).toFixed(2)} - ${pTypeLabel}${pRef}${pRcpt}`;
          if (selectedPayment && p.id === selectedPayment.id) {
            opt.selected = true;
          }
          paymentSelect.appendChild(opt);
        });
        paymentSelect.onchange = (e) => {
          appState.activePdfPaymentId = e.target.value;
          updatePdfDocView();
        };
      }
      if (paymentHint && selectedPayment) {
        paymentHint.innerHTML = lang === 'bm'
          ? `<span style="color:#0284c7; font-weight:700;">Bayaran Ini:</span> ${currency} ${Number(selectedPayment.amount || 0).toFixed(2)} &nbsp;|&nbsp; <span style="font-weight:700;">Kumulatif:</span> ${currency} ${cumulativePaid.toFixed(2)} &nbsp;|&nbsp; <span style="font-weight:700;">Baki:</span> <strong style="color:${balanceAfter <= 0.009 ? '#059669' : '#b45309'}">${currency} ${balanceAfter.toFixed(2)}</strong>`
          : `<span style="color:#0284c7; font-weight:700;">This Payment:</span> ${currency} ${Number(selectedPayment.amount || 0).toFixed(2)} &nbsp;|&nbsp; <span style="font-weight:700;">Cumulative:</span> ${currency} ${cumulativePaid.toFixed(2)} &nbsp;|&nbsp; <span style="font-weight:700;">Balance:</span> <strong style="color:${balanceAfter <= 0.009 ? '#059669' : '#b45309'}">${currency} ${balanceAfter.toFixed(2)}</strong>`;
      }
    } else {
      paymentSelectGroup.style.display = 'none';
      if (paymentHint) paymentHint.textContent = '';
    }
  }

  // Update Deposit balance hint in toolbar
  const depBalHint = document.getElementById('pdfDepositBalanceHint');
  if (depBalHint) {
    const displayBal = (!isMonthly && (docType === 'receipt' || docType === 'deposit_receipt')) ? balanceAfter : balAmt;
    depBalHint.textContent = lang === 'bm' ? `Baki: ${currency} ${displayBal.toFixed(2)}` : `Bal: ${currency} ${displayBal.toFixed(2)}`;
    depBalHint.style.color = displayBal > 0 ? '#b45309' : '#059669';
  }

  // 3. Document Number & Date & Meta
  const year = new Date().getFullYear();
  const idShort = (booking.id || '').replace(/\D/g, '').slice(-4) || '1088';
  let docPrefix = 'QT';
  let docTitle = t.docTitleQuotation;
  let docNoTitle = t.lblPdfDocNoTitleQuotation;
  let docDateTitle = t.lblPdfDocDateTitleQuotation;
  let docBadge = t.docBadgeQuotation;
  let badgeBg = '#e0f2fe';
  let badgeColor = '#0369a1';
  let titleColor = '#ea580c';

  if (isMonthly) {
    if (currentMonthInv) {
      if (docType === 'receipt' || currentMonthInv.status === 'paid') {
        docPrefix = `REC-M${currentMonthInv.monthIndex}`;
        docTitle = lang === 'bm' ? `Resit Bayaran Sewa Bulan ke-${currentMonthInv.monthIndex}` : `Monthly Rent Receipt Month ${currentMonthInv.monthIndex}`;
        docNoTitle = t.lblPdfDocNoTitleReceipt;
        docDateTitle = t.lblPdfDocDateTitleReceipt;
        docBadge = lang === 'bm' ? `RESIT SEWA BULAN KE-${currentMonthInv.monthIndex}` : `RENT RECEIPT MONTH ${currentMonthInv.monthIndex}`;
        badgeBg = '#d1fae5'; badgeColor = '#065f46'; titleColor = '#059669';
      } else {
        docPrefix = `INV-M${currentMonthInv.monthIndex}`;
        docTitle = lang === 'bm' ? `Invois Sewa Bulan ke-${currentMonthInv.monthIndex}` : `Monthly Rent Invoice Month ${currentMonthInv.monthIndex}`;
        docNoTitle = t.lblPdfDocNoTitleInvoice;
        docDateTitle = t.lblPdfDocDateTitleInvoice;
        docBadge = lang === 'bm' ? `INVOIS SEWA BULAN KE-${currentMonthInv.monthIndex}` : `MONTHLY RENT INVOICE MONTH ${currentMonthInv.monthIndex}`;
        badgeBg = '#ede9fe'; badgeColor = '#5b21b6'; titleColor = '#5b21b6';
      }
    } else {
      if (docType === 'invoice') {
        docPrefix = 'INV-M';
        docTitle = t.docTitleInvoiceMonthly || (lang === 'bm' ? 'Invois Kemasukan Sewaan Bulanan' : 'Monthly Tenancy Move-in Invoice');
        docNoTitle = t.lblPdfDocNoTitleInvoice;
        docDateTitle = t.lblPdfDocDateTitleInvoice;
        docBadge = t.docBadgeInvoiceMonthly || (lang === 'bm' ? 'INVOIS SEWAAN BULANAN' : 'MONTHLY TENANCY INVOICE');
        badgeBg = '#ede9fe'; badgeColor = '#5b21b6'; titleColor = '#5b21b6';
      } else if (docType === 'deposit_receipt') {
        docPrefix = 'REC-BOOK-M';
        docTitle = t.docTitleDepositReceiptMonthly || (lang === 'bm' ? 'Resit Bayaran Booking Sewaan' : 'Tenancy Booking Receipt');
        docNoTitle = t.lblPdfDocNoTitleDepositReceipt;
        docDateTitle = t.lblPdfDocDateTitleDepositReceipt;
        docBadge = t.docBadgeDepositReceiptMonthly || (lang === 'bm' ? 'RESIT BAYARAN BOOKING SEWAAN' : 'TENANCY BOOKING RECEIPT');
        badgeBg = '#dbeafe'; badgeColor = '#1e40af'; titleColor = '#0284c7';
      } else if (docType === 'receipt') {
        docPrefix = 'REC-M';
        docTitle = t.docTitleReceiptMonthly || (lang === 'bm' ? 'Resit Rasmi Bayaran Kemasukan' : 'Move-in Payment Receipt');
        docNoTitle = t.lblPdfDocNoTitleReceipt;
        docDateTitle = t.lblPdfDocDateTitleReceipt;
        docBadge = t.docBadgeReceiptMonthly || (lang === 'bm' ? 'RESIT RASMI BAYARAN KEMASUKAN' : 'MOVE-IN PAYMENT RECEIPT');
        badgeBg = '#d1fae5'; badgeColor = '#065f46'; titleColor = '#059669';
      } else {
        docPrefix = 'QUO-M';
        docTitle = t.docTitleQuotationMonthly || (lang === 'bm' ? 'Sebut Harga Sewaan Bulanan' : 'Monthly Tenancy Quotation');
        docNoTitle = t.lblPdfDocNoTitleQuotation;
        docDateTitle = t.lblPdfDocDateTitleQuotation;
        docBadge = t.docBadgeQuotationMonthly || (lang === 'bm' ? 'SEBUT HARGA SEWAAN BULANAN' : 'MONTHLY TENANCY QUOTATION');
        badgeBg = '#e0f2fe'; badgeColor = '#0369a1'; titleColor = '#ea580c';
      }
    }
  } else {
    if (docType === 'invoice') {
      docPrefix = 'INV';
      docTitle = t.docTitleInvoice;
      docNoTitle = t.lblPdfDocNoTitleInvoice;
      docDateTitle = t.lblPdfDocDateTitleInvoice;
      docBadge = t.docBadgeInvoice;
      badgeBg = '#ede9fe'; badgeColor = '#5b21b6'; titleColor = '#5b21b6';
    } else if (docType === 'deposit_receipt') {
      docPrefix = 'REC-DEP';
      docTitle = t.docTitleDepositReceipt;
      docNoTitle = t.lblPdfDocNoTitleDepositReceipt;
      docDateTitle = t.lblPdfDocDateTitleDepositReceipt;
      docBadge = t.docBadgeDepositReceipt;
      badgeBg = '#dbeafe'; badgeColor = '#1e40af'; titleColor = '#0284c7';
    } else if (docType === 'receipt') {
      docPrefix = 'REC';
      const isPaidFull = !isMonthly ? (balanceAfter <= 0.009) : true;
      docTitle = isPaidFull ? t.docTitleReceipt : (lang === 'bm' ? 'Resit Rasmi Pembayaran (Bahagian)' : 'Official Payment Receipt (Partial)');
      docNoTitle = t.lblPdfDocNoTitleReceipt;
      docDateTitle = t.lblPdfDocDateTitleReceipt;
      docBadge = isPaidFull ? t.docBadgeReceipt : (lang === 'bm' ? 'RESIT BAYARAN SEBAHAGIAN' : 'PARTIAL PAYMENT RECEIPT');
      badgeBg = isPaidFull ? '#d1fae5' : '#e0f2fe';
      badgeColor = isPaidFull ? '#065f46' : '#0369a1';
      titleColor = isPaidFull ? '#059669' : '#0284c7';
    }
  }

  // Allocate or retrieve document number and audit status (B2)
  const alloc = getOrAllocateDocNo(booking, docType, activeMonthIdx, false, appState.activePdfPaymentId);
  const fullDocNo = alloc.docNo;
  const docRecord = alloc.docRecord;
  const isDraft = alloc.isDraft;
  const isReprint = alloc.isReprint;

  // Status Badge on Sheet (DRAF, BATAL, DIGANTIKAN, SALINAN / COPY)
  const docStatusBadge = document.getElementById('pdfDocStatusBadge');
  if (docStatusBadge) {
    if (isDraft) {
      docStatusBadge.style.display = 'inline-block';
      docStatusBadge.textContent = 'DRAF';
      docStatusBadge.style.background = '#f1f5f9';
      docStatusBadge.style.color = '#475569';
    } else if (docRecord && docRecord.status === 'void') {
      docStatusBadge.style.display = 'inline-block';
      docStatusBadge.textContent = 'BATAL (VOID)';
      docStatusBadge.style.background = '#fee2e2';
      docStatusBadge.style.color = '#dc2626';
    } else if (docRecord && docRecord.status === 'superseded') {
      docStatusBadge.style.display = 'inline-block';
      docStatusBadge.textContent = 'DIGANTIKAN (SUPERSEDED)';
      docStatusBadge.style.background = '#fef3c7';
      docStatusBadge.style.color = '#d97706';
    } else if (isReprint) {
      docStatusBadge.style.display = 'inline-block';
      docStatusBadge.textContent = 'SALINAN / COPY';
      docStatusBadge.style.background = '#e0f2fe';
      docStatusBadge.style.color = '#0284c7';
    } else {
      docStatusBadge.style.display = 'none';
    }
  }

  // Toolbar Status Pill & Action Buttons (B2)
  const toolbarPill = document.getElementById('pdfToolbarStatusPill');
  const btnMarkIssued = document.getElementById('btnPdfMarkIssued');
  const btnCreateRev = document.getElementById('btnPdfCreateRevision');
  const btnVoidReissue = document.getElementById('btnPdfVoidReissue');
  const toolbarNotice = document.getElementById('pdfToolbarReplacedNotice');

  if (toolbarPill) {
    if (isDraft) {
      toolbarPill.textContent = 'DRAF';
      toolbarPill.style.background = '#e2e8f0';
      toolbarPill.style.color = '#475569';
    } else if (docRecord && docRecord.status === 'void') {
      toolbarPill.textContent = 'BATAL (VOID)';
      toolbarPill.style.background = '#fee2e2';
      toolbarPill.style.color = '#dc2626';
    } else if (docRecord && docRecord.status === 'superseded') {
      toolbarPill.textContent = 'DIGANTIKAN (SUPERSEDED)';
      toolbarPill.style.background = '#fef3c7';
      toolbarPill.style.color = '#b45309';
    } else {
      toolbarPill.textContent = isReprint ? 'DITERBITKAN (SALINAN)' : 'DITERBITKAN (ISSUED)';
      toolbarPill.style.background = '#dcfce7';
      toolbarPill.style.color = '#166534';
    }
  }

  if (btnMarkIssued) {
    btnMarkIssued.style.display = isDraft ? 'inline-flex' : 'none';
  }
  if (btnCreateRev) {
    btnCreateRev.style.display = (docType === 'quotation' && !isDraft && docRecord?.status !== 'void') ? 'inline-flex' : 'none';
  }
  if (btnVoidReissue) {
    btnVoidReissue.style.display = ((docType === 'invoice' || docType === 'deposit_receipt' || docType === 'receipt') && !isDraft && docRecord?.status !== 'void') ? 'inline-flex' : 'none';
  }

  if (toolbarNotice) {
    if (docRecord?.replacesDocNo) {
      toolbarNotice.style.display = 'inline';
      toolbarNotice.textContent = `• Menggantikan ${docRecord.replacesDocNo}`;
    } else if (docRecord?.replacedByDocNo) {
      toolbarNotice.style.display = 'inline';
      toolbarNotice.textContent = `• Digantikan oleh ${docRecord.replacedByDocNo}`;
    } else {
      toolbarNotice.style.display = 'none';
    }
  }

  // Replaces Banner on Printable Sheet
  const replacesBanner = document.getElementById('pdfReplacesBanner');
  const replacesText = document.getElementById('pdfReplacesText');
  if (replacesBanner && replacesText) {
    if (docRecord && docRecord.replacesDocNo) {
      replacesBanner.style.display = 'block';
      replacesText.textContent = `${lang === 'bm' ? 'Menggantikan Dokumen Batal / Replaces Voided' : 'Replaces Voided'}: ${docRecord.replacesDocNo}`;
    } else {
      replacesBanner.style.display = 'none';
    }
  }

  // Void Banner on Printable Sheet
  const voidBanner = document.getElementById('pdfVoidBanner');
  if (voidBanner) {
    if (docRecord && docRecord.status === 'void') {
      voidBanner.style.display = 'block';
      voidBanner.innerHTML = `⚠️ DOKUMEN INI TELAH DIBATALKAN (VOID)${docRecord.voidReason ? ` — Sebab: ${docRecord.voidReason}` : ''}${docRecord.replacedByDocNo ? `<br><span style="font-size:11px; font-weight:normal;">Digantikan oleh dokumen baharu: <strong>${docRecord.replacedByDocNo}</strong></span>` : ''}`;
    } else {
      voidBanner.style.display = 'none';
    }
  }

  const titleEl = document.getElementById('pdfDocTitle');
  if (titleEl) {
    titleEl.textContent = docTitle;
    titleEl.style.color = titleColor;
  }

  const lblDocNoEl = document.getElementById('lblPdfDocNoTitle');
  if (lblDocNoEl) lblDocNoEl.textContent = docNoTitle;

  const docNoEl = document.getElementById('pdfDocNo');
  if (docNoEl) docNoEl.textContent = fullDocNo;

  const lblDocDateEl = document.getElementById('lblPdfDocDateTitle');
  if (lblDocDateEl) lblDocDateEl.textContent = docDateTitle;

  const docDateEl = document.getElementById('pdfDocDate');
  if (docDateEl) {
    let rawDate = null;
    let timeStr = '12:00 PM';
    if (!isMonthly && (docType === 'receipt' || docType === 'deposit_receipt') && selectedPayment) {
      rawDate = selectedPayment.dateTime || selectedPayment.date;
      timeStr = selectedPayment.time || (selectedPayment.dateTime && selectedPayment.dateTime.includes('T') ? selectedPayment.dateTime.split('T')[1].slice(0, 5) : '12:00 PM');
    } else if (docRecord) {
      rawDate = docRecord.date || docRecord.issuedAt;
      timeStr = (docRecord.issuedAt && docRecord.issuedAt.includes('T')) ? docRecord.issuedAt.split('T')[1].slice(0, 5) : '12:00 PM';
    }
    const d = rawDate ? new Date(rawDate.includes('T') ? rawDate : rawDate + 'T12:00:00') : new Date();
    const formattedDate = (isNaN(d.getTime()) ? new Date() : d).toLocaleDateString(lang === 'bm' ? 'ms-MY' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    const formattedTime = timeStr.includes('M') ? timeStr : formatTime12H(timeStr);
    docDateEl.textContent = `${formattedDate} ${formattedTime}`.trim();
  }

  // Validity calculation (Quotation only)
  const valDays = parseInt(document.getElementById('pdfQuotationValidityInput')?.value) || booking.quotationValidityDays || settings.quotationValidityDays || 3;
  const expDateObj = new Date();
  expDateObj.setDate(expDateObj.getDate() + valDays);
  const expFormatted = expDateObj.toLocaleDateString(lang === 'bm' ? 'ms-MY' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

  const valRow = document.getElementById('pdfDocValidityRow');
  const lblValTitle = document.getElementById('lblPdfValidityTitle');
  const docValEl = document.getElementById('pdfDocValidity');
  if (lblValTitle) lblValTitle.textContent = t.lblPdfValidityTitle;
  if (docValEl) docValEl.textContent = `${expFormatted} (${valDays} ${lang === 'bm' ? 'Hari' : 'Days'})`;
  if (valRow) valRow.style.display = (docType === 'quotation' && !currentMonthInv) ? 'block' : 'none';

  const calcDateEl = document.getElementById('pdfValidityCalculatedDate');
  if (calcDateEl) calcDateEl.textContent = lang === 'bm' ? `Hingga ${expFormatted}` : `Until ${expFormatted}`;

  // LPO Row
  const lpoInputVal = document.getElementById('pdfLpoRefInput')?.value.trim() || booking.lpoRef || '';
  const lpoRow = document.getElementById('pdfDocLpoRow');
  const lblLpoTitle = document.getElementById('lblPdfLpoTitle');
  const lpoText = document.getElementById('pdfDocLpo');
  if (lblLpoTitle) lblLpoTitle.textContent = t.lblPdfLpoTitle;
  if (lpoRow && lpoText) {
    if (lpoInputVal) {
      lpoRow.style.display = 'block';
      lpoText.textContent = lpoInputVal;
    } else {
      lpoRow.style.display = 'none';
    }
  }

  // Payment Method & Transaction Reference Row
  const payMethodRow = document.getElementById('pdfDocPayMethodRow');
  const lblPayMethodTitle = document.getElementById('lblPdfPayMethodTitle');
  const payMethodText = document.getElementById('pdfDocPayMethodText');
  const userPayRef = document.getElementById('pdfPaymentRefInput')?.value.trim();

  let paymentRefStr = '';
  if (!isMonthly && (docType === 'deposit_receipt' || docType === 'receipt') && selectedPayment) {
    const bankName = selectedPayment.bank || selectedPayment.bankName || '';
    const refVal = selectedPayment.reference || selectedPayment.ref || selectedPayment.referenceNo || '';
    if (bankName && refVal) {
      paymentRefStr = `${bankName} - ${refVal}`;
    } else {
      paymentRefStr = refVal || bankName || (lang === 'bm' ? 'Pindahan Bank' : 'Bank Transfer');
    }
  } else {
    paymentRefStr = userPayRef || (booking.lastPaymentRef ? `${booking.lastPaymentBank || 'Bank'} - ${booking.lastPaymentRef}` : '');
  }

  if (lblPayMethodTitle) lblPayMethodTitle.textContent = t.lblPdfPayMethodTitle;
  if (payMethodRow && payMethodText) {
    if ((docType === 'deposit_receipt' || docType === 'receipt') && paymentRefStr) {
      payMethodRow.style.display = 'block';
      payMethodText.textContent = paymentRefStr;
    } else {
      payMethodRow.style.display = 'none';
    }
  }

  // Transaction Reference row in the printable bank card
  const txRefRow = document.getElementById('pdfTxRefRow');
  const lblTxRef = document.getElementById('lblPdfTxRef');
  const txRefVal = document.getElementById('pdfTxRefVal');
  if (txRefRow && txRefVal) {
    const selBank = selectedPayment ? (selectedPayment.bank || selectedPayment.bankName || '') : '';
    const selRef = selectedPayment ? (selectedPayment.reference || selectedPayment.ref || selectedPayment.referenceNo || '') : '';
    if ((docType === 'deposit_receipt' || docType === 'receipt') && (selBank || selRef)) {
      txRefRow.style.display = 'flex';
      if (lblTxRef) lblTxRef.textContent = lang === 'bm' ? 'No. Rujukan / Ref:' : 'Reference / Trans ID:';
      txRefVal.textContent = selBank && selRef ? `${selBank} - ${selRef}` : (selRef || selBank);
    } else {
      txRefRow.style.display = 'none';
    }
  }

  // Watermark (B1 & B2 Strict Audit Rule)
  // "PAID IN FULL" must appear ONLY on documents that are genuinely fully paid (receipt with balance zero).
  // It must NEVER appear on quotations, invoices with a balance, or partial payment receipts!
  const watermark = document.getElementById('pdfPaidWatermark');
  if (watermark) {
    if (docRecord && docRecord.status === 'void') {
      watermark.classList.remove('hidden');
      watermark.textContent = 'BATAL / VOID';
      watermark.style.color = 'rgba(239, 68, 68, 0.22)';
      watermark.style.borderColor = 'rgba(239, 68, 68, 0.35)';
    } else if (docRecord && docRecord.status === 'superseded') {
      watermark.classList.remove('hidden');
      watermark.textContent = 'DIGANTIKAN / SUPERSEDED';
      watermark.style.color = 'rgba(245, 158, 11, 0.22)';
      watermark.style.borderColor = 'rgba(245, 158, 11, 0.35)';
    } else if (docType === 'receipt') {
      if (isMonthly) {
        if ((currentMonthInv && currentMonthInv.status === 'paid') || (!currentMonthInv && balAmt <= 0.009)) {
          watermark.classList.remove('hidden');
          watermark.textContent = lang === 'bm' ? 'TELAH LUNAS' : 'PAID IN FULL';
          watermark.style.color = 'rgba(16, 185, 129, 0.16)';
          watermark.style.borderColor = 'rgba(16, 185, 129, 0.28)';
        } else {
          watermark.classList.add('hidden');
        }
      } else {
        // Daily booking receipt
        if (balanceAfter <= 0.009) {
          watermark.classList.remove('hidden');
          watermark.textContent = lang === 'bm' ? 'TELAH LUNAS' : 'PAID IN FULL';
          watermark.style.color = 'rgba(16, 185, 129, 0.16)';
          watermark.style.borderColor = 'rgba(16, 185, 129, 0.28)';
        } else {
          // Earlier partial payment receipt - strictly NEVER show paid in full stamp!
          watermark.classList.remove('hidden');
          watermark.textContent = lang === 'bm' ? 'BAYARAN DITERIMA' : 'PAYMENT RECEIVED';
          watermark.style.color = 'rgba(2, 132, 199, 0.16)';
          watermark.style.borderColor = 'rgba(2, 132, 199, 0.28)';
        }
      }
    } else if (docType === 'deposit_receipt') {
      watermark.classList.remove('hidden');
      watermark.textContent = lang === 'bm' ? 'DEPOSIT DITERIMA' : 'DEPOSIT PAID';
      watermark.style.color = 'rgba(2, 132, 199, 0.16)';
      watermark.style.borderColor = 'rgba(2, 132, 199, 0.28)';
    } else {
      watermark.classList.add('hidden');
    }
  }

  // 4. Recipient Particulars (Bill To)
  const lblBillToEl = document.getElementById('lblPdfBillTo');
  if (lblBillToEl) lblBillToEl.textContent = t.lblPdfBillTo;

  const companyInputVal = document.getElementById('pdfClientCompanyInput')?.value.trim() || booking.guestCompany || '';
  const clientCompanyEl = document.getElementById('pdfClientCompanyText');
  if (clientCompanyEl) {
    if (companyInputVal) {
      clientCompanyEl.textContent = companyInputVal;
      clientCompanyEl.style.display = 'block';
    } else {
      clientCompanyEl.style.display = 'none';
    }
  }

  const clientNameEl = document.getElementById('pdfClientNameText');
  if (clientNameEl) {
    clientNameEl.textContent = (companyInputVal ? (lang === 'bm' ? 'U.P: ' : 'Attn: ') : '') + (booking.guestName || 'Tetamu');
  }

  const custPhoneEl = document.getElementById('pdfClientPhone');
  if (custPhoneEl) custPhoneEl.textContent = booking.guestPhone || '-';

  const custEmailEl = document.getElementById('pdfClientEmail');
  if (custEmailEl) custEmailEl.textContent = booking.guestEmail || '-';

  const nricEl = document.getElementById('pdfClientNric');
  if (nricEl) nricEl.textContent = booking.guestNric || '-';

  const custAddrEl = document.getElementById('pdfClientAddress');
  const custAddrDiv = document.getElementById('pdfClientAddressDiv');
  if (custAddrDiv && custAddrEl) {
    if (booking.guestAddress) {
      custAddrDiv.style.display = 'block';
      custAddrEl.textContent = booking.guestAddress;
    } else {
      custAddrDiv.style.display = 'none';
    }
  }

  // 5. Homestay / Tenancy Stay Particulars
  const propNameEl = document.getElementById('pdfPropNameText');
  if (propNameEl) propNameEl.textContent = prop.name;

  const propAddrEl = document.getElementById('pdfPropAddressText');
  if (propAddrEl) propAddrEl.textContent = prop.address ? `(${prop.address})` : '';

  const lblCheckInDate = document.getElementById('lblPdfCheckInDate');
  const lblCheckOutDate = document.getElementById('lblPdfCheckOutDate');
  const checkInDateEl = document.getElementById('pdfCheckInDate');
  const checkInTimeEl = document.getElementById('pdfCheckInTime');
  const checkOutDateEl = document.getElementById('pdfCheckOutDate');
  const checkOutTimeEl = document.getElementById('pdfCheckOutTime');
  const durTextEl = document.getElementById('pdfDurationGuestText');
  const guests = booking.guestCount || booking.adults || 1;

  if (isMonthly) {
    if (currentMonthInv) {
      if (lblCheckInDate) lblCheckInDate.textContent = lang === 'bm' ? 'Tempoh Mula:' : 'Period Start:';
      if (lblCheckOutDate) lblCheckOutDate.textContent = lang === 'bm' ? 'Tempoh Akhir:' : 'Period End:';
      if (checkInDateEl) checkInDateEl.textContent = currentMonthInv.periodStart || '-';
      if (checkInTimeEl) checkInTimeEl.textContent = `${lang === 'bm' ? 'Akhir Bayar' : 'Due'}: ${currentMonthInv.dueDate}`;
      if (checkOutDateEl) checkOutDateEl.textContent = currentMonthInv.periodEnd || '-';
      if (checkOutTimeEl) checkOutTimeEl.textContent = currentMonthInv.status === 'paid' ? (lang === 'bm' ? 'LUNAS' : 'PAID') : (lang === 'bm' ? 'BELUM' : 'DUE');
      if (durTextEl) {
        durTextEl.textContent = lang === 'bm'
          ? `Bulan ke-${currentMonthInv.monthIndex} drpd ${booking.monthlyDuration || 6} Bulan • ${guests} Penyewa`
          : `Month ${currentMonthInv.monthIndex} of ${booking.monthlyDuration || 6} • ${guests} Tenant(s)`;
      }
    } else {
      if (lblCheckInDate) lblCheckInDate.textContent = lang === 'bm' ? 'Mula Sewa:' : 'Start Date:';
      if (lblCheckOutDate) lblCheckOutDate.textContent = lang === 'bm' ? 'Tamat Sewa:' : 'End Date:';
      if (checkInDateEl) checkInDateEl.textContent = booking.checkIn || '-';
      if (checkInTimeEl) checkInTimeEl.textContent = lang === 'bm' ? 'Kemasukan' : 'Move-in';
      if (checkOutDateEl) checkOutDateEl.textContent = booking.checkOut || '-';
      if (checkOutTimeEl) checkOutTimeEl.textContent = lang === 'bm' ? 'Serahan Kunci' : 'Handover';
      if (durTextEl) {
        durTextEl.textContent = lang === 'bm'
          ? `${booking.monthlyDuration || 1} Bulan • ${guests} Penyewa`
          : `${booking.monthlyDuration || 1} Month(s) • ${guests} Tenant(s)`;
      }
    }
  } else {
    const nights = booking.nights || 1;
    if (lblCheckInDate) lblCheckInDate.textContent = lang === 'bm' ? 'Masuk:' : 'Check-In:';
    if (lblCheckOutDate) lblCheckOutDate.textContent = lang === 'bm' ? 'Keluar:' : 'Check-Out:';
    if (checkInDateEl) checkInDateEl.textContent = booking.checkIn || '-';
    if (checkInTimeEl) checkInTimeEl.textContent = prop.checkInTime || '3:00 PM';
    if (checkOutDateEl) checkOutDateEl.textContent = booking.checkOut || '-';
    if (checkOutTimeEl) checkOutTimeEl.textContent = prop.checkOutTime || '12:00 PM';
    if (durTextEl) {
      durTextEl.textContent = lang === 'bm' 
        ? `${nights} Malam • ${guests} Tetamu`
        : `${nights} Nights • ${guests} Guests`;
    }
  }

  // 6. Itemized Table
  const tableBody = document.getElementById('pdfTableBody');
  if (tableBody) {
    tableBody.innerHTML = '';

    if (isMonthly) {
      if (currentMonthInv) {
        // Specific Month Invoice Table
        let rIdx = 1;
        const tr1 = document.createElement('tr');
        tr1.style.borderBottom = '1px solid #f1f5f9';
        tr1.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? `Sewa Bulanan (Bulan ke-${currentMonthInv.monthIndex})` : `Monthly Rental (Month ${currentMonthInv.monthIndex})`}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? `Kitaran sewaan dari ${currentMonthInv.periodStart} hingga ${currentMonthInv.periodEnd}` : `Rental billing period from ${currentMonthInv.periodStart} to ${currentMonthInv.periodEnd}`}</span>
            ${currentMonthInv.monthIndex === 1 ? `<div style="font-size:10.5px; font-weight:700; color:#166534; background:#dcfce7; padding:2px 6px; border-radius:4px; display:inline-block; margin-top:3px;"><i class="fa-solid fa-circle-check"></i> ${lang === 'bm' ? 'Sewa Bulan 1 Telah Dibayar Melalui Pakej Kemasukan' : 'Month 1 Rental Paid Via Move-In Package'}</div>` : ''}
          </td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Bulan' : 'Mth'}</td>
          <td style="padding:8px 8px; text-align:right;">${Number(currentMonthInv.rentAmount || mRate).toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${Number(currentMonthInv.rentAmount || mRate).toFixed(2)}</td>
        `;
        tableBody.appendChild(tr1);

        if (currentMonthInv.utilityCharges && currentMonthInv.utilityCharges > 0) {
          const tr2 = document.createElement('tr');
          tr2.style.borderBottom = '1px solid #f1f5f9';
          tr2.innerHTML = `
            <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
            <td style="padding:8px 8px;">
              <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Caj Penggunaan Utiliti Sebenar (Air & Elektrik)' : 'Actual Utility Usage Charges (Water & Electricity)'}</strong>
              <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Caj bil utiliti sebenar yang ditambah ke dalam sewa bulanan mengikut penggunaan' : 'Actual utility usage charges added into monthly rental invoice per usage'}</span>
            </td>
            <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Pakej' : 'Unit'}</td>
            <td style="padding:8px 8px; text-align:right;">${Number(currentMonthInv.utilityCharges).toFixed(2)}</td>
            <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
            <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${Number(currentMonthInv.utilityCharges).toFixed(2)}</td>
          `;
          tableBody.appendChild(tr2);
        }
      } else {
        // Move-in Package Quotation / Move-in Statement
        let rIdx = 1;

        // Row 1: Advance Monthly Rental (1 Month)
        const tr1 = document.createElement('tr');
        tr1.style.borderBottom = '1px solid #f1f5f9';
        tr1.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Sewa Bulan Pertama (Bayaran Pendahuluan)' : '1st Month Advance Rental'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Bayaran sewa bulan pertama dikutip secara pendahuluan (sewa bagi setiap bulan berikutnya diinvois pada awal bulan)' : 'Advance payment for 1st month rental (subsequent months invoiced at the beginning of each month)'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Bulan' : 'Mth'}</td>
          <td style="padding:8px 8px; text-align:right;">${mRate.toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${mRate.toFixed(2)}</td>
        `;
        tableBody.appendChild(tr1);

        // Row 2: Rental Security Deposit (1 Month Rent)
        const tr2 = document.createElement('tr');
        tr2.style.borderBottom = '1px solid #f1f5f9';
        tr2.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Deposit Keselamatan Sewaan (1 Bulan Sewa)' : 'Rental Security Deposit (1 Month Rent)'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Deposit sekuriti 1 bulan sewa (Boleh dipulangkan sepenuhnya pada akhir tempoh sewaan tertakluk kepada keadaan premis)' : 'Security deposit equal to 1 month rent (Fully refundable at end of tenancy subject to unit handover)'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Bulan' : 'Mth'}</td>
          <td style="padding:8px 8px; text-align:right;">${rDep.toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${rDep.toFixed(2)}</td>
        `;
        tableBody.appendChild(tr2);

        // Row 3: Utilities Deposit (RM 300)
        const tr3 = document.createElement('tr');
        tr3.style.borderBottom = '1px solid #f1f5f9';
        tr3.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Deposit Utiliti / Air & Elektrik (Boleh Dipulangkan)' : 'Utilities Deposit / Water & Electricity (Refundable)'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Deposit cagaran utiliti (Boleh dipulangkan sepenuhnya pada akhir tempoh sewaan tertakluk kepada penyelesaian bil utiliti)' : 'Utility security deposit (Fully refundable at end of tenancy subject to utility arrears settlement)'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Pakej' : 'Unit'}</td>
          <td style="padding:8px 8px; text-align:right;">${uDep.toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${uDep.toFixed(2)}</td>
        `;
        tableBody.appendChild(tr3);

        // Row 4: Agreement Fee (if any)
        if (aFee > 0) {
          const tr4 = document.createElement('tr');
          tr4.style.borderBottom = '1px solid #f1f5f9';
          tr4.innerHTML = `
            <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
            <td style="padding:8px 8px;">
              <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Yuran Perjanjian Sewa & Duti Setem' : 'Tenancy Agreement & Legal Stamp Duty'}</strong>
              <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Penyediaan dokumen kontrak perjanjian sewaan & duti setem sah' : 'Tenancy contract preparation, administrative documentation & legal stamp duty'}</span>
            </td>
            <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Dok' : 'Doc'}</td>
            <td style="padding:8px 8px; text-align:right;">${aFee.toFixed(2)}</td>
            <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
            <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${aFee.toFixed(2)}</td>
          `;
          tableBody.appendChild(tr4);
        }

        // Row 5: Monthly Utilities Policy Row
        const tr5 = document.createElement('tr');
        tr5.style.background = '#fcfdfd';
        tr5.style.borderBottom = '1px solid #f1f5f9';
        tr5.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Kadar Caj Bil Utiliti Bulanan (Elektrik & Air)' : 'Monthly Utilities Billing Policy (Electricity & Water)'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Bagi sewaan jangka panjang melebihi 1 bulan, penyewa membayar bil utiliti terus kepada pembekal atau ditambah ke dalam invois sewa bulanan mengikut kadar penggunaan sebenar setiap bulan' : 'In long term rental over 1 month, tenant will pay direct or plus in monthly rental per usage charges'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">-</td>
          <td style="padding:8px 8px; text-align:right; font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Kadar Sebenar' : 'Actual Rate'}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#059669;">${lang === 'bm' ? 'IKUT PENGGUNAAN' : 'PER USAGE'}</td>
        `;
        tableBody.appendChild(tr5);
      }
    } else {
      const nights = booking.nights || 1;
      const ratePerNight = nights > 0 ? (booking.baseRate ? booking.baseRate / nights : (booking.totalAmount - (booking.cleaningFee || 0)) / nights) : booking.totalAmount;
      const accommodationTotal = ratePerNight * nights;

      // Row 1: Accommodation Stay
      const tr1 = document.createElement('tr');
      tr1.style.borderBottom = '1px solid #f1f5f9';
      tr1.innerHTML = `
        <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">1</td>
        <td style="padding:8px 8px;">
          <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Sewa Penginapan Homestay (Accommodation Stay)' : 'Homestay Accommodation Rental'}</strong>
          <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? `Penginapan dari ${booking.checkIn} hingga ${booking.checkOut} (${nights} malam)` : `Stay from ${booking.checkIn} to ${booking.checkOut} (${nights} nights)`}</span>
        </td>
        <td style="padding:8px 8px; text-align:center; font-weight:700;">${nights}.00</td>
        <td style="padding:8px 8px; text-align:right;">${ratePerNight.toFixed(2)}</td>
        <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
        <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${accommodationTotal.toFixed(2)}</td>
      `;
      tableBody.appendChild(tr1);

      // Row 2: Cleaning fee (if any)
      let rowIndex = 2;
      if (booking.cleaningFee && booking.cleaningFee > 0) {
        const tr2 = document.createElement('tr');
        tr2.style.borderBottom = '1px solid #f1f5f9';
        tr2.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rowIndex++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Fi Pembersihan & Pengemasan (Turnover Cleaning Fee)' : 'Sanitized Cleaning & Turnover Fee'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Penyediaan cadar bersih, tuala, sanitasi premis dan pengemasan' : 'Fresh linen, bath towels, room sanitization and turnover service'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00</td>
          <td style="padding:8px 8px; text-align:right;">${Number(booking.cleaningFee).toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${Number(booking.cleaningFee).toFixed(2)}</td>
        `;
        tableBody.appendChild(tr2);
      }

      // Row 3: Utilities & WiFi (Included)
      const tr3 = document.createElement('tr');
      tr3.style.background = '#fcfdfd';
      tr3.style.borderBottom = '1px solid #f1f5f9';
      tr3.innerHTML = `
        <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rowIndex++}</td>
        <td style="padding:8px 8px;">
          <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Utiliti, Elektrik, Air & WiFi Berkelajuan Tinggi' : 'Utilities, Electricity, Water & High-Speed WiFi'}</strong>
          <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Penghawa dingin sepenuhnya, bekalan air bersih dan internet tanpa had' : 'Full air-conditioning, clean water supply and unlimited high-speed WiFi access'}</span>
        </td>
        <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00</td>
        <td style="padding:8px 8px; text-align:right;">0.00</td>
        <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
        <td style="padding:8px 8px; text-align:right; font-weight:800; color:#059669;">${lang === 'bm' ? 'TERMASUK' : 'INCLUDED'}</td>
      `;
      tableBody.appendChild(tr3);
    }
  }

  // 7. Calculations & Financial Summary
  const subtotalQtyEl = document.getElementById('pdfSubtotalQty');
  const subtotalEl = document.getElementById('pdfValSubtotal');
  const taxSubtotalEl = document.getElementById('pdfValTaxableSubtotal');
  const extraChargesEl = document.getElementById('pdfValExtraCharges');
  const depRow = document.getElementById('pdfRowDeposit');
  const depVal = document.getElementById('pdfValDepositReq');
  const depLbl = document.getElementById('lblPdfDepositReq');
  const paidRow = document.getElementById('pdfRowPaid');
  const paidVal = document.getElementById('pdfValPaid');
  const paidLbl = document.getElementById('lblPdfPaid');
  const balRow = document.getElementById('pdfRowBalance');
  const balVal = document.getElementById('pdfValBalance');
  const balLbl = document.getElementById('lblPdfBalance');
  const grandTotalEl = document.getElementById('pdfValGrandTotal');
  const grandTotalLbl = document.getElementById('lblPdfGrandTotal');
  const wordsTitleLbl = document.getElementById('lblPdfWordsTitle');
  const wordsEl = document.getElementById('pdfTotalAmountInWords');

  if (isMonthly) {
    if (currentMonthInv) {
      const curMonthTotal = Number((currentMonthInv.rentAmount || mRate) + (currentMonthInv.utilityCharges || 0));
      const isPaid = currentMonthInv.status === 'paid';

      if (subtotalQtyEl) subtotalQtyEl.textContent = currentMonthInv.utilityCharges > 0 ? '2.00' : '1.00';
      if (subtotalEl) subtotalEl.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
      if (taxSubtotalEl) taxSubtotalEl.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
      if (extraChargesEl) extraChargesEl.textContent = `${currency} ${(currentMonthInv.utilityCharges || 0).toFixed(2)}`;

      if (depRow) depRow.style.display = 'none';

      if (isPaid) {
        if (paidRow && paidVal && paidLbl) {
          paidRow.style.display = 'flex';
          paidLbl.textContent = lang === 'bm' ? 'Bayaran Diterima (+):' : 'Payment Received (+):';
          paidVal.textContent = `${currency} ${curMonthTotal.toFixed(2)} (${lang === 'bm' ? 'LUNAS' : 'PAID'})`;
          paidVal.style.color = '#059669';
        }
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = lang === 'bm' ? 'Baki Belum Jelas:' : 'Balance Due:';
          balVal.textContent = `${currency} 0.00`;
          balVal.style.color = '#059669';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH SEWA BULANAN DIBAYAR' : 'MONTHLY RENT PAID';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
          grandTotalEl.style.color = '#059669';
        }
      } else {
        if (paidRow) paidRow.style.display = 'none';
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = lang === 'bm' ? 'Baki Perlu Dijelaskan:' : 'Amount Due:';
          balVal.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
          balVal.style.color = '#b45309';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH PERLU DIBAYAR (AMOUNT DUE)' : 'TOTAL AMOUNT DUE';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
          grandTotalEl.style.color = '#5b21b6';
        }
      }

      if (wordsTitleLbl) wordsTitleLbl.textContent = lang === 'bm' ? 'Jumlah Sewa Bulanan Dalam Perkataan' : 'Monthly Rent Amount in Words';
      if (wordsEl) wordsEl.textContent = numberToWordsMYR(curMonthTotal, lang);

    } else {
      // Move-in Package Quotation / Move-in Statement
      const totalQty = (1 + 1 + 1 + (aFee > 0 ? 1 : 0)).toFixed(2);
      if (subtotalQtyEl) subtotalQtyEl.textContent = totalQty;
      if (subtotalEl) subtotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
      if (taxSubtotalEl) taxSubtotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
      if (extraChargesEl) extraChargesEl.textContent = `${currency} 0.00`;

      const bookingFee = booking.depositPaid > 0 
        ? booking.depositPaid 
        : (booking.depositAmount && booking.depositAmount > 0 ? booking.depositAmount : Math.round(mRate * 0.5));
      const balMoveIn = Math.max(0, totalMoveIn - (docType === 'deposit_receipt' ? depositPaidAmt : (booking.depositPaid > 0 ? booking.depositPaid : bookingFee)));

      if (docType === 'quotation') {
        if (depRow && depVal && depLbl) {
          depRow.style.display = 'flex';
          depLbl.textContent = lang === 'bm' ? 'Bayaran Booking (Kunci Unit):' : 'Booking Fee to Reserve Unit:';
          depVal.textContent = `${currency} ${bookingFee.toFixed(2)}`;
        }
        if (paidRow) paidRow.style.display = 'none';
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = lang === 'bm' ? 'Baki Bayaran Sebelum Kunci/Masuk:' : 'Balance Due before Move-in:';
          balVal.textContent = `${currency} ${balMoveIn.toFixed(2)}`;
          balVal.style.color = '#b45309';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH PAKEJ KEMASUKAN (MOVE-IN)' : 'TOTAL MOVE-IN PACKAGE';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
          grandTotalEl.style.color = '#ea580c';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = lang === 'bm' ? 'Jumlah Pakej Kemasukan Dalam Perkataan' : 'Total Move-in Package in Words';
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(totalMoveIn, lang);

      } else if (docType === 'deposit_receipt') {
        if (depRow) depRow.style.display = 'none';
        if (paidRow && paidVal && paidLbl) {
          paidRow.style.display = 'flex';
          paidLbl.textContent = t.lblPdfDepositPaidRow;
          paidVal.textContent = `(+) ${currency} ${depositPaidAmt.toFixed(2)}`;
          paidVal.style.color = '#059669';
        }
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = lang === 'bm' ? 'Baki Sebelum Serahan Kunci:' : 'Balance Due before Handover:';
          balVal.textContent = `${currency} ${Math.max(0, totalMoveIn - depositPaidAmt).toFixed(2)} (${lang === 'bm' ? 'BELUM JELAS' : 'PENDING'})`;
          balVal.style.color = '#b45309';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH BAYARAN BOOKING DITERIMA' : 'BOOKING DEPOSIT RECEIVED';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${depositPaidAmt.toFixed(2)}`;
          grandTotalEl.style.color = '#0284c7';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleDeposit;
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(depositPaidAmt, lang);

      } else if (docType === 'receipt') {
        if (depRow) depRow.style.display = 'none';
        if (paidRow && paidVal && paidLbl) {
          paidRow.style.display = 'flex';
          paidLbl.textContent = t.lblPdfPaid;
          paidVal.textContent = `${currency} ${totalMoveIn.toFixed(2)} (${lang === 'bm' ? 'PENUH' : 'FULL'})`;
          paidVal.style.color = '#059669';
        }
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = t.lblPdfBalance;
          balVal.textContent = `${currency} 0.00 (${lang === 'bm' ? 'LUNAS / SELESAI' : 'SETTLED'})`;
          balVal.style.color = '#059669';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH BAYARAN PENUH KEMASUKAN' : 'FULL MOVE-IN SETTLEMENT';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
          grandTotalEl.style.color = '#059669';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(totalMoveIn, lang);

      } else if (docType === 'invoice') {
        if (depRow) depRow.style.display = 'none';
        if (depositPaidAmt > 0) {
          if (paidRow && paidVal && paidLbl) {
            paidRow.style.display = 'flex';
            paidLbl.textContent = t.lblPdfDepositDeductedRow;
            paidVal.textContent = `(-) ${currency} ${depositPaidAmt.toFixed(2)}`;
            paidVal.style.color = '#059669';
          }
          if (balRow && balVal && balLbl) {
            balRow.style.display = 'flex';
            balLbl.textContent = t.lblPdfBalance;
            balVal.textContent = `${currency} ${balAmt.toFixed(2)}`;
            balVal.style.color = balAmt <= 0 ? '#059669' : '#b45309';
          }
          if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalInvoice;
          if (grandTotalEl) {
            grandTotalEl.textContent = `${currency} ${balAmt.toFixed(2)}`;
            grandTotalEl.style.color = balAmt <= 0 ? '#059669' : '#5b21b6';
          }
          if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
          if (wordsEl) wordsEl.textContent = numberToWordsMYR(balAmt, lang);
        } else {
          if (paidRow) paidRow.style.display = 'none';
          if (balRow) balRow.style.display = 'none';
          if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH PAKEJ KEMASUKAN' : 'TOTAL MOVE-IN PACKAGE';
          if (grandTotalEl) {
            grandTotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
            grandTotalEl.style.color = '#5b21b6';
          }
          if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
          if (wordsEl) wordsEl.textContent = numberToWordsMYR(totalMoveIn, lang);
        }
      }
    }
  } else {
    // Existing daily booking calculations
    const nights = booking.nights || 1;
    const totalQty = (nights + (booking.cleaningFee && booking.cleaningFee > 0 ? 1 : 0)).toFixed(2);
    if (subtotalQtyEl) subtotalQtyEl.textContent = totalQty;
    if (subtotalEl) subtotalEl.textContent = `${currency} ${Number(grandTotal).toFixed(2)}`;
    if (taxSubtotalEl) taxSubtotalEl.textContent = `${currency} ${Number(grandTotal).toFixed(2)}`;
    if (extraChargesEl) extraChargesEl.textContent = `${currency} 0.00`;

    const depositPct = settings.defaultDepositPct || 30;
    const depReqAmount = booking.depositAmount && booking.depositAmount > 0 ? booking.depositAmount : (grandTotal * depositPct / 100);

    if (docType === 'deposit_receipt' || docType === 'receipt') {
      const thisPaymentAmt = selectedPayment ? Number(selectedPayment.amount || 0) : (docType === 'deposit_receipt' ? depositPaidAmt : grandTotal);

      if (depRow) depRow.style.display = 'none';

      if (paidRow && paidVal && paidLbl) {
        paidRow.style.display = 'flex';
        paidLbl.textContent = lang === 'bm' ? 'Jumlah Telah Dibayar (Kumulatif):' : 'Total Paid to Date (Cumulative):';
        paidVal.textContent = `(+) ${currency} ${cumulativePaid.toFixed(2)}`;
        paidVal.style.color = '#059669';
      }

      if (balRow && balVal && balLbl) {
        balRow.style.display = 'flex';
        balLbl.textContent = lang === 'bm' ? 'Baki Selepas Bayaran Ini:' : 'Balance After This Payment:';
        if (balanceAfter <= 0.009) {
          balVal.textContent = `${currency} 0.00 (${lang === 'bm' ? 'TELAH LUNAS' : 'PAID IN FULL'})`;
          balVal.style.color = '#059669';
        } else {
          balVal.textContent = `${currency} ${balanceAfter.toFixed(2)} (${lang === 'bm' ? 'BELUM JELAS' : 'PENDING'})`;
          balVal.style.color = '#b45309';
        }
      }

      if (grandTotalLbl) {
        if (docType === 'deposit_receipt') {
          grandTotalLbl.textContent = t.lblPdfGrandTotalDepositReceipt;
        } else if (balanceAfter <= 0.009) {
          grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH BAYARAN PENUH DITERIMA' : 'TOTAL PAYMENT RECEIVED (PAID IN FULL)';
        } else {
          grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH BAYARAN DITERIMA (BAHAGIAN)' : 'PARTIAL PAYMENT RECEIVED';
        }
      }

      if (grandTotalEl) {
        grandTotalEl.textContent = `${currency} ${thisPaymentAmt.toFixed(2)}`;
        grandTotalEl.style.color = (docType === 'deposit_receipt') ? '#0284c7' : '#059669';
      }

      if (wordsTitleLbl) {
        wordsTitleLbl.textContent = (docType === 'deposit_receipt')
          ? t.lblPdfWordsTitleDeposit
          : (lang === 'bm' ? 'Jumlah Bayaran Resit Ini Dalam Perkataan' : 'Amount Received in Words');
      }

      if (wordsEl) {
        wordsEl.textContent = numberToWordsMYR(thisPaymentAmt, lang);
      }

    } else if (docType === 'invoice') {
      if (depRow) depRow.style.display = 'none';
      if (depositPaidAmt > 0) {
        if (paidRow && paidVal && paidLbl) {
          paidRow.style.display = 'flex';
          paidLbl.textContent = t.lblPdfDepositDeductedRow;
          paidVal.textContent = `(-) ${currency} ${depositPaidAmt.toFixed(2)}`;
          paidVal.style.color = '#059669';
        }
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = t.lblPdfBalance;
          balVal.textContent = `${currency} ${balAmt.toFixed(2)}`;
          balVal.style.color = balAmt <= 0 ? '#059669' : '#b45309';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalInvoice;
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${balAmt.toFixed(2)}`;
          grandTotalEl.style.color = balAmt <= 0 ? '#059669' : '#5b21b6';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(balAmt, lang);
      } else {
        if (paidRow) paidRow.style.display = 'none';
        if (balRow) balRow.style.display = 'none';
        if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalInvoiceNoDep;
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${grandTotal.toFixed(2)}`;
          grandTotalEl.style.color = '#5b21b6';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(grandTotal, lang);
      }
    } else {
      // Quotation
      if (depRow && depVal && depLbl) {
        depRow.style.display = 'flex';
        depLbl.textContent = `${t.lblPdfDepositReq} (${depositPct}%):`;
        depVal.textContent = `${currency} ${depReqAmount.toFixed(2)}`;
      }
      if (paidRow) paidRow.style.display = 'none';
      if (balRow) balRow.style.display = 'none';

      if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalQuotation;
      if (grandTotalEl) {
        grandTotalEl.textContent = `${currency} ${grandTotal.toFixed(2)}`;
        grandTotalEl.style.color = '#ea580c';
      }
      if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
      if (wordsEl) wordsEl.textContent = numberToWordsMYR(grandTotal, lang);
    }
  }

  // 8. Terms & Notes
  const termsList = document.getElementById('pdfTermsList');
  if (termsList) {
    termsList.innerHTML = '';
    let list;
    if (isMonthly) {
      if (currentMonthInv) {
        list = t.termsInvoiceMonthly || PDF_DOC_I18N.bm.termsInvoiceMonthly;
      } else {
        list = docType === 'quotation' 
          ? (t.termsQuotationMonthly || PDF_DOC_I18N.bm.termsQuotationMonthly)
          : (docType === 'deposit_receipt' ? t.termsDepositReceipt : (docType === 'invoice' ? (t.termsInvoiceMonthly || PDF_DOC_I18N.bm.termsInvoiceMonthly) : t.termsReceipt));
      }
    } else {
      list = docType === 'deposit_receipt' 
        ? t.termsDepositReceipt 
        : docType === 'quotation' 
          ? t.termsQuotation 
          : docType === 'invoice' 
            ? t.termsInvoice 
            : t.termsReceipt;
    }
    list.forEach(item => {
      const li = document.createElement('li');
      li.textContent = item;
      termsList.appendChild(li);
    });
  }

  // 9. Bank Details (Only use user's saved settings, hide if empty)
  const bankNameEl = document.getElementById('pdfBankName');
  const bankNameRow = bankNameEl ? bankNameEl.closest('div') : null;
  if (bankNameRow && bankNameEl) {
    if (settings.bankName && settings.bankName.trim()) {
      bankNameRow.style.display = 'flex';
      bankNameEl.textContent = settings.bankName.trim();
    } else {
      bankNameRow.style.display = 'none';
    }
  }

  const bankAccNumEl = document.getElementById('pdfBankAccNum');
  const bankAccNumRow = bankAccNumEl ? bankAccNumEl.closest('div') : null;
  if (bankAccNumRow && bankAccNumEl) {
    if (settings.bankAccNum && settings.bankAccNum.trim()) {
      bankAccNumRow.style.display = 'flex';
      bankAccNumEl.textContent = settings.bankAccNum.trim();
    } else {
      bankAccNumRow.style.display = 'none';
    }
  }

  const bankAccHolderEl = document.getElementById('pdfBankAccHolder');
  const bankAccHolderRow = bankAccHolderEl ? bankAccHolderEl.closest('div') : null;
  if (bankAccHolderRow && bankAccHolderEl) {
    const holder = settings.bankAccHolder || settings.businessName || '';
    if (holder && holder.trim()) {
      bankAccHolderRow.style.display = 'flex';
      bankAccHolderEl.textContent = holder.trim();
    } else {
      bankAccHolderRow.style.display = 'none';
    }
  }

  const bankBranchEl = document.getElementById('pdfBankBranch');
  const bankBranchRow = bankBranchEl ? bankBranchEl.closest('div') : null;
  if (bankBranchRow && bankBranchEl) {
    if (settings.bankBranch && settings.bankBranch.trim()) {
      bankBranchRow.style.display = 'flex';
      bankBranchEl.textContent = settings.bankBranch.trim();
    } else {
      bankBranchRow.style.display = 'none';
    }
  }

  const duitNowEl = document.getElementById('pdfDuitNow');
  const duitNowRow = document.getElementById('pdfDuitNowRow');
  if (duitNowRow && duitNowEl) {
    if (settings.duitNow && settings.duitNow.trim()) {
      duitNowRow.style.display = 'flex';
      duitNowEl.textContent = settings.duitNow.trim();
    } else {
      duitNowRow.style.display = 'none';
    }
  }

  // 10. Optional Sales & Service Tax (SST)
  const sstRate = parseFloat(settings.sstRate) || 0;
  const sstRow = document.getElementById('pdfRowSst');
  const sstLbl = document.getElementById('lblPdfSst');
  const sstVal = document.getElementById('pdfValSst');
  if (sstRow && sstLbl && sstVal) {
    if (sstRate > 0) {
      const sstAmount = (grandTotal * sstRate) / 100;
      sstRow.style.display = 'flex';
      sstLbl.textContent = `${t.lblPdfSst || 'SST'} (${sstRate}%):`;
      sstVal.textContent = `${currency} ${sstAmount.toFixed(2)}`;
    } else {
      sstRow.style.display = 'none';
    }
  }

  // Document UID
  const uidEl = document.getElementById('pdfDocUid');
  if (uidEl) uidEl.textContent = `UID: MHY-${year}-${idShort}`;

  // Translated Labels
  const thItemEl = document.getElementById('thPdfItem');
  if (thItemEl) thItemEl.textContent = t.thPdfItem;

  const thQtyEl = document.getElementById('thPdfQty');
  if (thQtyEl) thQtyEl.textContent = t.thPdfQty;

  const thRateEl = document.getElementById('thPdfRate');
  if (thRateEl) thRateEl.textContent = `${t.thPdfRate} (${currency})`;

  const thTaxEl = document.getElementById('thPdfTax');
  if (thTaxEl) thTaxEl.textContent = `${t.thPdfTax} (${currency})`;

  const thAmtEl = document.getElementById('thPdfAmount');
  if (thAmtEl) thAmtEl.textContent = `${t.thPdfAmount} (${currency})`;

  const subTotalTableLbl = document.getElementById('lblPdfSubTotalTable');
  if (subTotalTableLbl) subTotalTableLbl.textContent = t.lblPdfSubTotalTable;

  const extraChargesLbl = document.getElementById('lblPdfExtraCharges');
  if (extraChargesLbl) extraChargesLbl.textContent = t.lblPdfExtraCharges;

  const taxableLbl = document.getElementById('lblPdfTaxableAmount');
  if (taxableLbl) taxableLbl.textContent = t.lblPdfTaxableAmount;

  const discLbl = document.getElementById('lblPdfDiscount');
  if (discLbl) discLbl.textContent = t.lblPdfDiscount;

  const bankTitleLbl = document.getElementById('lblPdfBankTitle');
  if (bankTitleLbl) bankTitleLbl.textContent = t.lblPdfBankTitle;

  const accHolderLbl = document.getElementById('lblPdfAccHolder');
  if (accHolderLbl) accHolderLbl.textContent = t.lblPdfAccHolder;

  const accNumLbl = document.getElementById('lblPdfAccNum');
  if (accNumLbl) accNumLbl.textContent = t.lblPdfAccNum;

  const bankNameLbl = document.getElementById('lblPdfBankName');
  if (bankNameLbl) bankNameLbl.textContent = t.lblPdfBankName;

  const branchLbl = document.getElementById('lblPdfBranch');
  if (branchLbl) branchLbl.textContent = t.lblPdfBranch;

  const duitNowLbl = document.getElementById('lblPdfDuitNow');
  if (duitNowLbl) duitNowLbl.textContent = t.lblPdfDuitNow;

  const termsTitleLbl = document.getElementById('lblPdfTermsTitle');
  if (termsTitleLbl) termsTitleLbl.textContent = t.lblPdfTermsTitle;

  const authLbl = document.getElementById('lblPdfAuthorized');
  if (authLbl) authLbl.textContent = t.lblPdfAuthorized;

  const sigTextEl = document.getElementById('pdfSignatureText');
  if (sigTextEl) sigTextEl.textContent = settings.ownerName || (lang === 'bm' ? 'Pengurus Homestay' : 'Homestay Manager');

  // WhatsApp Prompt Banner Translations
  const waPromptTitle = document.getElementById('txtWaPromptTitle');
  if (waPromptTitle) waPromptTitle.textContent = t.txtWaPromptTitle;

  const waPromptSub = document.getElementById('txtWaPromptSub');
  if (waPromptSub) waPromptSub.textContent = t.txtWaPromptSub;

  const btnPromptYes = document.getElementById('txtBtnPromptYes');
  if (btnPromptYes) btnPromptYes.textContent = t.txtBtnPromptYes;

  const btnPromptNo = document.getElementById('txtBtnPromptNo');
  if (btnPromptNo) btnPromptNo.textContent = t.txtBtnPromptNo;
}

function printPdfDocument() {
  const isBM = (appState.activePdfLang || appState.settings.language) === 'bm';
  showToast(isBM ? 'Membuka dialog cetak... Sila pilih "Save as PDF" / "Simpan sebagai PDF".' : 'Opening print dialog... Please select "Save as PDF".');
  setTimeout(() => {
    window.print();
  }, 350);
}

/**
 * Helper: Extract structured metadata and filenames for current PDF document
 */
function getPdfDocMeta() {
  const booking = appState.activePdfBooking;
  if (!booking) return null;
  const docType = appState.activePdfDocType || 'quotation';
  const lang = appState.activePdfLang || appState.settings.language || 'bm';
  const isBM = lang === 'bm';
  const prop = getPropertyById(booking.propertyId) || { name: 'Homestay Unit' };
  const year = new Date().getFullYear();
  const idShort = (booking.id || '').replace(/\D/g, '').slice(-4) || '1088';
  const isMonthly = (booking.rentalType === 'monthly');
  const activeMonth = appState.activePdfMonthIndex;

  let prefix = 'QT';
  let docTitle = isBM ? 'Sebut Harga Rasmi' : 'Official Quotation';

  if (isMonthly) {
    if (activeMonth !== null && activeMonth !== undefined) {
      if (docType === 'receipt') {
        prefix = `REC_M${activeMonth}`;
        docTitle = isBM ? `Resit Bayaran Sewa Bulan ke-${activeMonth}` : `Month ${activeMonth} Rent Payment Receipt`;
      } else {
        prefix = `INV_M${activeMonth}`;
        docTitle = isBM ? `Invois Sewa Bulan ke-${activeMonth}` : `Month ${activeMonth} Rent Invoice`;
      }
    } else {
      if (docType === 'invoice') {
        prefix = 'INV_M';
        docTitle = isBM ? 'Invois Kemasukan Sewaan Bulanan' : 'Monthly Tenancy Move-in Invoice';
      } else if (docType === 'deposit_receipt') {
        prefix = 'REC_BOOK_M';
        docTitle = isBM ? 'Resit Bayaran Booking Sewaan' : 'Tenancy Booking Receipt';
      } else if (docType === 'receipt') {
        prefix = 'REC_M';
        docTitle = isBM ? 'Resit Rasmi Bayaran Kemasukan' : 'Move-in Payment Receipt';
      } else {
        prefix = 'QUO_M';
        docTitle = isBM ? 'Sebut Harga Pakej Kemasukan Sewaan Bulanan' : 'Monthly Tenancy Move-In Quotation';
      }
    }
  } else {
    if (docType === 'invoice') {
      prefix = 'INV';
      docTitle = isBM ? 'Invois Rasmi' : 'Official Invoice';
    } else if (docType === 'deposit_receipt') {
      prefix = 'REC_DEP';
      docTitle = isBM ? 'Resit Bayaran Deposit' : 'Deposit Payment Receipt';
    } else if (docType === 'receipt') {
      prefix = 'REC';
      docTitle = isBM ? 'Resit Bayaran Penuh' : 'Official Payment Receipt';
    }
  }

  const cleanName = (booking.guestName || 'Tetamu').replace(/[^a-zA-Z0-9_-]/g, '_');
  const domDocNo = document.getElementById('pdfDocNo')?.textContent?.trim();
  const fullDocNo = (domDocNo && !domDocNo.includes('(Draf)')) ? domDocNo : `${prefix.replace(/_/g, '-')}-${year}-${idShort}`;
  const docNoClean = fullDocNo.replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `${docNoClean}_${cleanName}.pdf`;
  return { booking, docType, lang, isBM, prop, year, idShort, prefix, docTitle, cleanName, fileName, fullDocNo, isMonthly, activeMonth };
}

/**
 * Reliable PDF Blob generator using direct, scroll-safe A4 element capture.
 * Guarantees standard 794px A4 layout, zero blank pages, zero horizontal cutoffs on PC & Mobile!
 */
function generatePdfBlob(onSuccess, onError) {
  const element = document.getElementById('printablePdfSheet');
  if (!element) {
    if (onError) onError(new Error('Elemen PDF tidak ditemui'));
    return;
  }

  const meta = getPdfDocMeta();
  const fileName = meta ? meta.fileName : 'Dokumen.pdf';

  if (typeof window.html2pdf === 'function') {
    // 1. Capture current scroll offsets so we can restore them seamlessly
    const modalBody = document.querySelector('#pdfDocModal .modal-body') || document.querySelector('.modal-body');
    const savedModalScroll = modalBody ? modalBody.scrollTop : 0;
    const savedWinScrollY = window.scrollY || window.pageYOffset || 0;
    const savedWinScrollX = window.scrollX || window.pageXOffset || 0;

    // 2. Temporarily reset scroll to 0 so html2canvas renders from exact top without viewport clipping
    if (modalBody) modalBody.scrollTop = 0;
    window.scrollTo(0, 0);

    // 3. Temporarily apply compact A4 1-page rendering class & enforce standard 794px width
    element.classList.add('pdf-rendering-mode');

    // 4. Configure html2pdf with zero margins and origin coordinates
    const opt = {
      margin: 0,
      filename: fileName,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        logging: false,
        scrollY: 0,
        scrollX: 0,
        backgroundColor: '#ffffff'
      },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    let resolved = false;
    const restore = () => {
      element.classList.remove('pdf-rendering-mode');
      if (modalBody) modalBody.scrollTop = savedModalScroll;
      window.scrollTo(savedWinScrollX, savedWinScrollY);
    };

    const timer = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        restore();
        console.warn('html2pdf took longer than 6s, triggering fallback');
        if (onError) onError(new Error('timeout'));
      }
    }, 6000);

    window.html2pdf().set(opt).from(element).output('blob').then(blob => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        restore();
        if (onSuccess) onSuccess(blob, fileName);
      }
    }).catch(err => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        restore();
        console.warn('html2pdf generation error:', err);
        if (onError) onError(err);
      }
    });
  } else {
    if (onError) onError(new Error('html2pdf_not_loaded'));
  }
}

/**
 * Direct file download as standard PDF with interactive feedback card
 */
function downloadPdfDocument() {
  const meta = getPdfDocMeta();
  if (!meta) return;

  const isBM = meta.isBM;
  const fileName = meta.fileName;
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  const statusCard = document.getElementById('pdfActionStatusCard');

  if (statusCard) {
    statusCard.style.display = 'block';
    statusCard.innerHTML = `
      <div style="background:#eff6ff; border:1.5px solid #3b82f6; border-radius:12px; padding:16px; display:flex; align-items:center; gap:12px; box-shadow:0 4px 12px rgba(59,130,246,0.1);">
        <div class="loading-spinner" style="width:26px; height:26px; border-width:3px; border-color:#3b82f6; border-top-color:transparent; flex-shrink:0;"></div>
        <div>
          <strong style="color:#1d4ed8; font-size:13.5px; display:block;">${isBM ? 'Sedang Menjana Fail PDF Standard A4...' : 'Generating Official A4 PDF Document...'}</strong>
          <span style="font-size:11.5px; color:#2563eb;">${isBM ? `Fail "${fileName}" sedang diproses untuk muat turun terus ke komputer/peranti anda.` : `Processing "${fileName}" for download.`}</span>
        </div>
      </div>
    `;
    statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  showToast(isBM ? 'Menjana fail PDF rasmi...' : 'Generating official PDF...');

  generatePdfBlob((blob, fName) => {
    const blobUrl = URL.createObjectURL(blob);

    // 1. Direct Anchor Download (Guaranteed download to user's Downloads folder)
    const downloadAnchor = document.createElement('a');
    downloadAnchor.href = blobUrl;
    downloadAnchor.download = fName;
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    setTimeout(() => {
      document.body.removeChild(downloadAnchor);
    }, 1500);

    // 2. Rich Interactive Status Card with Direct Links & Shortcuts
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#ecfdf5; border:2px solid #10b981; border-radius:12px; padding:18px; box-shadow:0 6px 16px rgba(16,185,129,0.12);">
          <div style="display:flex; align-items:flex-start; gap:14px; margin-bottom:14px;">
            <div style="width:44px; height:44px; border-radius:50%; background:#10b981; color:#fff; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0; box-shadow:0 3px 8px rgba(16,185,129,0.35);">
              <i class="fa-solid fa-circle-check"></i>
            </div>
            <div style="flex:1;">
              <h4 style="margin:0; color:#065f46; font-size:15px; font-weight:800;">
                ${isBM ? '✅ Fail PDF Berjaya Dijana & Dimuat Turun!' : '✅ PDF Document Generated & Downloaded!'}
              </h4>
              <p style="margin:4px 0 0 0; font-size:12px; color:#047857; line-height:1.5;">
                ${isBM 
                  ? `Fail telah disimpan terus ke folder <strong>Downloads</strong> komputer / telefon anda sebagai:<br><strong style="font-family:monospace; color:#0f172a; background:#e2e8f0; padding:2px 6px; border-radius:4px;">${fName}</strong>`
                  : `File saved directly into your <strong>Downloads</strong> folder as:<br><strong style="font-family:monospace; color:#0f172a; background:#e2e8f0; padding:2px 6px; border-radius:4px;">${fName}</strong>`}
              </p>
              ${!isMobile ? `
                <div style="margin-top:6px; font-size:11px; color:#64748b;">
                  ${isBM ? '💡 Tip: Tekan <kbd style="background:#f1f5f9; border:1px solid #cbd5e1; padding:1px 5px; border-radius:3px;">Ctrl</kbd> + <kbd style="background:#f1f5f9; border:1px solid #cbd5e1; padding:1px 5px; border-radius:3px;">J</kbd> (Windows) atau semak ikon muat turun pelayar.' : '💡 Tip: Press Ctrl + J to see downloaded files.'}
                </div>
              ` : `
                <div style="margin-top:8px; font-size:11.5px; color:#14532d; background:#dcfce7; border:1px solid #86efac; border-radius:8px; padding:8px 12px; line-height:1.5;">
                  📱 <strong>Pengguna Telefon:</strong> Fail PDF telah disimpan ke folder <strong>Downloads</strong> peranti anda. Anda boleh membukanya daripada notifikasi muat turun di bar atas skrin atau kongsi terus ke WhatsApp.
                </div>
              `}
            </div>
          </div>
          <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
            ${!isMobile ? `
              <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:linear-gradient(135deg, #0284c7, #0369a1);">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? '👁️ Buka & Lihat PDF Sekarang' : '👁️ View PDF Now'}
              </a>
              <a href="${blobUrl}" download="${fName}" class="btn btn-outline btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; color:#065f46; border-color:#059669; background:#fff;">
                <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun Semula' : 'Download Again'}
              </a>
            ` : `
              <a href="${blobUrl}" download="${fName}" class="btn btn-primary btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:linear-gradient(135deg, #ea580c, #c2410c);">
                <i class="fa-solid fa-file-arrow-down"></i> ${isBM ? '📥 Muat Turun Semula' : '📥 Download Again'}
              </a>
            `}
            <button type="button" class="btn btn-whatsapp btn-sm" id="btnStatusCardWa" style="font-weight:800; display:inline-flex; align-items:center; gap:6px;">
              <i class="fa-brands fa-whatsapp"></i> ${isBM ? '📲 Hantar ke WhatsApp Tetamu' : 'Send via WhatsApp'}
            </button>
            <button type="button" class="btn btn-outline btn-sm" id="btnDismissStatusCard" style="font-size:11px; background:#fff; color:#64748b; margin-left:auto;">
              ${isBM ? 'Tutup' : 'Dismiss'}
            </button>
          </div>
        </div>
      `;
      document.getElementById('btnStatusCardWa')?.addEventListener('click', sharePdfViaWhatsApp);
      document.getElementById('btnDismissStatusCard')?.addEventListener('click', () => {
        statusCard.style.display = 'none';
      });
      statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    showToast(isBM 
      ? `✅ Fail dimuat turun: "${fName}" (Disimpan di Downloads)` 
      : `✅ Downloaded: "${fName}"`, 6000);

  }, (err) => {
    console.warn('PDF blob generation error, fallback to print:', err);
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#fffbeb; border:1.5px solid #f59e0b; border-radius:12px; padding:16px;">
          <strong style="color:#b45309; display:block; font-size:13.5px;">⚠️ Menggunakan Cetakan Sistem Pelayar</strong>
          <p style="margin:4px 0 10px 0; font-size:12px; color:#92400e;">
            ${isBM 
              ? 'Tetingkap cetakan dibuka. Sila pilih <strong>"Save as PDF" / "Simpan sebagai PDF"</strong> pada pilihan Destination/Pencetak untuk menyimpan fail.'
              : 'Print dialog opened. Please select "Save as PDF" to save the file.'}
          </p>
          <button type="button" class="btn btn-primary btn-sm" id="btnRetryPrint" style="font-weight:700;">
            <i class="fa-solid fa-print"></i> ${isBM ? 'Buka Cetak / Simpan PDF' : 'Print / Save as PDF'}
          </button>
        </div>
      `;
      document.getElementById('btnRetryPrint')?.addEventListener('click', () => window.print());
    }
    window.print();
  });
}

/**
 * Open generated PDF directly in a new browser tab for immediate viewing/printing
 */
function viewPdfInNewTab() {
  const meta = getPdfDocMeta();
  if (!meta) return;

  const isBM = meta.isBM;
  const fileName = meta.fileName;
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  // On Mobile: Browsers cannot render blob: PDFs in new tabs (results in blank white tab).
  // Automatically trigger download so phone opens it in native PDF viewer.
  if (isMobile) {
    showToast(isBM ? 'Menjana & memuat turun fail PDF untuk telefon...' : 'Generating & downloading PDF for mobile...');
    downloadPdfDocument();
    return;
  }

  // Pre-open window synchronously to avoid popup blocker
  let newTab = null;
  try {
    newTab = window.open('about:blank', '_blank');
    if (newTab) {
      newTab.document.write(`
        <!DOCTYPE html><html><body style="font-family:system-ui,sans-serif; text-align:center; padding:50px; background:#f8fafc; color:#0f172a;">
          <h3 style="color:#0284c7;">Menjana Fail PDF...</h3><p style="color:#64748b;">Sila tunggu sebentar, dokumen akan dibuka serta-merta.</p>
        </body></html>
      `);
    }
  } catch(e) {
    console.warn('Could not pre-open new tab:', e);
  }

  showToast(isBM ? 'Menjana PDF untuk dibuka di tab baru...' : 'Generating PDF to open in new tab...');

  generatePdfBlob((blob, fName) => {
    const blobUrl = URL.createObjectURL(blob);
    if (newTab && !newTab.closed) {
      newTab.location.href = blobUrl;
    } else {
      window.open(blobUrl, '_blank');
    }

    const statusCard = document.getElementById('pdfActionStatusCard');
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#f0fdf4; border:1.5px solid #10b981; border-radius:12px; padding:14px 16px; display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap;">
          <div style="display:flex; align-items:center; gap:10px;">
            <i class="fa-solid fa-circle-check" style="color:#059669; font-size:20px;"></i>
            <span style="font-size:12.5px; color:#065f46; font-weight:700;">
              ${isBM ? 'PDF telah dibuka di tab baru pelayar anda!' : 'PDF opened in a new browser tab!'}
            </span>
          </div>
          <div style="display:flex; gap:6px;">
            <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-xs" style="font-weight:700; text-decoration:none;">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? 'Klik Sini Jika Tab Tidak Terbuka' : 'Click Here If Tab Did Not Open'}
            </a>
            <a href="${blobUrl}" download="${fName}" class="btn btn-outline btn-xs" style="font-weight:700; text-decoration:none; background:#fff;">
              <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun' : 'Download'}
            </a>
          </div>
        </div>
      `;
    }
    showToast(isBM ? 'PDF dibuka di tab baru pelayar anda!' : 'PDF opened in a new browser tab!');
  }, (err) => {
    console.warn('Error generating PDF for new tab:', err);
    window.print();
  });
}

/**
 * Share PDF directly to WhatsApp with file attachment & unblockable popup prevention
 */
function sharePdfViaWhatsApp() {
  const meta = getPdfDocMeta();
  if (!meta) return;

  const { booking, docType, lang, isBM, prop, fullDocNo, fileName, docTitle } = meta;
  const currency = appState.settings.currency || 'RM';
  const grandTotal = booking.totalAmount || 0;

  let depositPaidAmt = parseFloat(document.getElementById('pdfDepositAmountInput')?.value);
  if (isNaN(depositPaidAmt)) {
    depositPaidAmt = Number(booking.depositPaid || (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0) || 0);
  }
  if (depositPaidAmt === 0 && (docType === 'deposit_receipt' || booking.status === 'booked')) {
    depositPaidAmt = Number(booking.depositAmount || Math.round(grandTotal * (appState.settings.defaultDepositPct || 30) / 100));
  }
  const balAmt = Math.max(0, grandTotal - depositPaidAmt);

  const isMonthly = (booking.rentalType === 'monthly');
  const activeMonth = appState.activePdfMonthIndex;

  let message = '';
  if (isMonthly) {
    if (activeMonth !== null && activeMonth !== undefined) {
      const inv = (booking.monthlyInvoices || []).find(x => x.monthIndex === activeMonth);
      const invTotal = inv ? (inv.totalAmount || inv.rentAmount) : (booking.monthlyRate || 0);
      const isPaid = inv && inv.status === 'paid';
      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi bayaran sewaan *Bulan ke-${activeMonth}* di *${prop.name}* (${inv ? `${inv.periodStart} → ${inv.periodEnd}` : ''}).\n\n💰 *Jumlah: ${currency} ${invTotal.toFixed(2)}* (${isPaid ? 'TELAH DIBAYAR' : `Tarikh Akhir: ${inv ? inv.dueDate : '-'}`})\n\n📄 *Sila rujuk fail PDF yang dilampirkan.* Terima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) for *Month ${activeMonth}* rental at *${prop.name}* (${inv ? `${inv.periodStart} → ${inv.periodEnd}` : ''}).\n\n💰 *Amount: ${currency} ${invTotal.toFixed(2)}* (${isPaid ? 'PAID' : `Due Date: ${inv ? inv.dueDate : '-'}`})\n\n📄 *Please refer to the attached PDF file.* Thank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    } else if (docType === 'deposit_receipt') {
      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi pengesahan bayaran booking sewaan bulanan di *${prop.name}* (${booking.monthlyStart || booking.checkIn}, tempoh ${booking.monthlyDuration || 6} Bulan).\n\n💰 *Rekod Bayaran:*\n• Pakej Kemasukan: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Booking Diterima:* *${currency} ${depositPaidAmt.toFixed(2)}*\n• 💳 *Baki Sebelum Serahan Kunci:* *${currency} ${balAmt.toFixed(2)}*\n\n📄 *Sila rujuk fail PDF yang dilampirkan.*\n\nTerima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) confirming your booking payment for monthly tenancy at *${prop.name}* (${booking.monthlyStart || booking.checkIn}, duration ${booking.monthlyDuration || 6} Months).\n\n💰 *Payment Record:*\n• Move-in Package: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Booking Received:* *${currency} ${depositPaidAmt.toFixed(2)}*\n• 💳 *Balance Due upon Key Handover:* *${currency} ${balAmt.toFixed(2)}*\n\n📄 *Please refer to the attached PDF file.*\n\nThank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    } else {
      // Monthly Move-in Quotation or Move-in Invoice
      const mRate = booking.monthlyRate || 0;
      const rDep = booking.rentalDeposit !== undefined ? booking.rentalDeposit : mRate;
      const uDep = booking.utilitiesDeposit !== undefined ? booking.utilitiesDeposit : 300;
      const aFee = booking.agreementFee !== undefined ? booking.agreementFee : 0;
      const totalMoveIn = mRate + rDep + uDep + aFee;
      const bookingFee = (booking.depositPaid > 0) ? booking.depositPaid : Math.round(mRate * 0.5);
      const balHandover = Math.max(0, totalMoveIn - bookingFee);

      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi sewaan bulanan di *${prop.name}* (${booking.monthlyStart || booking.checkIn}, tempoh ${booking.monthlyDuration || 6} Bulan).\n\n💰 *Perincian Pakej Kemasukan (Move-In):*\n• Sewa Bulan Pertama (Pendahuluan): ${currency} ${mRate.toFixed(2)}\n• Deposit Keselamatan Sewa (1 Bulan Sewa): ${currency} ${rDep.toFixed(2)}\n• Deposit Utiliti (Air & Elektrik): ${currency} ${uDep.toFixed(2)}\n${aFee > 0 ? `• Yuran Perjanjian Sewa & Duti Setem: ${currency} ${aFee.toFixed(2)}\n` : ''}----------------------------------------\n💵 *Jumlah Bayaran Kemasukan:* *${currency} ${totalMoveIn.toFixed(2)}*\n🔒 *Bayaran Booking Diperlukan untuk Kunci Unit:* ${currency} ${bookingFee.toFixed(2)}\n⏳ *Baki Sebelum Serahan Kunci:* ${currency} ${balHandover.toFixed(2)}\n\n📌 *Syarat & Polisi Sewaan Bulanan:*\n1. Bayaran sewa bulanan dikutip secara pendahuluan (advance) pada awal setiap bulan sewaan melalui Invois Rasmi.\n2. Bagi sewaan jangka panjang melebihi 1 bulan, bil utiliti (elektrik & air) adalah mengikut kadar penggunaan bulanan sebenar (dibayar terus oleh penyewa atau dimasukkan ke dalam invois sewa bulanan).\n3. Deposit Keselamatan (1 bulan sewa) dan Deposit Utiliti (${currency} ${uDep.toFixed(2)}) akan dipulangkan sepenuhnya pada akhir tempoh sewaan tertakluk kepada bil utiliti dan pemeriksaan unit.\n\n📄 *Sila rujuk fail PDF yang dilampirkan.*\n\nTerima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) for the monthly tenancy at *${prop.name}* (${booking.monthlyStart || booking.checkIn}, duration ${booking.monthlyDuration || 6} Months).\n\n💰 *Move-in Initial Package Breakdown:*\n• 1st Month Advance Rent: ${currency} ${mRate.toFixed(2)}\n• Rental Security Deposit (1 Month Rent): ${currency} ${rDep.toFixed(2)}\n• Utilities Deposit (Electricity & Water): ${currency} ${uDep.toFixed(2)}\n${aFee > 0 ? `• Tenancy Agreement & Stamp Duty: ${currency} ${aFee.toFixed(2)}\n` : ''}----------------------------------------\n💵 *Total Move-in Package:* *${currency} ${totalMoveIn.toFixed(2)}*\n🔒 *Booking Fee to Reserve Unit:* ${currency} ${bookingFee.toFixed(2)}\n⏳ *Balance Due upon Key Handover:* ${currency} ${balHandover.toFixed(2)}\n\n📌 *Monthly Tenancy Terms & Policies:*\n1. Monthly rental is collected in advance at the beginning of each rental month via official invoice.\n2. In long-term rentals over 1 month, utilities (electricity & water) are charged per actual usage (paid directly by tenant or added into monthly invoice).\n3. Rental Deposit (1 month rent) and Utilities Deposit (${currency} ${uDep.toFixed(2)}) are fully refundable at the end of tenancy subject to utility clearance and unit inspection.\n\n📄 *Please refer to the attached PDF file.*\n\nThank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    }
  } else {
    // Non-monthly / Daily booking
    const payments = Array.isArray(booking.payments) ? booking.payments : [];
    let selectedPayment = null;
    let cumulativePaid = 0;
    let balanceAfter = 0;
    let thisPaymentAmt = 0;

    if (payments.length > 0) {
      if (appState.activePdfPaymentId) {
        selectedPayment = payments.find(p => p.id === appState.activePdfPaymentId) || null;
      }
      if (!selectedPayment) {
        if (docType === 'deposit_receipt') {
          selectedPayment = payments.find(p => p.type === 'deposit') || payments[0];
        } else {
          selectedPayment = payments[payments.length - 1];
        }
      }
      const pIdx = payments.findIndex(p => p.id === selectedPayment.id);
      const paymentsUpTo = payments.slice(0, pIdx >= 0 ? pIdx + 1 : 1);
      cumulativePaid = paymentsUpTo.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      balanceAfter = Math.max(0, grandTotal - cumulativePaid);
      thisPaymentAmt = Number(selectedPayment.amount || 0);
    } else {
      thisPaymentAmt = depositPaidAmt;
      cumulativePaid = depositPaidAmt;
      balanceAfter = Math.max(0, grandTotal - cumulativePaid);
    }

    if (docType === 'deposit_receipt') {
      const pRef = selectedPayment && (selectedPayment.reference || selectedPayment.ref || selectedPayment.referenceNo) ? ` (Ruj: ${selectedPayment.reference || selectedPayment.ref || selectedPayment.referenceNo})` : '';
      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi bayaran deposit penginapan di *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n💰 *Rekod Bayaran:*\n• Jumlah Pakej: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Deposit Diterima:* *${currency} ${thisPaymentAmt.toFixed(2)}*${pRef}\n• 💵 *Jumlah Telah Dibayar:* *${currency} ${cumulativePaid.toFixed(2)}*\n• 💳 *Baki Sebelum Masuk:* *${currency} ${balanceAfter.toFixed(2)}*\n\n📄 *Sila rujuk fail PDF yang dilampirkan.* Sila maklumkan kepada kami sekiranya pihak kewangan / pejabat anda memerlukan sebarang pengesahan lanjut.\n\nTerima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) confirming your deposit payment for the stay at *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n💰 *Payment Record:*\n• Total Package: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Deposit Received:* *${currency} ${thisPaymentAmt.toFixed(2)}*${pRef}\n• 💵 *Total Paid to Date:* *${currency} ${cumulativePaid.toFixed(2)}*\n• 💳 *Remaining Balance:* *${currency} ${balanceAfter.toFixed(2)}*\n\n📄 *Please refer to the attached PDF file.* Kindly let us know if your accounts / finance department requires any further verification.\n\nThank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    } else if (docType === 'receipt') {
      const pRef = selectedPayment && (selectedPayment.reference || selectedPayment.ref || selectedPayment.referenceNo) ? ` (Ruj: ${selectedPayment.reference || selectedPayment.ref || selectedPayment.referenceNo})` : '';
      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi bayaran penginapan di *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n💰 *Perincian Bayaran:*\n• Jumlah Pakej: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Bayaran Diterima (Resit Ini):* *${currency} ${thisPaymentAmt.toFixed(2)}*${pRef}\n• 💵 *Jumlah Telah Dibayar (Kumulatif):* *${currency} ${cumulativePaid.toFixed(2)}*\n• ${balanceAfter <= 0.009 ? '🎉 *Status: TELAH LUNAS SEPENUHNYA (Baki: RM 0.00)*' : `💳 *Baki Selepas Bayaran Ini:* *${currency} ${balanceAfter.toFixed(2)}*`}\n\n📄 *Sila rujuk fail PDF yang dilampirkan.* Sila maklumkan kepada kami sekiranya pihak kewangan / pejabat anda memerlukan sebarang pengesahan lanjut.\n\nTerima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) for your stay at *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n💰 *Payment Breakdown:*\n• Total Package: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Payment Received (This Receipt):* *${currency} ${thisPaymentAmt.toFixed(2)}*${pRef}\n• 💵 *Total Paid to Date (Cumulative):* *${currency} ${cumulativePaid.toFixed(2)}*\n• ${balanceAfter <= 0.009 ? '🎉 *Status: PAID IN FULL (Balance: RM 0.00)*' : `💳 *Balance After This Payment:* *${currency} ${balanceAfter.toFixed(2)}*`}\n\n📄 *Please refer to the attached PDF file.* Kindly let us know if your accounts / finance department requires any further verification.\n\nThank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    } else {
      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi penginapan di *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n📄 *Sila rujuk fail PDF yang dilampirkan.* Sila maklumkan kepada kami sekiranya pihak kewangan / pejabat anda memerlukan sebarang pengesahan lanjut.\n\nTerima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) for your stay at *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n📄 *Please refer to the attached PDF file.* Kindly let us know if your accounts / finance department requires any further verification.\n\nThank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    }
  }

  // Copy text to clipboard
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(message);
  }

  const cleanPhone = normalizePhoneNumber(booking.guestPhone);
  const waUrl = cleanPhone 
    ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`
    : `https://wa.me/?text=${encodeURIComponent(message)}`;

  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  let waWindow = null;

  // ON DESKTOP: Pre-open the window synchronously within the user click gesture!
  // This guarantees that browser popup blockers will NEVER block WhatsApp Web!
  if (!isMobile) {
    try {
      waWindow = window.open('about:blank', '_blank');
      if (waWindow) {
        waWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head><title>Menghubungkan ke WhatsApp...</title></head>
          <body style="font-family:system-ui,sans-serif; text-align:center; padding:50px; background:#f8fafc; color:#0f172a;">
            <div style="max-width:480px; margin:0 auto; background:#fff; padding:30px; border-radius:16px; box-shadow:0 4px 20px rgba(0,0,0,0.08); border:1px solid #e2e8f0;">
              <div style="font-size:36px; margin-bottom:12px;">📲</div>
              <h2 style="color:#15803d; margin:0 0 8px 0; font-size:20px;">Menghubungkan ke WhatsApp Tetamu...</h2>
              <p style="color:#64748b; font-size:13px; line-height:1.5; margin:0 0 16px 0;">Fail PDF sedang dijana dan dimuat turun ke komputer anda.</p>
              <div style="display:inline-block; border:3px solid #e2e8f0; border-top-color:#15803d; border-radius:50%; width:24px; height:24px; animation:spin 0.8s linear infinite;"></div>
              <style>@keyframes spin { to { transform: rotate(360deg); } }</style>
            </div>
          </body>
          </html>
        `);
      }
    } catch(e) {
      console.warn('Could not pre-open blank window:', e);
    }
  }

  const statusCard = document.getElementById('pdfActionStatusCard');
  if (statusCard) {
    statusCard.style.display = 'block';
    statusCard.innerHTML = `
      <div style="background:#eff6ff; border:1.5px solid #3b82f6; border-radius:12px; padding:16px; display:flex; align-items:center; gap:12px; box-shadow:0 4px 12px rgba(59,130,246,0.1);">
        <div class="loading-spinner" style="width:26px; height:26px; border-width:3px; border-color:#3b82f6; border-top-color:transparent; flex-shrink:0;"></div>
        <div>
          <strong style="color:#1d4ed8; font-size:13.5px; display:block;">${isBM ? 'Menjana Fail PDF & Menghubungkan ke WhatsApp...' : 'Generating PDF & Connecting to WhatsApp...'}</strong>
          <span style="font-size:11.5px; color:#2563eb;">${isBM ? 'Sila tunggu sebentar, fail sedang disediakan...' : 'Please wait a moment...'}</span>
        </div>
      </div>
    `;
    statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  showToast(isBM ? 'Menjana fail PDF dan menghubungkan ke WhatsApp...' : 'Generating PDF & connecting to WhatsApp...');

  generatePdfBlob(async (pdfBlob, fName) => {
    const pdfFile = new File([pdfBlob], fName, { type: 'application/pdf' });
    const blobUrl = URL.createObjectURL(pdfBlob);

    // 1. If mobile browser supports Web Share API Level 2 with files, attach directly to WhatsApp
    if (isMobile && navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
      try {
        if (waWindow) waWindow.close();
        await navigator.share({
          title: `${docTitle} (${fullDocNo})`,
          text: message,
          files: [pdfFile]
        });
        showToast(isBM ? '✅ Berjaya dikongsi ke WhatsApp!' : '✅ Shared to WhatsApp successfully!');
        if (statusCard) statusCard.style.display = 'none';
        return;
      } catch (shareErr) {
        if (shareErr.name === 'AbortError') return;
        console.warn('navigator.share failed, fallback to download + open WhatsApp:', shareErr);
      }
    }

    // 2. Desktop & Mobile fallback:
    // Download PDF directly to Downloads folder
    const downloadAnchor = document.createElement('a');
    downloadAnchor.href = blobUrl;
    downloadAnchor.download = fName;
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    setTimeout(() => {
      document.body.removeChild(downloadAnchor);
    }, 1500);

    // Redirect the pre-opened window directly to waUrl
    if (waWindow && !waWindow.closed) {
      waWindow.location.href = waUrl;
    }

    // Render unblockable, crystal-clear Step-by-Step Card
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#f0fdf4; border:2px solid #22c55e; border-radius:12px; padding:18px; box-shadow:0 6px 18px rgba(34,197,94,0.15);">
          <div style="display:flex; align-items:flex-start; gap:14px; margin-bottom:14px;">
            <div style="width:46px; height:46px; border-radius:50%; background:#22c55e; color:#fff; display:flex; align-items:center; justify-content:center; font-size:24px; flex-shrink:0; box-shadow:0 3px 10px rgba(34,197,94,0.4);">
              <i class="fa-brands fa-whatsapp"></i>
            </div>
            <div style="flex:1;">
              <h4 style="margin:0; color:#14532d; font-size:15px; font-weight:800;">
                ${isBM ? '✅ Fail PDF Dimuat Turun & WhatsApp Sedia Dihantar!' : '✅ PDF Downloaded & WhatsApp Ready!'}
              </h4>
              <p style="margin:4px 0 8px 0; font-size:12px; color:#166534; line-height:1.5;">
                ${isBM 
                  ? `Fail rasmi <strong>${fName}</strong> telah dimuat turun ke folder <strong>Downloads</strong> anda.` 
                  : `Official file <strong>${fName}</strong> has been saved into your <strong>Downloads</strong> folder.`}
              </p>
              <div style="background:#dcfce7; border:1px solid #86efac; border-radius:8px; padding:10px 12px; font-size:12px; color:#14532d; line-height:1.6;">
                <strong>${isBM ? '👉 2 Langkah Mudah Untuk Menghantar:' : '👉 2 Easy Steps to Send:'}</strong><br>
                1. ${isBM ? 'Tetingkap WhatsApp telah dibuka (atau klik butang hijau di bawah).' : 'WhatsApp window is opened (or click the green button below).'}<br>
                2. ${isBM ? `Di WhatsApp tetamu, klik ikon <strong>Lampiran (📎 atau +)</strong> dan pilih fail <strong style="font-family:monospace;">${fName}</strong> dari folder Downloads.` : `In WhatsApp chat, click <strong>Attachment (📎 or +)</strong> and select the downloaded PDF.`}
              </div>
            </div>
          </div>

          <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
            <a href="${waUrl}" target="_blank" class="btn btn-whatsapp btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:8px; padding:8px 16px; font-size:13px;">
              <i class="fa-brands fa-whatsapp"></i> ${isBM ? '📲 Buka WhatsApp Sekarang (Pautan Langsung)' : '📲 Open WhatsApp Now'}
            </a>
            <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px;">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? '👁️ Lihat Fail PDF' : '👁️ View PDF'}
            </a>
            <a href="${blobUrl}" download="${fName}" class="btn btn-outline btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:#fff; color:#065f46; border-color:#059669;">
              <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun Semula' : 'Download Again'}
            </a>
            <button type="button" class="btn btn-outline btn-sm" id="btnDismissWaStatus" style="font-size:11px; background:#fff; color:#64748b; margin-left:auto;">
              ${isBM ? 'Tutup' : 'Dismiss'}
            </button>
          </div>
        </div>
      `;
      document.getElementById('btnDismissWaStatus')?.addEventListener('click', () => {
        statusCard.style.display = 'none';
      });
      statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    showToast(isBM ? `Fail PDF (${fName}) dimuat turun ke Downloads!` : `PDF (${fName}) downloaded!`, 6000);

  }, (err) => {
    console.error('Error generating PDF for WhatsApp:', err);
    if (waWindow && !waWindow.closed) {
      waWindow.location.href = waUrl;
    } else {
      window.open(waUrl, '_blank');
    }
  });
}



// ==========================================================================
// 15. DIGITAL GUEST GUIDE MODAL
// ==========================================================================

function openGuestGuideModal() {
  const content = document.getElementById('guestGuideContent');
  content.innerHTML = '';

  const prop = appState.selectedPropertyId !== 'all' 
    ? getPropertyById(appState.selectedPropertyId) 
    : appState.properties[0];

  if (!prop) {
    showToast('Please create a homestay unit first.');
    return;
  }

  // QR Code URL using Google Chart API or QR service
  const wifiString = `WIFI:S:${encodeURIComponent(prop.wifiName || '')};T:WPA;P:${encodeURIComponent(prop.wifiPass || '')};;`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(wifiString)}`;

  content.innerHTML = `
    <div class="guest-guide-hero">
      <h3 style="font-size:18px; font-weight:800;">${prop.name}</h3>
      <p class="card-subtitle"><i class="fa-solid fa-location-dot"></i> ${prop.address || 'Homestay Address'}${prop.gpsLocation ? ` • <a href="${prop.gpsLocation}" target="_blank" style="color:var(--primary); font-weight:700; text-decoration:none;"><i class="fa-solid fa-map-location-dot"></i> Maps / GPS</a>` : ''}</p>
      
      <div class="qr-code-box">
        <img src="${qrUrl}" alt="WiFi QR Code" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Crect width=%22100%22 height=%22100%22 fill=%22%23f1f5f9%22/%3E%3Ctext x=%2250%22 y=%2255%22 font-size=%2212%22 text-anchor=%22middle%22 fill=%22%2364748b%22%3EWiFi QR%3C/text%3E%3C/svg%3E'">
      </div>
      <p style="font-size:11px; font-weight:700; color:var(--primary);">📱 Scan to Connect to WiFi Automatically</p>
    </div>

    <div class="guide-info-card">
      <h4><i class="fa-solid fa-wifi" style="color:var(--primary)"></i> WiFi Credentials</h4>
      <p>Network: <strong>${prop.wifiName || 'None'}</strong></p>
      <p>Password: <strong>${prop.wifiPass || 'None'}</strong></p>
    </div>

    <div class="guide-info-card">
      <h4><i class="fa-solid fa-key" style="color:var(--warning)"></i> Smart Lock / Access</h4>
      <p>Door PIN Code: <strong>${prop.doorCode || 'Provided upon arrival'}</strong></p>
      <p>Check-In: <strong>${prop.checkInTime || '3:00 PM'}</strong> • Check-Out: <strong>${prop.checkOutTime || '12:00 PM'}</strong></p>
    </div>

    <div class="guide-info-card">
      <h4><i class="fa-solid fa-circle-exclamation" style="color:var(--danger)"></i> House Rules</h4>
      <p>${prop.rules || 'Please treat our home with respect.'}</p>
    </div>

    <button class="btn btn-whatsapp btn-block" id="btnShareGuideWa" style="margin-top:12px;">
      <i class="fa-brands fa-whatsapp"></i> Share Guide with Guest via WhatsApp
    </button>
  `;

  document.getElementById('btnShareGuideWa').addEventListener('click', () => {
    const text = `🏡 *Welcome Guide - ${prop.name}*\n\n` +
      `📍 *Address:* ${prop.address || 'Standard Address'}\n` +
      (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
      `📶 *WiFi:* ${prop.wifiName} (Pass: ${prop.wifiPass})\n` +
      `🔑 *Door PIN:* ${prop.doorCode}\n` +
      `📜 *Rules:* ${prop.rules}\n\n` +
      `Need assistance? Feel free to message us anytime!`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  });

  document.getElementById('guestGuideModal').classList.add('active');
}

// ==========================================================================
// 16. DATA BACKUP, EXPORT & RESTORE
// ==========================================================================

async function exportDataBackup() {
  const isLangBm = appState.settings.language === 'bm';
  const images = {};

  // 1. Harvest from IndexedDB
  try {
    const dbImages = await getAllImagesFromDB();
    if (Array.isArray(dbImages)) {
      for (const item of dbImages) {
        if (item && item.id && item.dataUrl) {
          images[item.id] = item.dataUrl;
        }
      }
    } else if (dbImages && typeof dbImages === 'object') {
      Object.assign(images, dbImages);
    }
  } catch (e) {
    console.warn('Notice: Could not load images from IndexedDB for backup:', e);
  }

  // 2. Harvest any images still in localStorage or memory (bookings and promo media)
  if (Array.isArray(appState.bookings)) {
    for (const b of appState.bookings) {
      if (Array.isArray(b.payments)) {
        for (const p of b.payments) {
          if (p.receiptImage && p.receiptImage.startsWith('data:image')) {
            const imgId = p.receiptImageId || `img-rcpt-${b.id}-${p.id || 'slip'}`;
            images[imgId] = p.receiptImage;
            p.receiptImageId = imgId;
          }
        }
      }
    }
  }

  if (Array.isArray(appState.promotionalMedia)) {
    for (const m of appState.promotionalMedia) {
      if (m.imageData && m.imageData.startsWith('data:image')) {
        const imgId = m.imageId || `img-promo-${m.id}`;
        images[imgId] = m.imageData;
        m.imageId = imgId;
      }
    }
  }

  // 3. Harvest any cached items
  IMAGE_CACHE.forEach((val, key) => {
    if (key && val && !images[key]) {
      images[key] = val;
    }
  });

  const exportObject = {
    version: APP_VERSION,
    exportDate: new Date().toISOString(),
    properties: appState.properties || [],
    bookings: appState.bookings || [],
    turnovers: appState.turnovers || [],
    expenses: appState.expenses || [],
    contacts: appState.contacts || [],
    maintenanceTeam: appState.contacts || [], // Explicitly named Maintenance Team & Suppliers directory
    maintenanceTasks: appState.turnovers || [], // Maintenance and turnover cleaning records
    promotionalMedia: appState.promotionalMedia || [],
    settings: appState.settings || {},
    quotationCounter: appState.quotationCounter || 1001,
    invoiceCounter: appState.invoiceCounter || 1001,
    depositReceiptCounter: appState.depositReceiptCounter || 1001,
    paymentReceiptCounter: appState.paymentReceiptCounter || 1001,
    refundCounter: appState.refundCounter || 1001,
    images: images
  };

  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportObject, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `StayManager_Backup_${formatLocalDate(new Date())}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();

  // Record last backup date to silence reminder banner
  localStorage.setItem('staymanager_last_backup_date', formatLocalDate(new Date()));
  dismissBackupReminderBanner();

  showToast(isLangBm 
    ? '🎉 Fail sandaran penuh (termasuk Imej, Pasukan & Tempahan) berjaya dimuat turun!' 
    : '🎉 Full backup file (including Images, Team, Bookings & Receipts) downloaded safely!');
}

function importDataBackup(event) {
  const file = event.target.files[0];
  if (!file) return;

  const isLangBm = appState.settings.language === 'bm';
  const reader = new FileReader();

  reader.onload = async function(e) {
    try {
      const data = JSON.parse(e.target.result);

      // Validate schema
      if (!data || typeof data !== 'object' || !Array.isArray(data.properties)) {
        alert(isLangBm 
          ? 'Format fail sandaran tidak sah. Fail mesti mengandungi senarai homestay.' 
          : 'Invalid backup file format. File must contain valid homestay property records.');
        event.target.value = '';
        return;
      }

      const propCount = data.properties.length;
      const bookCount = (data.bookings && data.bookings.length) || 0;
      const expCount = (data.expenses && data.expenses.length) || 0;
      const imgCount = (data.images && typeof data.images === 'object') 
        ? (Array.isArray(data.images) ? data.images.length : Object.keys(data.images).length) 
        : 0;

      const confirmMsg = isLangBm
        ? `Adakah anda pasti mahu memulihkan data ini?\n\n` +
          `• Homestay: ${propCount} unit\n` +
          `• Tempahan: ${bookCount} rekod\n` +
          `• Perbelanjaan: ${expCount} rekod\n` +
          `• Imej/Resit: ${imgCount} fail\n\n` +
          `⚠️ NOTIS: Salinan keselamatan peranti ini akan disimpan secara automatik sebelum data digantikan.`
        : `Are you sure you want to restore this backup?\n\n` +
          `• Homestays: ${propCount} units\n` +
          `• Bookings: ${bookCount} records\n` +
          `• Expenses: ${expCount} records\n` +
          `• Images/Receipts: ${imgCount} files\n\n` +
          `⚠️ NOTICE: A safety snapshot will be created automatically before existing data is replaced.`;

      if (!confirm(confirmMsg)) {
        event.target.value = '';
        return;
      }

      // 1. SAVE SAFETY SNAPSHOT OF CURRENT DATA BEFORE OVERWRITING (Undo safety)
      const preRestoreSnapshot = {
        version: APP_VERSION,
        backupDate: new Date().toISOString(),
        properties: appState.properties || [],
        bookings: appState.bookings || [],
        turnovers: appState.turnovers || [],
        expenses: appState.expenses || [],
        contacts: appState.contacts || [],
        promotionalMedia: appState.promotionalMedia || [],
        settings: appState.settings || {},
        quotationCounter: appState.quotationCounter || 1001,
        invoiceCounter: appState.invoiceCounter || 1001,
        depositReceiptCounter: appState.depositReceiptCounter || 1001,
        paymentReceiptCounter: appState.paymentReceiptCounter || 1001,
        refundCounter: appState.refundCounter || 1001
      };
      localStorage.setItem('staymanager_pre_restore_snapshot', JSON.stringify(preRestoreSnapshot));
      localStorage.setItem('staymanager_auto_backup', JSON.stringify(preRestoreSnapshot));

      // 2. RESTORE DATA OBJECTS
      appState.properties = data.properties;
      appState.bookings = Array.isArray(data.bookings) ? data.bookings : [];
      migrateBookingTenantModel();
      appState.turnovers = Array.isArray(data.turnovers) ? data.turnovers : (Array.isArray(data.maintenanceTasks) ? data.maintenanceTasks : []);
      appState.expenses = Array.isArray(data.expenses) ? data.expenses : [];
      appState.contacts = (Array.isArray(data.maintenanceTeam) && data.maintenanceTeam.length > 0)
        ? data.maintenanceTeam
        : (Array.isArray(data.contacts) ? data.contacts : [...DEFAULT_CONTACTS]);
      appState.promotionalMedia = Array.isArray(data.promotionalMedia) ? data.promotionalMedia : [...DEFAULT_PROMO_MEDIA];
      appState.settings = data.settings ? { ...DEFAULT_SETTINGS, ...data.settings } : DEFAULT_SETTINGS;

      // Restore document counters if present
      if (typeof data.quotationCounter === 'number') appState.quotationCounter = data.quotationCounter;
      if (typeof data.invoiceCounter === 'number') appState.invoiceCounter = data.invoiceCounter;
      if (typeof data.depositReceiptCounter === 'number') appState.depositReceiptCounter = data.depositReceiptCounter;
      if (typeof data.paymentReceiptCounter === 'number') appState.paymentReceiptCounter = data.paymentReceiptCounter;
      if (typeof data.refundCounter === 'number') appState.refundCounter = data.refundCounter;

      // Freeze all numbers in restored bookings and ensure counters are >= highest in data
      migrateExistingBookingDocuments();
      syncDocumentCounters();

      // 3. RESTORE IMAGES TO IndexedDB
      if (data.images) {
        if (Array.isArray(data.images)) {
          for (const item of data.images) {
            if (item && item.id && item.dataUrl) {
              await saveImageToDB(item.id, item.dataUrl);
            }
          }
        } else if (typeof data.images === 'object') {
          for (const [imgId, imgData] of Object.entries(data.images)) {
            if (imgId && typeof imgData === 'string') {
              await saveImageToDB(imgId, imgData);
            } else if (imgData && typeof imgData === 'object' && imgData.id && imgData.dataUrl) {
              await saveImageToDB(imgData.id, imgData.dataUrl);
            }
          }
        }
      }

      // 4. PRESERVE DEVICE'S EXISTING LICENSE
      // Backups never contain or override the device's cryptographic license token.
      await evaluateLicenseState();

      // Run image migration on any legacy unmigrated base64 that came from the backup
      await migrateImagesToIndexedDB();

      localStorage.setItem('staymanager_initialized', 'true');
      localStorage.setItem('staymanager_last_backup_date', formatLocalDate(new Date()));
      saveToStorage();
      renderApp();
      dismissBackupReminderBanner();

      showToast(isLangBm 
        ? '🎉 Salinan sandaran (termasuk Imej, Pasukan & Tempahan) berjaya dipulihkan!' 
        : '🎉 Full backup (including Images, Team & Bookings) restored successfully!');
    } catch (err) {
      console.error('Backup restore error:', err);
      alert(isLangBm ? `Ralat membaca fail sandaran: ${err.message}` : `Error parsing backup file: ${err.message}`);
    } finally {
      event.target.value = '';
    }
  };

  reader.readAsText(file);
}

async function restoreAutoBackup() {
  const autoBackupStr = localStorage.getItem('staymanager_pre_restore_snapshot') || localStorage.getItem('staymanager_auto_backup');
  if (!autoBackupStr) {
    alert(t('no_auto_backup_found'));
    return;
  }
  try {
    const data = JSON.parse(autoBackupStr);
    const dateStr = data.backupDate ? new Date(data.backupDate).toLocaleString() : 'Safety Snapshot';
    const propCount = (data.properties && data.properties.length) || 0;
    const bookCount = (data.bookings && data.bookings.length) || 0;
    const isLangBm = appState.settings.language === 'bm';
    const promptMsg = isLangBm 
      ? `Salinan Keselamatan dijumpai!\nTarikh: ${dateStr}\nHomestay: ${propCount} unit\nTempahan: ${bookCount} rekod\n\nAdakah anda mahu memulihkan data ini sekarang?`
      : `Safety Snapshot found!\nDate: ${dateStr}\nHomestays: ${propCount} units\nBookings: ${bookCount} records\n\nDo you want to restore this data now?`;

    if (confirm(promptMsg)) {
      if (Array.isArray(data.properties)) appState.properties = data.properties;
      if (Array.isArray(data.bookings)) appState.bookings = data.bookings;
      if (Array.isArray(data.turnovers)) appState.turnovers = data.turnovers;
      if (Array.isArray(data.expenses)) appState.expenses = data.expenses;
      if (Array.isArray(data.maintenanceTeam) && data.maintenanceTeam.length > 0) {
        appState.contacts = data.maintenanceTeam;
      } else if (Array.isArray(data.contacts)) {
        appState.contacts = data.contacts;
      }
      if (Array.isArray(data.promotionalMedia)) appState.promotionalMedia = data.promotionalMedia;
      if (data.settings) appState.settings = { ...DEFAULT_SETTINGS, ...data.settings };
      
      // Preserve device's active cryptographic license token
      await evaluateLicenseState();

      saveToStorage();
      renderApp();
      showToast(isLangBm ? '🎉 Salinan keselamatan berjaya dipulihkan!' : '🎉 Safety snapshot successfully restored!');
    }
  } catch (err) {
    alert('Error restoring safety snapshot: ' + err.message);
  }
}

function resetAllData() {
  if (confirm('Are you sure you want to clear all homestays, bookings, turnovers, and expenses? Your license and preferences will be preserved.')) {
    const preservedLicense = appState.licenseKey;
    const preservedIsLicensed = appState.isLicensed;
    const preservedToken = appState.licenseToken;
    const preservedPayload = appState.licensePayload;
    const preservedDays = appState.licenseDaysRemaining;
    const preservedProState = appState.proHubState;
    const preservedSettings = { ...appState.settings };

    appState.properties = [];
    appState.bookings = [];
    appState.turnovers = [];
    appState.expenses = [];
    appState.contacts = [...DEFAULT_CONTACTS];
    appState.promotionalMedia = [];
    appState.selectedPropertyId = 'all';
    appState.isLicensed = preservedIsLicensed;
    appState.licenseToken = preservedToken;
    appState.licensePayload = preservedPayload;
    appState.licenseDaysRemaining = preservedDays;
    appState.proHubState = preservedProState;
    appState.licenseKey = preservedLicense;
    appState.isMasterAdmin = false;
    appState.settings = preservedSettings;

    // Mark as initialized so demo data does not auto-seed on reload
    localStorage.setItem('staymanager_initialized', 'true');
    saveToStorage();
    renderApp();
    showToast('All homestay & booking data cleared successfully!');
  }
}

// ==========================================================================
// 17. THEME & UTILITIES
// ==========================================================================

function toggleTheme() {
  const isDark = document.body.classList.contains('theme-dark');
  const newTheme = isDark ? 'light' : 'dark';
  applyTheme(newTheme);
  appState.settings.theme = newTheme;
  saveToStorage();
}

function applyTheme(theme) {
  if (theme === 'dark') {
    document.body.classList.remove('theme-light');
    document.body.classList.add('theme-dark');
    document.getElementById('btnThemeToggle').innerHTML = '<i class="fa-solid fa-sun"></i>';
  } else {
    document.body.classList.remove('theme-dark');
    document.body.classList.add('theme-light');
    document.getElementById('btnThemeToggle').innerHTML = '<i class="fa-solid fa-moon"></i>';
  }
}

function closeAllModals() {
  document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.classList.remove('active');
    m.style.display = '';
  });
}

function showToast(message) {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<i class="fa-solid fa-circle-check" style="color:var(--success);"></i> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px)';
    toast.style.transition = 'all 0.2s ease';
    setTimeout(() => toast.remove(), 200);
  }, 2800);
}

// ==========================================================================
// 18. IN-APP USER MANUAL & INTERACTIVE GUIDE ENGINE
// ==========================================================================

const USER_GUIDE_DATA = {
  en: [
    {
      id: 'guide-install',
      icon: 'fa-mobile-screen-button',
      title: '1. How to Install on Your Phone (iOS & Android)',
      content: `
        <p>You do not need to download anything from the App Store or Google Play. The app installs directly from your web browser as a fast, lightweight mobile app.</p>
        <div class="guide-callout success">
          <strong>🍏 iPhone / iPad (Safari):</strong><br>
          1. Open the app link in <strong>Safari</strong>.<br>
          2. Tap the <strong>Share</strong> button (box with an arrow pointing up at the bottom).<br>
          3. Scroll down and tap <strong>"Add to Home Screen"</strong>.<br>
          4. Tap <strong>Add</strong> in the top-right corner. The app icon will appear on your home screen!
        </div>
        <div class="guide-callout">
          <strong>🤖 Android (Chrome / Samsung Internet):</strong><br>
          1. Open the app link in <strong>Google Chrome</strong>.<br>
          2. Tap the <strong>Three Dots Menu (⋮)</strong> at the top right.<br>
          3. Tap <strong>"Install App"</strong> or <strong>"Add to Home screen"</strong>.<br>
          4. Confirm by tapping <strong>Install</strong>.
        </div>
        <p style="font-size:11.5px; color:var(--text-muted);"><i class="fa-solid fa-bolt"></i> <strong>Offline Ready:</strong> Once installed, the app opens full-screen like a native app and works even with no internet connection.</p>
      `
    },
    {
      id: 'guide-license',
      icon: 'fa-key',
      title: '2. Activating Your License Key',
      content: `
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>No key yet?</strong> Tap <strong>Buy License</strong> to request one on the purchase page. After your payment is confirmed you receive the key on WhatsApp.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">Go to the <strong>Settings (⚙️)</strong> tab (or tap the <strong>DEMO</strong> badge in the header).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tap <strong>"Enter License Key"</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text">Enter your registered <strong>WhatsApp Phone Number</strong> (e.g. <code>+60123456789</code>) and paste your <strong>License Key</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">5</div>
          <div class="guide-step-text">Tap <strong>"Activate Full App"</strong>. You now have lifetime access with unlimited homestays!</div>
        </div>
      `
    },
    {
      id: 'guide-props',
      icon: 'fa-house-chimney',
      title: '3. Adding Homestays & Room Rentals',
      content: `
        <p>You can manage entire houses, villas, apartments, or individual room rentals:</p>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Tap <strong>Settings (⚙️)</strong> > Tap <strong>"+ Add Homestay Unit"</strong> (or tap <strong>"+ Add"</strong> in the top header).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">
            <strong>Fill in Unit Particulars:</strong><br>
            • <strong>Category:</strong> Entire House, Master Room, Medium Room, Single Room, or Studio.<br>
            • <strong>Location:</strong> Full Address and <strong>GPS / Google Maps Link</strong> (for guest navigation).<br>
            • <strong>Access:</strong> Smart Lock Door PIN (e.g. <code>5829#</code>) and WiFi Name/Password.<br>
            • <strong>Pricing:</strong> Standard nightly rate and cleaning fee.
          </div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tap <strong>"Save Property"</strong>.</div>
        </div>
      `
    },
    {
      id: 'guide-bookings',
      icon: 'fa-calendar-plus',
      title: '4. Creating Bookings (Daily vs. Monthly)',
      content: `
        <p>Tap the floating <strong><code>+</code> (Add)</strong> button on the bottom-right to create a booking:</p>
        <div class="guide-callout success">
          <strong>☀️ Daily / Short-Term Stays:</strong><br>
          • Select <strong>"Daily / Short-Term"</strong> (monthly fields are automatically blocked).<br>
          • Enter Check-In/Out dates, Nightly Rate, and Cleaning Fee.<br>
          • Tap quick deposit presets: <code>30%</code>, <code>50%</code>, or <code>100% Full</code>.<br>
          • Enter guest particulars: Name, WhatsApp Phone, NRIC/Passport, and Address.
        </div>
        <div class="guide-callout">
          <strong>📅 Monthly Tenancy:</strong><br>
          • Select <strong>"Monthly Tenancy"</strong> (daily fields are automatically blocked).<br>
          • Enter Start Date, Duration (e.g. 6 Months), and Monthly Rental.<br>
          • Enter Rental Deposit, Utilities Deposit, and Tenancy Agreement Fee.<br>
          • The system automatically calculates the <strong>Total Move-In Package</strong>.
        </div>
        <div class="guide-callout success">
          <strong>💡 Calendar View (Check-In vs. Check-Out Modes):</strong><br>
          • <strong>📥 Check-In Mode:</strong> Highlights days when guests arrive with count badges (e.g. 📥 1) and lists upcoming arrivals.<br>
          • <strong>📤 Check-Out Mode:</strong> Highlights departure dates (e.g. 📤 1). Displays vacating unit notices with 1-tap <code>+ Book This Unit Starting Today</code> button!<br>
          • <strong>🛏️ All Stays:</strong> View overnight stays with colored dots for each homestay unit.<br>
          • <strong>4-Metric Bar:</strong> Tap any date to inspect Check-Ins, Check-Outs, In-Stay guests, and units available tonight.
        </div>
      `
    },
    {
      id: 'guide-invoicing',
      icon: 'fa-file-invoice-dollar',
      title: '5. Multi-Month Rental Invoices & Receipts',
      content: `
        <p>For monthly tenancies, the app provides a sequential monthly billing schedule:</p>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Go to the <strong>Bookings</strong> tab and tap <strong>"📑 Monthly Invoices (X/Y)"</strong> on any monthly booking card.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Send Invoice:</strong> Tap <code>Invoice</code> next to any month (e.g. Month 2). You can enter optional utility arrears (TNB/Water) before opening WhatsApp.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Mark Paid:</strong> Tap <code>Mark Paid</code> when the tenant transfers rent.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Send Receipt:</strong> Tap <code>Receipt</code> to send an official WhatsApp payment confirmation (<code>REC-RENT-M2-XXXX</code>).</div>
        </div>
      `
    },
    {
      id: 'guide-receipts',
      icon: 'fa-receipt',
      title: '5B. Digital Payment Receipts & Bank Reference Capture',
      content: `
        <p>When guests transfer booking deposits, balance settlements, or monthly rentals and share their bank slips, easily record and archive them:</p>
        <div class="guide-callout success">
          <strong>📸 Auto Image Compression:</strong><br>
          Bank slips and camera photos are compressed by 97% down to ~40KB–70KB without losing text sharpness, preserving your browser storage indefinitely!
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Capture Receipt:</strong> Tap <code>+ Resit / + Receipt</code> on any booking card, or tap <code>Mark Deposit Paid</code> / <code>Mark Fully Paid</code>. The receipt capture modal opens with recommended amounts pre-filled.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Bank & Ref No:</strong> Select the bank (Maybank, CIMB, Bank Islam, DuitNow, etc.) and paste or type the tenant's transaction reference ID.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Upload Slip:</strong> Tap or drag the screenshot into the dropzone. It previews instantly with the compressed size.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Receipt Gallery:</strong> Tap the <code>🧾 X Receipt(s)</code> chip anytime to inspect all attached receipts, copy reference numbers with 1 tap, or zoom full-screen with the Lightbox viewer.</div>
        </div>
      `
    },
    {
      id: 'guide-agreement',
      icon: 'fa-file-signature',
      title: '5C. Tenancy Agreement Generator (Individual & Corporate Tenants)',
      content: `
        <p>Generate formal Malaysian Residential Tenancy Agreements (in Bahasa Melayu or English) with full support for both individual owners and corporate management, as well as personal or company tenants:</p>
        <div class="guide-callout success">
          <strong>🏢 Corporate & Individual Entities:</strong><br>
          • <strong>Landlord:</strong> Select <code>Individual / Owner</code> (NRIC) or <code>Company / SSM</code> (Registration No). Commercial homestay branding is separated from legal ownership.<br>
          • <strong>Tenant:</strong> Select <code>Individual</code> or <code>Company / SSM</code>. For corporate tenants, input company details plus an <strong>Authorized Contact Person</strong> (Full Name, Designation, NRIC & Mobile Phone).
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Open Generator:</strong> Tap <code>📄 Perjanjian / Agreement</code> on any monthly booking card, or open the <strong>Monthly Tenancy Hub</strong> and tap <code>Pratonton</code>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Review Particulars:</strong> All dates, rental rates, deposits, property addresses, and inventory are auto-filled from your booking and settings.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Muslim-Friendly Covenants:</strong> Fasal 2 / Section 2 highlights strict covenants for halal food, absolute prohibition of alcohol, no unauthorized pets, and Islamic living decorum.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Direct Download to Downloads Folder:</strong> Tap <code>Muat Turun PDF / Download PDF</code>. The official multi-page A4 document is generated and saved directly to your device's <strong>Downloads</strong> folder.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">5</div>
          <div class="guide-step-text"><strong>1-Tap WhatsApp & Email:</strong> Tap <code>Hantar WhatsApp</code> to send a pre-formatted agreement cover message routed directly to the tenant or corporate representative's mobile WhatsApp!</div>
        </div>
      `
    },
    {
      id: 'guide-wa',
      icon: 'fa-brands fa-whatsapp',
      title: '6. 1-Tap WhatsApp Automation (9 Templates)',
      content: `
        <p>Tap the WhatsApp button on any booking card to choose from 9 pre-formatted templates with zero manual typing:</p>
        <ul style="padding-left:18px; margin:6px 0;">
          <li><strong>📄 Quotation:</strong> Send price breakdown, location, & deposit request.</li>
          <li><strong>🧾 Deposit Receipt:</strong> Confirm booking & lock calendar dates.</li>
          <li><strong>📅 Check-In Reminder:</strong> Send friendly arrival guide with check-in time, address, GPS link, access PIN, & payment status (sent at owner's discretion when arrival is near).</li>
          <li><strong>🔑 Full Receipt & Keys:</strong> Send Door Lock PIN, WiFi credentials, address & directions.</li>
          <li><strong>📑 Monthly Invoice:</strong> Send monthly rent bill with due date & bank account.</li>
          <li><strong>🧾 Monthly Rent Receipt:</strong> Send official rent payment confirmation.</li>
          <li><strong>🏁 Check-Out Reminder:</strong> Reminder on check-out time & key return.</li>
          <li><strong>💰 Deposit Refund Statement:</strong> Itemized statement with utility deductions.</li>
          <li><strong>🧹 Cleaner Notice:</strong> Job alert with unit address, GPS link, check-out time & PIN code.</li>
        </ul>
      `
    },
    {
      id: 'guide-refunds',
      icon: 'fa-money-bill-transfer',
      title: '7. End of Tenancy & Deposit Refunds',
      content: `
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Tap <strong>"End Tenancy & Refund Deposit"</strong> on the booking card.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">Enter any deductions for <strong>Unpaid Utilities (TNB/Water)</strong> or <strong>Repairs/Cleaning</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tap <strong>"Send Refund Statement"</strong> — opens an itemized, transparent statement in WhatsApp for your tenant!</div>
        </div>
      `
    },
    {
      id: 'guide-cleaning',
      icon: 'fa-broom',
      title: '8. Turnovers, Maintenance Team & Supplier Dispatch',
      content: `
        <p>Keep your homestays pristine, coordinate cleaning crews, technicians, and restock supplies with 1-click WhatsApp alerts:</p>
        <div class="guide-callout success">
          <strong>👷 Team & Supplier Directory (Settings > Maintenance Team & Suppliers):</strong><br>
          • Store phone numbers, rates, and notes for your cleaners, aircond specialists, plumbers, electricians, handymen, and supply vendors (linen/laundry, cooking gas, toiletries).<br>
          • Direct 1-tap WhatsApp chat and dispatch alert buttons on every contact card.
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Turnover Cleaning:</strong> Every checkout generates a turnover card in the <strong>Turnovers (🧹)</strong> tab. Tap <strong>"WhatsApp Cleaner"</strong> to open the Dispatch modal with target date, cleaning window, address, GPS link, and Smart Lock PIN pre-filled.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Service & Repair Alerts:</strong> Tap <strong>"🛠️ Service / Supply Alert"</strong> in the Turnovers header anytime to dispatch job requests for aircond servicing, plumbing leaks, electrical power trips, or general handyman fixes with urgency levels (Urgent / High / Normal).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Supply Restock Orders:</strong> Order fresh bedsheets, bath towels from your linen supplier or cooking gas cylinders from your gas vendor with 1 tap.</div>
        </div>
      `
    },
    {
      id: 'guide-finances',
      icon: 'fa-chart-line',
      title: '9. Financial Reports & Monthly Profit',
      content: `
        <p>Tap the <strong>Finances (📈)</strong> tab to see your business performance:</p>
        <ul style="padding-left:18px; margin:6px 0;">
          <li>💵 <strong>Total Revenue:</strong> Total booking income collected.</li>
          <li>📉 <strong>Total Expenses:</strong> Operational costs logged (tap <em>+ Add Expense</em>).</li>
          <li>🏆 <strong>Net Profit:</strong> Actual profit in green (<em>Revenue minus Expenses</em>).</li>
          <li>📊 <strong>Property Share:</strong> Percentage bars showing which unit earns the most.</li>
        </ul>
      `
    },
    {
      id: 'guide-backup',
      icon: 'fa-shield-halved',
      title: '10. Zero-Data-Loss Updates & Backups',
      content: `
        <div class="guide-callout success">
          <strong>🔒 100% Data Preservation Guarantee:</strong><br>
          All your homestays, bookings, tenant records, invoices, and license keys are stored in your device's persistent <code>localStorage</code> database. Updating the app only refreshes the code cache — it <strong>never deletes or touches your data</strong>!
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>1-Tap Auto Banner:</strong> When an update is deployed, tap <strong>"Update Now"</strong> on the notification banner at the top of the screen to activate instantly (~1s).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Check in Settings:</strong> You can also go to <strong>Settings (⚙️) > App Version & Updates</strong> and tap <strong>"Check for Updates"</strong> anytime.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>PWA Mobile App:</strong> For apps installed on your home screen, closing the app and reopening while connected to internet triggers automatic update in the background.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Safety Backup:</strong> Under <strong>Settings (⚙️) > Data Backup</strong>, tap <strong>"Export Backup (.json)"</strong> to save an encrypted snapshot of your business anytime.</div>
        </div>
      `
    }
  ],
  bm: [
    {
      id: 'guide-install',
      icon: 'fa-mobile-screen-button',
      title: '1. Cara Pasang di Telefon Pintar (iOS & Android)',
      content: `
        <p>Anda tidak perlu memuat turun apa-apa dari App Store atau Google Play. Aplikasi ini dipasang terus dari pelayar web anda sebagai aplikasi telefon pintar yang pantas dan ringan.</p>
        <div class="guide-callout success">
          <strong>🍏 Pengguna iPhone / iPad (Safari):</strong><br>
          1. Buka pautan aplikasi di <strong>Safari</strong>.<br>
          2. Tekan butang <strong>Kongsi (Share)</strong> (ikon petak dengan anak panah ke atas di bahagian bawah).<br>
          3. Skrol ke bawah dan tekan <strong>"Add to Home Screen" (Tambah ke Skrin Utama)</strong>.<br>
          4. Tekan <strong>Add</strong> di penjuru kanan atas. Ikon aplikasi akan muncul di skrin utama telefon anda!
        </div>
        <div class="guide-callout">
          <strong>🤖 Pengguna Android (Chrome / Samsung Internet):</strong><br>
          1. Buka pautan aplikasi di <strong>Google Chrome</strong>.<br>
          2. Tekan ikon <strong>Tiga Titik (⋮)</strong> di penjuru kanan atas.<br>
          3. Tekan <strong>"Install App" (Pasang Aplikasi)</strong> atau <strong>"Add to Home screen"</strong>.<br>
          4. Sahkan dengan menekan <strong>Install</strong>.
        </div>
        <p style="font-size:11.5px; color:var(--text-muted);"><i class="fa-solid fa-bolt"></i> <strong>Sedia Luar Talian:</strong> Selepas dipasang, aplikasi dibuka skrin penuh dan berfungsi walaupun tiada sambungan internet.</p>
      `
    },
    {
      id: 'guide-license',
      icon: 'fa-key',
      title: '2. Mengaktifkan Kunci Lesen Anda',
      content: `
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Belum ada kunci?</strong> Tekan <strong>Beli Lesen</strong> untuk membuat permohonan di halaman pembelian. Selepas bayaran anda disahkan, anda menerima kunci lesen melalui WhatsApp.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">Pergi ke tab <strong>Tetapan (⚙️)</strong> (atau tekan lencana <strong>DEMO</strong> di bar atas).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tekan <strong>"Masukkan Kunci Lesen"</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text">Masukkan <strong>Nombor WhatsApp Berdaftar</strong> anda (cth: <code>+60123456789</code>) dan tampal <strong>Kunci Lesen</strong> anda.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">5</div>
          <div class="guide-step-text">Tekan <strong>"Aktifkan Aplikasi Penuh"</strong>. Anda kini memiliki akses seumur hidup dengan unit tanpa had!</div>
        </div>
      `
    },
    {
      id: 'guide-props',
      icon: 'fa-house-chimney',
      title: '3. Menambah Unit Homestay & Bilik Sewa',
      content: `
        <p>Anda boleh menguruskan seluruh rumah, vila, apartmen, atau bilik sewa individu:</p>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Tekan <strong>Tetapan (⚙️)</strong> > Tekan <strong>"+ Tambah Unit Homestay / Bilik"</strong> (atau tekan <strong>"+ Tambah"</strong> di bar atas).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">
            <strong>Isikan Butiran Unit:</strong><br>
            • <strong>Kategori:</strong> Seluruh Rumah, Bilik Master, Bilik Medium, Bilik Single, atau Studio.<br>
            • <strong>Lokasi:</strong> Alamat Penuh dan <strong>Pautan GPS / Google Maps</strong> (panduan arah tetamu).<br>
            • <strong>Akses:</strong> Kod PIN Kunci Pintu Pintar (cth: <code>5829#</code>) dan Nama/Kata Laluan WiFi.<br>
            • <strong>Harga:</strong> Kadar asas semalam dan yuran pembersihan.
          </div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tekan <strong>"Simpan Unit Homestay"</strong>.</div>
        </div>
      `
    },
    {
      id: 'guide-bookings',
      icon: 'fa-calendar-plus',
      title: '4. Merekod Tempahan (Harian & Bulanan)',
      content: `
        <p>Tekan butang terapung <strong><code>+</code> (Tambah)</strong> di penjuru kanan bawah untuk membuka borang tempahan:</p>
        <div class="guide-callout success">
          <strong>☀️ Sewaan Harian / Jangka Pendek:</strong><br>
          • Pilih <strong>"Harian / Jangka Pendek"</strong> (bahagian bulanan disekat automatik).<br>
          • Masukkan Tarikh Masuk/Keluar, Kadar Semalam, dan Yuran Pembersihan.<br>
          • Tekan pilihan deposit pantas: <code>30%</code>, <code>50%</code>, atau <code>100% Penuh</code>.<br>
          • Isikan maklumat tetamu: Nama, WhatsApp, No. KP/Pasport, dan Alamat.
        </div>
        <div class="guide-callout">
          <strong>📅 Sewaan Bulanan (Bilik / Rumah):</strong><br>
          • Pilih <strong>"Sewaan Bulanan"</strong> (bahagian harian disekat automatik).<br>
          • Masukkan Tarikh Mula, Tempoh (cth: 6 Bulan), dan Sewa Bulanan.<br>
          • Masukkan Deposit Sewa, Deposit Utiliti, dan Yuran Perjanjian Sewa.<br>
          • Sistem mengira <strong>Jumlah Pakej Kemasukan (Move-In)</strong> secara automatik.
        </div>
        <div class="guide-callout success">
          <strong>💡 Paparan Kalendar (Mod Daftar Masuk vs. Daftar Keluar):</strong><br>
          • <strong>📥 Mod Daftar Masuk:</strong> Menandakan hari ketibaan tetamu dengan lencana bilangan (cth: 📥 1) dan menyusun senarai ketibaan terdekat.<br>
          • <strong>📤 Mod Daftar Keluar:</strong> Menandakan hari tetamu keluar (cth: 📤 1). Memaparkan notis unit sedia dibersihkan berserta butang 1-sentuhan <code>+ Tempah Unit Ini Mulai Hari Ini</code>!<br>
          • <strong>🛏️ Penginapan:</strong> Paparkan semua malam penginapan dengan titik warna bagi setiap unit homestay.<br>
          • <strong>Bar 4-Statistik:</strong> Tekan mana-mana tarikh untuk melihat Masuk, Keluar, Menginap, dan unit Kosong Malam Ini.
        </div>
      `
    },
    {
      id: 'guide-invoicing',
      icon: 'fa-file-invoice-dollar',
      title: '5. Invois & Resit Sewaan Bulanan',
      content: `
        <p>Bagi sewaan bulanan, sistem menyediakan jadual bil bulanan berurutan:</p>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Buka tab <strong>Tempahan</strong> dan tekan butang <strong>"📑 Jadual Invois (X/Y)"</strong> pada kad sewaan bulanan.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Hantar Invois:</strong> Tekan <code>Invois</code> pada mana-mana bulan (cth: Bulan 2). Boleh masukkan caj utiliti TNB/Air tambahan jika ada sebelum buka WhatsApp.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Tanda Bayar:</strong> Tekan <code>Tanda Bayar</code> apabila penyewa telah memindahkan bayaran sewa.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Hantar Resit:</strong> Tekan <code>Resit</code> untuk menghantar resit rasmi WhatsApp pengesahan bayaran sewa (<code>REC-RENT-M2-XXXX</code>).</div>
        </div>
      `
    },
    {
      id: 'guide-receipts',
      icon: 'fa-receipt',
      title: '5B. Rekod Resit Digital & No. Rujukan Bank',
      content: `
        <p>Apabila tetamu atau penyewa memindahkan wang deposit, baki bayaran, atau sewa bulanan dan berkongsi slip transaksi di WhatsApp, anda boleh merekod dan menyimpannya terus di dalam aplikasi:</p>
        <div class="guide-callout success">
          <strong>📸 Pemampatan Imej Pintar:</strong><br>
          Gambar slip bank dimampatkan secara automatik sebanyak 97% ke ~40KB–70KB tanpa menjejaskan kejelasan teks nombor akaun dan ID transaksi, mengelakkan memori peranti penuh!
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Buka Borang Resit:</strong> Tekan <code>+ Resit</code> pada mana-mana kad tempahan, atau tekan <code>Tanda Deposit Dibayar</code> / <code>Tanda Bayaran Penuh</code>. Jumlah bayaran dicadangkan automatik.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Pilih Bank & No. Rujukan:</strong> Pilih bank (Maybank, CIMB, Bank Islam, DuitNow, dll.) dan tekan <code>Tampal</code> atau taip ID Rujukan Transaksi bank.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Muat Naik Slip:</strong> Tekan atau seret tangkapan skrin resit. Pratonton imej dan saiz mampat dipaparkan serta-merta.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Galeri Resit & No. Rujukan:</strong> Tekan lencana <code>🧾 X Resit</code> bila-bila masa untuk semak semua resit yang disimpan, salin no rujukan dengan 1 sentuhan, atau lihat gambar skrin penuh (Lightbox) berserta butang Muat Turun.</div>
        </div>
      `
    },
    {
      id: 'guide-agreement',
      icon: 'fa-file-signature',
      title: '5C. Penjana Surat Perjanjian Sewaan (Penyewa Individu & Syarikat)',
      content: `
        <p>Jana Surat Perjanjian Penyewaan Kediaman rasmi Malaysia (dwibahasa: Bahasa Melayu & English) dengan pemisahan sah antara nama penjenamaan homestay, pemilik sah hartanah, serta penyewa individu mahupun syarikat:</p>
        <div class="guide-callout success">
          <strong>🏢 Sokongan Entiti Individu & Syarikat (SSM):</strong><br>
          • <strong>Tuan Rumah:</strong> Pilih <code>Individu / Pemilik</code> (No. K/P) atau <code>Syarikat / SSM</code> (No. Pendaftaran Syarikat). Nama komersil homestay diasingkan daripada entiti pemilik.<br>
          • <strong>Penyewa:</strong> Pilih <code>Individu</code> atau <code>Syarikat / SSM</code>. Jika syarikat, lengkapkan maklumat syarikat berserta <strong>Pegawai Dihubungi / Wakil Syarikat Diberi Kuasa</strong> (Nama, Jawatan, No. K/P & No. Tel Bimbit).
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Buka Penjana:</strong> Tekan butang <code>📄 Perjanjian</code> pada mana-mana kad tempahan bulanan, atau buka <strong>Hab Sewaan Bulanan</strong> dan tekan <code>Pratonton</code>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Auto-Isi Butiran:</strong> Semua kadar sewa bulanan, wang cagaran (deposit sewa & utiliti), tarikh sewaan, alamat premis dan senarai inventori perabot diisi secara automatik.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Syarat Khas Rumah Mesra Muslim:</strong> Fasal 2 menetapkan pemeliharaan kesucian kediaman merangkumi makanan halal, larangan mutlak arak/alkohol, larangan haiwan terlarang, serta ketenteraman moral kejiranan.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Muat Turun Terus ke Folder Downloads:</strong> Tekan <code>Muat Turun PDF</code>. Fail rasmi A4 dijana dan disimpan terus ke folder <strong>Downloads</strong> komputer atau telefon anda.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">5</div>
          <div class="guide-step-text"><strong>Hantar ke WhatsApp & Emel:</strong> Tekan <code>Hantar WhatsApp</code> untuk membuka mesej iringan rasmi yang dialamatkan terus kepada nombor telefon bimbit wakil syarikat atau penyewa!</div>
        </div>
      `
    },
    {
      id: 'guide-wa',
      icon: 'fa-brands fa-whatsapp',
      title: '6. Automasi WhatsApp 1-Sentuhan (9 Templat)',
      content: `
        <p>Tekan butang WhatsApp pada mana-mana kad tempahan untuk memilih daripada 9 templat siap sedia tanpa perlu taip manual:</p>
        <ul style="padding-left:18px; margin:6px 0;">
          <li><strong>📄 Sebut Harga:</strong> Hantar perincian harga rasmi, lokasi, & jumlah bayaran booking.</li>
          <li><strong>🧾 Resit Booking / Deposit:</strong> Pengesahan deposit & unit ditanda ditempah.</li>
          <li><strong>📅 Peringatan Daftar Masuk:</strong> Peringatan mesra ketibaan berserta waktu masuk, alamat, pautan GPS Maps, PIN pintu & status baki bayaran (dihantar mengikut budi bicara pemilik apabila tarikh masuk hampir).</li>
          <li><strong>🔑 Resit Penuh & Panduan Kunci:</strong> Resit bayaran penuh berserta PIN pintu, WiFi, alamat & panduan.</li>
          <li><strong>📑 Invois Sewa Bulanan:</strong> Invois bulanan mengikut bulan, tarikh akhir & no bank.</li>
          <li><strong>🧾 Resit Rasmi Sewa Bulanan:</strong> Resit rasmi pengesahan bayaran sewa bulanan.</li>
          <li><strong>🏁 Peringatan Daftar Keluar:</strong> Peringatan waktu keluar, suis elektrik & kunci.</li>
          <li><strong>💰 Penyata Pulangan Deposit:</strong> Penyata perincian deposit & tolakan bil utiliti.</li>
          <li><strong>🧹 Arahan Pembersihan:</strong> Arahan tugasan kepada pembersih berserta alamat, GPS, & kod PIN pintu.</li>
        </ul>
      `
    },
    {
      id: 'guide-refunds',
      icon: 'fa-money-bill-transfer',
      title: '7. Tamat Sewaan & Pemulangan Deposit',
      content: `
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Tekan butang <strong>"Tamat Sewa & Pulang Deposit"</strong> pada kad tempahan.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">Masukkan jumlah tolakan jika ada <strong>Tunggakan Utiliti (TNB/Air)</strong> atau <strong>Kerosakan / Pembersihan</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tekan <strong>"Hantar Penyata Pulangan"</strong> — membuka penyata tolakan yang telus dan jelas di WhatsApp penyewa!</div>
        </div>
      `
    },
    {
      id: 'guide-cleaning',
      icon: 'fa-broom',
      title: '8. Pembersihan, Pasukan Penyelenggaraan & Tempahan Bekalan',
      content: `
        <p>Kekalkan kebersihan homestay anda, selaraskan kakitangan pembersihan, juruteknik, dan tempahan stok bekalan sepantas 1-klik WhatsApp:</p>
        <div class="guide-callout success">
          <strong>👷 Direktori Pasukan & Pembekal (Tetapan > Pasukan Penyelenggaraan & Pembekal):</strong><br>
          • Simpan nombor telefon, kadar caj dan nota kerja untuk tukang cuci, pakar aircond, tukang paip, juruelektrik, tukang rumah, dan pembekal (dobi linen, tong gas memasak, sabun/syampu).<br>
          • Butang sembang terus WhatsApp dan butang hantar notis tugasan tersedia pada setiap kad kenalan.
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Pembersihan Unit (Turnover):</strong> Setiap daftar keluar menjana tugasan di tab <strong>Pembersihan (🧹)</strong>. Tekan <strong>"WhatsApp Cleaner"</strong> untuk membuka tetingkap Notis dengan tarikh, waktu mengemas, alamat, pautan GPS Maps, dan Kod PIN pintu tersedia automatik.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Notis Pembaikan & Servis:</strong> Tekan <strong>"🛠️ Notis Servis & Bekalan"</strong> di bar atas tab Pembersihan pada bila-bila masa untuk menghantar tugasan servis aircond, paip bocor, bekalan elektrik trip, atau baiki perkakasan dengan tahap keperluan (Kecemasan / Tinggi / Biasa).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Pesanan Tambahan Stok:</strong> Tempah set cadar & tuala baru dari pembekal linen atau tong gas memasak baru daripada pembekal gas dengan 1 sentuhan.</div>
        </div>
      `
    },
    {
      id: 'guide-finances',
      icon: 'fa-chart-line',
      title: '9. Laporan Kewangan & Untung Bersih',
      content: `
        <p>Tekan tab <strong>Kewangan (📈)</strong> untuk melihat prestasi perniagaan anda:</p>
        <ul style="padding-left:18px; margin:6px 0;">
          <li>💵 <strong>Jumlah Hasil:</strong> Jumlah pendapatan sewaan yang diterima.</li>
          <li>📉 <strong>Jumlah Perbelanjaan:</strong> Kos operasi yang direkod (tekan <em>+ Tambah Kos</em>).</li>
          <li>🏆 <strong>Untung Bersih:</strong> Keuntungan sebenar berwarna hijau (<em>Hasil tolak Perbelanjaan</em>).</li>
          <li>📊 <strong>Pecahan Unit:</strong> Carta peratusan unit homestay/bilik yang menjana hasil tertinggi.</li>
        </ul>
      `
    },
    {
      id: 'guide-backup',
      icon: 'fa-shield-halved',
      title: '10. Kemas Kini Tanpa Hilang Data & Sandaran',
      content: `
        <div class="guide-callout success">
          <strong>🔒 Jaminan 100% Data Selamat:</strong><br>
          Semua maklumat homestay, tempahan, rekod penyewa, invois, dan lesen disimpan secara kekal di dalam <code>localStorage</code> peranti anda. Kemas kini aplikasi hanya memperbaharui kod program — ia <strong>tidak sekali-kali memadamkan data anda</strong>!
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Sepanduk 1-Sentuhan:</strong> Apabila versi baharu dikeluarkan, tekan <strong>"Kemas Kini Sekarang"</strong> pada sepanduk atas untuk memuatkan versi terkini (~1 saat).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Semak di Tetapan:</strong> Anda juga boleh pergi ke <strong>Tetapan (⚙️) > Versi Aplikasi</strong> dan tekan <strong>"Semak Kemas Kini"</strong> pada bila-bila masa.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Aplikasi Telefon (PWA):</strong> Jika dipasang di skrin utama telefon, tutup aplikasi sepenuhnya dan buka semula semasa ada internet untuk muat turun fail terkini di latar belakang.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Sandaran Keselamatan:</strong> Di <strong>Tetapan (⚙️) > Sandaran Data</strong>, tekan <strong>"Eksport Sandaran (.json)"</strong> bila-bila masa untuk simpan salinan keselamatan fail bisnes anda.</div>
        </div>
      `
    }
  ]
};

async function getSupportDiagnosticsData() {
  const isSecure = typeof window !== 'undefined' && window.isSecureContext !== false;
  const hasCryptoSubtle = !!(typeof window !== 'undefined' && window.crypto && window.crypto.subtle);
  const devId = getOrCreateDeviceId().slice(0, 8);
  const storedToken = localStorage.getItem(STORAGE_KEYS.TOKEN);
  const hasToken = !!storedToken;

  let verifyResult = 'None (No token stored)';
  if (hasToken) {
    if (appState.isLicensed) {
      verifyResult = 'Valid (Active)';
    } else {
      try {
        const v = await verifyLicenseToken(storedToken);
        if (v.valid) {
          verifyResult = 'Signature Valid (Unlicensed)';
        } else {
          verifyResult = `Invalid: ${v.error || 'Verification failed'}`;
        }
      } catch (e) {
        verifyResult = `Error: ${e.message || 'Verification error'}`;
      }
    }
  }

  const savedLastSeen = localStorage.getItem(STORAGE_KEYS.LAST_SEEN_AT);
  let clockStatus = 'OK (Normal)';
  if (savedLastSeen) {
    const lsMs = parseInt(savedLastSeen, 10);
    if (!isNaN(lsMs) && (lsMs - Date.now() > 86400 * 1000)) {
      clockStatus = 'Clock Rolled Back (Error)';
    }
  }

  const proState = appState.proHubState || 'UNLICENSED';
  const network = typeof navigator !== 'undefined' && navigator.onLine ? 'Online' : 'Offline';
  const ua = typeof navigator !== 'undefined' && navigator.userAgent ? navigator.userAgent : 'Unknown';

  return {
    version: APP_VERSION,
    isSecureContext: String(isSecure),
    cryptoSubtle: hasCryptoSubtle ? 'Yes' : 'No',
    deviceId: devId,
    tokenStored: hasToken ? 'Yes' : 'No',
    tokenVerification: verifyResult,
    clockStatus: clockStatus,
    proHubState: proState,
    network: network,
    userAgent: ua
  };
}

function formatDiagnosticsForWhatsApp(diag) {
  return [
    '📋 *StayManager Support Diagnostics*',
    `• App Version: v${diag.version}`,
    `• Secure Context: ${diag.isSecureContext}`,
    `• WebCrypto Subtle: ${diag.cryptoSubtle}`,
    `• Short Device ID: ${diag.deviceId}`,
    `• Token Stored: ${diag.tokenStored}`,
    `• Token Verification: ${diag.tokenVerification}`,
    `• Clock Status: ${diag.clockStatus}`,
    `• Pro Hub State: ${diag.proHubState}`,
    `• Network: ${diag.network}`,
    `• User Agent: ${diag.userAgent}`
  ].join('\n');
}

function openProSystemModal() {
  const modal = document.getElementById('proSystemModal');
  if (!modal) return;

  const isBM = appState.settings.language === 'bm';
  const statusText = document.getElementById('proModalStatusText');
  const verText = document.getElementById('proModalVersionText');
  const titleEl = document.getElementById('proModalTitle');
  const subEl = document.getElementById('proModalSub');
  const iconEl = document.getElementById('proModalIcon');
  const detailsEl = document.getElementById('proModalDetailsContainer');

  if (titleEl) {
    titleEl.textContent = isBM ? 'Hab Sistem StayManager Pro' : 'StayManager Pro Hub';
  }
  if (subEl) {
    subEl.textContent = isBM ? 'Status Akaun & Akses Pantas' : 'System Status & Quick Tools';
  }
  if (verText) {
    verText.textContent = `v${APP_VERSION}`;
  }

  // Derive current state
  const devId = getOrCreateDeviceId();
  const maskedDev = devId.slice(0, 8) + '...';
  const boundPhone = appState.licensePayload?.phone || (appState.settings.ownerPhone ? normalizeLicensePhone(appState.settings.ownerPhone) : '');
  const daysLeft = appState.licenseDaysRemaining || 0;
  const isOnline = navigator.onLine;

  let state = appState.proHubState || 'UNLICENSED';

  // Dynamic real-time adjustment
  if (appState.isLicensed) {
    if (!isOnline) {
      state = 'OFFLINE';
    } else if (state !== 'SERVER_UNREACHABLE') {
      state = 'ACTIVE';
    }
  }

  let statusLabel = '';
  let statusColor = 'var(--text-main)';
  let iconClass = 'fa-circle-check';
  let iconColor = 'var(--success)';
  let detailsHtml = '';

  switch (state) {
    case 'CHECKING':
      statusLabel = isBM ? '⏳ Menyemak Status...' : '⏳ Checking Status...';
      statusColor = 'var(--text-muted)';
      iconClass = 'fa-circle-notch fa-spin';
      iconColor = 'var(--primary)';
      detailsHtml = `
        <div style="background:var(--bg-surface-subtle); padding:10px 12px; border-radius:var(--radius-md); border:1px solid var(--border-color); font-size:12px; color:var(--text-muted);">
          ${isBM ? 'Sedang menyemak token lesen dengan pelayan...' : 'Validating cryptographic license token with server...'}
        </div>
      `;
      break;

    case 'ACTIVE':
      statusLabel = isBM ? '✨ LESEN PRO AKTIF' : '✨ PRO ACTIVE';
      statusColor = 'var(--success)';
      iconClass = 'fa-circle-check';
      iconColor = 'var(--success)';
      const activeNextCheck = formatLicenseDate((appState.licensePayload?.iat || 0) + 7 * 86400, isBM ? 'bm' : 'en');
      const activeRenewal = formatLicenseDate(appState.licensePayload?.exp || 0, isBM ? 'bm' : 'en');
      detailsHtml = `
        <div style="background:var(--bg-surface-subtle); padding:10px 12px; border-radius:var(--radius-md); border:1px solid var(--border-color); font-size:12px; line-height:1.5;">
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:var(--text-muted);"><i class="fa-solid fa-mobile-screen"></i> ${isBM ? 'ID Peranti' : 'Device ID'}:</span>
            <code style="font-weight:700;">${maskedDev}</code>
          </div>
          ${boundPhone ? `
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:var(--text-muted);"><i class="fa-brands fa-whatsapp"></i> WhatsApp:</span>
            <span style="font-weight:700;">${formatDisplayLicensePhone(boundPhone) || ('+' + boundPhone)}</span>
          </div>` : ''}
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:var(--text-muted);"><i class="fa-solid fa-arrows-rotate"></i> ${isBM ? 'Semakan Seterusnya' : 'Next Check'}:</span>
            <span style="font-weight:700;">${activeNextCheck}</span>
          </div>
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:var(--text-muted);"><i class="fa-solid fa-calendar-check"></i> ${isBM ? 'Tarikh Pembaharuan' : 'Renewal Date'}:</span>
            <span style="font-weight:700; color:var(--primary);">${activeRenewal} (${daysLeft} ${isBM ? 'hari lagi' : 'days remaining'})</span>
          </div>
          <div style="margin-top:6px; font-size:11px; color:var(--text-muted); border-top:1px dashed var(--border-color); padding-top:6px;">
            <i class="fa-solid fa-shield-halved" style="color:var(--primary); margin-right:4px;"></i>
            ${isBM ? 'Disahkan melalui WebCrypto ECDSA P-256. Bersedia untuk operasi luar talian 100%.' : 'Verified via WebCrypto ECDSA P-256. 100% private offline-ready.'}
          </div>
        </div>
      `;
      break;

    case 'OFFLINE':
      statusLabel = isBM 
        ? `✨ LESEN PRO AKTIF (${daysLeft}H LUAR TALIAN)` 
        : `✨ PRO ACTIVE (${daysLeft}d OFFLINE)`;
      statusColor = 'var(--success)';
      iconClass = 'fa-wifi-slash';
      iconColor = 'var(--success)';
      const offNextCheck = formatLicenseDate((appState.licensePayload?.iat || 0) + 7 * 86400, isBM ? 'bm' : 'en');
      const offRenewal = formatLicenseDate(appState.licensePayload?.exp || 0, isBM ? 'bm' : 'en');
      detailsHtml = `
        <div style="background:var(--bg-surface-subtle); padding:10px 12px; border-radius:var(--radius-md); border:1px solid var(--border-color); font-size:12px; line-height:1.5;">
          <div style="margin-bottom:6px; font-weight:700; color:var(--success);">
            <i class="fa-solid fa-circle-check"></i> ${isBM ? 'Mod Luar Talian Berfungsi Penuh' : 'Fully Functional Offline Mode'}
          </div>
          <div style="color:var(--text-muted); font-size:11.5px; margin-bottom:6px;">
            ${isBM 
              ? `Aplikasi berfungsi sepenuhnya tanpa internet. Semakan seterusnya pada ${offNextCheck}; pembaharuan pada ${offRenewal}.` 
              : `App works 100% offline. Next check on ${offNextCheck}; renewal on ${offRenewal}.`}
          </div>
          <div style="display:flex; justify-content:space-between; font-size:11px; color:var(--text-muted); border-top:1px dashed var(--border-color); padding-top:6px;">
            <span>${isBM ? 'ID Peranti' : 'Device ID'}: <code>${maskedDev}</code></span>
            <span>${isBM ? 'Pembaharuan' : 'Renewal'}: ${offRenewal}</span>
          </div>
        </div>
      `;
      break;

    case 'CLOCK_ERROR':
      statusLabel = isBM ? '⚠️ RALAT JAM PERANTI' : '⚠️ DEVICE CLOCK ERROR';
      statusColor = 'var(--warning)';
      iconClass = 'fa-clock-rotate-left';
      iconColor = 'var(--warning)';
      detailsHtml = `
        <div style="background:var(--warning-light); color:var(--warning-text); padding:12px; border-radius:var(--radius-md); border:1px solid rgba(245, 158, 11, 0.3); font-size:12px; line-height:1.5;">
          <div style="font-weight:800; margin-bottom:4px;">
            ${isBM ? 'Tarikh Peranti Tidak Tepat' : 'Device Clock Discrepancy'}
          </div>
          <div style="font-size:11.5px; margin-bottom:10px;">
            ${isBM 
              ? 'Jam peranti anda ditetapkan lebih awal daripada rekod penggunaan sebelum ini. Sila betulkan tarikh & masa pada tetapan telefon anda atau sambung ke internet untuk mengesahkan lesen.' 
              : 'Your device clock is set earlier than previously recorded. Please set your device date & time correctly in system settings, or connect to the internet to verify your license.'}
          </div>
          <div style="display:flex; gap:8px;">
            <button type="button" class="btn btn-primary btn-sm btn-block" id="btnProReconnectNow">
              <i class="fa-solid fa-rotate"></i> ${isBM ? 'Sambung & Sahkan' : 'Connect & Verify'}
            </button>
            <button type="button" class="btn btn-outline btn-sm btn-block" id="btnProReactivateModal">
              <i class="fa-solid fa-key"></i> ${isBM ? 'Masukkan Kunci' : 'Enter Key'}
            </button>
          </div>
        </div>
      `;
      break;

    case 'NEEDS_RECONNECT':
      statusLabel = isBM ? '⚠️ PERLU SAMBUNGAN INTERNET' : '⚠️ NEEDS RECONNECT';
      statusColor = 'var(--warning)';
      iconClass = 'fa-triangle-exclamation';
      iconColor = 'var(--warning)';
      detailsHtml = `
        <div style="background:var(--warning-light); color:var(--warning-text); padding:10px 12px; border-radius:var(--radius-md); border:1px solid rgba(245, 158, 11, 0.3); font-size:12px; line-height:1.5;">
          <div style="font-weight:800; margin-bottom:4px;">
            ${isBM ? 'Sesi Lesen Telah Tamat' : 'License Session Expired'}
          </div>
          <div style="font-size:11.5px; margin-bottom:8px;">
            ${isBM 
              ? 'Sila sambung ke internet untuk memperbaharui pengesahan lesen anda secara automatik atau masukkan semula kunci lesen.' 
              : 'Please connect to the internet to auto-refresh your license verification, or re-enter your license key.'}
          </div>
          <div style="display:flex; gap:8px;">
            <button type="button" class="btn btn-primary btn-sm btn-block" id="btnProReconnectNow">
              <i class="fa-solid fa-rotate"></i> ${isBM ? 'Segarkan Sambungan' : 'Reconnect & Refresh'}
            </button>
            <button type="button" class="btn btn-outline btn-sm btn-block" id="btnProReactivateModal">
              <i class="fa-solid fa-key"></i> ${isBM ? 'Masukkan Kunci' : 'Enter Key'}
            </button>
          </div>
        </div>
      `;
      break;

    case 'REVOKED':
      statusLabel = isBM ? '🚫 LESEN DIBATALKAN' : '🚫 LICENSE REVOKED';
      statusColor = 'var(--danger)';
      iconClass = 'fa-ban';
      iconColor = 'var(--danger)';
      detailsHtml = `
        <div style="background:var(--danger-light); color:var(--danger-text); padding:12px; border-radius:var(--radius-md); border:1px solid rgba(239, 68, 68, 0.3); font-size:12px; line-height:1.5;">
          <div style="font-weight:800; margin-bottom:4px;">
            ${isBM ? 'Lesen Dibatalkan oleh Pentadbir' : 'License Revoked by Admin'}
          </div>
          <div style="font-size:11.5px; margin-bottom:10px;">
            ${isBM 
              ? 'Kunci lesen ini telah dibatalkan. Sila hubungi penjual melalui WhatsApp untuk mengaktifkan semula akaun anda.' 
              : 'This license key has been revoked. Please contact the seller on WhatsApp to restore your access.'}
          </div>
          <button type="button" class="btn btn-whatsapp btn-block" id="btnProContactSellerRevoked">
            <i class="fa-brands fa-whatsapp"></i> ${isBM ? 'Hubungi Penjual di WhatsApp' : 'Contact Seller on WhatsApp'}
          </button>
        </div>
      `;
      break;

    case 'DEVICE_LIMIT_REACHED':
      statusLabel = isBM ? '⚠️ HAD PERANTI DICAPAI' : '⚠️ DEVICE LIMIT REACHED';
      statusColor = 'var(--danger)';
      iconClass = 'fa-mobile-screen-button';
      iconColor = 'var(--danger)';
      detailsHtml = `
        <div style="background:var(--danger-light); color:var(--danger-text); padding:12px; border-radius:var(--radius-md); border:1px solid rgba(239, 68, 68, 0.3); font-size:12px; line-height:1.5;">
          <div style="font-weight:800; margin-bottom:4px;">
            ${isBM ? 'Had Maksimum Peranti Dicapai' : 'Maximum Devices Reached'}
          </div>
          <div style="font-size:11.5px; margin-bottom:10px;">
            ${isBM 
              ? 'Lesen ini telah digunakan pada bilangan peranti maksimum. Hubungi penjual untuk menetapkan semula senarai peranti anda.' 
              : 'This license has been registered on the maximum allowed devices. Contact seller to reset registered devices.'}
          </div>
          <button type="button" class="btn btn-whatsapp btn-block" id="btnProContactSellerDevLimit">
            <i class="fa-brands fa-whatsapp"></i> ${isBM ? 'Hubungi Penjual di WhatsApp' : 'Contact Seller on WhatsApp'}
          </button>
        </div>
      `;
      break;

    case 'SERVER_UNREACHABLE':
      statusLabel = isBM 
        ? `🌐 PELAYAN LUAR TALIAN (Pro Aktif)` 
        : `🌐 SERVER UNREACHABLE (Pro Active)`;
      statusColor = 'var(--primary)';
      iconClass = 'fa-cloud-slash';
      iconColor = 'var(--primary)';
      const unreachNextCheck = formatLicenseDate((appState.licensePayload?.iat || 0) + 7 * 86400, isBM ? 'bm' : 'en');
      const unreachRenewal = formatLicenseDate(appState.licensePayload?.exp || 0, isBM ? 'bm' : 'en');
      detailsHtml = `
        <div style="background:var(--bg-surface-subtle); padding:10px 12px; border-radius:var(--radius-md); border:1px solid var(--border-color); font-size:12px; line-height:1.5;">
          <div style="font-weight:700; color:var(--primary); margin-bottom:4px;">
            ${isBM ? 'Pelayan Lesen Tidak Dapat Dihubungi' : 'License Server Unreachable'}
          </div>
          <div style="font-size:11.5px; color:var(--text-muted); margin-bottom:6px;">
            ${isBM 
              ? `Tidak dapat menghubungi pelayan lesen sekarang, tetapi lesen Pro anda kekal aktif menggunakan token tempatan (${daysLeft} hari lagi). Tarikh semakan seterusnya: ${unreachNextCheck}; tarikh pembaharuan: ${unreachRenewal}.` 
              : `Could not reach license server, but your Pro license remains fully active using local cryptographic token (${daysLeft} days remaining). Next check: ${unreachNextCheck}; renewal: ${unreachRenewal}.`}
          </div>
        </div>
      `;
      break;

    default: // UNLICENSED / DEMO
      statusLabel = isBM ? '⏱️ MOD PERCUBAAN / DEMO' : '⏱️ TRIAL / FREE DEMO';
      statusColor = 'var(--warning)';
      iconClass = 'fa-crown';
      iconColor = 'var(--warning)';
      detailsHtml = `
        <div style="background:var(--bg-surface-subtle); padding:10px 12px; border-radius:var(--radius-md); border:1px solid var(--border-color); font-size:12px; line-height:1.5;">
          <div style="font-size:11.5px; color:var(--text-muted); margin-bottom:8px;">
            ${isBM 
              ? 'Anda sedang menggunakan mod demo. Buka akses penuh tanpa had dengan Kunci Lesen Pro Seumur Hidup.' 
              : 'You are using free demo mode. Unlock unlimited homestays, WhatsApp automation, and reports with a Lifetime Pro Key.'}
          </div>
          <div style="display:flex; gap:8px;">
            <button type="button" class="btn btn-primary btn-sm btn-block" id="btnProActivateDemo">
              <i class="fa-solid fa-key"></i> ${isBM ? 'Aktifkan Lesen' : 'Activate License'}
            </button>
            <button type="button" class="btn btn-warning btn-sm btn-block" id="btnProBuyDemo">
              <i class="fa-solid fa-cart-shopping"></i> ${isBM ? 'Beli Lesen' : 'Buy License'}
            </button>
          </div>
        </div>
      `;
      break;
  }

  if (statusText) {
    statusText.textContent = statusLabel;
    statusText.style.color = statusColor;
  }
  if (iconEl) {
    iconEl.className = `fa-solid ${iconClass}`;
    iconEl.style.color = iconColor;
  }
  if (detailsEl) {
    detailsEl.innerHTML = detailsHtml;

    // Attach event listeners for dynamic action buttons
    document.getElementById('btnProContactSellerRevoked')?.addEventListener('click', () => handleContactSellerWhatsApp('revoked'));
    document.getElementById('btnProContactSellerDevLimit')?.addEventListener('click', () => handleContactSellerWhatsApp('device_limit_reached'));
    document.getElementById('btnProReconnectNow')?.addEventListener('click', () => {
      closeProSystemModal();
      checkAndRefreshTokenSilently(true);
    });
    document.getElementById('btnProReactivateModal')?.addEventListener('click', () => {
      closeProSystemModal();
      openLicenseModal();
    });
    document.getElementById('btnProActivateDemo')?.addEventListener('click', () => {
      closeProSystemModal();
      openLicenseModal();
    });
    document.getElementById('btnProBuyDemo')?.addEventListener('click', handleBuyLicense);
  }

  // Diagnostics Section (Pro Hub)
  const diagContentEl = document.getElementById('proModalDiagnosticsContent');
  if (diagContentEl) {
    diagContentEl.innerHTML = '<div style="color:var(--text-muted); padding:4px 0;"><i class="fa-solid fa-spinner fa-spin"></i> Reading diagnostics...</div>';
  }

  getSupportDiagnosticsData().then(diag => {
    if (diagContentEl) {
      diagContentEl.innerHTML = `
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 4px 10px; margin-bottom: 6px;">
          <div><span style="color:var(--text-main); font-weight:700;">Version:</span> v${escapeHtml(diag.version)}</div>
          <div><span style="color:var(--text-main); font-weight:700;">Secure:</span> ${escapeHtml(diag.isSecureContext)}</div>
          <div><span style="color:var(--text-main); font-weight:700;">Crypto:</span> ${escapeHtml(diag.cryptoSubtle)}</div>
          <div><span style="color:var(--text-main); font-weight:700;">Device ID:</span> ${escapeHtml(diag.deviceId)}</div>
          <div><span style="color:var(--text-main); font-weight:700;">Token Stored:</span> ${escapeHtml(diag.tokenStored)}</div>
          <div><span style="color:var(--text-main); font-weight:700;">Clock:</span> ${escapeHtml(diag.clockStatus)}</div>
          <div><span style="color:var(--text-main); font-weight:700;">Hub State:</span> ${escapeHtml(diag.proHubState)}</div>
          <div><span style="color:var(--text-main); font-weight:700;">Network:</span> ${escapeHtml(diag.network)}</div>
        </div>
        <div style="margin-bottom: 4px;"><span style="color:var(--text-main); font-weight:700;">Verification:</span> ${escapeHtml(diag.tokenVerification)}</div>
        <div style="font-size: 10px; color:var(--text-muted); line-height: 1.3; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(diag.userAgent)}"><span style="color:var(--text-main); font-weight:700;">UA:</span> ${escapeHtml(diag.userAgent)}</div>
      `;
    }

    const copyBtn = document.getElementById('btnCopyDiagnostics');
    if (copyBtn) {
      copyBtn.onclick = async () => {
        const text = formatDiagnosticsForWhatsApp(diag);
        try {
          if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            await navigator.clipboard.writeText(text);
          } else {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
          }
          showToast(isBM ? '📋 Diagnostik disalin ke papan keratan!' : '📋 Diagnostics copied to clipboard!');
        } catch (err) {
          alert(text);
        }
      };
    }
  });

  modal.classList.add('active');
}

function closeProSystemModal() {
  const modal = document.getElementById('proSystemModal');
  if (modal) modal.classList.remove('active');
}

function openUserGuideModal() {
  const currentAppLang = appState.settings.language || 'en';
  
  // Set segment active state matching app language
  document.querySelectorAll('#guideLangSegmented .segment-btn').forEach(b => {
    b.classList.toggle('active', b.getAttribute('data-glang') === currentAppLang);
  });

  renderUserGuideAccordion(currentAppLang);
  document.getElementById('userGuideModal').classList.add('active');
}

function renderUserGuideAccordion(lang = 'en') {
  const container = document.getElementById('userGuideAccordion');
  if (!container) return;
  container.innerHTML = '';

  const list = USER_GUIDE_DATA[lang] || USER_GUIDE_DATA.en;

  list.forEach((item, index) => {
    const card = document.createElement('div');
    card.className = `guide-card ${index === 0 ? 'active' : ''}`;
    card.innerHTML = `
      <div class="guide-card-header">
        <div class="guide-card-title-group">
          <div class="guide-card-icon">
            <i class="fa-solid ${item.icon}"></i>
          </div>
          <h4 class="guide-card-title">${item.title}</h4>
        </div>
        <i class="fa-solid fa-chevron-down guide-card-chevron"></i>
      </div>
      <div class="guide-card-body">
        ${item.content}
      </div>
    `;

    card.querySelector('.guide-card-header').addEventListener('click', () => {
      const wasActive = card.classList.contains('active');
      container.querySelectorAll('.guide-card').forEach(c => c.classList.remove('active'));
      if (!wasActive) card.classList.add('active');
    });

    container.appendChild(card);
  });
}

// ==========================================================================
// 19. RESIDENTIAL TENANCY AGREEMENT GENERATOR MODULE (v2.7.0)
// Automated legal Malaysian Tenancy Agreement with Muslim-friendly covenants
// ==========================================================================

const DEFAULT_AGREEMENT_INVENTORY = [
  { item: 'Air Conditioner & Remote / Pendingin Hawa', qty: 2, condition: 'Good & Functional / Baik' },
  { item: 'Refrigerator (2-Door) / Peti Sejuk', qty: 1, condition: 'Good & Functional / Baik' },
  { item: 'Automatic Washing Machine / Mesin Basuh', qty: 1, condition: 'Good & Functional / Baik' },
  { item: 'Smart Television & Remote / TV Pintar', qty: 1, condition: 'Good & Functional / Baik' },
  { item: 'Queen Bed Frame, Mattress & Wardrobe / Katil & Tilam', qty: 2, condition: 'Clean & Good / Baik' },
  { item: 'Single Bed Frame & Mattress / Katil Bujang', qty: 1, condition: 'Clean & Good / Baik' },
  { item: 'Dining Table & 4 Chairs / Set Meja Makan', qty: 1, condition: 'Good & Sturdy / Baik' },
  { item: 'Living Room Sofa & Coffee Table / Set Sofa', qty: 1, condition: 'Good & Clean / Baik' },
  { item: 'Kitchen Gas Stove & Cylinder / Dapur Gas & Tong', qty: 1, condition: 'Clean & Functional / Baik' },
  { item: 'Ceiling / Wall Fans / Kipas Siling & Dinding', qty: 4, condition: 'Good & Working / Baik' },
  { item: 'House Keys & Gate Access / Kunci Rumah & Akses', qty: 2, condition: 'Complete Sets / Lengkap' }
];

const AGREEMENT_DOC_I18N = {
  bm: {
    docHeaderTitle: 'SURAT PERJANJIAN PENYEWAAN KEDIAMAN',
    docHeaderSub: 'RESIDENTIAL TENANCY AGREEMENT',
    preambleP1: (date, data) => {
      const isLandlordComp = data.landlordType === 'company';
      const isTenantComp = data.tenantType === 'company' || !!data.tenantContactName || (data.tenantIc && data.tenantIc.includes('('));

      let landlordStr = isLandlordComp
        ? `<strong>${escapeHtml(data.landlordName || 'TUAN RUMAH')}</strong> (No. Pendaftaran Syarikat / SSM: <strong>${escapeHtml(data.landlordIc || '-')}</strong>)`
        : `<strong>${escapeHtml(data.landlordName || 'TUAN RUMAH')}</strong> (No. Kad Pengenalan / NRIC: <strong>${escapeHtml(data.landlordIc || '-')}</strong>)`;

      if (isLandlordComp && data.landlordContactName) {
        landlordStr += ` yang diwakili oleh <strong>${escapeHtml(data.landlordContactName)}</strong> (No. K/P: <strong>${escapeHtml(data.landlordContactIc || '-')}</strong>${data.landlordContactDesignation ? `, Jawatan: <strong>${escapeHtml(data.landlordContactDesignation)}</strong>` : ''})`;
      }

      let tenantStr = '';
      if (isTenantComp) {
        tenantStr = `<strong>${escapeHtml(data.tenantName || 'PENYEWA')}</strong> (No. Pendaftaran Syarikat / SSM: <strong>${escapeHtml(data.tenantIc || '-')}</strong>)`;
        if (data.tenantContactName) {
          tenantStr += ` yang diwakili secara sah oleh Pegawai Dihubungi <strong>${escapeHtml(data.tenantContactName)}</strong> (No. K/P: <strong>${escapeHtml(data.tenantContactIc || '-')}</strong>${data.tenantContactDesignation ? `, Jawatan: <strong>${escapeHtml(data.tenantContactDesignation)}</strong>` : ''}${data.tenantContactPhone ? `, No. Tel: <strong>${escapeHtml(data.tenantContactPhone)}</strong>` : ''})`;
        }
      } else {
        tenantStr = `<strong>${escapeHtml(data.tenantName || 'PENYEWA')}</strong> (No. K/P / Pasport: <strong>${escapeHtml(data.tenantIc || '-')}</strong>)`;
        if (data.tenantContactName) {
          tenantStr += ` yang boleh dihubungi melalui / diwakili oleh <strong>${escapeHtml(data.tenantContactName)}</strong> (No. K/P: <strong>${escapeHtml(data.tenantContactIc || '-')}</strong>${data.tenantContactDesignation ? `, Hubungan/Jawatan: <strong>${escapeHtml(data.tenantContactDesignation)}</strong>` : ''}${data.tenantContactPhone ? `, No. Tel: <strong>${escapeHtml(data.tenantContactPhone)}</strong>` : ''})`;
        }
      }

      return `PERJANJIAN INI diperbuat pada tarikh <strong>${date}</strong> DI ANTARA ${landlordStr} yang beralamat di tempat yang dinyatakan dalam Seksyen 2 Jadual Pertama (selepas ini dirujuk sebagai <strong>"Tuan Rumah"</strong>) di satu pihak; DAN ${tenantStr} yang beralamat ${isTenantComp ? 'pejabat berdaftar' : 'tetap'} seperti dalam Seksyen 3 Jadual Pertama (selepas ini dirujuk sebagai <strong>"Penyewa"</strong>) di pihak yang satu lagi.`;
    },
    preambleP2: (propName, propAddress) =>
      `BAHAWASANYA Tuan Rumah adalah pemilik sah berdaftar / pengendali sah yang diberi kuasa bagi premis kediaman yang dikenali secara komersil sebagai <strong>"${propName}"</strong> yang beralamat di <strong>${propAddress}</strong> (selepas ini dirujuk sebagai <strong>"Premis Demis"</strong>) bersama segala lekapan, perabot dan inventori yang disenaraikan dalam Jadual Kedua. Tuan Rumah dengan ini bersetuju memberi sewaan dan Penyewa bersetuju menerima sewaan Premis Demis tersebut tertakluk kepada syarat-syarat dan fasal-fasal yang ditetapkan di bawah.`,
    
    // First Schedule
    firstScheduleTitle: 'JADUAL PERTAMA (FIRST SCHEDULE)',
    firstScheduleSub: 'JADUAL BUTIR-BUTIR PERJANJIAN PENYEWAAN',
    thItemNo: 'Item',
    thSubject: 'Perkara',
    thParticulars: 'Butir-Butir / Perincian',
    
    schDate: 'Tarikh Perjanjian',
    schLandlord: 'Tuan Rumah (Lessor)',
    schTenant: 'Penyewa (Lessee)',
    schProperty: 'Premis Yang Disewakan (Premis Demis)',
    schTerm: 'Tempoh Sewaan',
    schDates: 'Tarikh Permulaan & Tamat',
    schRent: 'Kadar Sewa Bulanan',
    schDue: 'Tarikh Genap Masa Bayaran',
    schRentalDep: 'Wang Cagaran Sewa (1 Bulan)',
    schUtilDep: 'Wang Cagaran Utiliti (Elektrik & Air)',
    schAdvance: 'Bayaran Sewa Pendahuluan (Bulan Pertama)',
    schFee: 'Duti Setem & Yuran Perjanjian',
    schUse: 'Kegunaan Premis Dibenarkan',
    schUseVal: 'Kediaman Persendirian Sahaja (Ditegah Perusahaan / Komersial)',
    schRenew: 'Opsyen Pembaharuan Sewaan',

    // Covenants
    sec1Title: 'FASAL 1: TANGGUNGJAWAB & AKU JANJI PENYEWA',
    sec1Clauses: [
      'Membayar sewa bulanan tepat pada tarikh yang ditetapkan tanpa sebarang tuntutan atau penolakan ke dalam akaun bank Tuan Rumah.',
      'Membayar semua bil penggunaan elektrik, air, caj perkhidmatan pembetungan (Indah Water) dan sebarang bil utiliti lain mengikut meter bacaan atau invois bulanan yang dikemukakan.',
      'Menjaga kebersihan dan keselamatan bahagian dalaman dan luaran premis, perabot, dan perkakas elektrik yang disenaraikan dalam Jadual Kedua agar sentiasa berada dalam keadaan baik, bersih dan berfungsi.',
      'Dilarang melakukan sebarang ubah suai struktur, meruntuhkan dinding, mengecat warna lain, atau menebuk lubang pada dinding tanpa mendapat persetujuan bertulis terlebih dahulu daripada Tuan Rumah.',
      'Dilarang sama sekali menyewakan semula (sublet), menyerahkan hak sewaan, atau berkongsi kediaman dengan mana-mana pihak ketiga tanpa kebenaran bertulis daripada Tuan Rumah.',
      'Membenarkan Tuan Rumah atau wakil yang diberikuasa memasuki premis pada bila-bila masa yang munasabah untuk tujuan pemeriksaan atau pembaikan dengan memberi notis awal sekurang-kurangnya 24 jam.',
      'Tidak menyimpan atau membenarkan disimpan sebarang barangan berbahaya, mudah terbakar, bahan letupan atau bahan terlarang di sisi undang-undang Malaysia di dalam premis.'
    ],

    // Special Muslim-Friendly Condition Clause (CRITICAL REQUIREMENT)
    secMuslimTitle: 'FASAL 2: KLAUSA KHAS PEMELIHARAAN KEADAAN RUMAH MESRA MUSLIM',
    secMuslimSub: 'Syarat pematuhan kesucian kediaman dan ketenteraman masyarakat Islam',
    secMuslimClauses: [
      '<strong>Makanan & Minuman Halal Sahaja:</strong> Penyewa, penghuni, dan mana-mana tetamu dilarang sama sekali membawa masuk, memasak, menyimpan atau memakan apa-apa makanan yang tidak halal, termasuk daging babi dan apa-apa produk atau ramuan yang berasaskannya di dalam premis sewaan.',
      '<strong>Larangan Mutlak Minuman Keras & Alkohol:</strong> Dilarang sama sekali membawa masuk, menyimpan, meminum, menghidang atau menjual arak, bir, wiski, atau sebarang minuman beralkohol yang memabukkan di dalam mana-mana bahagian premis.',
      '<strong>Larangan Haiwan Peliharaan Tidak Patuh Syarak:</strong> Dilarang sama sekali membawa masuk, memelihara atau membiarkan anjing atau apa-apa haiwan peliharaan yang tidak mematuhi hukum syarak di dalam kawasan rumah atau sekitarnya.',
      '<strong>Pemeliharaan Adab, Keharmonian Kejiranan & Larangan Maksiat:</strong> Penyewa bertanggungjawab memastikan premis digunakan secara beradab dan bermoral selaras dengan undang-undang negara dan tatasusila masyarakat setempat. Dilarang sama sekali melakukan perbuatan maksiat, pergaulan bebas / khalwat, aktiviti perjudian, dadah atau sebarang aktiviti yang melanggar hukum syarak.',
      '<strong>Hak Penamatan Serta-Merta & Kos Pensucian (Sertu):</strong> Sekiranya Penyewa didapati melanggar mana-mana peruntukan di bawah Fasal Khas ini, Tuan Rumah berhak menamatkan Perjanjian Sewaan ini serta-merta tanpa sebarang notis pemulangan sewa, mengarahkan Penyewa mengosongkan premis dalam tempoh 48 jam, dan menggunakan wang cagaran sewa/deposit untuk menanggung kos pembersihan menyeluruh premis termasuk kos pensucian (sertu/samak) jika perlu.'
    ],

    sec3Title: 'FASAL 3: TANGGUNGJAWAB & AKU JANJI TUAN RUMAH',
    sec3Clauses: [
      'Menyerahkan milikan kosong Premis Demis bersama kunci dan inventori dalam keadaan bersih, elok dan selamat untuk diduduki pada tarikh permulaan sewaan.',
      'Membayar cukai tanah (Quit Rent), cukai taksiran (Assessment Tax) dan sebarang caj penyelenggaraan bangunan/strata (jika ada).',
      'Menjamin bahawa Penyewa yang membayar sewa dan mematuhi terma perjanjian berhak menikmati dan mendiami Premis Demis dengan aman dan tenteram tanpa gangguan (Quiet Enjoyment).',
      'Membaiki sebarang kerosakan struktur utama bangunan (seperti bumbung bocor, retakan dinding utama, paip utama pecah) yang bukan disebabkan oleh salah laku atau kecuaian Penyewa.'
    ],

    sec4Title: 'FASAL 4: WANG CAGARAN (DEPOSIT) & POLISI PEMULANGAN',
    sec4Clauses: [
      'Wang Cagaran Sewa dan Utiliti hendaklah dibayar semasa menandatangani perjanjian ini dan dipegang oleh Tuan Rumah sebagai jaminan pematuhan syarat perjanjian.',
      'Wang cagaran ini tidak boleh sekali-kali dianggap atau digunakan oleh Penyewa sebagai bayaran sewa bulanan.',
      'Tuan Rumah akan memulangkan baki Wang Cagaran Sewa dan Cagaran Utiliti tanpa faedah kepada Penyewa dalam tempoh empat belas (14) hari selepas tarikh tamat sewaan dan penyerahan kunci, setelah ditolak sebarang tunggakan bil utiliti, kos pembaikan kerosakan fizikal, atau kos pembersihan premis.'
    ],

    sec5Title: 'FASAL 5: PENAMATAN SEWAAN, KEMUNGKIRAN & PENGOSONGAN',
    sec5Clauses: [
      'Sekiranya sewa bulanan tertunggak melebihi tempoh empat belas (14) hari daripada tarikh genap masa bayaran, Tuan Rumah berhak menuntut penamatan perjanjian dan mengambil semula milikan sah ke atas Premis Demis.',
      'Jika mana-mana pihak berhasrat menamatkan sewaan sebelum tamat tempoh yang dipersetujui, pihak tersebut hendaklah memberi notis bertulis sekurang-kurangnya dua (2) bulan atau membayar gantirugi sewa sebanyak dua (2) bulan.',
      'Pada hari terakhir sewaan, Penyewa hendaklah menyerahkan semula premis dan semua inventori dalam keadaan bersih dan baik (kehausan munasabah dikecualikan) bersama semua set kunci asal.'
    ],

    // Second Schedule: Inventory
    secondScheduleTitle: 'JADUAL KEDUA (SECOND SCHEDULE)',
    secondScheduleSub: 'SENARAI LEKAPAN, PERABOT & INVENTORI PREMIS',
    thInvNo: 'No.',
    thInvItem: 'Perkara / Perkakas / Perabot',
    thInvQty: 'Kuantiti',
    thInvCond: 'Keadaan Semasa Penyerahan',
    invVerifiedNote: 'Semua inventori dan perkakas di atas telah disemak, disahkan lengkap dan berfungsi dengan baik oleh kedua-dua pihak pada tarikh penyerahan kunci premis.',

    // Execution & Signatures
    executionTitle: 'METERAI & TANDATANGAN PIHAK-PIHAK',
    executionSub: 'DITANDATANGANI OLEH PIHAK-PIHAK PADA HARI DAN TAHUN SEPERTI YANG DINYATAKAN DI ATAS',
    signedByLandlord: 'Ditandatangani oleh TUAN RUMAH:',
    signedByTenant: 'Ditandatangani oleh PENYEWA:',
    witnessedBy: 'Disaksikan oleh SAKSI:',
    nameLabel: 'Nama:',
    icLabel: 'No. K/P:',
    dateLabel: 'Tarikh:',
    stampDutyNote: 'PENGESAHAN DUTI SETEM (STAMP DUTY LHDN)',
    stampDutyDesc: 'Dokumen ini boleh dimatikan setem hasil secara dalam talian melalui Portal STAMPS Lembaga Hasil Dalam Negeri Malaysia (LHDN) untuk tujuan perundangan rasmi.'
  },

  en: {
    docHeaderTitle: 'RESIDENTIAL TENANCY AGREEMENT',
    docHeaderSub: 'SURAT PERJANJIAN PENYEWAAN KEDIAMAN',
    preambleP1: (date, data) => {
      const isLandlordComp = data.landlordType === 'company';
      const isTenantComp = data.tenantType === 'company' || !!data.tenantContactName || (data.tenantIc && data.tenantIc.includes('('));

      let landlordStr = isLandlordComp
        ? `<strong>${escapeHtml(data.landlordName || 'LANDLORD')}</strong> (Company Reg No / SSM: <strong>${escapeHtml(data.landlordIc || '-')}</strong>)`
        : `<strong>${escapeHtml(data.landlordName || 'LANDLORD')}</strong> (NRIC No: <strong>${escapeHtml(data.landlordIc || '-')}</strong>)`;

      if (isLandlordComp && data.landlordContactName) {
        landlordStr += ` represented by <strong>${escapeHtml(data.landlordContactName)}</strong> (NRIC: <strong>${escapeHtml(data.landlordContactIc || '-')}</strong>${data.landlordContactDesignation ? `, Designation: <strong>${escapeHtml(data.landlordContactDesignation)}</strong>` : ''})`;
      }

      let tenantStr = '';
      if (isTenantComp) {
        tenantStr = `<strong>${escapeHtml(data.tenantName || 'TENANT')}</strong> (Company Registration No: <strong>${escapeHtml(data.tenantIc || '-')}</strong>)`;
        if (data.tenantContactName) {
          tenantStr += ` legally represented herein by Authorized Contact Person <strong>${escapeHtml(data.tenantContactName)}</strong> (NRIC: <strong>${escapeHtml(data.tenantContactIc || '-')}</strong>${data.tenantContactDesignation ? `, Designation: <strong>${escapeHtml(data.tenantContactDesignation)}</strong>` : ''}${data.tenantContactPhone ? `, Tel: <strong>${escapeHtml(data.tenantContactPhone)}</strong>` : ''})`;
        }
      } else {
        tenantStr = `<strong>${escapeHtml(data.tenantName || 'TENANT')}</strong> (NRIC / Passport No: <strong>${escapeHtml(data.tenantIc || '-')}</strong>)`;
        if (data.tenantContactName) {
          tenantStr += ` represented by / reachable via <strong>${escapeHtml(data.tenantContactName)}</strong> (NRIC: <strong>${escapeHtml(data.tenantContactIc || '-')}</strong>${data.tenantContactDesignation ? `, Capacity: <strong>${escapeHtml(data.tenantContactDesignation)}</strong>` : ''}${data.tenantContactPhone ? `, Tel: <strong>${escapeHtml(data.tenantContactPhone)}</strong>` : ''})`;
        }
      }

      return `THIS AGREEMENT is made on <strong>${date}</strong> BETWEEN ${landlordStr} having its address as stated in Section 2 of the First Schedule (hereinafter referred to as the <strong>"Landlord"</strong>) of the one part; AND ${tenantStr} having its ${isTenantComp ? 'registered office address' : 'permanent address'} as stated in Section 3 of the First Schedule (hereinafter referred to as the <strong>"Tenant"</strong>) of the other part.`;
    },
    preambleP2: (propName, propAddress) =>
      `WHEREAS the Landlord is the lawful registered owner / authorized operator of the residential property commercially known as <strong>"${propName}"</strong> situated at <strong>${propAddress}</strong> (hereinafter referred to as the <strong>"Demised Premises"</strong>) together with all fixtures, furniture, and fittings specified in the Second Schedule hereto. The Landlord agrees to let and the Tenant agrees to take the Demised Premises on the terms and covenants contained herein.`,

    // First Schedule
    firstScheduleTitle: 'FIRST SCHEDULE',
    firstScheduleSub: 'SCHEDULE OF TENANCY PARTICULAR DETAILS',
    thItemNo: 'Item',
    thSubject: 'Subject Matter',
    thParticulars: 'Particulars & Descriptions',

    schDate: 'Agreement Execution Date',
    schLandlord: 'Landlord (Lessor)',
    schTenant: 'Tenant (Lessee)',
    schProperty: 'Demised Premises Address',
    schTerm: 'Tenancy Term / Duration',
    schDates: 'Commencement & Expiry Dates',
    schRent: 'Monthly Rental Amount',
    schDue: 'Monthly Rent Due Date',
    schRentalDep: 'Rental Security Deposit (1 Month)',
    schUtilDep: 'Utilities Deposit (Water & Electric)',
    schAdvance: 'Advance Rental (First Month)',
    schFee: 'Agreement Preparation & Stamping Fee',
    schUse: 'Permitted Use of Premises',
    schUseVal: 'Private Residential Dwelling Only (Commercial use strictly prohibited)',
    schRenew: 'Option to Renew Notice',

    // Covenants
    sec1Title: "SECTION 1: TENANT'S COVENANTS & OBLIGATIONS",
    sec1Clauses: [
      'To pay the reserved monthly rent promptly on the stipulated due date without any deduction into the designated bank account of the Landlord.',
      'To pay all charges for water, electricity, sewerage services (Indah Water), and other utilities consumed on the premises directly or upon presentation of monthly billing statements.',
      'To maintain the interior and fixtures of the Demised Premises, including furniture and electrical appliances listed in the Second Schedule, in a clean, tenantable, and working condition.',
      'Not to make any structural alterations, renovations, wall hacking, or paint work without first obtaining the prior written consent of the Landlord.',
      'Strictly not to assign, sublet, or share possession of the Demised Premises or any part thereof with any third party without prior written permission from the Landlord.',
      'To permit the Landlord or authorized representatives to enter upon the Demised Premises at all reasonable times for inspection or maintenance purposes upon giving at least 24 hours prior notice.',
      'Not to bring, store, or permit to be stored on the premises any combustible, hazardous, explosive, or illicit goods in contravention of the laws of Malaysia.'
    ],

    // Special Muslim-Friendly Condition Clause (CRITICAL REQUIREMENT)
    secMuslimTitle: 'SECTION 2: SPECIAL MUSLIM-FRIENDLY HOUSE COVENANTS',
    secMuslimSub: 'Covenants for maintaining Muslim living conditions and community sanctity',
    secMuslimClauses: [
      '<strong>Halal Food & Drink Requirement:</strong> The Tenant and any occupants or guests are strictly prohibited from bringing, cooking, storing, or consuming any non-halal food, including pork and any pork-derived products or ingredients, inside the Demised Premises.',
      '<strong>Absolute Prohibition of Liquor & Alcohol:</strong> Strictly no intoxicating alcoholic beverages, beer, wine, or spirits shall be brought into, stored, consumed, served, or sold on the Demised Premises.',
      '<strong>Prohibition of Syarak-Restricted Pets:</strong> The Tenant shall not bring or keep dogs or any animals prohibited by Islamic principles (syarak) inside or around the compound of the Demised Premises.',
      '<strong>Islamic Decorum, Neighborhood Harmony & Prohibition of Vice:</strong> The Tenant undertakes to maintain standard moral and neighborhood decorum. Strictly no immoral acts, illicit cohabitation (khalwat), gambling, drug abuse, or unlawful conduct contrary to Islamic norms and Malaysian law shall occur on the premises.',
      '<strong>Landlord Right of Immediate Termination & Cleansing (Sertu) Costs:</strong> Any breach of this Special Covenant shall entitle the Landlord to immediately terminate this Tenancy Agreement without compensation, demand vacant possession within 48 hours, and forfeit/apply deposits towards professional deep-cleansing and Islamic ritual purification (sertu/samak) expenses where required.'
    ],

    sec3Title: "SECTION 3: LANDLORD'S COVENANTS & OBLIGATIONS",
    sec3Clauses: [
      'To deliver vacant possession of the Demised Premises together with keys and inventoried fixtures in clean and habitable condition on the commencement date.',
      'To pay all quit rent, property assessment taxes, and building management service maintenance charges (if applicable).',
      'To ensure that the Tenant paying the rent and observing the covenants shall peaceably hold and enjoy the Demised Premises during the term without any interruption by the Landlord (Quiet Enjoyment).',
      'To maintain and repair main structural components (e.g., roof leaks, structural walls, main external pipes) not caused by the negligence or misuse of the Tenant.'
    ],

    sec4Title: 'SECTION 4: SECURITY & UTILITY DEPOSITS REFUND POLICY',
    sec4Clauses: [
      'The Rental Deposit and Utilities Deposit paid upon execution shall be retained by the Landlord as security against default or physical damage.',
      'Under no circumstances shall the Tenant treat the deposits as payment for monthly rent.',
      'The Landlord shall refund the balance of the deposits without interest to the Tenant within fourteen (14) days after the expiration of the tenancy, subject to deduction for outstanding utility bills and repair of damaged inventory.'
    ],

    sec5Title: 'SECTION 5: TERMINATION, DEFAULT & RE-ENTRY',
    sec5Clauses: [
      'If the monthly rent remains unpaid for fourteen (14) days after becoming due, the Landlord shall be entitled to terminate this agreement and re-enter upon the Demised Premises.',
      'Either party may terminate the tenancy prior to expiration by serving at least two (2) months prior written notice or paying two (2) months rent in lieu of notice.',
      'Upon determination of the tenancy, the Tenant shall peacefully yield up the Demised Premises and inventoried items in good, clean condition (reasonable wear and tear excepted) together with all original keys.'
    ],

    // Second Schedule: Inventory
    secondScheduleTitle: 'SECOND SCHEDULE',
    secondScheduleSub: 'SCHEDULE OF FIXTURES, FITTINGS & INVENTORY',
    thInvNo: 'No.',
    thInvItem: 'Item / Fixture Description',
    thInvQty: 'Qty',
    thInvCond: 'Condition at Handover',
    invVerifiedNote: 'All fixtures and appliances listed above have been inspected, tested, and verified to be complete and in good working order by both parties upon key handover.',

    // Execution & Signatures
    executionTitle: 'EXECUTION & SIGNATURES',
    executionSub: 'IN WITNESS WHEREOF the parties have hereunto executed this Agreement on the day and year first above written',
    signedByLandlord: 'Signed by the LANDLORD:',
    signedByTenant: 'Signed by the TENANT:',
    witnessedBy: 'Witnessed by WITNESS:',
    nameLabel: 'Name:',
    icLabel: 'NRIC / Passport:',
    dateLabel: 'Date:',
    stampDutyNote: 'STAMP DUTY ATTESTATION (INLAND REVENUE BOARD / LHDN)',
    stampDutyDesc: 'This agreement may be digitally stamped via the Inland Revenue Board of Malaysia (LHDN) STAMPS portal for official legal and evidentiary enforcement.'
  }
};

/**
 * Detect if tenant/party name or notes indicate a registered company/enterprise
 */
function detectIsCompany(name = '', notes = '') {
  const text = `${name || ''} ${notes || ''}`.toLowerCase();
  const companyKeywords = [
    'sdn bhd', 'sdn. bhd.', 'bhd', 'bhd.', 'enterprise', 'trading', 'plt', 'llp',
    'holding', 'holdings', 'services', 'solutions', 'contractor', 'construction',
    'engineering', 'ventures', 'corporation', 'corp', 'agency', 'koperasi',
    'resources', 'associates', 'syarikat', 'co.', '& co', 'consultancy', 'logistics'
  ];
  return companyKeywords.some(kw => text.includes(kw));
}

/**
 * Set active entity type for Landlord (Individu vs Syarikat/SSM)
 */
function setAgreementLandlordType(type = 'individual') {
  const isComp = type === 'company';
  const hiddenInput = document.getElementById('agrLandlordType');
  if (hiddenInput) hiddenInput.value = isComp ? 'company' : 'individual';

  const btnIndiv = document.getElementById('btnAgrLandlordTypeIndiv');
  const btnComp = document.getElementById('btnAgrLandlordTypeComp');
  if (btnIndiv && btnComp) {
    if (isComp) {
      btnComp.classList.add('active');
      btnIndiv.classList.remove('active');
    } else {
      btnIndiv.classList.add('active');
      btnComp.classList.remove('active');
    }
  }

  const compContactGroup = document.getElementById('agrLandlordCompanyContactGroup');
  if (compContactGroup) {
    compContactGroup.style.display = isComp ? 'block' : 'none';
  }

  const lblName = document.getElementById('lblAgrLandlordName');
  const inputName = document.getElementById('agrLandlordName');
  const lblIc = document.getElementById('lblAgrLandlordIc');
  const inputIc = document.getElementById('agrLandlordIc');

  if (isComp) {
    if (lblName) lblName.textContent = 'Nama Syarikat Pemilik / Pengurusan (Company Name):';
    if (inputName) inputName.placeholder = 'cth: Semarak Hospitality Sdn. Bhd. / Homestay Services';
    if (lblIc) lblIc.textContent = 'No. Pendaftaran Syarikat (SSM):';
    if (inputIc) inputIc.placeholder = 'cth: 202301012345 (1234567-X)';
  } else {
    if (lblName) lblName.textContent = 'Nama Pemilik / Pemilik-Pemilik Sah:';
    if (inputName) inputName.placeholder = 'Nama Pemilik Sah (cth: Ali bin Abu / Pemilik Bersama)';
    if (lblIc) lblIc.textContent = 'No. Kad Pengenalan Pemilik (NRIC):';
    if (inputIc) inputIc.placeholder = 'cth: 850101-02-1234';
  }
}

/**
 * Set active entity type for Tenant (Individu vs Syarikat/SSM)
 */
function setAgreementTenantType(type = 'individual') {
  const isComp = type === 'company';
  const hiddenInput = document.getElementById('agrTenantType');
  if (hiddenInput) hiddenInput.value = isComp ? 'company' : 'individual';

  const btnIndiv = document.getElementById('btnAgrTenantTypeIndiv');
  const btnComp = document.getElementById('btnAgrTenantTypeComp');
  if (btnIndiv && btnComp) {
    if (isComp) {
      btnComp.classList.add('active');
      btnIndiv.classList.remove('active');
    } else {
      btnIndiv.classList.add('active');
      btnComp.classList.remove('active');
    }
  }

  const contactGroup = document.getElementById('agrTenantCompanyContactGroup');
  if (contactGroup) {
    contactGroup.style.display = 'block';
  }
  const lblContactHeader = document.getElementById('lblAgrTenantContactHeader');
  if (lblContactHeader) {
    lblContactHeader.textContent = isComp
      ? 'Wakil / Pegawai Dihubungi Syarikat (Authorized Contact Person):'
      : 'Pegawai Dihubungi / Wakil Penyewa (Contact Person & Authorized Representative):';
  }

  const lblName = document.getElementById('lblAgrTenantName');
  const inputName = document.getElementById('agrTenantName');
  const lblIc = document.getElementById('lblAgrTenantIc');
  const inputIc = document.getElementById('agrTenantIc');
  const lblPhone = document.getElementById('lblAgrTenantPhone');
  const inputPhone = document.getElementById('agrTenantPhone');
  const lblAddress = document.getElementById('lblAgrTenantAddress');
  const inputAddress = document.getElementById('agrTenantAddress');

  if (isComp) {
    if (lblName) lblName.textContent = 'Nama Syarikat Penyewa (Company Name):';
    if (inputName) inputName.placeholder = 'cth: Bina Jaya Construction Sdn Bhd / Maju Enterprise';
    if (lblIc) lblIc.textContent = 'No. Pendaftaran Syarikat (SSM):';
    if (inputIc) inputIc.placeholder = 'cth: 201901034567 (1345678-W)';
    if (lblPhone) lblPhone.textContent = 'No. Tel Pejabat / Syarikat:';
    if (inputPhone) inputPhone.placeholder = 'cth: +603-79881122';
    if (lblAddress) lblAddress.textContent = 'Alamat Pejabat Berdaftar Syarikat:';
    if (inputAddress) inputAddress.placeholder = 'Alamat pejabat berdaftar / operasi syarikat penyewa';
  } else {
    if (lblName) lblName.textContent = 'Nama Penuh Penyewa:';
    if (inputName) inputName.placeholder = 'Nama Penuh Penyewa';
    if (lblIc) lblIc.textContent = 'No. K/P / Pasport:';
    if (inputIc) inputIc.placeholder = 'cth: 920512-10-6677';
    if (lblPhone) lblPhone.textContent = 'No. Telefon / WhatsApp:';
    if (inputPhone) inputPhone.placeholder = 'cth: +60198765432';
    if (lblAddress) lblAddress.textContent = 'Alamat Tetap Penyewa:';
    if (inputAddress) inputAddress.placeholder = 'Alamat mengikut kad pengenalan penyewa';
  }
}

/**
 * Initialize agreement generator module event listeners
 */
function initAgreementGenerator() {
  appState.activeAgreementBooking = null;
  appState.activeAgreementLang = 'bm';

  // Party entity type toggle buttons (Landlord & Tenant: Individual vs Company)
  const btnLandlordIndiv = document.getElementById('btnAgrLandlordTypeIndiv');
  const btnLandlordComp = document.getElementById('btnAgrLandlordTypeComp');
  if (btnLandlordIndiv) {
    btnLandlordIndiv.addEventListener('click', () => {
      setAgreementLandlordType('individual');
      renderAgreementPreview();
    });
  }
  if (btnLandlordComp) {
    btnLandlordComp.addEventListener('click', () => {
      setAgreementLandlordType('company');
      renderAgreementPreview();
    });
  }

  const btnTenantIndiv = document.getElementById('btnAgrTenantTypeIndiv');
  const btnTenantComp = document.getElementById('btnAgrTenantTypeComp');
  if (btnTenantIndiv) {
    btnTenantIndiv.addEventListener('click', () => {
      setAgreementTenantType('individual');
      renderAgreementPreview();
    });
  }
  if (btnTenantComp) {
    btnTenantComp.addEventListener('click', () => {
      setAgreementTenantType('company');
      renderAgreementPreview();
    });
  }

  // Modal navigation tabs
  const tabForm = document.getElementById('btnAgrTabForm');
  const tabPreview = document.getElementById('btnAgrTabPreview');
  const formWrap = document.getElementById('agrTabFormContainer');
  const previewWrap = document.getElementById('agrTabPreviewContainer');

  if (tabForm && tabPreview) {
    tabForm.addEventListener('click', () => {
      tabForm.classList.add('active');
      tabPreview.classList.remove('active');
      if (formWrap) formWrap.style.display = 'block';
      if (previewWrap) previewWrap.style.display = 'none';
    });

    tabPreview.addEventListener('click', () => {
      tabPreview.classList.add('active');
      tabForm.classList.remove('active');
      if (formWrap) formWrap.style.display = 'none';
      if (previewWrap) previewWrap.style.display = 'block';
      renderAgreementPreview();
    });
  }

  const btnGoPreview = document.getElementById('btnAgrGoToPreview');
  if (btnGoPreview && tabPreview) {
    btnGoPreview.addEventListener('click', () => {
      tabPreview.click();
      const modalBody = document.querySelector('#agreementGeneratorModal .modal-body');
      if (modalBody) modalBody.scrollTop = 0;
    });
  }

  const btnBackForm = document.getElementById('btnAgrBackToForm');
  if (btnBackForm && tabForm) {
    btnBackForm.addEventListener('click', () => {
      tabForm.click();
      const modalBody = document.querySelector('#agreementGeneratorModal .modal-body');
      if (modalBody) modalBody.scrollTop = 0;
    });
  }

  const btnQuickSwitch = document.getElementById('btnQuickSwitchToForm');
  if (btnQuickSwitch && tabForm) {
    btnQuickSwitch.addEventListener('click', () => {
      tabForm.click();
      const modalBody = document.querySelector('#agreementGeneratorModal .modal-body');
      if (modalBody) modalBody.scrollTop = 0;
    });
  }

  // Modal close buttons
  const btnClose = document.getElementById('btnCloseAgreementModal');
  const btnCloseBtn = document.getElementById('btnCloseAgreementModalBtn');
  if (btnClose) btnClose.addEventListener('click', closeAllModals);
  if (btnCloseBtn) btnCloseBtn.addEventListener('click', closeAllModals);

  // Language buttons
  const btnBM = document.getElementById('btnAgrLangBM');
  const btnEN = document.getElementById('btnAgrLangEN');
  if (btnBM && btnEN) {
    btnBM.addEventListener('click', () => {
      btnBM.classList.add('active');
      btnEN.classList.remove('active');
      appState.activeAgreementLang = 'bm';
      renderAgreementPreview();
    });
    btnEN.addEventListener('click', () => {
      btnEN.classList.add('active');
      btnBM.classList.remove('active');
      appState.activeAgreementLang = 'en';
      renderAgreementPreview();
    });
  }

  // Booking selection & Auto-fill
  const bSelect = document.getElementById('agrBookingSelect');
  if (bSelect) {
    bSelect.addEventListener('change', () => {
      const bid = bSelect.value;
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        populateAgreementForm(b);
      }
    });
  }

  const btnAuto = document.getElementById('btnAgrAutoFill');
  if (btnAuto) {
    btnAuto.addEventListener('click', () => {
      const bid = document.getElementById('agrBookingSelect')?.value;
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        populateAgreementForm(b, true);
        showToast(appState.settings.language === 'bm' ? 'Maklumat tempahan berjaya dimuatkan semula!' : 'Booking particulars re-populated successfully!');
      } else {
        showToast(appState.settings.language === 'bm' ? 'Sila pilih rekod tempahan di atas.' : 'Please select a booking record above.');
      }
    });
  }

  // Add Inventory Item
  const btnAddInv = document.getElementById('btnAgrAddInventoryItem');
  if (btnAddInv) {
    btnAddInv.addEventListener('click', () => {
      addCustomInventoryRow('', 1, 'Baik & Berfungsi / Good', true);
    });
  }

  // Actions: Save Draft, Print, WhatsApp, Download PDF (Top Toolbar & Bottom Action Bar)
  const btnSave = document.getElementById('btnSaveAgreementDraft');
  if (btnSave) btnSave.addEventListener('click', (e) => { e?.preventDefault(); saveAgreementDraft(); });

  const btnPrint = document.getElementById('btnPrintAgreementDoc');
  if (btnPrint) btnPrint.addEventListener('click', (e) => { e?.preventDefault(); printAgreementDocument(); });

  const btnEmail = document.getElementById('btnEmailAgreement');
  if (btnEmail) btnEmail.addEventListener('click', (e) => { e?.preventDefault(); sendAgreementEmail(); });

  const btnEmailBottom = document.getElementById('btnEmailAgreementBottom');
  if (btnEmailBottom) btnEmailBottom.addEventListener('click', (e) => { e?.preventDefault(); sendAgreementEmail(); });

  const btnWa = document.getElementById('btnShareAgreementWa');
  if (btnWa) btnWa.addEventListener('click', (e) => { e?.preventDefault(); shareAgreementWhatsApp(); });

  const btnWaBottom = document.getElementById('btnShareAgreementWaBottom');
  if (btnWaBottom) btnWaBottom.addEventListener('click', (e) => { e?.preventDefault(); shareAgreementWhatsApp(); });

  const btnPdf = document.getElementById('btnDownloadAgreementPdf');
  if (btnPdf) btnPdf.addEventListener('click', (e) => { e?.preventDefault(); downloadAgreementPdf(); });

  const btnPdfBottom = document.getElementById('btnDownloadAgreementPdfBottom');
  if (btnPdfBottom) btnPdfBottom.addEventListener('click', (e) => { e?.preventDefault(); downloadAgreementPdf(); });

  // Recalculate duration when dates change
  const startInput = document.getElementById('agrStartDate');
  const endInput = document.getElementById('agrEndDate');
  if (startInput && endInput) {
    const handleDatesChange = () => {
      if (startInput.value && endInput.value) {
        const d1 = new Date(startInput.value);
        const d2 = new Date(endInput.value);
        if (d2 > d1) {
          const diffMonths = Math.max(1, Math.round((d2 - d1) / (1000 * 60 * 60 * 24 * 30.4375)));
          const durEl = document.getElementById('agrDurationMonths');
          if (durEl) durEl.value = diffMonths;
        }
      }
    };
    startInput.addEventListener('change', handleDatesChange);
    endInput.addEventListener('change', handleDatesChange);
  }

  // Real-time live synchronization: Any edit in the form instantly refreshes the document preview
  const formWrapEl = document.getElementById('agrTabFormContainer');
  if (formWrapEl) {
    formWrapEl.addEventListener('input', () => {
      renderAgreementPreview();
    });
    formWrapEl.addEventListener('change', () => {
      renderAgreementPreview();
    });
  }
}

/**
 * Set active agreement language cleanly ('bm' or 'en')
 */
function setAgreementLanguage(lang = 'bm') {
  appState.activeAgreementLang = (lang === 'en') ? 'en' : 'bm';
  const btnBM = document.getElementById('btnAgrLangBM');
  const btnEN = document.getElementById('btnAgrLangEN');
  if (btnBM && btnEN) {
    if (appState.activeAgreementLang === 'en') {
      btnEN.classList.add('active');
      btnBM.classList.remove('active');
    } else {
      btnBM.classList.add('active');
      btnEN.classList.remove('active');
    }
  }
  renderAgreementPreview();
}
window.setAgreementLanguage = setAgreementLanguage;

/**
 * Re-populate agreement form from selected booking
 */
function repopulateAgreementForm() {
  const bSelect = document.getElementById('agrBookingSelect');
  const bid = bSelect ? bSelect.value : null;
  const b = appState.bookings.find(x => x.id === bid) || null;
  if (b) {
    populateAgreementForm(b, true);
    renderAgreementPreview();
    showToast(appState.settings.language === 'bm' ? 'Maklumat tempahan berjaya dimuatkan semula!' : 'Booking particulars re-populated successfully!');
  } else {
    showToast(appState.settings.language === 'bm' ? 'Sila pilih rekod tempahan di atas.' : 'Please select a booking record above.');
  }
}
window.repopulateAgreementForm = repopulateAgreementForm;

/**
 * Switch agreement modal tab cleanly ('form' vs 'preview')
 */
function switchAgreementTab(tabName = 'form') {
  const tabForm = document.getElementById('btnAgrTabForm');
  const tabPreview = document.getElementById('btnAgrTabPreview');
  const formWrap = document.getElementById('agrTabFormContainer');
  const previewWrap = document.getElementById('agrTabPreviewContainer');

  if (tabName === 'preview') {
    tabPreview?.classList.add('active');
    tabForm?.classList.remove('active');
    if (formWrap) formWrap.style.display = 'none';
    if (previewWrap) {
      previewWrap.style.display = 'block';
      renderAgreementPreview();
    }
  } else {
    tabForm?.classList.add('active');
    tabPreview?.classList.remove('active');
    if (formWrap) formWrap.style.display = 'block';
    if (previewWrap) previewWrap.style.display = 'none';
  }
}
window.switchAgreementTab = switchAgreementTab;

/**
 * Open agreement modal, auto-populating from booking
 */
function openAgreementModal(booking = null, defaultTab = 'form') {
  try {
    // 0. Argument Sanitization: Protect against Event objects passed by listeners
    if (booking && (booking instanceof Event || booking.target || booking.currentTarget)) {
      booking = null;
    }
    if (typeof booking === 'string') {
      const bid = booking;
      booking = appState.bookings.find(b => String(b.id) === String(bid)) || null;
    }

    // Resolve fallback booking if none provided
    if (!booking) {
      if (appState.activeWaBooking && appState.activeWaBooking.rentalType === 'monthly') {
        booking = appState.activeWaBooking;
      } else if (appState.activePdfBooking && appState.activePdfBooking.rentalType === 'monthly') {
        booking = appState.activePdfBooking;
      } else {
        booking = appState.bookings.find(b => b.rentalType === 'monthly') || appState.bookings[0] || null;
      }
    }

    // CRITICAL: Close all existing active modals (e.g. monthlyInvoicesModal, pdfDocModal)
    closeAllModals();

    appState.activeAgreementBooking = booking;
    appState.activeAgreementLang = (appState.settings && appState.settings.language === 'en') ? 'en' : 'bm';

    const isBM = appState.activeAgreementLang === 'bm';

    // 1. Populate bookings dropdown
    try {
      populateAgreementBookingSelect(booking ? booking.id : null);
    } catch (e) {
      console.warn('Agreement dropdown populate notice:', e);
    }

    // 2. Populate form
    try {
      const activeBooking = booking || (() => {
        const bid = document.getElementById('agrBookingSelect')?.value;
        return appState.bookings.find(b => b.id === bid) || null;
      })();
      populateAgreementForm(activeBooking);
    } catch (e) {
      console.warn('Agreement form populate notice:', e);
    }

    // 3. Switch tab according to parameter ('form' or 'preview')
    switchAgreementTab(defaultTab || 'form');

    // 4. Update language toggle active pill
    setAgreementLanguage(appState.activeAgreementLang);

    // 5. Open modal with explicit flex display, top scroll & guaranteed highest z-index
    const modal = document.getElementById('agreementGeneratorModal');
    if (modal) {
      modal.style.setProperty('display', 'flex', 'important');
      modal.classList.add('active');
      modal.style.zIndex = '99999';
      modal.style.opacity = '1';
      modal.style.visibility = 'visible';
      modal.style.pointerEvents = 'auto';
      const modalBody = modal.querySelector('.modal-body');
      if (modalBody) modalBody.scrollTop = 0;
    }

    showToast(isBM ? 'Membuka Penjana Perjanjian Sewaan...' : 'Opening Tenancy Agreement Generator...');
  } catch (err) {
    console.error('Fatal error in openAgreementModal:', err);
    // Ultimate fallback: force modal visible
    const modal = document.getElementById('agreementGeneratorModal');
    if (modal) {
      modal.style.setProperty('display', 'flex', 'important');
      modal.classList.add('active');
      modal.style.zIndex = '99999';
      modal.style.opacity = '1';
      modal.style.visibility = 'visible';
      modal.style.pointerEvents = 'auto';
    }
  }
}
window.openAgreementModal = openAgreementModal;

/**
 * Populate bookings select element
 */
function populateAgreementBookingSelect(selectedBookingId = null) {
  const select = document.getElementById('agrBookingSelect');
  if (!select) return;
  select.innerHTML = '';

  const monthlyBookings = appState.bookings.filter(b => b.rentalType === 'monthly');
  const otherBookings = appState.bookings.filter(b => b.rentalType !== 'monthly');

  if (monthlyBookings.length > 0) {
    const grpMonthly = document.createElement('optgroup');
    grpMonthly.label = '── Sewaan Bulanan / Monthly Rentals ──';
    monthlyBookings.forEach(b => {
      const prop = getPropertyById(b.propertyId);
      const opt = document.createElement('option');
      opt.value = b.id;
      opt.textContent = `${b.guestName} • ${prop.name} (${b.checkIn} → ${b.checkOut} • RM${b.monthlyRate || b.totalAmount}/bln)`;
      grpMonthly.appendChild(opt);
    });
    select.appendChild(grpMonthly);
  }

  if (otherBookings.length > 0) {
    const grpOther = document.createElement('optgroup');
    grpOther.label = '── Rekod Tempahan Harian Lain ──';
    otherBookings.forEach(b => {
      const prop = getPropertyById(b.propertyId);
      const opt = document.createElement('option');
      opt.value = b.id;
      opt.textContent = `${b.guestName} • ${prop.name} (${b.checkIn} → ${b.checkOut})`;
      grpOther.appendChild(opt);
    });
    select.appendChild(grpOther);
  }

  if (select.options.length === 0) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = 'Tiada rekod tempahan (Borang Manual)';
    select.appendChild(opt);
  }

  if (selectedBookingId) {
    select.value = selectedBookingId;
  } else if (monthlyBookings.length > 0) {
    select.value = monthlyBookings[0].id;
  }
}

/**
 * Populate form inputs from booking or defaults
 */
function populateAgreementForm(booking = null, forceReset = false) {
  const settings = appState.settings || {};
  const isBM = appState.settings.language === 'bm';
  const todayStr = formatLocalDate(new Date());

  // Check if booking has saved agreement draft
  if (booking && booking.tenancyAgreement && !forceReset) {
    const draft = booking.tenancyAgreement;
    setAgreementLandlordType(draft.landlordType || 'individual');
    setAgreementTenantType(draft.tenantType || 'individual');

    document.getElementById('agrLandlordName').value = draft.landlordName || settings.ownerLegalName || settings.businessName || '';
    document.getElementById('agrLandlordIc').value = draft.landlordIc || settings.ownerIc || '';
    document.getElementById('agrLandlordPhone').value = draft.landlordPhone || settings.businessPhone || settings.ownerPhone || '';
    document.getElementById('agrLandlordAddress').value = draft.landlordAddress || settings.businessAddress || '';

    const elLCName = document.getElementById('agrLandlordContactName');
    const elLCDesig = document.getElementById('agrLandlordContactDesignation');
    const elLCIc = document.getElementById('agrLandlordContactIc');
    if (elLCName) elLCName.value = draft.landlordContactName || '';
    if (elLCDesig) elLCDesig.value = draft.landlordContactDesignation || '';
    if (elLCIc) elLCIc.value = draft.landlordContactIc || '';

    document.getElementById('agrTenantName').value = draft.tenantName || booking.guestName || '';
    document.getElementById('agrTenantIc').value = draft.tenantIc || booking.companyRegNo || booking.guestIc || '';
    document.getElementById('agrTenantPhone').value = draft.tenantPhone || booking.guestPhone || '';
    document.getElementById('agrTenantEmail').value = draft.tenantEmail || booking.guestEmail || '';
    document.getElementById('agrTenantAddress').value = draft.tenantAddress || booking.guestAddress || '';

    const elCName = document.getElementById('agrTenantContactName');
    const elCDesig = document.getElementById('agrTenantContactDesignation');
    const elCIc = document.getElementById('agrTenantContactIc');
    const elCPhone = document.getElementById('agrTenantContactPhone');
    if (elCName) elCName.value = draft.tenantContactName || booking.contactPerson || '';
    if (elCDesig) elCDesig.value = draft.tenantContactDesignation || booking.contactDesignation || '';
    if (elCIc) elCIc.value = draft.tenantContactIc || booking.contactIc || '';
    if (elCPhone) elCPhone.value = draft.tenantContactPhone || booking.contactPhone || '';

    document.getElementById('agrPropertyName').value = draft.propertyName || '';
    document.getElementById('agrPropertyType').value = draft.propertyType || '';
    document.getElementById('agrPropertyAddress').value = draft.propertyAddress || '';

    document.getElementById('agrAgreementDate').value = draft.agreementDate || todayStr;
    document.getElementById('agrStartDate').value = draft.startDate || booking.checkIn || '';
    document.getElementById('agrEndDate').value = draft.endDate || booking.checkOut || '';
    document.getElementById('agrDurationMonths').value = draft.durationMonths || booking.monthlyDuration || 6;

    document.getElementById('agrMonthlyRent').value = draft.monthlyRent || booking.monthlyRate || '';
    document.getElementById('agrRentalDueDay').value = draft.rentalDueDay || (isBM ? '7hb setiap bulan' : '7th of every month');
    document.getElementById('agrRentalDeposit').value = draft.rentalDeposit !== undefined ? draft.rentalDeposit : '';
    document.getElementById('agrUtilitiesDeposit').value = draft.utilitiesDeposit !== undefined ? draft.utilitiesDeposit : 300;
    document.getElementById('agrAdvanceRent').value = draft.advanceRent !== undefined ? draft.advanceRent : '';
    document.getElementById('agrAgreementFee').value = draft.agreementFee !== undefined ? draft.agreementFee : 150;
    document.getElementById('agrRenewalNotice').value = draft.renewalNotice || (isBM ? '2 Bulan bertulis sebelum tamat sewaan' : '2 Months prior written notice');
    document.getElementById('agrPaymentAccount').value = draft.paymentAccount || '';

    const chkMuslim = document.getElementById('agrMuslimFriendlyEnabled');
    if (chkMuslim) chkMuslim.checked = draft.muslimFriendlyEnabled !== false;
    document.getElementById('agrCustomClauses').value = draft.customClauses || '';

    document.getElementById('agrLandlordWitnessName').value = draft.landlordWitnessName || '';
    document.getElementById('agrLandlordWitnessIc').value = draft.landlordWitnessIc || '';
    document.getElementById('agrTenantWitnessName').value = draft.tenantWitnessName || '';
    document.getElementById('agrTenantWitnessIc').value = draft.tenantWitnessIc || '';

    renderDefaultInventoryRows(draft.inventory);
    return;
  }

  // Auto-populate from fresh booking & settings
  const isCorporateTenant = booking 
    ? (booking.tenantType === 'company' || detectIsCompany(booking.guestName, booking.notes) || !!booking.companyRegNo || !!booking.contactPerson) 
    : false;
  const isCorporateLandlord = !!(settings.businessSsm || settings.businessRegNo);

  setAgreementLandlordType(isCorporateLandlord ? 'company' : 'individual');
  setAgreementTenantType(isCorporateTenant ? 'company' : 'individual');

  const prop = booking ? getPropertyById(booking.propertyId) : (appState.properties[0] || {});
  const mRate = booking ? (Number(booking.monthlyRate || booking.baseRate || 1200)) : 1200;
  const mDeposit = (booking && booking.rentalDeposit !== undefined && booking.rentalDeposit !== null && booking.rentalDeposit !== '')
    ? Number(booking.rentalDeposit)
    : mRate;
  const uDeposit = (booking && booking.utilitiesDeposit !== undefined && booking.utilitiesDeposit !== null && booking.utilitiesDeposit !== '')
    ? Number(booking.utilitiesDeposit)
    : 300;
  const aFee = (booking && booking.agreementFee !== undefined && booking.agreementFee !== null && booking.agreementFee !== '')
    ? Number(booking.agreementFee)
    : 150;

  // Landlord
  document.getElementById('agrLandlordName').value = settings.ownerLegalName || settings.businessName || 'Pengurusan Homestay & Kediaman';
  document.getElementById('agrLandlordIc').value = isCorporateLandlord ? (settings.businessSsm || settings.businessRegNo || '') : (settings.ownerIc || '');
  document.getElementById('agrLandlordPhone').value = settings.businessPhone || settings.phone || settings.ownerPhone || '';
  document.getElementById('agrLandlordAddress').value = settings.businessAddress || 'Malaysia';

  const elLCName = document.getElementById('agrLandlordContactName');
  const elLCDesig = document.getElementById('agrLandlordContactDesignation');
  const elLCIc = document.getElementById('agrLandlordContactIc');
  if (elLCName) elLCName.value = '';
  if (elLCDesig) elLCDesig.value = '';
  if (elLCIc) elLCIc.value = '';

  // Tenant (Legal Party)
  document.getElementById('agrTenantName').value = booking ? (isCorporateTenant ? (booking.companyName || booking.guestName) : booking.guestName) : '';
  document.getElementById('agrTenantIc').value = booking ? (isCorporateTenant ? (booking.companyRegNo || booking.guestNric || '') : (booking.guestNric || '')) : '';
  document.getElementById('agrTenantPhone').value = booking ? (isCorporateTenant ? (booking.contactPhone || booking.guestPhone || '') : (booking.guestPhone || '')) : '';
  document.getElementById('agrTenantEmail').value = booking ? (isCorporateTenant ? (booking.contactEmail || booking.guestEmail || '') : (booking.guestEmail || '')) : '';
  document.getElementById('agrTenantAddress').value = booking ? (isCorporateTenant ? (booking.companyAddress || booking.guestAddress || '') : (booking.guestAddress || '')) : '';

  // Corporate tenant contact person & authorized signatory
  const elCName = document.getElementById('agrTenantContactName');
  const elCDesig = document.getElementById('agrTenantContactDesignation');
  const elCIc = document.getElementById('agrTenantContactIc');
  const elCPhone = document.getElementById('agrTenantContactPhone');
  if (elCName) elCName.value = booking ? (booking.signatoryName || booking.contactPerson || '') : '';
  if (elCDesig) elCDesig.value = booking ? (booking.signatoryDesignation || booking.contactDesignation || (isCorporateTenant ? (isBM ? 'Pengarah / Wakil Diberikuasa' : 'Director / Authorized Representative') : '')) : '';
  if (elCIc) elCIc.value = booking ? (booking.signatoryIc || booking.contactIc || '') : '';
  if (elCPhone) elCPhone.value = booking ? (booking.contactPhone || (isCorporateTenant ? (booking.guestPhone || '') : '')) : '';

  // Property
  document.getElementById('agrPropertyName').value = prop ? prop.name : '';
  document.getElementById('agrPropertyType').value = prop.propType === 'entire'
    ? (isBM ? 'Rumah Kediaman (Whole House)' : 'Residential House (Whole Unit)')
    : (prop.roomNo ? `Bilik Kediaman (${prop.roomNo})` : 'Rumah Kediaman');
  document.getElementById('agrPropertyAddress').value = prop.address || '';

  // Dates & Terms
  document.getElementById('agrAgreementDate').value = todayStr;
  document.getElementById('agrStartDate').value = booking ? booking.checkIn : todayStr;
  document.getElementById('agrEndDate').value = booking ? booking.checkOut : '';
  document.getElementById('agrDurationMonths').value = booking ? (booking.monthlyDuration || 6) : 6;

  document.getElementById('agrMonthlyRent').value = mRate;
  document.getElementById('agrRentalDueDay').value = isBM ? '7hb setiap bulan' : '7th of every month';
  document.getElementById('agrRentalDeposit').value = mDeposit;
  document.getElementById('agrUtilitiesDeposit').value = uDeposit;
  document.getElementById('agrAdvanceRent').value = mRate;
  document.getElementById('agrAgreementFee').value = aFee;
  document.getElementById('agrRenewalNotice').value = isBM ? '2 Bulan bertulis sebelum tamat sewaan' : '2 Months prior written notice';

  // Bank Account
  const bankStr = `${settings.bankName || 'Maybank'} - ${settings.bankAccount || '5140-xxxx-xxxx'} (${settings.bankHolder || settings.businessName || 'Tuan Rumah'})`;
  document.getElementById('agrPaymentAccount').value = bankStr;

  // Muslim Condition (Enabled by default as per user request)
  const chkMuslim = document.getElementById('agrMuslimFriendlyEnabled');
  if (chkMuslim) chkMuslim.checked = true;
  document.getElementById('agrCustomClauses').value = '';

  // Witnesses
  document.getElementById('agrLandlordWitnessName').value = '';
  document.getElementById('agrLandlordWitnessIc').value = '';
  document.getElementById('agrTenantWitnessName').value = '';
  document.getElementById('agrTenantWitnessIc').value = '';

  // Inventory Checklist
  renderDefaultInventoryRows();

  // Status badge update
  const statusBadge = document.getElementById('agrBookingStatusBadge');
  if (statusBadge && booking) {
    statusBadge.innerHTML = `<span style="color:var(--success); font-weight:700;"><i class="fa-solid fa-check-circle"></i> Maklumat tempahan "${booking.guestName}" (${prop.name}) dimuatkan.</span>`;
  }
}

/**
 * Render inventory table rows
 */
function renderDefaultInventoryRows(savedInventory = null) {
  const tbody = document.getElementById('agrInventoryTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  const list = (savedInventory || DEFAULT_AGREEMENT_INVENTORY).filter(item => {
    const name = (item.item || '').toLowerCase();
    return !name.includes('water heater') && !name.includes('pemanas air');
  });
  list.forEach(item => {
    addCustomInventoryRow(item.item, item.qty, item.condition, item.checked !== false);
  });
}

/**
 * Add an inventory item row into the table
 */
function addCustomInventoryRow(item = '', qty = 1, condition = 'Baik & Berfungsi / Good', checked = true) {
  const tbody = document.getElementById('agrInventoryTableBody');
  if (!tbody) return;

  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td style="padding:6px; text-align:center;">
      <input type="checkbox" class="agr-inv-check" ${checked ? 'checked' : ''} style="accent-color:var(--primary); transform:scale(1.1);">
    </td>
    <td style="padding:6px;">
      <input type="text" class="agr-inv-item" value="${escapeHtml(item)}" placeholder="Nama perkakas / perabot">
    </td>
    <td style="padding:6px; text-align:center;">
      <input type="number" class="agr-inv-qty" value="${qty || 1}" min="1" max="99" style="text-align:center;">
    </td>
    <td style="padding:6px;">
      <input type="text" class="agr-inv-condition" value="${escapeHtml(condition)}" placeholder="Keadaan (Baik & Berfungsi)">
    </td>
    <td style="padding:6px; text-align:center;">
      <button type="button" class="btn btn-outline btn-xs btn-del-inv-row" style="padding:2px 6px; color:var(--danger); border-color:var(--danger);">
        <i class="fa-solid fa-trash-can"></i>
      </button>
    </td>
  `;

  tr.querySelector('.btn-del-inv-row').addEventListener('click', () => {
    tr.remove();
  });

  tbody.appendChild(tr);
}

/**
 * Gather all agreement form inputs into an object
 */
function getAgreementFormData() {
  const getVal = id => (document.getElementById(id)?.value || '').trim();

  // Inventory
  const inventory = [];
  document.querySelectorAll('#agrInventoryTableBody tr').forEach(tr => {
    const isChecked = tr.querySelector('.agr-inv-check')?.checked;
    const item = tr.querySelector('.agr-inv-item')?.value.trim();
    const qty = parseInt(tr.querySelector('.agr-inv-qty')?.value) || 1;
    const condition = tr.querySelector('.agr-inv-condition')?.value.trim();
    if (item) {
      inventory.push({
        item,
        qty,
        condition: condition || 'Baik & Berfungsi / Good',
        checked: !!isChecked
      });
    }
  });

  return {
    landlordType: document.getElementById('agrLandlordType')?.value || 'individual',
    landlordName: getVal('agrLandlordName'),
    landlordIc: getVal('agrLandlordIc'),
    landlordPhone: getVal('agrLandlordPhone'),
    landlordAddress: getVal('agrLandlordAddress'),
    landlordContactName: getVal('agrLandlordContactName'),
    landlordContactDesignation: getVal('agrLandlordContactDesignation'),
    landlordContactIc: getVal('agrLandlordContactIc'),

    tenantType: document.getElementById('agrTenantType')?.value || 'individual',
    tenantName: getVal('agrTenantName'),
    tenantIc: getVal('agrTenantIc'),
    tenantPhone: getVal('agrTenantPhone'),
    tenantEmail: getVal('agrTenantEmail'),
    tenantAddress: getVal('agrTenantAddress'),

    tenantContactName: getVal('agrTenantContactName'),
    tenantContactDesignation: getVal('agrTenantContactDesignation'),
    tenantContactIc: getVal('agrTenantContactIc'),
    tenantContactPhone: getVal('agrTenantContactPhone'),

    propertyName: getVal('agrPropertyName'),
    propertyType: getVal('agrPropertyType'),
    propertyAddress: getVal('agrPropertyAddress'),

    agreementDate: getVal('agrAgreementDate'),
    startDate: getVal('agrStartDate'),
    endDate: getVal('agrEndDate'),
    durationMonths: parseInt(getVal('agrDurationMonths')) || 6,

    monthlyRent: parseFloat(getVal('agrMonthlyRent')) || 0,
    rentalDueDay: getVal('agrRentalDueDay') || '7hb setiap bulan',
    rentalDeposit: parseFloat(getVal('agrRentalDeposit')) || 0,
    utilitiesDeposit: parseFloat(getVal('agrUtilitiesDeposit')) || 0,
    advanceRent: parseFloat(getVal('agrAdvanceRent')) || 0,
    agreementFee: parseFloat(getVal('agrAgreementFee')) || 0,
    renewalNotice: getVal('agrRenewalNotice'),
    paymentAccount: getVal('agrPaymentAccount'),

    muslimFriendlyEnabled: document.getElementById('agrMuslimFriendlyEnabled')?.checked ?? true,
    customClauses: getVal('agrCustomClauses'),

    inventory,

    landlordWitnessName: getVal('agrLandlordWitnessName'),
    landlordWitnessIc: getVal('agrLandlordWitnessIc'),
    tenantWitnessName: getVal('agrTenantWitnessName'),
    tenantWitnessIc: getVal('agrTenantWitnessIc')
  };
}

/**
 * Format date for official Malaysian legal document
 */
function formatLegalDate(isoDateStr, lang = 'bm') {
  if (!isoDateStr) return '-';
  const parts = isoDateStr.split('-');
  if (parts.length !== 3) return isoDateStr;
  const day = parseInt(parts[2], 10);
  const monthIdx = parseInt(parts[1], 10) - 1;
  const year = parts[0];

  const monthsBM = ['Januari', 'Februari', 'Mac', 'April', 'Mei', 'Jun', 'Julai', 'Ogos', 'September', 'Oktober', 'November', 'Disember'];
  const monthsEN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const monthName = lang === 'en' ? (monthsEN[monthIdx] || parts[1]) : (monthsBM[monthIdx] || parts[1]);
  return `${day} ${monthName} ${year}`;
}

/**
 * Render the live A4 agreement document preview
 */
function renderAgreementPreview() {
  const sheet = document.getElementById('printableAgreementSheet');
  if (!sheet) return;

  const data = getAgreementFormData();
  const lang = appState.activeAgreementLang || 'bm';
  const i18n = AGREEMENT_DOC_I18N[lang] || AGREEMENT_DOC_I18N.bm;

  const formattedDate = formatLegalDate(data.agreementDate, lang);
  const formattedStart = formatLegalDate(data.startDate, lang);
  const formattedEnd = formatLegalDate(data.endDate, lang);

  const formatRM = val => `RM ${Number(val || 0).toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  // Checked inventory items only (safeguard against water heater)
  const activeInventory = (data.inventory || []).filter(x => {
    if (!x.checked) return false;
    const name = (x.item || '').toLowerCase();
    return !name.includes('water heater') && !name.includes('pemanas air');
  });

  // Generate Document HTML
  sheet.innerHTML = `
    <!-- DOCUMENT HEADER -->
    <div style="text-align:center; margin-bottom:20px; border-bottom:2px solid #0f172a; padding-bottom:12px;">
      <h1 class="agr-doc-title">${i18n.docHeaderTitle}</h1>
      <div class="agr-doc-subtitle">${i18n.docHeaderSub}</div>
      <div style="font-size:10.5pt; font-weight:bold; letter-spacing:0.5px;">
        ${lang === 'en' ? 'BETWEEN' : 'DI ANTARA'}<br>
        <span style="font-size:12pt; text-transform:uppercase;">${escapeHtml(data.landlordName || 'TUAN RUMAH')}</span>
        ${data.landlordType === 'company' && data.landlordIc ? `<span style="font-size:9.5pt; font-weight:normal; display:block;">(${lang === 'en' ? 'Company Reg No / SSM' : 'No. Pendaftaran Syarikat / SSM'}: ${escapeHtml(data.landlordIc)})</span>` : ''}
        <br>${lang === 'en' ? 'AND' : 'DAN'}<br>
        <span style="font-size:12pt; text-transform:uppercase;">${escapeHtml(data.tenantName || 'PENYEWA')}</span>
        ${data.tenantType === 'company' && data.tenantIc ? `<span style="font-size:9.5pt; font-weight:normal; display:block;">(${lang === 'en' ? 'Company Reg No / SSM' : 'No. Pendaftaran Syarikat / SSM'}: ${escapeHtml(data.tenantIc)})</span>` : ''}
      </div>
    </div>

    <!-- PREAMBLE -->
    <div class="agr-preamble">
      <p style="margin-bottom:10px;">
        ${i18n.preambleP1(formattedDate, data)}
      </p>
      <p style="margin-bottom:0;">
        ${i18n.preambleP2(
          escapeHtml(data.propertyName || 'PREMIS KEDIAMAN'),
          escapeHtml(data.propertyAddress || '-')
        )}
      </p>
    </div>

    <!-- FIRST SCHEDULE -->
    <div class="agr-clause-block">
      <div class="agr-clause-title" style="text-align:center;">${i18n.firstScheduleTitle}</div>
      <div style="text-align:center; font-size:10pt; font-style:italic; margin-bottom:8px;">${i18n.firstScheduleSub}</div>

      <table class="agr-schedule-table">
        <thead>
          <tr>
            <th class="agr-schedule-item-num">${i18n.thItemNo}</th>
            <th class="agr-schedule-item-title">${i18n.thSubject}</th>
            <th>${i18n.thParticulars}</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="agr-schedule-item-num">1.</td>
            <td class="agr-schedule-item-title">${i18n.schDate}</td>
            <td><strong>${formattedDate}</strong></td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">2.</td>
            <td class="agr-schedule-item-title">${i18n.schLandlord}</td>
            <td>
              <strong>${escapeHtml(data.landlordName || '-')}</strong><br>
              ${data.landlordType === 'company' 
                ? `${lang === 'en' ? 'Company Reg No (SSM):' : 'No. Pendaftaran Syarikat (SSM):'} <strong>${escapeHtml(data.landlordIc || '-')}</strong><br>${lang === 'en' ? 'Business / Office Tel:' : 'No. Tel Pejabat / WhatsApp:'} ${escapeHtml(data.landlordPhone || '-')}<br>${lang === 'en' ? 'Registered Office Address:' : 'Alamat Pejabat / Surat-Menyurat:'} ${escapeHtml(data.landlordAddress || '-')}`
                : `${lang === 'en' ? 'NRIC No:' : 'No. Kad Pengenalan (NRIC):'} <strong>${escapeHtml(data.landlordIc || '-')}</strong><br>${lang === 'en' ? 'Phone / WhatsApp:' : 'No. Tel / WhatsApp:'} ${escapeHtml(data.landlordPhone || '-')}<br>${lang === 'en' ? 'Correspondence Address:' : 'Alamat Surat-Menyurat:'} ${escapeHtml(data.landlordAddress || '-')}`
              }
              ${(data.landlordType === 'company' && data.landlordContactName) ? `
                <div style="margin-top:6px; padding:6px 10px; background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px; font-size:9.5pt; line-height:1.45;">
                  <strong style="color:#0f172a;"><i class="fa-solid fa-user-tie"></i> ${lang === 'en' ? 'Authorized Signatory / Representative:' : 'Wakil Sah / Penandatangan Tuan Rumah:'}</strong><br>
                  • ${lang === 'en' ? 'Name:' : 'Nama:'} <strong>${escapeHtml(data.landlordContactName)}</strong> ${data.landlordContactDesignation ? `(${escapeHtml(data.landlordContactDesignation)})` : ''}<br>
                  • ${lang === 'en' ? 'NRIC No:' : 'No. K/P:'} <strong>${escapeHtml(data.landlordContactIc || '-')}</strong>
                </div>
              ` : ''}
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">3.</td>
            <td class="agr-schedule-item-title">${i18n.schTenant}</td>
            <td>
              <strong>${escapeHtml(data.tenantName || '-')}</strong><br>
              ${(data.tenantType === 'company' || (data.tenantIc && data.tenantIc.includes('(')))
                ? `${lang === 'en' ? 'Company Reg No (SSM):' : 'No. Pendaftaran Syarikat (SSM):'} <strong>${escapeHtml(data.tenantIc || '-')}</strong><br>`
                : `${lang === 'en' ? 'NRIC / Passport:' : 'No. K/P / Pasport:'} <strong>${escapeHtml(data.tenantIc || '-')}</strong><br>`
              }
              ${data.tenantType === 'company' 
                ? `${lang === 'en' ? 'Registered Office Address:' : 'Alamat Pejabat Berdaftar:'} ${escapeHtml(data.tenantAddress || '-')}<br>${lang === 'en' ? 'Office Phone:' : 'No. Tel Pejabat:'} ${escapeHtml(data.tenantPhone || '-')}<br>`
                : `${lang === 'en' ? 'Permanent Address:' : 'Alamat Tetap:'} ${escapeHtml(data.tenantAddress || '-')}<br>${lang === 'en' ? 'Phone:' : 'No. Tel:'} ${escapeHtml(data.tenantPhone || '-')}<br>`
              }
              ${data.tenantEmail ? `${lang === 'en' ? 'Email:' : 'Emel:'} ${escapeHtml(data.tenantEmail)}<br>` : ''}
              ${(data.tenantContactName || data.tenantContactPhone || data.tenantType === 'company') ? `
                <div style="margin-top:6px; padding:6px 10px; background:#f0fdf4; border:1px solid #86efac; border-radius:6px; font-size:9.5pt; line-height:1.45;">
                  <strong style="color:#166534;"><i class="fa-solid fa-id-badge"></i> ${lang === 'en' ? 'Authorized Contact Person / Representative:' : 'Pegawai Dihubungi / Wakil Penyewa Diberi Kuasa:'}</strong><br>
                  • ${lang === 'en' ? 'Full Name:' : 'Nama Penuh:'} <strong>${escapeHtml(data.tenantContactName || '-')}</strong> ${data.tenantContactDesignation ? `(${escapeHtml(data.tenantContactDesignation)})` : ''}<br>
                  • ${lang === 'en' ? 'NRIC No:' : 'No. K/P (NRIC):'} <strong>${escapeHtml(data.tenantContactIc || '-')}</strong><br>
                  • ${lang === 'en' ? 'Mobile / WhatsApp:' : 'No. Tel Bimbit / WhatsApp:'} <strong>${escapeHtml(data.tenantContactPhone || '-')}</strong>
                </div>
              ` : ''}
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">4.</td>
            <td class="agr-schedule-item-title">${i18n.schProperty}</td>
            <td>
              <strong>${escapeHtml(data.propertyName || '-')}</strong> (${escapeHtml(data.propertyType || '-')})<br>
              ${escapeHtml(data.propertyAddress || '-')}
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">5.</td>
            <td class="agr-schedule-item-title">${i18n.schTerm}</td>
            <td><strong>${data.durationMonths} ${lang === 'en' ? 'Months' : 'Bulan'}</strong></td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">6.</td>
            <td class="agr-schedule-item-title">${i18n.schDates}</td>
            <td>
              ${lang === 'en' ? 'From' : 'Mulai'}: <strong>${formattedStart}</strong><br>
              ${lang === 'en' ? 'To' : 'Hingga'}: <strong>${formattedEnd}</strong>
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">7.</td>
            <td class="agr-schedule-item-title">${i18n.schRent}</td>
            <td>
              <strong style="font-size:11.5pt;">${formatRM(data.monthlyRent)}</strong> ${lang === 'en' ? 'per month' : 'sebulan'}<br>
              <span style="font-size:9.5pt; color:#475569;">(${lang === 'en' ? 'Bank Account' : 'Akaun Bayaran'}: ${escapeHtml(data.paymentAccount || '-')})</span>
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">8.</td>
            <td class="agr-schedule-item-title">${i18n.schDue}</td>
            <td><strong>${escapeHtml(data.rentalDueDay || '7hb setiap bulan')}</strong></td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">9.</td>
            <td class="agr-schedule-item-title">${i18n.schRentalDep}</td>
            <td><strong>${formatRM(data.rentalDeposit)}</strong> (${lang === 'en' ? 'Security Deposit' : 'Cagaran Keselamatan'})</td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">10.</td>
            <td class="agr-schedule-item-title">${i18n.schUtilDep}</td>
            <td><strong>${formatRM(data.utilitiesDeposit)}</strong> (${lang === 'en' ? 'Electricity & Water' : 'Elektrik & Air'})</td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">11.</td>
            <td class="agr-schedule-item-title">${i18n.schAdvance}</td>
            <td><strong>${formatRM(data.advanceRent)}</strong> (${lang === 'en' ? 'First month rental payment' : 'Sewa bulan pertama semasa kemasukan'})</td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">12.</td>
            <td class="agr-schedule-item-title">${i18n.schFee}</td>
            <td><strong>${formatRM(data.agreementFee)}</strong></td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">13.</td>
            <td class="agr-schedule-item-title">${i18n.schUse}</td>
            <td>${i18n.schUseVal}</td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">14.</td>
            <td class="agr-schedule-item-title">${i18n.schRenew}</td>
            <td>${escapeHtml(data.renewalNotice || (lang === 'en' ? '2 Months written notice prior to expiration' : '2 Bulan notis bertulis sebelum tamat sewaan'))}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- COVENANTS -->
    <div style="margin-top:20px;">
      
      <!-- FASAL 1: TENANT COVENANTS -->
      <div class="agr-clause-block">
        <div class="agr-clause-title">${i18n.sec1Title}</div>
        <ol class="agr-clause-list">
          ${i18n.sec1Clauses.map(clause => `<li>${clause}</li>`).join('')}
        </ol>
      </div>

      <!-- FASAL 2: SPECIAL MUSLIM-FRIENDLY HOUSE COVENANTS (HIGHLIGHTED PER USER SPECIFICATION) -->
      ${data.muslimFriendlyEnabled ? `
        <div class="agr-clause-block">
          <div class="agr-clause-title" style="color:#065f46; border-bottom:2px solid #059669;">
            ${i18n.secMuslimTitle}
          </div>
          <div style="font-size:10pt; font-style:italic; color:#065f46; margin-bottom:8px;">
            ${i18n.secMuslimSub}
          </div>
          <div class="agr-muslim-highlight-box">
            <ol class="agr-clause-list" style="margin:0; padding-left:18px;">
              ${i18n.secMuslimClauses.map(clause => `<li style="margin-bottom:6px;">${clause}</li>`).join('')}
            </ol>
            ${data.customClauses ? `
              <div style="margin-top:10px; padding-top:8px; border-top:1px dashed #86efac; font-size:10.5pt;">
                <strong>${lang === 'en' ? 'Additional Landlord Special Rules:' : 'Syarat Khas Tambahan Tuan Rumah:'}</strong><br>
                ${escapeHtml(data.customClauses).replace(/\n/g, '<br>')}
              </div>
            ` : ''}
          </div>
        </div>
      ` : ''}

      <!-- FASAL 3: LANDLORD COVENANTS -->
      <div class="agr-clause-block">
        <div class="agr-clause-title">${i18n.sec3Title}</div>
        <ol class="agr-clause-list">
          ${i18n.sec3Clauses.map(clause => `<li>${clause}</li>`).join('')}
        </ol>
      </div>

      <!-- FASAL 4: DEPOSITS & REFUND -->
      <div class="agr-clause-block">
        <div class="agr-clause-title">${i18n.sec4Title}</div>
        <ol class="agr-clause-list">
          ${i18n.sec4Clauses.map(clause => `<li>${clause}</li>`).join('')}
        </ol>
      </div>

      <!-- FASAL 5: TERMINATION & DEFAULT -->
      <div class="agr-clause-block">
        <div class="agr-clause-title">${i18n.sec5Title}</div>
        <ol class="agr-clause-list">
          ${i18n.sec5Clauses.map(clause => `<li>${clause}</li>`).join('')}
        </ol>
      </div>

    </div>

    <!-- SECOND SCHEDULE: INVENTORY -->
    <div class="agr-clause-block" style="margin-top:24px;">
      <div class="agr-clause-title" style="text-align:center;">${i18n.secondScheduleTitle}</div>
      <div style="text-align:center; font-size:10pt; font-style:italic; margin-bottom:8px;">${i18n.secondScheduleSub}</div>

      <table class="agr-inventory-schedule-table">
        <thead>
          <tr>
            <th style="width:36px; text-align:center;">${i18n.thInvNo}</th>
            <th>${i18n.thInvItem}</th>
            <th style="width:60px; text-align:center;">${i18n.thInvQty}</th>
            <th style="width:180px;">${i18n.thInvCond}</th>
          </tr>
        </thead>
        <tbody>
          ${activeInventory.length > 0 ? activeInventory.map((inv, idx) => `
            <tr>
              <td style="text-align:center;">${idx + 1}.</td>
              <td><strong>${escapeHtml(inv.item)}</strong></td>
              <td style="text-align:center;">${inv.qty}</td>
              <td>${escapeHtml(inv.condition)}</td>
            </tr>
          `).join('') : `
            <tr>
              <td colspan="4" style="text-align:center; font-style:italic; padding:10px;">
                ${lang === 'en' ? 'Demised Premises leased unfurnished or inventory verified separately.' : 'Premis disewakan tanpa perabot tambahan atau inventori disahkan berasingan.'}
              </td>
            </tr>
          `}
        </tbody>
      </table>
      <div style="font-size:9.5pt; font-style:italic; color:#475569; margin-top:4px;">
        ${i18n.invVerifiedNote}
      </div>
    </div>

    <!-- EXECUTION & SIGNATURES -->
    <div class="agr-signatures">
      <div class="agr-clause-title" style="text-align:center; border:none; margin-bottom:4px;">${i18n.executionTitle}</div>
      <div style="text-align:center; font-size:9.5pt; font-style:italic; margin-bottom:18px;">${i18n.executionSub}</div>

      <div class="agr-sig-grid">
        <!-- Landlord Column -->
        <div class="agr-sig-card">
          <div>
            <strong>${data.landlordType === 'company' 
              ? (lang === 'en' ? `Signed for and on behalf of LANDLORD:<br><span style="text-transform:uppercase;">${escapeHtml(data.landlordName || '')}</span>` : `Ditandatangani bagi pihak TUAN RUMAH:<br><span style="text-transform:uppercase;">${escapeHtml(data.landlordName || '')}</span>`) 
              : i18n.signedByLandlord}</strong>
            <div style="height:60px; border-bottom:1px solid #0f172a; margin-top:16px;"></div>
          </div>
          <div style="font-size:9.5pt; line-height:1.4; margin-top:8px;">
            ${(data.landlordType === 'company' && data.landlordContactName) ? `
              ${lang === 'en' ? 'Authorized Signatory:' : 'Nama Wakil / Pengarah:'} <strong>${escapeHtml(data.landlordContactName)}</strong><br>
              ${i18n.icLabel} <strong>${escapeHtml(data.landlordContactIc || '_______________________')}</strong><br>
              ${lang === 'en' ? 'Designation:' : 'Jawatan:'} <strong>${escapeHtml(data.landlordContactDesignation || 'Pengarah / Wakil')}</strong><br>
              ${i18n.dateLabel} ${formattedDate}
            ` : data.landlordType === 'company' ? `
              ${lang === 'en' ? 'Authorized Signatory:' : 'Nama Wakil / Pengarah:'} _______________________<br>
              ${i18n.icLabel} _______________________<br>
              ${lang === 'en' ? 'Designation:' : 'Jawatan:'} _______________________<br>
              ${i18n.dateLabel} ${formattedDate}
            ` : `
              ${i18n.nameLabel} <strong>${escapeHtml(data.landlordName || '')}</strong><br>
              ${i18n.icLabel} ${escapeHtml(data.landlordIc || '-')}<br>
              ${i18n.dateLabel} ${formattedDate}
            `}
          </div>
        </div>

        <!-- Tenant Column -->
        <div class="agr-sig-card">
          <div>
            <strong>${(data.tenantType === 'company' || data.tenantContactName)
              ? (lang === 'en' ? `Signed for and on behalf of TENANT:<br><span style="text-transform:uppercase;">${escapeHtml(data.tenantName || '')}</span>` : `Ditandatangani bagi & bagi pihak PENYEWA:<br><span style="text-transform:uppercase;">${escapeHtml(data.tenantName || '')}</span>`) 
              : i18n.signedByTenant}</strong>
            <div style="height:60px; border-bottom:1px solid #0f172a; margin-top:16px;"></div>
          </div>
          <div style="font-size:9.5pt; line-height:1.4; margin-top:8px;">
            ${(data.tenantType === 'company' || data.tenantContactName) ? `
              ${lang === 'en' ? 'Authorized Representative / Signatory:' : 'Nama Wakil Diberikuasa / Penandatangan:'} <strong>${escapeHtml(data.tenantContactName || '_______________________')}</strong><br>
              ${i18n.icLabel} <strong>${escapeHtml(data.tenantContactIc || '_______________________')}</strong><br>
              ${lang === 'en' ? 'Designation / Capacity:' : 'Jawatan / Kapasiti:'} <strong>${escapeHtml(data.tenantContactDesignation || (data.tenantType === 'company' ? 'Wakil Diberikuasa' : 'Penyewa / Wakil'))}</strong><br>
              ${i18n.dateLabel} ${formattedDate}
            ` : `
              ${i18n.nameLabel} <strong>${escapeHtml(data.tenantName || '')}</strong><br>
              ${i18n.icLabel} ${escapeHtml(data.tenantIc || '-')}<br>
              ${i18n.dateLabel} ${formattedDate}
            `}
          </div>
        </div>
      </div>

      <!-- Witnesses Grid -->
      <div class="agr-sig-grid" style="margin-top:12px;">
        <!-- Landlord Witness -->
        <div class="agr-sig-card">
          <div>
            <strong>${i18n.witnessedBy} (${lang === 'en' ? 'For Landlord' : 'Bagi Tuan Rumah'})</strong>
            <div style="height:50px; border-bottom:1px solid #0f172a; margin-top:16px;"></div>
          </div>
          <div style="font-size:10pt; line-height:1.4; margin-top:8px;">
            ${i18n.nameLabel} ${escapeHtml(data.landlordWitnessName || '________________________')}<br>
            ${i18n.icLabel} ${escapeHtml(data.landlordWitnessIc || '________________________')}<br>
            ${i18n.dateLabel} ${formattedDate}
          </div>
        </div>

        <!-- Tenant Witness -->
        <div class="agr-sig-card">
          <div>
            <strong>${i18n.witnessedBy} (${lang === 'en' ? 'For Tenant' : 'Bagi Penyewa'})</strong>
            <div style="height:50px; border-bottom:1px solid #0f172a; margin-top:16px;"></div>
          </div>
          <div style="font-size:10pt; line-height:1.4; margin-top:8px;">
            ${i18n.nameLabel} ${escapeHtml(data.tenantWitnessName || '________________________')}<br>
            ${i18n.icLabel} ${escapeHtml(data.tenantWitnessIc || '________________________')}<br>
            ${i18n.dateLabel} ${formattedDate}
          </div>
        </div>
      </div>

      <!-- Stamp Duty Box -->
      <div class="agr-stamp-panel">
        <strong>${i18n.stampDutyNote}</strong><br>
        <span style="font-size:9pt; color:#334155;">${i18n.stampDutyDesc}</span>
      </div>
    </div>
  `;
}

/**
 * Generate agreement PDF blob using html2pdf.js with multi-page handling
 */
function generateAgreementPdfBlob(onSuccess, onError) {
  const element = document.getElementById('printableAgreementSheet');
  if (!element) {
    if (onError) onError(new Error('element_not_found'));
    return;
  }

  // Ensure document preview is fully rendered
  renderAgreementPreview();

  const formData = getAgreementFormData();
  const tenantClean = (formData.tenantName || 'Penyewa').replace(/[^a-zA-Z0-9]/g, '_');
  const isBM = appState.activeAgreementLang === 'bm';
  const fileName = isBM ? `Surat_Perjanjian_Sewaan_${tenantClean}.pdf` : `Tenancy_Agreement_${tenantClean}.pdf`;

  if (typeof window.html2pdf === 'function') {
    const modalBody = document.querySelector('#agreementGeneratorModal .modal-body') || document.querySelector('.modal-body');
    const savedModalScroll = modalBody ? modalBody.scrollTop : 0;
    const savedWinScrollY = window.scrollY || window.pageYOffset || 0;
    const savedWinScrollX = window.scrollX || window.pageXOffset || 0;

    if (modalBody) modalBody.scrollTop = 0;
    window.scrollTo(0, 0);

    element.classList.add('agr-rendering-mode');

    const opt = {
      margin: [10, 10, 10, 10], // top, left, bottom, right margins in mm
      filename: fileName,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        logging: false,
        scrollY: 0,
        scrollX: 0,
        backgroundColor: '#ffffff'
      },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak: { mode: 'css' }
    };

    let resolved = false;
    const restore = () => {
      element.classList.remove('agr-rendering-mode');
      if (modalBody) modalBody.scrollTop = savedModalScroll;
      window.scrollTo(savedWinScrollX, savedWinScrollY);
    };

    const timer = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        restore();
        console.warn('html2pdf agreement generation timeout (15s fallback)');
        if (onError) onError(new Error('timeout'));
      }
    }, 15000);

    window.html2pdf().set(opt).from(element).toPdf().get('pdf').then(pdf => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        restore();
        try {
          const blob = pdf.output('blob');
          if (onSuccess) onSuccess(blob, fileName);
        } catch (blobErr) {
          console.warn('pdf.output blob error, falling back to output blob promise:', blobErr);
          window.html2pdf().set(opt).from(element).output('blob').then(altBlob => {
            if (onSuccess) onSuccess(altBlob, fileName);
          }).catch(altErr => {
            if (onError) onError(altErr);
          });
        }
      }
    }).catch(err => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        restore();
        console.warn('html2pdf agreement error:', err);
        if (onError) onError(err);
      }
    });
  } else {
    if (onError) onError(new Error('html2pdf_not_loaded'));
  }
}

/**
 * Direct file download as standard multi-page A4 PDF to Downloads folder
 */
let activeAgreementBlobUrl = null;

function downloadAgreementPdf(callback) {
  const isBM = appState.activeAgreementLang === 'bm';
  const statusCard = document.getElementById('agrActionStatusCard');
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  if (statusCard) {
    statusCard.style.display = 'block';
    statusCard.innerHTML = `
      <div style="background:#eff6ff; border:1.5px solid #0284c7; border-radius:12px; padding:16px; display:flex; align-items:center; gap:12px; box-shadow:0 4px 12px rgba(2,132,199,0.12);">
        <div class="loading-spinner" style="width:26px; height:26px; border-width:3px; border-color:#0284c7; border-top-color:transparent; flex-shrink:0;"></div>
        <div>
          <strong style="color:#0369a1; font-size:13.5px; display:block;">${isBM ? 'Sedang Menjana Fail PDF Surat Perjanjian A4...' : 'Generating Official A4 Tenancy Agreement PDF...'}</strong>
          <span style="font-size:11.5px; color:#0284c7;">${isBM ? 'Format surat perjanjian, klausa mesra Muslim & jadual inventori sedang diproses untuk muat turun terus ke folder Downloads.' : 'Processing formal covenants, Muslim-friendly conditions & inventory schedule for direct download.'}</span>
        </div>
      </div>
    `;
    statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  showToast(isBM ? 'Menjana fail PDF Perjanjian Sewa...' : 'Generating Tenancy Agreement PDF...');

  generateAgreementPdfBlob((blob, fileName) => {
    try {
      if (activeAgreementBlobUrl) {
        try { URL.revokeObjectURL(activeAgreementBlobUrl); } catch (e) {}
      }
      activeAgreementBlobUrl = URL.createObjectURL(blob);
      const blobUrl = activeAgreementBlobUrl;

      // 1. Direct Anchor Download (Guaranteed download to user's Downloads folder)
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        document.body.removeChild(a);
      }, 1500);

      // 2. Render the rich, clear status card just like quotation, receipt and invoice
      if (statusCard) {
        statusCard.style.display = 'block';
        statusCard.innerHTML = `
          <div style="background:#ecfdf5; border:2px solid #10b981; border-radius:12px; padding:18px; box-shadow:0 6px 16px rgba(16,185,129,0.12);">
            <div style="display:flex; align-items:flex-start; gap:14px; margin-bottom:14px;">
              <div style="width:44px; height:44px; border-radius:50%; background:#10b981; color:#fff; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0; box-shadow:0 3px 8px rgba(16,185,129,0.35);">
                <i class="fa-solid fa-circle-check"></i>
              </div>
              <div style="flex:1;">
                <h4 style="margin:0; color:#065f46; font-size:15px; font-weight:800;">
                  ${isBM ? '✅ Surat Perjanjian Berjaya Dijana & Dimuat Turun!' : '✅ Tenancy Agreement Generated & Downloaded!'}
                </h4>
                <p style="margin:4px 0 0 0; font-size:12px; color:#047857; line-height:1.5;">
                  ${isBM 
                    ? `Fail telah disimpan terus ke folder <strong>Downloads</strong> komputer / telefon anda sebagai:<br><strong style="font-family:monospace; color:#0f172a; background:#e2e8f0; padding:2px 6px; border-radius:4px;">${fileName}</strong>`
                    : `File saved directly into your <strong>Downloads</strong> folder as:<br><strong style="font-family:monospace; color:#0f172a; background:#e2e8f0; padding:2px 6px; border-radius:4px;">${fileName}</strong>`}
                </p>
                ${!isMobile ? `
                  <div style="margin-top:6px; font-size:11px; color:#64748b;">
                    ${isBM ? '💡 Tip: Tekan <kbd style="background:#f1f5f9; border:1px solid #cbd5e1; padding:1px 5px; border-radius:3px;">Ctrl</kbd> + <kbd style="background:#f1f5f9; border:1px solid #cbd5e1; padding:1px 5px; border-radius:3px;">J</kbd> (Windows) atau semak ikon muat turun pelayar untuk membuka fail terus dari folder Downloads.' : '💡 Tip: Press Ctrl + J to see downloaded files in Downloads folder.'}
                  </div>
                ` : `
                  <div style="margin-top:8px; font-size:11.5px; color:#14532d; background:#dcfce7; border:1px solid #86efac; border-radius:8px; padding:8px 12px; line-height:1.5;">
                    📱 <strong>Pengguna Telefon:</strong> Fail PDF telah disimpan ke folder <strong>Downloads</strong> peranti anda. Anda kini boleh melampirkannya ke WhatsApp atau Emel dengan mudah.
                  </div>
                `}
              </div>
            </div>

            <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
              <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:linear-gradient(135deg, #0284c7, #0369a1);">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? '👁️ Buka & Lihat PDF Sekarang' : '👁️ View PDF Now'}
              </a>
              <a href="${blobUrl}" download="${fileName}" class="btn btn-outline btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; color:#065f46; border-color:#059669; background:#fff;">
                <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun Semula' : 'Download Again'}
              </a>
              <button type="button" class="btn btn-whatsapp btn-sm" id="btnStatusCardAgrWa" style="font-weight:800; display:inline-flex; align-items:center; gap:6px;">
                <i class="fa-brands fa-whatsapp"></i> ${isBM ? '📲 Hantar ke WhatsApp Tetamu' : 'Send via WhatsApp'}
              </button>
              <button type="button" class="btn btn-outline btn-sm" id="btnStatusCardAgrEmail" style="font-weight:700; display:inline-flex; align-items:center; gap:6px; color:#1e293b; background:#fff;">
                <i class="fa-solid fa-envelope"></i> ${isBM ? '✉️ Emel Penyewa' : 'Email Tenant'}
              </button>
              <button type="button" class="btn btn-outline btn-sm" id="btnDismissAgrStatus" style="font-size:11px; background:#fff; color:#64748b; margin-left:auto;">
                ${isBM ? 'Tutup' : 'Dismiss'}
              </button>
            </div>
          </div>
        `;

        document.getElementById('btnStatusCardAgrWa')?.addEventListener('click', () => shareAgreementWhatsApp(blob, fileName));
        document.getElementById('btnStatusCardAgrEmail')?.addEventListener('click', () => sendAgreementEmail(fileName));
        document.getElementById('btnDismissAgrStatus')?.addEventListener('click', () => {
          statusCard.style.display = 'none';
        });
        statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }

      showToast(isBM ? `Fail PDF (${fileName}) berjaya dimuat turun ke folder Downloads!` : `Tenancy Agreement PDF (${fileName}) downloaded!`);
      if (typeof callback === 'function') callback(blob, fileName);
    } catch (e) {
      console.error('Download error in callback:', e);
    }
  }, err => {
    console.warn('PDF generation fallback to window.print:', err);
    if (statusCard) {
      statusCard.innerHTML = `
        <div style="background:#fffbeb; border:1.5px solid #f59e0b; border-radius:10px; padding:12px; display:flex; align-items:center; justify-content:space-between; gap:10px;">
          <div style="display:flex; align-items:center; gap:8px;">
            <i class="fa-solid fa-triangle-exclamation" style="color:#d97706; font-size:16px;"></i>
            <span style="font-size:11.5px; color:#92400e;">${isBM ? 'Membuka dialog cetakan pelayar...' : 'Opening browser print dialog...'}</span>
          </div>
        </div>
      `;
    }
    setTimeout(() => {
      window.print();
    }, 400);
  });
}

/**
 * Print agreement document directly using browser native print
 */
function printAgreementDocument() {
  renderAgreementPreview();
  setTimeout(() => {
    window.print();
  }, 100);
}

/**
 * Share agreement summary & confirmation via WhatsApp with PDF Download to Downloads folder
 */
function shareAgreementWhatsApp(existingBlob = null, existingFileName = null) {
  const formData = getAgreementFormData();
  const isTenantComp = formData.tenantType === 'company';
  const targetPhone = (isTenantComp && formData.tenantContactPhone) 
    ? formData.tenantContactPhone 
    : (formData.tenantPhone || '');
  const phone = targetPhone.replace(/[^0-9+]/g, '');
  const isBM = appState.activeAgreementLang === 'bm';
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  const statusCard = document.getElementById('agrActionStatusCard');

  const tenantGreeting = isTenantComp && formData.tenantContactName
    ? `${formData.tenantContactName} (${formData.tenantName})`
    : (formData.tenantName || 'Penyewa');

  let msg = '';
  if (isBM) {
    msg = `Salam sejahtera ${tenantGreeting},\n\n` +
      `Dilampirkan dokumen rasmi *Surat Perjanjian Penyewaan Kediaman* bagi premis *${formData.propertyName}*:\n\n` +
      (isTenantComp ? `🏢 *Penyewa (Syarikat):* ${formData.tenantName} (SSM: ${formData.tenantIc || '-'})\n👤 *Pegawai Dihubungi:* ${formData.tenantContactName || '-'} (${formData.tenantContactDesignation || 'Wakil Syarikat'})\n` : '') +
      `📅 *Tempoh Sewaan:* ${formData.startDate} hingga ${formData.endDate} (${formData.durationMonths} Bulan)\n` +
      `💰 *Kadar Sewa:* RM ${Number(formData.monthlyRent || 0).toFixed(2)} / bulan (Genap masa: ${formData.rentalDueDay})\n` +
      `🛡️ *Cagaran Sewa:* RM ${Number(formData.rentalDeposit || 0).toFixed(2)}\n` +
      `💡 *Cagaran Utiliti:* RM ${Number(formData.utilitiesDeposit || 0).toFixed(2)}\n` +
      `🕌 *Syarat Khas Kediaman:* Mematuhi syarat rumah mesra Muslim (Makanan halal, larangan mutlak arak/alkohol, larangan haiwan terlarang & pemeliharaan syarak).\n\n` +
      `📄 *Sila rujuk fail PDF rasmi yang dilampirkan bersama ini.* Terima kasih!\n_${formData.landlordName}_`;
  } else {
    msg = `Greetings ${tenantGreeting},\n\n` +
      `Attached is the official *Residential Tenancy Agreement* for *${formData.propertyName}*:\n\n` +
      (isTenantComp ? `🏢 *Tenant (Company):* ${formData.tenantName} (Reg No: ${formData.tenantIc || '-'})\n👤 *Contact Person:* ${formData.tenantContactName || '-'} (${formData.tenantContactDesignation || 'Representative'})\n` : '') +
      `📅 *Tenancy Term:* ${formData.startDate} to ${formData.endDate} (${formData.durationMonths} Months)\n` +
      `💰 *Monthly Rent:* RM ${Number(formData.monthlyRent || 0).toFixed(2)} / month (Due: ${formData.rentalDueDay})\n` +
      `🛡️ *Rental Deposit:* RM ${Number(formData.rentalDeposit || 0).toFixed(2)}\n` +
      `💡 *Utilities Deposit:* RM ${Number(formData.utilitiesDeposit || 0).toFixed(2)}\n` +
      `🕌 *Special Covenants:* Compliance with Muslim-friendly house requirements (Halal food only, strictly no alcohol, no dogs & Islamic decorum).\n\n` +
      `📄 *Please refer to the attached official PDF document.* Thank you!\n_${formData.landlordName}_`;
  }

  // Copy text to clipboard
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(msg);
  }

  const cleanPhone = normalizePhoneNumber(phone);
  const waUrl = cleanPhone 
    ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`
    : `https://wa.me/?text=${encodeURIComponent(msg)}`;

  let waWindow = null;
  if (!isMobile) {
    try {
      waWindow = window.open('about:blank', '_blank');
      if (waWindow) {
        waWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head><title>Menghubungkan ke WhatsApp...</title></head>
          <body style="font-family:system-ui,sans-serif; text-align:center; padding:50px; background:#f8fafc; color:#0f172a;">
            <div style="max-width:480px; margin:0 auto; background:#fff; padding:30px; border-radius:16px; box-shadow:0 4px 20px rgba(0,0,0,0.08); border:1px solid #e2e8f0;">
              <div style="font-size:36px; margin-bottom:12px;">📲</div>
              <h2 style="color:#15803d; margin:0 0 8px 0; font-size:20px;">Menghubungkan ke WhatsApp Penyewa...</h2>
              <p style="color:#64748b; font-size:13px; line-height:1.5; margin:0 0 16px 0;">Fail PDF Surat Perjanjian sedang dimuat turun ke folder Downloads anda.</p>
              <div style="display:inline-block; border:3px solid #e2e8f0; border-top-color:#15803d; border-radius:50%; width:24px; height:24px; animation:spin 0.8s linear infinite;"></div>
              <style>@keyframes spin { to { transform: rotate(360deg); } }</style>
            </div>
          </body>
          </html>
        `);
      }
    } catch(e) {
      console.warn('Could not pre-open window:', e);
    }
  }

  const handlePdfReady = async (pdfBlob, fName) => {
    const pdfFile = new File([pdfBlob], fName, { type: 'application/pdf' });
    const blobUrl = URL.createObjectURL(pdfBlob);

    // 1. Mobile Web Share Level 2 (Direct WhatsApp file attachment)
    if (isMobile && navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
      try {
        if (waWindow) waWindow.close();
        await navigator.share({
          title: `Surat Perjanjian Sewaan (${formData.tenantName})`,
          text: msg,
          files: [pdfFile]
        });
        showToast(isBM ? '✅ Berjaya dikongsi ke WhatsApp!' : '✅ Shared to WhatsApp successfully!');
        if (statusCard) statusCard.style.display = 'none';
        return;
      } catch (shareErr) {
        if (shareErr.name === 'AbortError') return;
        console.warn('navigator.share failed, fallback to download + open WhatsApp:', shareErr);
      }
    }

    // 2. Download directly to Downloads folder
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = fName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); }, 1500);

    if (waWindow && !waWindow.closed) {
      waWindow.location.href = waUrl;
    }

    // Step-by-Step Card
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#f0fdf4; border:2px solid #22c55e; border-radius:12px; padding:18px; box-shadow:0 6px 18px rgba(34,197,94,0.15);">
          <div style="display:flex; align-items:flex-start; gap:14px; margin-bottom:14px;">
            <div style="width:46px; height:46px; border-radius:50%; background:#22c55e; color:#fff; display:flex; align-items:center; justify-content:center; font-size:24px; flex-shrink:0; box-shadow:0 3px 10px rgba(34,197,94,0.4);">
              <i class="fa-brands fa-whatsapp"></i>
            </div>
            <div style="flex:1;">
              <h4 style="margin:0; color:#14532d; font-size:15px; font-weight:800;">
                ${isBM ? '✅ Fail PDF Dimuat Turun & WhatsApp Sedia Dihantar!' : '✅ PDF Downloaded & WhatsApp Ready!'}
              </h4>
              <p style="margin:4px 0 8px 0; font-size:12px; color:#166534; line-height:1.5;">
                ${isBM 
                  ? `Fail rasmi <strong>${fName}</strong> telah dimuat turun terus ke folder <strong>Downloads</strong> anda.` 
                  : `Official file <strong>${fName}</strong> has been saved directly into your <strong>Downloads</strong> folder.`}
              </p>
              <div style="background:#dcfce7; border:1px solid #86efac; border-radius:8px; padding:10px 12px; font-size:12px; color:#14532d; line-height:1.6;">
                <strong>${isBM ? '👉 2 Langkah Mudah Untuk Menghantar di WhatsApp:' : '👉 2 Easy Steps to Send on WhatsApp:'}</strong><br>
                1. ${isBM ? 'Tetingkap WhatsApp telah dibuka (atau klik butang hijau di bawah).' : 'WhatsApp window is opened (or click green button below).'}<br>
                2. ${isBM ? `Di WhatsApp penyewa, klik ikon <strong>Lampiran (📎 atau +) > Dokumen</strong> dan pilih fail <strong style="font-family:monospace;">${fName}</strong> dari folder Downloads.` : `In WhatsApp chat, click <strong>Attachment (📎 or +) > Document</strong> and select the downloaded PDF.`}
              </div>
            </div>
          </div>

          <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
            <a href="${waUrl}" target="_blank" class="btn btn-whatsapp btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:8px; padding:8px 16px; font-size:13px;">
              <i class="fa-brands fa-whatsapp"></i> ${isBM ? '📲 Buka WhatsApp Sekarang (Pautan Langsung)' : '📲 Open WhatsApp Now'}
            </a>
            <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px;">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? '👁️ Lihat Fail PDF' : '👁️ View PDF'}
            </a>
            <a href="${blobUrl}" download="${fName}" class="btn btn-outline btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:#fff; color:#065f46; border-color:#059669;">
              <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun Semula' : 'Download Again'}
            </a>
            <button type="button" class="btn btn-outline btn-sm" id="btnDismissAgrWaStatus" style="font-size:11px; background:#fff; color:#64748b; margin-left:auto;">
              ${isBM ? 'Tutup' : 'Dismiss'}
            </button>
          </div>
        </div>
      `;
      document.getElementById('btnDismissAgrWaStatus')?.addEventListener('click', () => {
        statusCard.style.display = 'none';
      });
      statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    showToast(isBM ? `Fail PDF (${fName}) dimuat turun ke Downloads!` : `PDF (${fName}) downloaded!`);
  };

  if (existingBlob && existingFileName) {
    handlePdfReady(existingBlob, existingFileName);
  } else {
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#eff6ff; border:1.5px solid #0284c7; border-radius:12px; padding:16px; display:flex; align-items:center; gap:12px; box-shadow:0 4px 12px rgba(2,132,199,0.12);">
          <div class="loading-spinner" style="width:26px; height:26px; border-width:3px; border-color:#0284c7; border-top-color:transparent; flex-shrink:0;"></div>
          <div>
            <strong style="color:#0369a1; font-size:13.5px; display:block;">${isBM ? 'Menjana Fail PDF Perjanjian & Menghubungkan ke WhatsApp...' : 'Generating Agreement PDF & Connecting to WhatsApp...'}</strong>
            <span style="font-size:11.5px; color:#0284c7;">${isBM ? 'Sila tunggu sebentar, fail sedang dimuat turun ke folder Downloads...' : 'Please wait a moment...'}</span>
          </div>
        </div>
      `;
      statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    showToast(isBM ? 'Menjana fail PDF dan menghubungkan ke WhatsApp...' : 'Generating PDF & connecting to WhatsApp...');
    generateAgreementPdfBlob(handlePdfReady, (err) => {
      console.error('Error generating PDF for WhatsApp:', err);
      if (waWindow && !waWindow.closed) {
        waWindow.location.href = waUrl;
      } else {
        window.open(waUrl, '_blank');
      }
    });
  }
}

/**
 * Send agreement document via Email client with attachment guidance
 */
function sendAgreementEmail(fileName = null) {
  const formData = getAgreementFormData();
  const email = (formData.tenantEmail || '').trim();
  const isBM = appState.activeAgreementLang === 'bm';
  const isTenantComp = formData.tenantType === 'company';
  const tenantClean = (formData.tenantName || 'Penyewa').replace(/[^a-zA-Z0-9]/g, '_');
  const actualFileName = fileName || (isBM ? `Surat_Perjanjian_Sewaan_${tenantClean}.pdf` : `Tenancy_Agreement_${tenantClean}.pdf`);

  const tenantGreeting = isTenantComp && formData.tenantContactName
    ? `${formData.tenantContactName} (${formData.tenantName})`
    : (formData.tenantName || 'Penyewa');

  const subject = isBM 
    ? `Surat Perjanjian Sewaan Kediaman - ${formData.propertyName} (${formData.tenantName})`
    : `Residential Tenancy Agreement - ${formData.propertyName} (${formData.tenantName})`;

  let body = '';
  if (isBM) {
    body = `Salam sejahtera ${tenantGreeting},\n\n` +
      `Bersama-sama ini dilampirkan dokumen rasmi Surat Perjanjian Penyewaan Kediaman bagi premis ${formData.propertyName} untuk semakan, pengesahan dan simpanan pihak anda.\n\n` +
      (isTenantComp ? `• Nama Syarikat Penyewa: ${formData.tenantName} (No. SSM: ${formData.tenantIc || '-'})\n• Pegawai Dihubungi: ${formData.tenantContactName || '-'} (${formData.tenantContactDesignation || 'Wakil Syarikat'})\n` : '') +
      `• Butiran Premis: ${formData.propertyName}\n` +
      `• Tempoh Sewaan: ${formData.startDate} hingga ${formData.endDate} (${formData.durationMonths} Bulan)\n` +
      `• Sewa Bulanan: RM ${Number(formData.monthlyRent || 0).toFixed(2)} (Genap masa: ${formData.rentalDueDay})\n` +
      `• Cagaran Sewa: RM ${Number(formData.rentalDeposit || 0).toFixed(2)}\n` +
      `• Cagaran Utiliti: RM ${Number(formData.utilitiesDeposit || 0).toFixed(2)}\n` +
      `• Syarat Kediaman: Mematuhi syarat rumah mesra Muslim (makanan halal, larangan mutlak arak/alkohol, larangan haiwan terlarang & adab ketenteraman).\n\n` +
      `Sila rujuk fail PDF yang dilampirkan ("${actualFileName}"). Sila cetak atau turun tandatangan dan kembalikan salinan bertandatangan kepada pihak kami.\n\n` +
      `Sekian, terima kasih.\n${formData.landlordName}\n${formData.landlordPhone}`;
  } else {
    body = `Dear ${tenantGreeting},\n\n` +
      `Attached is the official Residential Tenancy Agreement for ${formData.propertyName} for your review, execution, and records.\n\n` +
      (isTenantComp ? `• Tenant (Company): ${formData.tenantName} (Company Reg No: ${formData.tenantIc || '-'})\n• Contact Person: ${formData.tenantContactName || '-'} (${formData.tenantContactDesignation || 'Representative'})\n` : '') +
      `• Demised Premises: ${formData.propertyName}\n` +
      `• Term: ${formData.startDate} to ${formData.endDate} (${formData.durationMonths} Months)\n` +
      `• Monthly Rent: RM ${Number(formData.monthlyRent || 0).toFixed(2)} (Due Date: ${formData.rentalDueDay})\n` +
      `• Security Deposit: RM ${Number(formData.rentalDeposit || 0).toFixed(2)}\n` +
      `• Utilities Deposit: RM ${Number(formData.utilitiesDeposit || 0).toFixed(2)}\n` +
      `• House Condition: Compliance with Muslim-friendly covenants.\n\n` +
      `Please find attached the official PDF agreement file ("${actualFileName}"). Kindly review, sign and return a copy to us.\n\n` +
      `Kind regards,\n${formData.landlordName}\n${formData.landlordPhone}`;
  }

  const mailtoUrl = `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  window.open(mailtoUrl, '_blank');

  showToast(isBM ? 'Membuka aplikasi emel... Sila lampirkan fail PDF dari folder Downloads anda.' : 'Opening email client... Please attach the PDF file from your Downloads folder.', 6000);
}

window.downloadAgreementPdf = downloadAgreementPdf;
window.shareAgreementWhatsApp = shareAgreementWhatsApp;
window.sendAgreementEmail = sendAgreementEmail;

/**
 * Save agreement draft into the booking record
 */
function saveAgreementDraft() {
  const formData = getAgreementFormData();
  const bookingId = document.getElementById('agrBookingSelect')?.value;
  const booking = appState.bookings.find(b => b.id === bookingId);
  const isBM = appState.settings.language === 'bm';

  if (booking) {
    booking.tenancyAgreement = {
      ...formData,
      savedAt: new Date().toISOString()
    };
    if (formData.tenantContactName) booking.contactPerson = formData.tenantContactName;
    if (formData.tenantContactDesignation) booking.contactDesignation = formData.tenantContactDesignation;
    if (formData.tenantContactIc) booking.contactIc = formData.tenantContactIc;
    if (formData.tenantContactPhone) booking.contactPhone = formData.tenantContactPhone;
    if (formData.tenantType === 'company' && formData.tenantIc) booking.companyRegNo = formData.tenantIc;

    saveToStorage();
    showToast(isBM ? 'Deraf Perjanjian Sewaan berjaya disimpan ke rekod penyewa!' : 'Tenancy Agreement draft saved successfully to tenant booking record!');
  } else {
    showToast(isBM ? 'Borang perjanjian dikemas kini.' : 'Agreement form updated.');
  }
}

// Global Window Exports for Tenancy Agreement Engine
window.openAgreementModal = openAgreementModal;
window.closeAllModals = closeAllModals;
window.switchAgreementTab = switchAgreementTab;
window.renderAgreementPreview = renderAgreementPreview;
window.setAgreementLandlordType = setAgreementLandlordType;
window.setAgreementTenantType = setAgreementTenantType;
window.setAgreementLanguage = setAgreementLanguage;
window.repopulateAgreementForm = repopulateAgreementForm;
window.addCustomInventoryRow = addCustomInventoryRow;
window.saveAgreementDraft = saveAgreementDraft;
window.printAgreementDocument = printAgreementDocument;
window.sendAgreementEmail = sendAgreementEmail;
window.shareAgreementWhatsApp = shareAgreementWhatsApp;
window.downloadAgreementPdf = downloadAgreementPdf;

// License Engine Exports
window.normalizeLicensePhone = normalizeLicensePhone;
window.formatDisplayLicensePhone = formatDisplayLicensePhone;
window.extractLicenseKey = extractLicenseKey;
window.cleanLicenseKey = cleanLicenseKey;
window.formatLicenseKeyPreview = formatLicenseKeyPreview;
window.updateLicensePhonePreview = updateLicensePhonePreview;
window.updateLicenseKeyPreview = updateLicenseKeyPreview;
window.handlePasteLicenseKey = handlePasteLicenseKey;
window.handleActivateLicenseSubmit = handleActivateLicenseSubmit;
window.getSupportDiagnosticsData = getSupportDiagnosticsData;
window.formatDiagnosticsForWhatsApp = formatDiagnosticsForWhatsApp;
window.handleContactSellerWhatsApp = handleContactSellerWhatsApp;
window.openProSystemModal = openProSystemModal;

// Monthly Invoicing Engine Exports
window.openMonthlyInvoicesModal = openMonthlyInvoicesModal;
window.renderMonthlyInvoicesList = renderMonthlyInvoicesList;
window.toggleMonthlyInvoicePaid = toggleMonthlyInvoicePaid;
window.getOrInitMonthlyInvoices = getOrInitMonthlyInvoices;
window.openWhatsAppModal = openWhatsAppModal;
window.openPdfDocModal = openPdfDocModal;
window.generateWhatsAppMessage = generateWhatsAppMessage;

if (typeof window !== 'undefined') {
  window.parseReceiptText = parseReceiptText;
  window.extractTextFromImage = extractTextFromImage;
  window.openUniversalOcrModal = openUniversalOcrModal;
  window.scanPaymentProofSlipOcr = scanPaymentProofSlipOcr;
  window.scanExpenseSlipOcr = scanExpenseSlipOcr;
  window.openExpenseModal = openExpenseModal;
  window.parseTenantChat = parseTenantChat;
  window.extractTenantChat = extractTenantChat;
  window.openTenantChatImportModal = openTenantChatImportModal;
  window.closeTenantChatImportModal = closeTenantChatImportModal;
  window.setTenantChatBookingType = setTenantChatBookingType;
  window.normalizeIdNumber = normalizeIdNumber;
  window.getGuestStayStats = getGuestStayStats;
  window.syncTenantLifecycleStatus = syncTenantLifecycleStatus;
  window.checkBookingRepeatGuest = checkBookingRepeatGuest;
  window.applyRepeatGuestDetails = applyRepeatGuestDetails;
  window.renderSettingsContactList = renderSettingsContactList;
  window.renderDashboardTab = renderDashboardTab;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    normalizePhoneNumber,
    normalizeIdNumber,
    normalizeLicensePhone,
    formatDisplayLicensePhone,
    extractLicenseKey,
    cleanLicenseKey,
    formatLicenseKeyPreview,
    verifyLicenseToken,
    evaluateLicenseState,
    getLicenseErrorMessage,
    handleActivateLicenseSubmit,
    getSupportDiagnosticsData,
    formatDiagnosticsForWhatsApp,
    handleContactSellerWhatsApp,
    openProSystemModal,
    openMonthlyInvoicesModal,
    renderMonthlyInvoicesList,
    toggleMonthlyInvoicePaid,
    getOrInitMonthlyInvoices,
    openWhatsAppModal,
    openPdfDocModal,
    generateWhatsAppMessage,
    parseReceiptText,
    extractTextFromImage,
    openUniversalOcrModal,
    scanPaymentProofSlipOcr,
    scanExpenseSlipOcr,
    openExpenseModal,
    parseTenantChat,
    extractTenantChat,
    openTenantChatImportModal,
    closeTenantChatImportModal,
    setTenantChatBookingType,
    getGuestStayStats,
    syncTenantLifecycleStatus,
    checkBookingRepeatGuest,
    applyRepeatGuestDetails,
    renderSettingsContactList,
    renderDashboardTab,
    openBookingModal,
    openContactModal,
    setTestLicensePublicKey: function (jwk) {
      testOverridePublicKeyJwk = jwk;
      cachedCryptoPublicKey = null;
    },
    appState,
    activateWithServer,
    getCryptoPublicKey,
    STORAGE_KEYS,
    APP_VERSION
  };
}

// Start application
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }
}

