/**
 * HOMESTAY MANAGER - MOBILE-FIRST PWA ENGINE
 * Full-featured property, booking, turnover, and revenue management system.
 */

// ==========================================================================
// 1. STATE & LOCALSTORAGE DATA MODEL
// ==========================================================================

const APP_VERSION = '2.7.5';

const STORAGE_KEYS = {
  PROPERTIES: 'staymanager_properties_v2',
  BOOKINGS: 'staymanager_bookings_v2',
  TURNOVERS: 'staymanager_turnovers_v2',
  EXPENSES: 'staymanager_expenses_v2',
  CONTACTS: 'staymanager_contacts_v2',
  PROMO_MEDIA: 'staymanager_promo_media_v2',
  SETTINGS: 'staymanager_settings_v2',
  LICENSE: 'staymanager_license_v2',
  VERSION: 'staymanager_app_version'
};

const DEFAULT_CONTACTS = [
  {
    id: 'c-1',
    name: 'Kak Siti',
    category: 'cleaner',
    phone: '+60129998877',
    company: 'Siti Clean Services',
    notes: 'Turnover cleaning RM70/unit. Available Mon-Sat.'
  },
  {
    id: 'c-2',
    name: 'Ah Keong',
    category: 'aircond',
    phone: '+60128887766',
    company: 'Keong Cool Aircond',
    notes: 'Aircond chemical wash (RM120/unit) & emergency gas refilling.'
  },
  {
    id: 'c-3',
    name: 'Pak Din',
    category: 'plumber',
    phone: '+60127776655',
    company: 'Pak Din Plumbing',
    notes: 'Pipe repairs, toilet clog, water heater troubleshooting.'
  },
  {
    id: 'c-4',
    name: 'Sri Dobi Supply',
    category: 'linen_supplier',
    phone: '+60126665544',
    company: 'Sri Dobi & Linens Sdn Bhd',
    notes: 'Bedsheet sets, duvets, white bath towels wholesale restock.'
  }
];

const DEFAULT_PROMO_MEDIA = [
  {
    id: 'promo-demo-1',
    propertyId: 'prop-1',
    category: 'photo',
    title: 'Sunset Ocean Villa - Panoramic Living & Balcony Seaview',
    caption: '🌊 *Sunset Ocean Villa (Whole Unit - 3 Bedrooms)* 🌅\nLooking for an unforgettable beachside getaway with family or friends?\n\n✨ *Key Highlights:* \n• Accommodates up to 8–10 guests comfortably\n• 3 air-conditioned bedrooms with luxury hotel-grade linens\n• Private balcony with direct panoramic sunset ocean views\n• High-speed 500Mbps WiFi & Smart TV with Netflix\n• Fully equipped dry & wet kitchen (fridge, microwave, induction cooker)\n• Infinity swimming pool, sauna & kids playground access\n\n📍 *Location:* Seaview Residences, Jalan Pantai\n💰 *Rates from:* RM 280 / night\n\n📲 Reply to this message now to check your dates and enjoy our early bird rates!',
    imageData: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="600" height="340" viewBox="0 0 600 340"><defs><linearGradient id="ocean" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#0284c7"/><stop offset="50%" stop-color="#0369a1"/><stop offset="100%" stop-color="#075985"/></linearGradient></defs><rect width="600" height="340" fill="url(#ocean)"/><circle cx="480" cy="100" r="55" fill="#f59e0b" opacity="0.85"/><path d="M0 240 Q150 200 300 240 T600 240 L600 340 L0 340 Z" fill="#0c4a6e" opacity="0.6"/><path d="M0 270 Q150 240 300 270 T600 270 L600 340 L0 340 Z" fill="#082f49"/><text x="40" y="80" fill="#ffffff" font-family="system-ui, sans-serif" font-size="24" font-weight="bold">🌊 Sunset Ocean Villa</text><text x="40" y="115" fill="#bae6fd" font-family="system-ui, sans-serif" font-size="15">Panoramic Living & Balcony Seaview</text><rect x="40" y="150" width="170" height="32" rx="6" fill="#f59e0b"/><text x="52" y="172" fill="#ffffff" font-family="system-ui, sans-serif" font-size="13" font-weight="bold">⭐ Top Rated Beachfront</text></svg>'),
    mediaUrl: 'https://maps.google.com/?q=3.1390,101.6869',
    createdAt: new Date().toISOString()
  },
  {
    id: 'promo-demo-2',
    propertyId: 'prop-2',
    category: 'video_tour',
    title: 'Villa Impian Master Bedroom - Virtual Video Tour',
    caption: '🎥 *Virtual Video Walkthrough: Villa Impian Master Bedroom* 🌿\nTake a quick 1-minute video tour inside our cozy highland sanctuary!\n\n✨ *Room Specs:* \n• King-size bed with premium orthopedic mattress\n• Private en-suite bathroom with instant hot rain shower\n• Quiet environment surrounded by cool mountain mist\n• Access to shared BBQ patio, tea terrace & garden\n\n👇 *Click to Watch the Walkthrough Video:* \nhttps://youtu.be/sample-villa-tour\n\n💬 Send us a message today to lock in your preferred stay dates!',
    imageData: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="600" height="340" viewBox="0 0 600 340"><defs><linearGradient id="vidbg" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#065f46"/><stop offset="100%" stop-color="#047857"/></linearGradient></defs><rect width="600" height="340" fill="url(#vidbg)"/><circle cx="300" cy="170" r="44" fill="#ffffff" opacity="0.92"/><polygon points="292,152 316,170 292,188" fill="#047857"/><text x="40" y="60" fill="#ffffff" font-family="system-ui, sans-serif" font-size="22" font-weight="bold">🎥 Villa Impian Virtual Tour</text><text x="40" y="90" fill="#a7f3d0" font-family="system-ui, sans-serif" font-size="14">Master Bedroom & Highland Garden Walkthrough</text></svg>'),
    mediaUrl: 'https://youtu.be/sample-villa-tour',
    createdAt: new Date().toISOString()
  },
  {
    id: 'promo-demo-3',
    propertyId: 'all',
    category: 'poster',
    title: 'School Holiday Early Bird 15% OFF Promo Flyer',
    caption: '🎉 *SPECIAL SCHOOL HOLIDAY PROMO - 15% OFF!* 🎒✨\nPlanning your next family trip or weekend getaway? Book early and save big!\n\n🎁 *Exclusive Early Bird Package:* \n• Get *15% OFF* for reservations of 2 nights or more\n• Free welcome drinks & late check-out till 1:00 PM (subject to availability)\n• Valid across all our homestay villas & medium rooms\n\n📅 *Booking Window:* Limited to the first 10 confirmed bookings!\n📲 Reply directly with your check-in dates to claim your 15% discount voucher!',
    imageData: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="600" height="340" viewBox="0 0 600 340"><defs><linearGradient id="poster" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#7c3aed"/><stop offset="100%" stop-color="#4f46e5"/></linearGradient></defs><rect width="600" height="340" fill="url(#poster)"/><circle cx="100" cy="80" r="90" fill="#a855f7" opacity="0.3"/><circle cx="520" cy="260" r="110" fill="#6366f1" opacity="0.3"/><text x="50" y="90" fill="#fde047" font-family="system-ui, sans-serif" font-size="16" font-weight="800" letter-spacing="1">LIMITED TIME SPECIAL DEAL</text><text x="50" y="145" fill="#ffffff" font-family="system-ui, sans-serif" font-size="34" font-weight="900">SCHOOL HOLIDAY</text><text x="50" y="195" fill="#38bdf8" font-family="system-ui, sans-serif" font-size="36" font-weight="900">SAVE 15% OFF!</text><text x="50" y="240" fill="#e2e8f0" font-family="system-ui, sans-serif" font-size="14">Book min 2 nights • Free welcome perks • Instant WhatsApp booking</text></svg>'),
    mediaUrl: '',
    createdAt: new Date().toISOString()
  },
  {
    id: 'promo-demo-4',
    propertyId: 'prop-3',
    category: 'copywriting',
    title: 'Affordable Highland Stay for Couples & Remote Workers',
    caption: '🍃 *Cozy Medium Room @ Villa Impian* 🛏️\nAffordable, sparkling clean comfort in the cool highlands!\n\n• Queen bed with plush orthopedic mattress\n• Dedicated work desk with high-speed 5G WiFi (remote-work friendly)\n• Access to spacious living hall & tea-making pantry\n• Only *RM 100 / night* (Cleaning fee RM25)\n\n💬 Send us a message today to book your peaceful retreat!',
    imageData: '',
    mediaUrl: '',
    createdAt: new Date().toISOString()
  }
];


const LICENSE_SECRET_SALT = 'HOMESTAY_PRO_SALT_2026_SECURE_AUTH';

// Secret Master Admin Keys (Master Admin / Unrestricted access)
// Master key validation is performed via cryptographic signatures
function isMasterAdminKey(rawKey) {
  if (!rawKey) return false;
  const k = rawKey.trim().toUpperCase();
  return k === 'STAY-MASTER-ADMIN-2026' || k === 'STAY-VIP-2026-LIFETIME';
}

const DEFAULT_SETTINGS = {
  businessName: 'My Homestay',
  businessSsm: '',
  businessAddress: '',
  businessEmail: '',
  currency: 'RM',
  theme: 'light',
  language: 'en',
  ownerPhone: '+60123456789',
  sellerPhone: '+60123456789',
  defaultDepositPct: 30,
  bankName: 'Maybank',
  bankAccNum: '5123 4567 8901',
  bankAccHolder: 'Homestay Host',
  duitNow: '0123456789',
  quotationValidityDays: 3,
  standardNotes: ''
};

const TRANSLATIONS = {
  en: {
    // Navigation
    nav_today: 'Today',
    nav_calendar: 'Calendar',
    nav_bookings: 'Bookings',
    nav_turnovers: 'Turnovers',
    nav_finances: 'Finances',
    nav_settings: 'Settings',

    // Header & Global
    all_units: 'All Units',
    add_unit: '+ Add',
    demo_badge: 'DEMO MODE',
    demo_banner_text: 'Loving this app for your homestays?',
    buy_app: 'Buy App',
    activate: 'Activate',
    today: 'Today',
    cancel: 'Cancel',
    save: 'Save',
    edit: 'Edit',
    delete: 'Delete',
    close: 'Close',

    // Dashboard
    kpi_checkin: 'Today Check-In',
    kpi_checkout: 'Today Check-Out',
    kpi_inhouse: 'In-House Guests',
    kpi_turnovers: 'Turnovers Needed',
    this_month: 'This Month',
    occupancy: 'Occupancy',
    nights_booked: 'nights booked',
    homestay_units_title: 'Homestay Units Overview',
    today_actions: "Today's Schedule & Actions",
    see_all: 'See All',
    manage_btn: 'Manage',
    vacant_ready: 'Vacant & Ready',
    turnover_required: 'Turnover / Cleaning Required',
    occupied_by: 'Occupied by',
    available: 'Available',
    occupied: 'Occupied',
    turnover: 'Turnover',
    no_actions_today: 'No urgent check-ins, check-outs, or turnovers today.',

    // Calendar
    cal_title: 'Calendar',
    sun: 'Sun', mon: 'Mon', tue: 'Tue', wed: 'Wed', thu: 'Thu', fri: 'Fri', sat: 'Sat',
    selected_date: 'Selected Date',
    select_a_date: 'Select a date',
    book_date_btn: 'Book Date',
    cal_tap_hint: 'Tap on any date above to view bookings or check availability.',
    no_bookings_date: 'No bookings for this date. Unit is vacant & available.',
    cal_all_incoming_tab: '📅 All Incoming (Nearest First)',
    cal_selected_date_tab: '🎯 Selected Date',
    cal_incoming_title: 'Incoming Bookings',
    cal_incoming_subtitle: 'Ordered by nearest dates',
    cal_no_incoming: 'No upcoming or active bookings found.',
    cal_mode_checkin: 'Check-In',
    cal_mode_checkout: 'Check-Out',
    cal_mode_stays: 'All Stays',
    cal_checkins_for_date: 'Check-In(s) on',
    cal_checkouts_for_date: 'Check-Out(s) on',
    cal_no_checkins_date: 'No check-ins on this date. Unit(s) available for new booking.',
    cal_no_checkouts_date: 'No check-outs scheduled on this date.',
    cal_unit_vacating_title: 'Checking Out Today — Ready for New Booking!',
    cal_unit_vacating_desc: 'Guest departs by 12:00 PM. Unit will be cleaned & ready for a new guest to check in at 3:00 PM.',
    cal_book_unit_today: '+ Book Unit from Today',

    // Bookings & Filters
    filter_all: 'All',
    filter_quotations: '📋 Quotations',
    filter_booked: '🟡 Booked (Deposit)',
    filter_confirmed: '🟢 Confirmed (Full)',
    filter_inhouse: '🔑 In-House',
    filter_completed: '🏁 Completed',
    filter_historical_tenancy: '📜 Historical Tenancies',
    btn_historical_tenancies: 'Historical Tenancies',
    historical_tenancies_title: 'Historical Completed Tenancies',
    filter_blocked: '🚫 Blocked',
    search_placeholder: 'Search guest name, phone, ref...',
    no_bookings_found: 'No Bookings Found',
    no_bookings_hint: 'Try adjusting your search or tap + to create a new quotation / booking.',
    nights: 'nights',
    months: 'months',
    guests: 'Guests',
    total: 'Total',
    balance: 'Balance',
    btn_wa: 'WhatsApp',
    btn_edit: 'Edit',

    // Turnovers
    turnover_title: 'Turnover & Cleaning',
    turnover_subtitle: 'Prep your homestay for the next guest',
    no_turnovers: 'No Turnovers Needed',
    all_clean_hint: 'All homestays are clean, sanitized and ready for check-in.',
    checklist: 'Checklist',
    assign_cleaner: 'Assign Cleaner',
    mark_clean_ready: 'Mark as Clean & Ready',
    cleaning_in_progress: 'Cleaning in Progress',
    ready_for_checkin: 'Ready for Check-In',
    btn_wa_cleaner: 'WhatsApp Cleaner',

    // Finances
    total_rev: 'Total Revenue',
    total_exp: 'Total Expenses',
    net_profit: 'Net Profit',
    rev_by_homestay: 'Revenue by Homestay',
    expense_breakdown: 'Expense Breakdown',
    add_expense_btn: '+ Expense',
    add_btn: '+ Add',
    no_expenses: 'No expenses logged for this month.',
    cat_cleaning: '🧹 Cleaning / Laundry',
    cat_utilities: '💡 Utilities (Electricity, Water, WiFi)',
    cat_supplies: '🧻 Supplies & Amenities',
    cat_maintenance: '🔧 Maintenance & Repairs',
    cat_commission: '🏷️ Platform Commission',
    cat_other: '📦 Other Expenses',

    // Settings
    your_homestays: 'Your Homestays',
    manage_homestays_sub: 'Manage names, WiFi, smart locks & rates',
    add_unit_btn: '+ Add Unit',
    app_pref_title: 'App Preferences & Seller Info',
    business_name_label: 'Business / Brand Name',
    seller_phone_label: 'Seller Support / Order WhatsApp Number',
    seller_phone_hint: 'Buyers will contact this WhatsApp number when clicking "Buy License".',
    currency_label: 'Currency Symbol',
    owner_phone_label: 'Owner WhatsApp Phone Number (Bound to License)',
    owner_phone_hint: 'Your official WhatsApp number. Used in quotations and permanently bound to your app license.',
    app_language_label: 'App Language / Bahasa',
    deposit_pct_label: 'Standard Deposit Percentage (%)',
    deposit_pct_hint: 'Default deposit requested upon booking (e.g. 30%).',
    quotation_validity_label: 'Default Quotation Validity (Days)',
    quotation_validity_hint: 'Default number of days a quotation remains valid before expiry.',
    standard_notes_label: 'Standard WhatsApp Notes / Footer',
    standard_notes_hint: 'Automatically appended at the bottom of customer WhatsApp automation messages.',
    days_label: 'days',
    btn_save_pref: 'Save Preferences',
    bank_title: 'Bank & Payment Details',
    bank_sub: 'Auto-included in Quotations, Invoices, and Payment Receipts sent to guests.',
    bank_name_label: 'Bank Name',
    acc_num_label: 'Account Number',
    acc_holder_label: 'Account Holder Name',
    duitnow_label: 'DuitNow ID / QR / Transfer Note',
    btn_save_bank: 'Save Payment Details',
    app_license_title: 'App License',
    admin_gen_title: 'Admin License Generator',
    admin_gen_sub: 'Generate phone-bound licenses and 1-click WhatsApp onboarding links for buyers.',
    buyer_phone_label: "Buyer's WhatsApp Phone Number",
    buyer_name_label: 'Buyer Name / Homestay Name (Optional)',
    btn_gen_license: 'Generate License & Magic Link',
    business_ssm_label: 'Business Registration / SSM No. (For Official PDF Docs)',
    business_address_label: 'Office / Business Address (For Quotations & Invoices)',
    business_email_label: 'Official Host Email',
    btn_generate_pdf_doc: 'Generate Official PDF Document (Quotation / Invoice / Receipt)',
    pdf_modal_title: 'Corporate & Office PDF Document Hub',
    pdf_modal_sub: 'Select document type, adjust quotation validity & save as standard A4 PDF.',
    pdf_tab_quotation: '1. Quotation (Sebut Harga)',
    pdf_tab_invoice: '2. Official Invoice (Invois)',
    pdf_tab_receipt: '3. Official Receipt (Resit Rasmi)',
    pdf_client_org_label: 'Company / Ministry / Agency Name (Optional)',
    pdf_lpo_ref_label: 'Local Purchase Order / PO Ref (Optional)',
    pdf_lang_label: 'Document Language',
    btn_print_pdf: 'Print / Save as PDF',
    btn_share_pdf_wa: 'Open WhatsApp & Share PDF',
    // App Updates & Version
    app_version_title: 'App Version & Updates',
    app_version_sub: 'Update to the latest version anytime without losing your homestay or booking data.',
    safe_update_guarantee_title: 'Zero Data Loss Guarantee:',
    safe_update_guarantee_desc: 'Your homestays, tenant records, financials, and license key stay privately stored on this device during updates.',
    btn_check_updates: 'Check for Updates',
    btn_force_refresh: 'Force Fresh Reload',
    btn_safety_backup: 'Safety Snapshot',
    update_banner_title: 'New Update Available!',
    update_banner_desc: 'New improvements & features ready. Your data is 100% preserved.',
    btn_update_now: 'Update Now',
    toast_app_updated: '🎉 App successfully updated to v2.6.6! All data is intact.',
    toast_up_to_date: '✨ You are already using the latest version (v2.6.6)!',
    toast_checking_updates: 'Checking for new updates...',
    toast_safety_saved: 'Safety backup snapshot downloaded!',

    data_backup_title: 'Data & Backup',
    data_backup_sub: 'All your data (Homestays, Bookings, Payments, Maintenance Team & Suppliers) is saved privately on your device. Export a backup anytime.',
    btn_export: 'Export Backup (.json)',
    btn_restore: 'Restore Backup',
    btn_restore_snapshot: 'Restore Pre-Update Safety Snapshot',
    no_auto_backup_found: 'No pre-update safety snapshot found. Your current data is active.',
    btn_load_demo: 'Load Rich Demo Data',
    btn_clear_data: 'Clear All Data',
    install_mobile_title: 'Install on Mobile',
    install_mobile_sub: 'To install like a native app: Open in Safari (iOS) and tap Share > Add to Home Screen, or in Chrome (Android) tap Menu > Install App.',

    // Modals - Booking
    booking_modal_new: 'New Quotation / Booking',
    booking_modal_edit: 'Edit Booking / Tenancy',
    select_property: 'Select Homestay Property',
    rental_type: 'Rental Type / Jenis Sewaan',
    type_daily: 'Daily / Short-Term',
    type_monthly: 'Monthly Tenancy',
    tenant_particulars_title: 'Tenant & Guest Particulars / Butiran Tetamu',
    full_name: 'Full Name / Nama Penuh',
    phone_wa: 'Phone / WhatsApp',
    nric_passport: 'NRIC / Passport No. / No. KP',
    email: 'Email Address / Emel',
    address: 'Residential / Home Address / Alamat Surat Menyurat',
    checkin_date: 'Check-In Date',
    checkout_date: 'Check-Out Date',
    rate_night: 'Rate/Night',
    cleaning_fee: 'Cleaning Fee',
    sec_deposit: 'Security Deposit (Refundable)',
    total_rental: 'Total Rental:',
    quick_deposit: 'Quick Booking Fee:',
    monthly_start: 'Tenancy Start Date',
    duration_months: 'Duration (Months)',
    monthly_rent: 'Monthly Rent:',
    rental_dep: 'Rental Deposit (Refundable):',
    util_dep: 'Utilities Deposit (Refundable):',
    agreement_fee: 'Agreement & Admin Fee:',
    initial_movein: 'Initial Move-In Total:',
    guests_occupants: 'Guests / Occupants',
    booking_channel: 'Booking Channel',
    deposit_paid: 'Advance / Deposit Paid',
    booking_stage: 'Booking Stage / Status',
    special_notes: 'Special Requests / Notes',
    btn_save_booking: 'Save Booking',

    // Overlap Prevention & Change Homestay (v2.6.3)
    overlap_detected_title: 'Booking Overlap Blocked!',
    overlap_detected_sub: 'The selected dates clash with an existing booking for this homestay.',
    overlap_action_change_unit: 'Switch to Available Unit',
    overlap_action_change_dates: 'Change Stay Dates',
    btn_change_homestay: 'Change Homestay',
    change_homestay_title: 'Change Homestay Unit',
    change_homestay_subtitle: 'Transfer this booking to another homestay while keeping all tenant particulars.',
    target_homestay: 'Target Homestay Unit',
    pricing_adjustment: 'Pricing Adjustment Option',
    keep_existing_price: 'Keep Existing Price & Payments',
    keep_existing_price_desc: 'Retain current total amount and balance. Ideal if price was already agreed upon.',
    recalc_new_price: 'Recalculate with New Homestay Rate',
    recalc_new_price_desc: 'Apply target homestay nightly rate & cleaning fee. Deposit paid is preserved.',
    confirm_transfer_btn: 'Confirm & Transfer Booking',

    // Modals - Property
    prop_modal_add: 'Add Homestay Unit',
    prop_modal_edit: 'Edit Homestay Unit',
    prop_name: 'Property / Homestay Name',
    room_no: 'Room / Unit No.',
    rental_cat: 'Rental Category / Jenis Unit',
    cat_entire: '🏡 Entire House / Whole Unit (Seluruh Rumah / Villa / Homestay)',
    cat_master: '🚪 Room Rental - Master Bedroom (Sewa Bilik Master)',
    cat_medium: '🚪 Room Rental - Medium Room (Sewa Bilik Medium)',
    cat_single: '🚪 Room Rental - Single Room (Sewa Bilik Single / Standard)',
    cat_studio: '🏢 Studio Apartment / Suite',
    address_loc: 'Address / Location',
    gps_loc: 'GPS / Google Maps Link',
    open_maps: 'Open in Google Maps / Waze',
    wifi_name: 'WiFi Name (SSID)',
    wifi_pass: 'WiFi Password',
    door_pin: 'Door / Smart Lock PIN',
    theme_color: 'Theme Color',
    default_rate: 'Default Nightly Rate',
    default_clean_fee: 'Cleaning Fee',
    checkin_time: 'Check-in Time',
    checkout_time: 'Check-out Time',
    house_rules: 'House Rules & Notes',
    btn_save_prop: 'Save Property',

    // Modals - WhatsApp
    wa_modal_title: 'Send WhatsApp Message',
    wa_to: 'To: Guest',
    wa_tab_quotation: '📄 Quotation',
    wa_tab_deposit: '🧾 Deposit Receipt (Booked)',
    wa_tab_checkin: '📅 Check-In Reminder',
    wa_tab_full: '🔑 Full Receipt & Keys',
    wa_tab_invoice: '📑 Monthly Rent Invoice',
    wa_tab_rent_receipt: '🧾 Monthly Rent Receipt',
    wa_tab_refund: '💰 Deposit Refund Statement',
    wa_tab_checkout: '🏁 Check-Out Reminder',
    wa_tab_cleaner: '🧹 Cleaner Job',
    wa_tab_payment: '💳 Balance Due',
    btn_checkin_reminder: 'Check-In Reminder',
    btn_copy_text: 'Copy Text',
    btn_open_wa: 'Open WhatsApp',

    // Modals - Monthly Tenancy Invoices
    monthly_invoices_modal_title: 'Monthly Rental Invoices',
    select_billing_month: 'Select Billing Month',
    extra_utility_surcharge: 'Utility / Extra (RM)',
    tenancy_period: 'Tenancy Period',
    monthly_schedule_title: 'Billing Cycles & Invoice Status',
    month_num: 'Month',
    due_date_label: 'Due Date',
    btn_send_month_inv: 'Send Invoice',
    btn_send_month_rec: 'Send Receipt',
    btn_mark_month_paid: 'Mark Paid',
    btn_unmark_month_paid: 'Unmark',
    paid_movein: 'Paid (Move-In)',
    pending: 'Pending',
    paid: 'Paid',
    btn_view_invoices: 'Monthly Invoices',

    // In-App User Guide
    user_guide_title: 'User Manual & Operational Guide',
    user_guide_sub: 'Step-by-step instructions on mobile setup, bookings, invoicing, WhatsApp, and finances.',
    btn_open_guide: 'Read In-App User Guide (EN / BM)',
    user_guide_modal_title: 'User Guide & Manual',
    user_guide_modal_sub: 'Interactive guide & operational walkthrough',
    guide_lang_label: 'Select Guide Language:',

    // Modals - Refund
    refund_modal_title: 'Tenancy Deposit Refund',
    rental_dep_held: 'Rental Deposit Held:',
    util_dep_held: 'Utilities Deposit Held:',
    deduct_util: 'Less: Utility Arrears (TNB/Water):',
    deduct_repair: 'Less: Repairs & Damage / Cleaning:',
    net_refund: 'Net Refund to Tenant:',
    deduct_notes: 'Deduction Notes & Bank Account for Transfer',
    btn_send_refund_wa: 'Send Refund Statement',

    // Modals - Expense
    exp_modal_title: 'Log Homestay Expense',
    exp_property: 'Property',
    exp_amount: 'Amount',
    exp_date: 'Date',
    exp_category: 'Category',
    exp_desc: 'Description / Receipt Note',
    btn_save_expense: 'Save Expense',

    // Modals - Guest Kit
    guide_modal_title: 'Digital Guest Welcome Kit',
    guide_wifi: 'WiFi Credentials',
    guide_smart_lock: 'Smart Lock / Access',
    guide_rules: 'House Rules',
    guide_share_btn: 'Share Guide with Guest via WhatsApp',

    // Modals - License
    lic_modal_title: 'Unlock Lifetime License',
    lic_modal_sub: 'One-time purchase • Zero monthly fees',
    lic_phone: 'Your Registered WhatsApp Phone Number',
    lic_key: 'Enter Your Activation License Key',
    btn_activate_app: 'Activate Full App',

    // Action Feed Tags & Buttons
    tag_checkin_today: 'Check-In Today',
    tag_checkout_today: 'Check-Out Today',
    tag_turnover_needed: 'Turnover Needed',
    btn_send_quotation: 'Send Quotation',
    btn_mark_booked: 'Mark Deposit Paid (Book)',
    btn_send_deposit_receipt: 'Send Deposit Receipt',
    btn_send_invoice: 'Send Invoice',
    btn_mark_confirmed: 'Mark Fully Paid (Confirm)',
    btn_send_full_receipt: 'Send Full Receipt & Key',
    btn_checkin: 'Check In',
    btn_checkout_reminder: 'Check-Out Reminder',
    btn_complete_checkout: 'Complete Check-Out',

    // Team & Suppliers Directory and Dispatch
    team_dir_title: 'Maintenance Team & Suppliers',
    team_dir_subtitle: 'Manage cleaners, technicians, handymen & suppliers',
    add_person_btn: '+ Add Person',
    btn_team_suppliers: '👷 Team & Suppliers',
    btn_service_supply_alert: '🛠️ Service / Supply Alert',
    contact_name_label: 'Contact / Person Name',
    contact_category_label: 'Service Category / Role',
    contact_phone_label: 'WhatsApp Phone Number',
    contact_company_label: 'Company / Shop Name (Optional)',
    contact_notes_label: 'Rates, Notes & Service Details',
    contact_modal_title_new: 'Add Team Member / Supplier',
    contact_modal_title_edit: 'Edit Contact Details',
    save_contact_btn: 'Save Contact',
    dispatch_modal_title: 'WhatsApp Service & Supply Alert',
    dispatch_modal_sub: 'Dispatch cleaners, technicians or order supplies',
    dispatch_recipient_label: 'Send WhatsApp To',
    dispatch_property_label: 'Homestay Unit / Property',
    dispatch_type_label: 'Service / Task Type',
    dispatch_urgency_label: 'Urgency Level',
    dispatch_details_label: 'Task / Order Instructions',
    dispatch_include_pin: 'Include Smart Lock Door PIN in message',
    btn_copy_text: 'Copy Text',
    btn_send_wa_direct: 'Send via WhatsApp',
    cat_cleaner: '🧹 Cleaner / Cleaning Crew',
    cat_aircond: '❄️ Aircond Specialist',
    cat_plumber: '🔧 Plumber',
    cat_electrician: '⚡ Electrician',
    cat_handyman: '🔨 Handyman / General Repairs',
    cat_linen_supplier: '🧺 Linen & Laundry Supplier',
    cat_gas_supplier: '⛽ Gas & Amenities Supplier',
    cat_locksmith: '🔐 Locksmith / Smart Lock Tech',
    cat_other: '📦 Other Contractor / Supplier',

    // Digital Receipts & Payments
    receipt_modal_title: 'Capture Payment Receipt & Reference',
    receipt_gallery_title: 'Payment Receipts & Proofs',
    btn_receipt_proofs: 'Payment Proofs',
    payment_type: 'Payment Type / Purpose',
    monthly_cycle: 'Month Cycle',
    amount_received: 'Amount Received (RM)',
    payment_date: 'Payment Date & Time',
    bank_channel: 'Bank / Payment Channel',
    bank_ref_no: 'Bank Ref No. / Transaction ID',
    paste: 'Paste',
    bank_ref_hint: 'Copy & paste the Reference No / Transaction ID from the tenant slip.',
    digital_receipt_slip: 'Digital Receipt Screenshot / Slip (Bukti Resit)',
    tap_to_upload_receipt: 'Tap to Upload or Snap Receipt Slip',
    receipt_formats_hint: 'JPG, PNG, WebP or PDF • Auto-compressed for zero storage lag',
    view: 'View',
    remove: 'Remove',
    payment_notes: 'Notes / Remarks (Optional)',
    save_payment_proof: 'Save Payment & Receipt',
    add_payment_receipt: '+ Record New Payment / Receipt',
    copy_ref: 'Copy Ref',
    ref_copied: 'Reference number copied!',
    download: 'Download Slip',
    no_receipts_recorded: 'No payment receipts recorded for this booking yet.',
    delete_receipt_confirm: 'Are you sure you want to delete this payment record and slip?',
    receipt_badge_count: 'Receipt(s)',

    // Promotional Media & Marketing Hub
    promo_hub_modal_title: 'Promotional Media & Marketing Hub',
    promo_hub_modal_sub: 'Store photos, posters, video tours & promo copywriting for 1-tap sharing',
    filter_by_property: 'Filter by Property',
    all_properties: 'All Homestays & General',
    add_media_asset: '+ Add Media',
    cat_all: 'All',
    cat_photos: 'Photos',
    cat_posters: 'Posters / Flyers',
    cat_videos: 'Video Tours',
    cat_copywriting: 'Copywriting',
    no_promo_media_found: 'No promotional media found',
    no_promo_media_hint: 'Store photos, posters, video walkthrough links, and promotional captions for quick sharing.',
    add_first_promo_media: 'Add First Media Asset',
    add_promo_media_title: 'Add Promotional Media',
    edit_promo_media_title: 'Edit Promotional Media',
    add_promo_media_sub: 'Upload property photos, video tour links, or promo text',
    media_category_label: 'Media Category',
    media_title_label: 'Title / Headline',
    upload_promo_image: 'Upload Image / Poster (Auto-Compressed for Storage)',
    tap_upload_photo_poster: 'Tap to Upload Photo or Poster',
    auto_compressed_note: 'JPG, PNG, WebP • Auto-downscaled to ~60KB to keep your app fast',
    external_link_label: 'External Tour / Cloud Link (Optional)',
    external_link_hint: 'Zero device storage used. Great for full 4K video tours or shared Google Drive galleries.',
    promo_caption_label: 'Promotional Copywriting / Pitch Text',
    insert_template: 'Preset Template',
    promo_caption_hint: 'This copywriting is pre-filled when sharing to WhatsApp or copying to clipboard.',
    save_promo_media: 'Save Media Asset',
    share_via_whatsapp: 'Send Promo via WhatsApp',
    send_to_recipient: 'Send To Recipient',
    enter_phone_number: 'Enter / Pick Phone Number',
    guest_phone_label: 'Guest WhatsApp Number',
    phone_empty_hint: 'Leave blank to open WhatsApp and pick from your recent contacts.',
    message_preview: 'Message Preview',
    open_in_whatsapp: 'Send on WhatsApp',
    attach_promo_media: '+ Append Promo Media / Tour Link',
    promo_media_card_title: 'Promotional Media & Marketing Hub',
    promo_media_card_sub: 'Store property photos, holiday posters, video walkthroughs & marketing pitch copywriting',
    open_media_hub: 'Open Media Hub',
    copy_pitch: 'Copy Pitch',
    pitch_copied: 'Promotional pitch copied to clipboard!',
    link_copied: 'Media link copied to clipboard!',
    delete_promo_confirm: 'Are you sure you want to delete this promotional media asset?',

    // Tenancy Agreement Generator
    agr_modal_title: 'Residential Tenancy Agreement Generator',
    agr_modal_subtitle: 'Generate official A4 tenancy agreements with Muslim-friendly covenants, schedule of terms, fixtures inventory & signatures.',
    tenancy_agreement_banner_title: 'Residential Tenancy Agreement',
    tenancy_agreement_banner_sub: 'Generate official A4 tenancy agreement with Muslim-friendly covenants, inventory & signatures.',
    btn_generate_agreement: 'Generate Tenancy Agreement',
    pdf_tab_agreement: '5. Tenancy Agreement',
    agr_tab_form: '1. Setup & Particulars',
    agr_tab_preview: '2. Live Preview & Export',
    agr_lbl_select_booking: 'Select Tenant / Monthly Booking Record:',
    agr_btn_autofill: 'Auto-Fill',
    agr_sec_parties: '1. Parties (Landlord & Tenant Particulars)',
    agr_title_landlord: 'Landlord (Lessor / Tuan Rumah)',
    agr_lbl_landlord_name: 'Full Name / Business Name:',
    agr_lbl_landlord_ic: 'NRIC / Passport / Company Reg (SSM):',
    agr_lbl_landlord_phone: 'Phone / WhatsApp:',
    agr_lbl_landlord_addr: 'Landlord Correspondence Address:',
    agr_title_tenant: 'Tenant (Lessee / Penyewa)',
    agr_lbl_tenant_name: 'Full Name of Tenant:',
    agr_lbl_tenant_ic: 'NRIC / Passport / Reg No:',
    agr_lbl_tenant_phone: 'Phone Number:',
    agr_lbl_tenant_email: 'Email Address (Optional):',
    agr_lbl_tenant_addr: 'Tenant Permanent Address:',
    agr_sec_property_terms: '2. Demised Property & Tenancy Financial Terms',
    agr_lbl_prop_name: 'Homestay / Property Name:',
    agr_lbl_prop_type: 'Property Type:',
    agr_lbl_prop_addr: 'Full Address of Demised Premises:',
    agr_lbl_agr_date: 'Agreement Execution Date:',
    agr_lbl_start_date: 'Tenancy Commencement Date:',
    agr_lbl_end_date: 'Tenancy Expiry Date:',
    agr_lbl_duration: 'Tenancy Duration (Months):',
    agr_lbl_monthly_rent: 'Monthly Rent (RM / Month):',
    agr_lbl_due_day: 'Monthly Payment Due Date:',
    agr_lbl_rental_deposit: 'Rental Security Deposit (1 Month - RM):',
    agr_lbl_util_deposit: 'Utilities Deposit (Electricity/Water - RM):',
    agr_lbl_advance_rent: 'Advance 1st Month Rent (RM):',
    agr_lbl_fee: 'Agreement & Stamping Fee (RM):',
    agr_lbl_renewal_notice: 'Renewal Option Notice Period:',
    agr_lbl_payment_account: 'Landlord Bank Account Details:',
    agr_sec_muslim_title: '3. Special Muslim-Friendly House Covenants',
    agr_switch_muslim: 'Activate Muslim-Friendly House Requirement',
    agr_muslim_desc_title: 'Strict Covenants for Maintaining Muslim Living Condition:',
    agr_lbl_custom_clauses: 'Custom Additional House Rules / Covenants (Optional):',
    agr_sec_inventory: '4. Fixtures, Furniture & Inventory Schedule',
    agr_btn_add_item: '+ Add Inventory Item',
    agr_th_item_name: 'Item / Fixture Description',
    agr_th_qty: 'Quantity',
    agr_th_condition: 'Current Condition',
    agr_sec_witnesses: '5. Witnesses Particulars',
    agr_title_witness_landlord: "Landlord's Witness",
    agr_title_witness_tenant: "Tenant's Witness",
    agr_lbl_wit_name: 'Witness Full Name:',
    agr_lbl_wit_ic: 'Witness NRIC / Passport:',
    agr_btn_go_preview: 'Generate & View Live Agreement Preview →',
    agr_lbl_lang: 'Document Language:',
    agr_btn_edit_details: '← Edit Details',
    agr_btn_save_draft: 'Save Draft',
    agr_btn_print: 'Print Document',
    agr_btn_share_wa: 'WhatsApp Tenant',
    agr_btn_download_pdf: 'Download A4 PDF'
  },
  bm: {
    // Navigation
    nav_today: 'Hari Ini',
    nav_calendar: 'Kalendar',
    nav_bookings: 'Tempahan',
    nav_turnovers: 'Pembersihan',
    nav_finances: 'Kewangan',
    nav_settings: 'Tetapan',

    // Header & Global
    all_units: 'Semua Unit',
    add_unit: '+ Tambah',
    demo_badge: 'MOD DEMO',
    demo_banner_text: 'Suka aplikasi ini untuk homestay anda?',
    buy_app: 'Beli App',
    activate: 'Aktifkan',
    today: 'Hari Ini',
    cancel: 'Batal',
    save: 'Simpan',
    edit: 'Kemas Kini',
    delete: 'Padam',
    close: 'Tutup',

    // Dashboard
    kpi_checkin: 'Daftar Masuk Hari Ini',
    kpi_checkout: 'Daftar Keluar Hari Ini',
    kpi_inhouse: 'Tetamu Menginap',
    kpi_turnovers: 'Perlu Dibersihkan',
    this_month: 'Bulan Ini',
    occupancy: 'Kadar Penghunian',
    nights_booked: 'malam ditempah',
    homestay_units_title: 'Ringkasan Unit Homestay',
    today_actions: 'Jadual & Tindakan Hari Ini',
    see_all: 'Lihat Semua',
    manage_btn: 'Urus',
    vacant_ready: 'Kosong & Sedia',
    turnover_required: 'Perlu Pembersihan / Turnover',
    occupied_by: 'Diduduki oleh',
    available: 'Kosong',
    occupied: 'Diduduki',
    turnover: 'Pembersihan',
    no_actions_today: 'Tiada daftar masuk, keluar atau pembersihan mendesak hari ini.',

    // Calendar
    cal_title: 'Kalendar',
    sun: 'Ahd', mon: 'Isn', tue: 'Sel', wed: 'Rab', thu: 'Kha', fri: 'Jum', sat: 'Sab',
    selected_date: 'Tarikh Dipilih',
    select_a_date: 'Pilih tarikh',
    book_date_btn: 'Tempah Tarikh',
    cal_tap_hint: 'Tekan mana-mana tarikh di atas untuk melihat tempahan atau kekosongan.',
    no_bookings_date: 'Tiada tempahan pada tarikh ini. Unit kosong & sedia ditempah.',
    cal_all_incoming_tab: '📅 Semua Akan Datang (Terdekat)',
    cal_selected_date_tab: '🎯 Tarikh Dipilih',
    cal_incoming_title: 'Tempahan Akan Datang',
    cal_incoming_subtitle: 'Susunan mengikut tarikh terdekat',
    cal_no_incoming: 'Tiada tempahan aktif atau akan datang ditemui.',
    cal_mode_checkin: 'Daftar Masuk',
    cal_mode_checkout: 'Daftar Keluar',
    cal_mode_stays: 'Penginapan',
    cal_checkins_for_date: 'Daftar Masuk pada',
    cal_checkouts_for_date: 'Daftar Keluar pada',
    cal_no_checkins_date: 'Tiada tetamu mendaftar masuk pada tarikh ini. Unit sedia untuk tempahan baharu.',
    cal_no_checkouts_date: 'Tiada daftar keluar dijadualkan pada tarikh ini.',
    cal_unit_vacating_title: 'Keluar Hari Ini — Sedia Untuk Tempahan Baharu!',
    cal_unit_vacating_desc: 'Tetamu keluar jam 12:00 PM. Unit dibersihkan & sedia untuk tetamu baharu mendaftar masuk jam 3:00 PM.',
    cal_book_unit_today: '+ Tempah Unit Mulai Hari Ini',

    // Bookings & Filters
    filter_all: 'Semua',
    filter_quotations: '📋 Sebut Harga',
    filter_booked: '🟡 Ditempah (Deposit)',
    filter_confirmed: '🟢 Disahkan (Penuh)',
    filter_inhouse: '🔑 Sedang Menginap',
    filter_completed: '🏁 Selesai',
    filter_historical_tenancy: '📜 Sejarah Sewaan',
    btn_historical_tenancies: 'Sejarah Sewaan',
    historical_tenancies_title: 'Sejarah Sewaan Bulanan Tamat',
    filter_blocked: '🚫 Disekat',
    search_placeholder: 'Cari nama tetamu, telefon, rujukan...',
    no_bookings_found: 'Tiada Tempahan Dijumpai',
    no_bookings_hint: 'Cuba tukar carian atau tekan + untuk mencipta sebut harga / tempahan baru.',
    nights: 'malam',
    months: 'bulan',
    guests: 'Tetamu',
    total: 'Jumlah',
    balance: 'Baki',
    btn_wa: 'WhatsApp',
    btn_edit: 'Kemas Kini',

    // Turnovers
    turnover_title: 'Pembersihan & Turnover',
    turnover_subtitle: 'Sediakan unit homestay anda untuk tetamu seterusnya',
    no_turnovers: 'Tiada Pembersihan Diperlukan',
    all_clean_hint: 'Semua unit bersih, disanitasi dan sedia untuk tetamu.',
    checklist: 'Senarai Semak',
    assign_cleaner: 'Tugaskan Pencuci',
    mark_clean_ready: 'Tanda Bersih & Sedia',
    cleaning_in_progress: 'Sedang Dibersihkan',
    ready_for_checkin: 'Sedia Untuk Daftar Masuk',
    btn_wa_cleaner: 'WhatsApp Pencuci',

    // Finances
    total_rev: 'Jumlah Pendapatan',
    total_exp: 'Jumlah Perbelanjaan',
    net_profit: 'Keuntungan Bersih',
    rev_by_homestay: 'Pendapatan Mengikut Unit',
    expense_breakdown: 'Pecahan Perbelanjaan',
    add_expense_btn: '+ Belanja',
    add_btn: '+ Tambah',
    no_expenses: 'Tiada rekod perbelanjaan untuk bulan ini.',
    cat_cleaning: '🧹 Pembersihan / Dobi',
    cat_utilities: '💡 Utiliti (Elektrik, Air, WiFi)',
    cat_supplies: '🧻 Barangan & Kelengkapan',
    cat_maintenance: '🔧 Penyelenggaraan & Baiki',
    cat_commission: '🏷️ Komisen Platform',
    cat_other: '📦 Perbelanjaan Lain',

    // Settings
    your_homestays: 'Unit Homestay & Bilik Anda',
    manage_homestays_sub: 'Urus nama, WiFi, kunci pintar & kadar sewa',
    add_unit_btn: '+ Tambah Unit',
    app_pref_title: 'Pilihan Aplikasi & Maklumat Penjual',
    business_name_label: 'Nama Homestay / Perniagaan',
    seller_phone_label: 'Nombor WhatsApp Sokongan / Tempahan',
    seller_phone_hint: 'Pembeli akan menghubungi nombor WhatsApp ini apabila menekan "Beli Lesen".',
    currency_label: 'Simbol Mata Wang',
    owner_phone_label: 'Nombor WhatsApp Pemilik (Terkunci ke Lesen)',
    owner_phone_hint: 'Nombor WhatsApp rasmi anda. Digunakan dalam sebut harga dan diikat secara kekal pada lesen aplikasi anda.',
    app_language_label: 'Bahasa Aplikasi',
    deposit_pct_label: 'Peratusan Deposit Standard (%)',
    deposit_pct_hint: 'Deposit standard yang diminta semasa tempahan (contoh: 30%).',
    quotation_validity_label: 'Tempoh Sah Sebut Harga (Hari)',
    quotation_validity_hint: 'Jumlah hari sebut harga sah sebelum luput.',
    standard_notes_label: 'Nota Standard WhatsApp (Kaki Mesej)',
    standard_notes_hint: 'Dimasukkan secara automatik di bahagian bawah mesej automasi WhatsApp.',
    days_label: 'hari',
    btn_save_pref: 'Simpan Tetapan',
    bank_title: 'Maklumat Akaun Bank & DuitNow',
    bank_sub: 'Dimasukkan secara automatik dalam Sebut Harga, Invois, dan Resit Bayaran tetamu.',
    bank_name_label: 'Nama Bank',
    acc_num_label: 'Nombor Akaun',
    acc_holder_label: 'Nama Pemegang Akaun',
    duitnow_label: 'ID DuitNow / QR / Nota Rujukan',
    btn_save_bank: 'Simpan Maklumat Pembayaran',
    app_license_title: 'Lesen Aplikasi',
    admin_gen_title: 'Penjana Kunci Lesen (Admin)',
    admin_gen_sub: 'Jana lesen terikat nombor telefon dan pautan aktivasi 1-klik WhatsApp untuk pembeli.',
    buyer_phone_label: 'Nombor WhatsApp Pembeli',
    buyer_name_label: 'Nama Pembeli / Nama Homestay (Pilihan)',
    btn_gen_license: 'Jana Kunci Lesen & Pautan Pintar',
    business_ssm_label: 'No. Pendaftaran SSM / Perniagaan (Untuk Dokumen PDF Rasmi)',
    business_address_label: 'Alamat Pejabat / Premis (Untuk Sebut Harga & Invois)',
    business_email_label: 'Emel Rasmi Hos',
    btn_generate_pdf_doc: 'Jana Dokumen PDF Rasmi (Quotation / Invois / Resit)',
    pdf_modal_title: 'Jana Dokumen PDF Rasmi (Office & Claim Ready)',
    pdf_modal_sub: 'Pilih jenis dokumen, sesuaikan tempoh sah sebut harga & muat turun sebagai PDF A4 standard.',
    pdf_tab_quotation: '1. Sebut Harga (Quotation)',
    pdf_tab_invoice: '2. Invois Rasmi (Invoice)',
    pdf_tab_receipt: '3. Resit Rasmi (Receipt)',
    pdf_client_org_label: 'Nama Syarikat / Kementerian / Jabatan (Pilihan)',
    pdf_lpo_ref_label: 'No. Pesanan Tempatan / LPO Ref (Pilihan)',
    pdf_lang_label: 'Bahasa Dokumen',
    btn_print_pdf: 'Cetak / Simpan Sebagai PDF',
    btn_share_pdf_wa: 'Buka WhatsApp & Kongsi PDF',
    // App Updates & Version
    app_version_title: 'Versi Aplikasi & Kemas Kini',
    app_version_sub: 'Kemas kini ke versi terkini pada bila-bila masa tanpa kehilangan data homestay atau tempahan anda.',
    safe_update_guarantee_title: 'Jaminan Sifar Kehilangan Data:',
    safe_update_guarantee_desc: 'Data unit homestay, rekod penyewa, kewangan dan lesen anda kekal tersimpan secara peribadi di peranti ini semasa kemas kini.',
    btn_check_updates: 'Semak Kemas Kini',
    btn_force_refresh: 'Muat Semula Bersih',
    btn_safety_backup: 'Salinan Keselamatan',
    update_banner_title: 'Kemas Kini Baharu Tersedia!',
    update_banner_desc: 'Ciri baharu & penambahbaikan sedia dipasang. Data anda kekal 100% selamat.',
    btn_update_now: 'Kemas Kini Sekarang',
    toast_app_updated: '🎉 Aplikasi berjaya dikemas kini ke v2.6.6! Semua data kekal selamat.',
    toast_up_to_date: '✨ Anda sedang menggunakan versi terkini (v2.6.6)!',
    toast_checking_updates: 'Menyemak kemas kini terkini...',
    toast_safety_saved: 'Salinan sandaran keselamatan berjaya dimuat turun!',

    data_backup_title: 'Data & Salinan Sandaran',
    data_backup_sub: 'Semua data anda (Homestay, Tempahan, Rekod Bayaran, Pasukan Penyelenggaraan & Pembekal) disimpan dengan selamat pada peranti anda. Eksport salinan sandaran bila-bila masa.',
    btn_export: 'Eksport Salinan (.json)',
    btn_restore: 'Pulihkan Salinan',
    btn_restore_snapshot: 'Pulihkan Salinan Keselamatan Pra-Kemas Kini',
    no_auto_backup_found: 'Tiada salinan keselamatan pra-kemas kini dijumpai. Data semasa anda sedang aktif.',
    btn_load_demo: 'Muat Data Demo Penuh',
    btn_clear_data: 'Padam Semua Data',
    install_mobile_title: 'Pasang Pada Telefon Pintar',
    install_mobile_sub: 'Untuk pasang seperti app biasa: Buka di Safari (iOS) dan tekan Share > Add to Home Screen, atau di Chrome (Android) tekan Menu > Install App.',

    // Modals - Booking
    booking_modal_new: 'Tempahan & Sebut Harga Baru',
    booking_modal_edit: 'Kemas Kini Tempahan / Sewaan',
    select_property: 'Pilih Unit Homestay',
    rental_type: 'Jenis Sewaan / Rental Type',
    type_daily: 'Sewaan Harian / Jangka Pendek',
    type_monthly: 'Sewaan Bulanan / Tenancy',
    tenant_particulars_title: 'Butiran Tetamu & Penyewa',
    full_name: 'Nama Penuh',
    phone_wa: 'No. Telefon / WhatsApp',
    nric_passport: 'No. Kad Pengenalan / Pasport',
    email: 'Alamat Emel',
    address: 'Alamat Rumah / Surat Menyurat',
    checkin_date: 'Tarikh Daftar Masuk',
    checkout_date: 'Tarikh Daftar Keluar',
    rate_night: 'Kadar/Malam',
    cleaning_fee: 'Yuran Pembersihan',
    sec_deposit: 'Deposit Keselamatan (Dipulangkan)',
    total_rental: 'Jumlah Sewaan:',
    quick_deposit: 'Pilihan Pantas Deposit:',
    monthly_start: 'Tarikh Mula Sewaan',
    duration_months: 'Tempoh (Bulan)',
    monthly_rent: 'Sewa Bulanan:',
    rental_dep: 'Deposit Sewa (Dipulangkan):',
    util_dep: 'Deposit Utiliti (Dipulangkan):',
    agreement_fee: 'Yuran Perjanjian & Duti Setem:',
    initial_movein: 'Jumlah Bayaran Kemasukan:',
    guests_occupants: 'Bilangan Tetamu / Penghuni',
    booking_channel: 'Saluran Tempahan',
    deposit_paid: 'Bayaran Deposit / Pendahuluan',
    booking_stage: 'Status / Peringkat Tempahan',
    special_notes: 'Permintaan Khas / Catatan',
    btn_save_booking: 'Simpan Tempahan',

    // Overlap Prevention & Change Homestay (v2.6.3)
    overlap_detected_title: 'Pertindihan Tempahan Dihalang!',
    overlap_detected_sub: 'Tarikh yang dipilih bertindih dengan tempahan sedia ada untuk homestay ini.',
    overlap_action_change_unit: 'Tukar ke Unit Tersedia',
    overlap_action_change_dates: 'Tukar Tarikh Menginap',
    btn_change_homestay: 'Tukar Homestay',
    change_homestay_title: 'Tukar Unit Homestay',
    change_homestay_subtitle: 'Pindahkan tempahan ini ke unit homestay lain dengan mengekalkan semua butiran penyewa.',
    target_homestay: 'Unit Homestay Sasaran',
    pricing_adjustment: 'Pilihan Pelarasan Harga',
    keep_existing_price: 'Kekalkan Harga & Bayaran Sedia Ada',
    keep_existing_price_desc: 'Kekalkan jumlah sewaan dan baki sedia ada mengikut persetujuan awal.',
    recalc_new_price: 'Kira Semula Ikut Kadar Homestay Baru',
    recalc_new_price_desc: 'Guna kadar harian & caj pembersihan unit baru. Deposit dibayar dikekalkan.',
    confirm_transfer_btn: 'Sahkan & Pindahkan Tempahan',

    // Modals - Property
    prop_modal_add: 'Tambah Unit Homestay / Bilik',
    prop_modal_edit: 'Kemas Kini Unit Homestay / Bilik',
    prop_name: 'Nama Homestay / Hartanah',
    room_no: 'No. Bilik / Unit',
    rental_cat: 'Kategori Sewaan / Jenis Unit',
    cat_entire: '🏡 Seluruh Rumah / Villa / Homestay (Whole Unit)',
    cat_master: '🚪 Sewa Bilik - Bilik Master',
    cat_medium: '🚪 Sewa Bilik - Bilik Medium',
    cat_single: '🚪 Sewa Bilik - Bilik Single',
    cat_studio: '🏢 Studio Apartmen / Suite',
    address_loc: 'Alamat / Lokasi',
    gps_loc: 'Pautan GPS / Google Maps',
    open_maps: 'Buka di Google Maps / Waze',
    wifi_name: 'Nama WiFi (SSID)',
    wifi_pass: 'Kata Laluan WiFi',
    door_pin: 'PIN Kunci Pintu / Smart Lock',
    theme_color: 'Warna Tema',
    default_rate: 'Kadar Sewa Harian Standard',
    default_clean_fee: 'Yuran Pembersihan',
    checkin_time: 'Waktu Daftar Masuk',
    checkout_time: 'Waktu Daftar Keluar',
    house_rules: 'Peraturan Rumah & Catatan',
    btn_save_prop: 'Simpan Unit',

    // Modals - WhatsApp
    wa_modal_title: 'Hantar Mesej WhatsApp',
    wa_to: 'Kepada: Tetamu',
    wa_tab_quotation: '📄 Sebut Harga',
    wa_tab_deposit: '🧾 Resit Booking & Deposit',
    wa_tab_checkin: '📅 Peringatan Masuk',
    wa_tab_full: '🔑 Resit Penuh & Kunci PIN',
    wa_tab_invoice: '📑 Invois Bulanan',
    wa_tab_rent_receipt: '🧾 Resit Sewa Bulanan',
    wa_tab_refund: '💰 Penyata Pemulangan Deposit',
    wa_tab_checkout: '🏁 Peringatan Daftar Keluar',
    wa_tab_cleaner: '🧹 Tugasan Pembersihan',
    wa_tab_payment: '💳 Peringatan Baki Bayaran',
    btn_checkin_reminder: 'Peringatan Masuk',
    btn_copy_text: 'Salin Teks',
    btn_open_wa: 'Buka WhatsApp Terus',

    // Modals - Refund
    refund_modal_title: 'Penyata Pemulangan Deposit Sewaan',
    rental_dep_held: 'Deposit Sewa Dipegang:',
    util_dep_held: 'Deposit Utiliti Dipegang:',
    deduct_util: 'Tolak: Tunggakan Utiliti (TNB/Air):',
    deduct_repair: 'Tolak: Pembaikan & Pembersihan:',
    net_refund: 'Jumlah Bersih Dipulangkan:',
    deduct_notes: 'Catatan Tolakan & Akaun Bank Pemulangan',
    btn_send_refund_wa: 'Hantar Penyata Pemulangan',

    // Modals - Expense
    exp_modal_title: 'Rekod Perbelanjaan Homestay',
    exp_property: 'Unit Homestay',
    exp_amount: 'Jumlah',
    exp_date: 'Tarikh',
    exp_category: 'Kategori',
    exp_desc: 'Penerangan / Catatan Resit',
    btn_save_expense: 'Simpan Perbelanjaan',

    // Modals - Guest Kit
    guide_modal_title: 'Kit Panduan Digital Tetamu',
    guide_wifi: 'Maklumat Sambungan WiFi',
    guide_smart_lock: 'Akses Kunci Pintu Pintar',
    guide_rules: 'Peraturan Rumah',
    guide_share_btn: 'Kongsi Panduan ke WhatsApp Tetamu',

    // Modals - License
    lic_modal_title: 'Buka Kunci Lesen Seumur Hidup',
    lic_modal_sub: 'Pembelian sekali • Tiada yuran bulanan',
    lic_phone: 'Nombor WhatsApp Berdaftar Anda',
    lic_key: 'Masukkan Kunci Lesen Aktivasi Anda',
    btn_activate_app: 'Aktifkan Aplikasi Penuh',

    // Action Feed Tags & Buttons
    tag_checkin_today: 'Daftar Masuk Hari Ini',
    tag_checkout_today: 'Daftar Keluar Hari Ini',
    tag_turnover_needed: 'Perlu Pembersihan',
    btn_send_quotation: 'Hantar Sebut Harga',
    btn_mark_booked: 'Tanda Deposit Dibayar (Kunci)',
    btn_send_deposit_receipt: 'Hantar Resit Deposit',
    btn_send_invoice: 'Hantar Invois',
    btn_mark_confirmed: 'Tanda Bayaran Penuh (Sahkan)',
    btn_send_full_receipt: 'Hantar Resit Penuh & Kunci',
    btn_checkin: 'Daftar Masuk',
    btn_checkout_reminder: 'Peringatan Daftar Keluar',
    btn_complete_checkout: 'Selesaikan Daftar Keluar',

    // Modals - Monthly Tenancy Invoices
    monthly_invoices_modal_title: 'Jadual Invois Sewaan Bulanan',
    select_billing_month: 'Pilih Bulan Invois',
    extra_utility_surcharge: 'Caj Utiliti / Tambahan (RM)',
    tenancy_period: 'Tempoh Sewaan',
    monthly_schedule_title: 'Kitaran Sewaan & Status Bayaran',
    month_num: 'Bulan ke-',
    due_date_label: 'Tarikh Akhir Bayaran',
    btn_send_month_inv: 'Hantar Invois',
    btn_send_month_rec: 'Hantar Resit',
    btn_mark_month_paid: 'Tanda Bayar',
    btn_unmark_month_paid: 'Batal Tanda',
    paid_movein: 'Dibayar (Kemasukan)',
    pending: 'Belum Bayar',
    paid: 'Telah Dibayar',
    btn_view_invoices: 'Jadual Invois',

    // In-App User Guide
    user_guide_title: 'Panduan Pengguna & Manual Operasi',
    user_guide_sub: 'Panduan langkah demi langkah pemasangan telefon, tempahan, invois, WhatsApp, dan kewangan.',
    btn_open_guide: 'Buka Panduan Pengguna (BM / EN)',
    user_guide_modal_title: 'Panduan Pengguna & Manual',
    user_guide_modal_sub: 'Panduan lengkap & panduan operasi sistem',
    guide_lang_label: 'Pilihan Bahasa Panduan:',

    // Team & Suppliers Directory and Dispatch
    team_dir_title: 'Pasukan Penyelenggaraan & Pembekal',
    team_dir_subtitle: 'Urus tukang cuci, juruteknik, tukang baiki & pembekal',
    add_person_btn: '+ Tambah Kenalan',
    btn_team_suppliers: '👷 Pasukan & Pembekal',
    btn_service_supply_alert: '🛠️ Notis Servis & Bekalan',
    contact_name_label: 'Nama Kenalan / Pekerja',
    contact_category_label: 'Kategori Servis / Peranan',
    contact_phone_label: 'Nombor WhatsApp',
    contact_company_label: 'Nama Syarikat / Kedai (Pilihan)',
    contact_notes_label: 'Kadar Caj, Skop Kerja & Nota',
    contact_modal_title_new: 'Tambah Pasukan / Pembekal',
    contact_modal_title_edit: 'Kemaskini Butiran Kenalan',
    save_contact_btn: 'Simpan Kenalan',
    dispatch_modal_title: 'WhatsApp Notis Servis & Bekalan',
    dispatch_modal_sub: 'Hantar arahan kepada pencuci, juruteknik atau tempah bekalan',
    dispatch_recipient_label: 'Hantar WhatsApp Kepada',
    dispatch_property_label: 'Unit Homestay Terlibat',
    dispatch_type_label: 'Jenis Servis / Tugasan',
    dispatch_urgency_label: 'Tahap Keperluan',
    dispatch_details_label: 'Arahan Kerja / Baiki / Tempahan',
    dispatch_include_pin: 'Sertakan Kod PIN Pintu & Akses',
    btn_copy_text: 'Salin Teks',
    btn_send_wa_direct: 'Hantar melalui WhatsApp',
    cat_cleaner: '🧹 Tukang Cuci / Pasukan Kemas',
    cat_aircond: '❄️ Pakar Servis Aircond',
    cat_plumber: '🔧 Tukang Paip',
    cat_electrician: '⚡ Juruelektrik / Pendawaian',
    cat_handyman: '🔨 Baiki Am / Tukang Rumah',
    cat_linen_supplier: '🧺 Pembekal Linen & Dobi',
    cat_gas_supplier: '⛽ Pembekal Gas & Keperluan',
    cat_locksmith: '🔐 Tukang Kunci / Smart Lock',
    cat_other: '📦 Kontraktor / Pembekal Lain',

    // Digital Receipts & Payments
    receipt_modal_title: 'Rekod Resit Bayaran & No. Rujukan',
    receipt_gallery_title: 'Bukti Bayaran & Resit Transaksi',
    btn_receipt_proofs: 'Bukti Bayaran',
    payment_type: 'Jenis / Tujuan Bayaran',
    monthly_cycle: 'Pusingan Bulan',
    amount_received: 'Jumlah Diterima (RM)',
    payment_date: 'Tarikh & Masa Bayaran',
    bank_channel: 'Bank / Saluran Bayaran',
    bank_ref_no: 'No. Rujukan Bank / ID Transaksi',
    paste: 'Tampal',
    bank_ref_hint: 'Salin & tampal No. Rujukan Transaksi daripada resit pindahan bank penyewa.',
    digital_receipt_slip: 'Tangkapan Skrin Resit / Slip (Bukti Resit)',
    tap_to_upload_receipt: 'Tekan untuk Muat Naik atau Tangkap Gambar Slip',
    receipt_formats_hint: 'JPG, PNG, WebP atau PDF • Dimampat automatik tanpa bebanan memori',
    view: 'Lihat',
    remove: 'Padam',
    payment_notes: 'Catatan / Nota (Pilihan)',
    save_payment_proof: 'Simpan Rekod Bayaran & Resit',
    add_payment_receipt: '+ Rekod Bayaran / Resit Baharu',
    copy_ref: 'Salin No. Ref',
    ref_copied: 'Nombor rujukan bank berjaya disalin!',
    download: 'Muat Turun Slip',
    no_receipts_recorded: 'Tiada resit bayaran direkodkan bagi tempahan ini lagi.',
    delete_receipt_confirm: 'Adakah anda pasti mahu memadamkan rekod bayaran dan slip ini?',
    receipt_badge_count: 'Resit',

    // Promotional Media & Marketing Hub
    promo_hub_modal_title: 'Hab Media Promosi & Pemasaran',
    promo_hub_modal_sub: 'Simpan foto, poster, video homestay & ayat iklan untuk dihantar pantas',
    filter_by_property: 'Tapis mengikut Homestay',
    all_properties: 'Semua Homestay & Umum',
    add_media_asset: '+ Tambah Media',
    cat_all: 'Semua',
    cat_photos: 'Foto Unit',
    cat_posters: 'Poster / Flyer',
    cat_videos: 'Video Tour',
    cat_copywriting: 'Ayat Iklan',
    no_promo_media_found: 'Tiada media promosi dijumpai',
    no_promo_media_hint: 'Simpan foto bilik, kemudahan, poster diskaun dan ayat promosi untuk dikongsi dengan bakal tetamu.',
    add_first_promo_media: 'Tambah Media Pertama',
    add_promo_media_title: 'Tambah Media Promosi',
    edit_promo_media_title: 'Kemaskini Media Promosi',
    add_promo_media_sub: 'Muat naik gambar, pautan video tour atau ayat promosi',
    media_category_label: 'Kategori Media',
    media_title_label: 'Tajuk / Tajuk Utama',
    upload_promo_image: 'Muat Naik Gambar / Poster (Mampat Automatik)',
    tap_upload_photo_poster: 'Tekan untuk Muat Naik Foto atau Poster',
    auto_compressed_note: 'JPG, PNG, WebP • Dimampatkan automatik ~60KB tanpa beban memori',
    external_link_label: 'Pautan Video Tour / Galeri Awan (Pilihan)',
    external_link_hint: 'Sifar penggunaan memori telefon. Sesuai untuk pautan video YouTube, TikTok atau Google Drive.',
    promo_caption_label: 'Ayat Iklan / Copywriting Promosi',
    insert_template: 'Templat Contoh',
    promo_caption_hint: 'Teks ini akan disertakan semasa perkongsian WhatsApp atau salin ke papan keratan.',
    save_promo_media: 'Simpan Media',
    share_via_whatsapp: 'Hantar Promosi via WhatsApp',
    send_to_recipient: 'Hantar Kepada',
    enter_phone_number: 'Masukkan / Pilih Nombor Telefon',
    guest_phone_label: 'Nombor WhatsApp Bakal Tetamu',
    phone_empty_hint: 'Biarkan kosong untuk buka WhatsApp dan pilih kenalan anda.',
    message_preview: 'Pratonton Mesej',
    open_in_whatsapp: 'Hantar di WhatsApp',
    attach_promo_media: '+ Sertakan Media Promosi / Pautan Tour',
    promo_media_card_title: 'Hab Media Promosi & Pemasaran',
    promo_media_card_sub: 'Simpan foto unit, poster promosi, video walkthrough dan ayat tawaran untuk bakal tetamu',
    open_media_hub: 'Buka Hab Media',
    copy_pitch: 'Salin Ayat',
    pitch_copied: 'Ayat promosi berjaya disalin ke papan keratan!',
    link_copied: 'Pautan media berjaya disalin ke papan keratan!',
    delete_promo_confirm: 'Adakah anda pasti mahu memadamkan media promosi ini?',

    // Tenancy Agreement Generator
    agr_modal_title: 'Penjana Perjanjian Sewaan Kediaman',
    agr_modal_subtitle: 'Jana surat perjanjian rasmi A4 lengkap dengan syarat rumah mesra Muslim, jadual terma, inventori & tandatangan.',
    tenancy_agreement_banner_title: 'Perjanjian Sewaan Kediaman (Tenancy Agreement)',
    tenancy_agreement_banner_sub: 'Auto-jana perjanjian rasmi A4, klausa mesra Muslim, inventori & tandatangan.',
    btn_generate_agreement: 'Jana Perjanjian Sewa',
    pdf_tab_agreement: '5. Perjanjian Sewaan',
    agr_tab_form: '1. Butiran & Syarat Perjanjian',
    agr_tab_preview: '2. Pratonton & Jana Dokumen A4',
    agr_lbl_select_booking: 'Pilih Rekod Penyewa / Tempahan Bulanan:',
    agr_btn_autofill: 'Isi Semula Auto',
    agr_sec_parties: '1. Butiran Pihak-Pihak (Tuan Rumah & Penyewa)',
    agr_title_landlord: 'Tuan Rumah (Landlord / Lessor)',
    agr_lbl_landlord_name: 'Nama Penuh Tuan Rumah / Syarikat:',
    agr_lbl_landlord_ic: 'No. K/P / No. Syarikat (SSM):',
    agr_lbl_landlord_phone: 'No. Telefon / WhatsApp:',
    agr_lbl_landlord_addr: 'Alamat Surat-Menyurat Tuan Rumah:',
    agr_title_tenant: 'Penyewa (Tenant / Lessee)',
    agr_lbl_tenant_name: 'Nama Penuh Penyewa:',
    agr_lbl_tenant_ic: 'No. K/P / Pasport:',
    agr_lbl_tenant_phone: 'No. Telefon:',
    agr_lbl_tenant_email: 'Alamat Emel (Jika Ada):',
    agr_lbl_tenant_addr: 'Alamat Tetap Penyewa (K/P / Asal):',
    agr_sec_property_terms: '2. Maklumat Premis Demis & Terma Kewangan',
    agr_lbl_prop_name: 'Nama Unit / Homestay:',
    agr_lbl_prop_type: 'Jenis Hartanah:',
    agr_lbl_prop_addr: 'Alamat Penuh Premis Yang Disewakan (Premis Demis):',
    agr_lbl_agr_date: 'Tarikh Perjanjian Dibuat:',
    agr_lbl_start_date: 'Tarikh Mula Sewaan:',
    agr_lbl_end_date: 'Tarikh Tamat Sewaan:',
    agr_lbl_duration: 'Tempoh Sewaan (Bulan):',
    agr_lbl_monthly_rent: 'Sewa Bulanan (RM / Bulan):',
    agr_lbl_due_day: 'Hari Genap Masa Bayaran:',
    agr_lbl_rental_deposit: 'Cagaran Sewa (1 Bulan - RM):',
    agr_lbl_util_deposit: 'Cagaran Utiliti (Elektrik/Air - RM):',
    agr_lbl_advance_rent: 'Sewa Bulan Pertama (RM):',
    agr_lbl_fee: 'Duti Setem & Yuran (RM):',
    agr_lbl_renewal_notice: 'Notis Opsyen Pembaharuan:',
    agr_lbl_payment_account: 'Akaun Bank Tuan Rumah:',
    agr_sec_muslim_title: '3. Klausa Khas Pemeliharaan Keadaan Rumah Mesra Muslim',
    agr_switch_muslim: 'Aktifkan Klausa Syarat Mesra Muslim',
    agr_muslim_desc_title: 'Syarat Mutlak Pemeliharaan Status & Kesucian Rumah Sewa:',
    agr_lbl_custom_clauses: 'Klausa / Syarat Khas Tambahan Tuan Rumah (Optional):',
    agr_sec_inventory: '4. Senarai Perkakas, Perabot & Inventori Premis',
    agr_btn_add_item: '+ Tambah Item',
    agr_th_item_name: 'Perkara / Inventori',
    agr_th_qty: 'Kuantiti',
    agr_th_condition: 'Keadaan Semasa',
    agr_sec_witnesses: '5. Maklumat Saksi-Saksi (Witnesses)',
    agr_title_witness_landlord: 'Saksi Tuan Rumah',
    agr_title_witness_tenant: 'Saksi Penyewa',
    agr_lbl_wit_name: 'Nama Saksi:',
    agr_lbl_wit_ic: 'No. K/P Saksi:',
    agr_btn_go_preview: 'Jana & Lihat Pratonton Dokumen Perjanjian →',
    agr_lbl_lang: 'Bahasa Dokumen:',
    agr_btn_edit_details: '← Edit Butiran',
    agr_btn_save_draft: 'Simpan Draf',
    agr_btn_print: 'Cetak Dokumen',
    agr_btn_share_wa: 'WhatsApp Penyewa',
    agr_btn_download_pdf: 'Muat Turun PDF A4'
  }
};

function t(key) {
  const lang = appState.settings.language || 'en';
  return (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || (TRANSLATIONS['en'][key]) || key;
}

const INITIAL_PROPERTIES = [
  {
    id: 'prop-1',
    name: 'Sunset Ocean Villa (Whole House)',
    propType: 'entire',
    roomNo: 'Whole Unit (3-Bedroom)',
    address: 'Unit 12-05, Seaview Residences, Jalan Pantai 1',
    gpsLocation: 'https://maps.google.com/?q=3.1390,101.6869',
    wifiName: 'SunsetVilla_HighSpeed',
    wifiPass: 'oceanbreeze2026',
    doorCode: '5829#',
    color: '#0284c7',
    defaultRate: 280,
    cleaningFee: 60,
    checkInTime: '15:00',
    checkOutTime: '12:00',
    rules: 'No smoking indoors. Quiet hours after 10:00 PM. Please turn off air conditioning when leaving.'
  },
  {
    id: 'prop-2',
    name: 'Villa Impian - Master Bedroom',
    propType: 'room_master',
    roomNo: 'Bilik Master (Attached Bathroom)',
    address: 'Lot 45, Green Hills Sanctuary, Cameron View',
    gpsLocation: 'https://maps.google.com/?q=4.4721,101.3789',
    wifiName: 'VillaImpian_5G',
    wifiPass: 'freshcool99',
    doorCode: '1122#',
    color: '#059669',
    defaultRate: 150,
    cleaningFee: 30,
    checkInTime: '15:00',
    checkOutTime: '12:00',
    rules: 'No pets inside. Shoes off at entrance. Kitchen and living hall are shared.'
  },
  {
    id: 'prop-3',
    name: 'Villa Impian - Room 2 (Medium)',
    propType: 'room_medium',
    roomNo: 'Bilik 2',
    address: 'Lot 45, Green Hills Sanctuary, Cameron View',
    gpsLocation: 'https://maps.google.com/?q=4.4721,101.3789',
    wifiName: 'VillaImpian_5G',
    wifiPass: 'freshcool99',
    doorCode: '1123#',
    color: '#d97706',
    defaultRate: 100,
    cleaningFee: 25,
    checkInTime: '15:00',
    checkOutTime: '12:00',
    rules: 'Quiet hours after 10:00 PM. Shared kitchen & living hall.'
  }
];

let appState = {
  properties: [],
  bookings: [],
  turnovers: [],
  expenses: [],
  contacts: [],
  promotionalMedia: [],
  selectedPromoPropertyId: 'all',
  selectedPromoCategory: 'all',
  promoSearchQuery: '',
  settings: { ...DEFAULT_SETTINGS },
  isLicensed: false,
  isMasterAdmin: false,
  licenseKey: null,
  selectedPropertyId: 'all',
  activeTab: 'dashboard',
  currentCalDate: new Date(),
  selectedCalDate: new Date().toISOString().split('T')[0],
  calListingMode: 'incoming',
  calFilterMode: 'checkin',
  activeWaBooking: null,
  activeWaTemplate: 'confirm',
  activePdfBooking: null,
  activePdfDocType: 'quotation',
  activePdfLang: 'bm',
  activeDispatchRecipientId: null,
  activeDispatchPropertyId: null,
  activeDispatchService: 'turnover_clean',
};
window.appState = appState;


// ==========================================================================
// 2. INITIALIZATION & DEMO DATA SEEDING
// ==========================================================================

function initApp() {
  loadFromStorage();

  // Check URL params for Demo or 1-Click Auto-Activation (?phone=...&key=...)
  const urlParams = new URLSearchParams(window.location.search);
  const isDemoParam = urlParams.get('demo') === '1';
  const phoneParam = urlParams.get('phone');
  const keyParam = urlParams.get('key');

  if (keyParam) {
    const rawTargetPhone = phoneParam || appState.settings.ownerPhone;
    const verification = verifyLicenseKey(keyParam, rawTargetPhone);

    if (verification.valid) {
      appState.isLicensed = true;
      appState.licenseKey = keyParam.toUpperCase();
      appState.isMasterAdmin = verification.isMaster;
      
      if (verification.phone) {
        appState.settings.ownerPhone = '+' + verification.phone;
        appState.settings.sellerPhone = '+' + verification.phone;
      }
      
      saveToStorage();
      showToast('🎉 Lifetime License Activated Successfully!');

      // Remove query params from address bar for clean PWA URL
      if (window.history.replaceState) {
        const cleanUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
        window.history.replaceState({ path: cleanUrl }, '', cleanUrl);
      }
    }
  }

  const isFirstEverVisit = localStorage.getItem('staymanager_initialized') === null;
  if (isDemoParam || (isFirstEverVisit && (!appState.properties || appState.properties.length === 0))) {
    seedDemoData();
    localStorage.setItem('staymanager_initialized', 'true');
  } else {
    localStorage.setItem('staymanager_initialized', 'true');
  }

  try {
    applyTheme(appState.settings.theme);
  } catch (e) { console.warn('Theme init note:', e); }

  try {
    applyLanguageUI();
  } catch (e) { console.warn('Language init note:', e); }

  try {
    setupEventListeners();
  } catch (e) { console.error('Listeners init error:', e); }

  try {
    initAgreementGenerator();
  } catch (e) { console.error('Agreement generator init error:', e); }

  try {
    closeAllModals();
  } catch (e) {}

  try {
    renderApp();
  } catch (e) { console.error('RenderApp error:', e); }

  try {
    initPWAUpdateService();
  } catch (e) { console.warn('PWA update service note:', e); }
}

function loadFromStorage() {
  try {
    const savedProps = localStorage.getItem(STORAGE_KEYS.PROPERTIES);
    const savedBookings = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
    const savedTurnovers = localStorage.getItem(STORAGE_KEYS.TURNOVERS);
    const savedExpenses = localStorage.getItem(STORAGE_KEYS.EXPENSES);
    const savedContacts = localStorage.getItem(STORAGE_KEYS.CONTACTS);
    const savedPromo = localStorage.getItem(STORAGE_KEYS.PROMO_MEDIA);
    const savedSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);

    if (savedProps) appState.properties = JSON.parse(savedProps);
    if (savedBookings) appState.bookings = JSON.parse(savedBookings);
    if (savedTurnovers) appState.turnovers = JSON.parse(savedTurnovers);
    if (savedExpenses) appState.expenses = JSON.parse(savedExpenses);
    
    if (savedContacts) {
      try {
        appState.contacts = JSON.parse(savedContacts);
      } catch (e) {
        appState.contacts = [...DEFAULT_CONTACTS];
      }
    } else {
      appState.contacts = [...DEFAULT_CONTACTS];
    }

    if (savedPromo) {
      try {
        appState.promotionalMedia = JSON.parse(savedPromo);
      } catch (e) {
        appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];
      }
    } else {
      appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];
    }

    if (savedSettings) appState.settings = { ...DEFAULT_SETTINGS, ...JSON.parse(savedSettings) };
    
    // Unbreakable License Recovery across all legacy & modern storage keys
    const savedLicense = localStorage.getItem(STORAGE_KEYS.LICENSE) 
      || localStorage.getItem('staymanager_license_v2')
      || localStorage.getItem('staymanager_license')
      || localStorage.getItem('staymanager_license_permanent')
      || localStorage.getItem('staymanager_license_key');

    const permanentLicFlag = localStorage.getItem('staymanager_is_licensed_forever') === 'true'
      || localStorage.getItem('staymanager_license_activated') === 'true';

    let foundKey = null;

    if (savedLicense) {
      if (typeof savedLicense === 'string' && (savedLicense.startsWith('{') || savedLicense.startsWith('"'))) {
        try {
          const parsed = JSON.parse(savedLicense);
          foundKey = (parsed && parsed.key) ? parsed.key : (typeof parsed === 'string' ? parsed : null);
          if (parsed && (parsed.isLicensed || parsed.valid)) {
            appState.isLicensed = true;
          }
        } catch (e) {
          foundKey = savedLicense.trim();
        }
      } else if (typeof savedLicense === 'string') {
        foundKey = savedLicense.trim();
      }
    }

    if (!foundKey && appState.settings && appState.settings.licenseKey) {
      foundKey = appState.settings.licenseKey;
    }

    if (foundKey) {
      const check = verifyLicenseKey(foundKey, null);
      if (check.valid) {
        appState.isLicensed = true;
        appState.licenseKey = foundKey;
        appState.isMasterAdmin = check.isMaster;
        if (check.phone && (!appState.settings.ownerPhone || appState.settings.ownerPhone === DEFAULT_SETTINGS.ownerPhone)) {
          appState.settings.ownerPhone = '+' + check.phone;
        }
      } else if (permanentLicFlag || isMasterAdminKey(foundKey)) {
        appState.isLicensed = true;
        appState.licenseKey = foundKey;
        appState.isMasterAdmin = isMasterAdminKey(foundKey);
      }
    } else if (permanentLicFlag) {
      appState.isLicensed = true;
      appState.licenseKey = 'STAY-VIP-2026-LIFETIME';
      appState.isMasterAdmin = true;
    }

    // Safety fallback: Check pre-update auto-backup if license dropped or data is empty
    const autoBackupStr = localStorage.getItem('staymanager_auto_backup');
    if (autoBackupStr) {
      try {
        const autoBackup = JSON.parse(autoBackupStr);
        if (autoBackup) {
          // Restore license if missing
          if (!appState.isLicensed && autoBackup.licenseKey) {
            const checkBackup = verifyLicenseKey(autoBackup.licenseKey, null);
            appState.isLicensed = true;
            appState.licenseKey = autoBackup.licenseKey;
            appState.isMasterAdmin = checkBackup.valid ? checkBackup.isMaster : isMasterAdminKey(autoBackup.licenseKey);
            localStorage.setItem(STORAGE_KEYS.LICENSE, JSON.stringify({ key: autoBackup.licenseKey, isLicensed: true, activatedAt: new Date().toISOString() }));
          } else if (!appState.isLicensed && (autoBackup.isLicensed || autoBackup.isMasterAdmin)) {
            appState.isLicensed = true;
            appState.licenseKey = autoBackup.licenseKey || 'STAY-VIP-2026-LIFETIME';
            if (autoBackup.isMasterAdmin) appState.isMasterAdmin = true;
            localStorage.setItem(STORAGE_KEYS.LICENSE, JSON.stringify({ key: appState.licenseKey, isLicensed: true, activatedAt: new Date().toISOString() }));
          }

          // Restore properties and records if empty
          if ((!appState.properties || appState.properties.length === 0) && Array.isArray(autoBackup.properties) && autoBackup.properties.length > 0) {
            appState.properties = autoBackup.properties;
            if (Array.isArray(autoBackup.bookings)) appState.bookings = autoBackup.bookings;
            if (Array.isArray(autoBackup.turnovers)) appState.turnovers = autoBackup.turnovers;
            if (Array.isArray(autoBackup.expenses)) appState.expenses = autoBackup.expenses;
            if (Array.isArray(autoBackup.contacts)) appState.contacts = autoBackup.contacts;
            if (Array.isArray(autoBackup.promotionalMedia)) appState.promotionalMedia = autoBackup.promotionalMedia;
            if (autoBackup.settings) appState.settings = { ...DEFAULT_SETTINGS, ...autoBackup.settings };
          }
        }
      } catch (bErr) {
        console.warn('Auto backup check notice:', bErr);
      }
    }

    // If activated, reinforce persistent keys so future updates never drop
    if (appState.isLicensed && appState.licenseKey) {
      localStorage.setItem('staymanager_license_activated', 'true');
      localStorage.setItem('staymanager_is_licensed_forever', 'true');
      localStorage.setItem('staymanager_license_permanent', appState.licenseKey);
    }

    // Run schema migrations and auto-safety snapshot
    runDataMigrations();
  } catch (e) {
    console.error('Error loading localStorage:', e);
  }
}

function runDataMigrations() {
  try {
    const savedVersion = localStorage.getItem(STORAGE_KEYS.VERSION) || '1.0.0';
    if (savedVersion !== APP_VERSION) {
      // 1. Pre-update safety snapshot stored locally in localStorage
      // Safeguard: Only record snapshot if current state has data, or if no snapshot exists yet
      const hasCurrentData = (appState.properties && appState.properties.length > 0) || appState.isLicensed;
      if (hasCurrentData || !localStorage.getItem('staymanager_auto_backup')) {
        const autoSnapshot = {
          properties: appState.properties,
          bookings: appState.bookings,
          turnovers: appState.turnovers,
          expenses: appState.expenses,
          contacts: appState.contacts,
          maintenanceTeam: appState.contacts,
          maintenanceTasks: appState.turnovers,
          promotionalMedia: appState.promotionalMedia,
          settings: appState.settings,
          licenseKey: appState.licenseKey,
          isLicensed: appState.isLicensed,
          isMasterAdmin: appState.isMasterAdmin,
          version: savedVersion,
          backupDate: new Date().toISOString()
        };
        localStorage.setItem('staymanager_auto_backup', JSON.stringify(autoSnapshot));
      }

      // 2. Backward-compatible field safety migrations:
      // Ensure all properties have valid property types and room numbers
      if (Array.isArray(appState.properties)) {
        appState.properties.forEach(p => {
          if (!p.propType) p.propType = 'entire';
          if (p.roomNo === undefined) p.roomNo = '';
        });
      }

      // Ensure all bookings have rental types and tenant particulars & auto-settle balances for confirmed / completed stays
      if (Array.isArray(appState.bookings)) {
        appState.bookings.forEach(b => {
          if (!b.rentalType) b.rentalType = 'daily';
          if (b.guestNric === undefined) b.guestNric = '';
          if (b.guestEmail === undefined) b.guestEmail = '';
          if (b.guestAddress === undefined) b.guestAddress = '';
          // If status is Fully Paid (confirmed), In-House, or Checked-Out, ensure balance is 0 and depositPaid equals totalAmount
          if ((b.status === 'confirmed' || b.status === 'checked-in' || b.status === 'checked-out') && (b.balance > 0 || b.depositPaid < b.totalAmount)) {
            b.depositPaid = b.totalAmount;
            b.balance = 0;
          }
        });
      }

      // Ensure contacts array exists
      if (!Array.isArray(appState.contacts) || appState.contacts.length === 0) {
        const savedContacts = localStorage.getItem(STORAGE_KEYS.CONTACTS);
        if (savedContacts) {
          try {
            appState.contacts = JSON.parse(savedContacts);
          } catch(e) {
            appState.contacts = [...DEFAULT_CONTACTS];
          }
        } else {
          appState.contacts = [...DEFAULT_CONTACTS];
        }
      }

      // Ensure promotionalMedia array exists
      if (!Array.isArray(appState.promotionalMedia) || appState.promotionalMedia.length === 0) {
        const savedPromo = localStorage.getItem(STORAGE_KEYS.PROMO_MEDIA);
        if (savedPromo) {
          try {
            appState.promotionalMedia = JSON.parse(savedPromo);
          } catch(e) {
            appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];
          }
        } else {
          appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];
        }
      }

      // Ensure settings have default language
      if (!appState.settings.language) {
        appState.settings.language = 'en';
      }

      // Save updated version
      localStorage.setItem(STORAGE_KEYS.VERSION, APP_VERSION);
      saveToStorage();

      // Show toast if upgrading from a previous version
      if (savedVersion !== '1.0.0' && savedVersion !== APP_VERSION) {
        setTimeout(() => {
          showToast(t('toast_app_updated'));
        }, 1000);
      }
    }
  } catch (err) {
    console.error('Data migration note:', err);
  }
}

function saveToStorage() {
  localStorage.setItem(STORAGE_KEYS.PROPERTIES, JSON.stringify(appState.properties));
  localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(appState.bookings));
  localStorage.setItem(STORAGE_KEYS.TURNOVERS, JSON.stringify(appState.turnovers));
  localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(appState.expenses));
  localStorage.setItem(STORAGE_KEYS.CONTACTS, JSON.stringify(appState.contacts));
  localStorage.setItem(STORAGE_KEYS.PROMO_MEDIA, JSON.stringify(appState.promotionalMedia));
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(appState.settings));
  if (appState.isLicensed && appState.licenseKey) {
    localStorage.setItem(STORAGE_KEYS.LICENSE, JSON.stringify({ key: appState.licenseKey, isLicensed: true, activatedAt: new Date().toISOString() }));
    localStorage.setItem('staymanager_license_v2', JSON.stringify({ key: appState.licenseKey, isLicensed: true, activatedAt: new Date().toISOString() }));
    localStorage.setItem('staymanager_license_permanent', appState.licenseKey);
    localStorage.setItem('staymanager_is_licensed_forever', 'true');
    localStorage.setItem('staymanager_license_activated', 'true');
  }
}

// ==========================================================================
// 2B. PWA LIVE UPDATE ENGINE & SEAMLESS MIGRATIONS
// ==========================================================================

let swRegistration = null;
let newWorkerWaiting = null;

function initPWAUpdateService() {
  if (!('serviceWorker' in navigator)) return;

  navigator.serviceWorker.register('./sw.js').then(reg => {
    swRegistration = reg;

    // Check if there is already a worker waiting to activate
    if (reg.waiting) {
      newWorkerWaiting = reg.waiting;
      showUpdateBanner();
    }

    reg.addEventListener('updatefound', () => {
      const newWorker = reg.installing;
      if (!newWorker) return;

      newWorker.addEventListener('statechange', () => {
        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
          newWorkerWaiting = newWorker;
          showUpdateBanner();
        }
      });
    });
  }).catch(err => {
    console.log('SW registration note:', err);
  });

  // When the new worker takes control, reload smoothly
  let isRefreshing = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (isRefreshing) return;
    isRefreshing = true;
    window.location.reload();
  });

  // Check for updates automatically on startup and every 15 minutes
  setTimeout(() => checkForAppUpdates(false), 1500);
  setInterval(() => checkForAppUpdates(false), 15 * 60 * 1000);
}

function showUpdateBanner() {
  const banner = document.getElementById('appUpdateBanner');
  if (banner) {
    banner.classList.add('active');
  }
}

function dismissUpdateBanner() {
  const banner = document.getElementById('appUpdateBanner');
  if (banner) {
    banner.classList.remove('active');
  }
}

async function applyAppUpdate() {
  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Mengemas kini aplikasi ke versi terkini...' : 'Updating application to latest version...');
  try {
    if (newWorkerWaiting) {
      newWorkerWaiting.postMessage({ type: 'SKIP_WAITING' });
    }
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      for (const r of regs) {
        await r.update();
      }
    }
  } catch (e) {
    console.warn('Update note:', e);
  }

  setTimeout(() => {
    const cleanUrl = window.location.href.split('?')[0];
    window.location.replace(`${cleanUrl}?v=${Date.now()}`);
  }, 450);
}

async function forcePurgeCacheAndReload() {
  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Membersihkan cache & memuat semula...' : 'Purging cache & reloading fresh...');
  try {
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }
  } catch (e) {
    console.warn('Purge cache error:', e);
  }
  setTimeout(() => {
    const cleanUrl = window.location.href.split('?')[0];
    window.location.replace(`${cleanUrl}?v=${Date.now()}`);
  }, 350);
}

async function checkForAppUpdates(isManual = false) {
  if (isManual) {
    showToast(t('toast_checking_updates'));
  }

  try {
    // 1. Tell the service worker registration to check the server for new sw.js
    if (swRegistration) {
      await swRegistration.update();
    }

    // 2. Fetch version.json directly with cache-busting timestamp
    const res = await fetch(`./version.json?t=${Date.now()}`);
    if (res.ok) {
      const verData = await res.json();
      if (verData && verData.version && verData.version !== APP_VERSION) {
        showUpdateBanner();
        if (isManual) {
          showToast(`${t('update_banner_title')} (v${verData.version})`);
        }
        return;
      } else {
        dismissUpdateBanner();
      }
    }

    if (isManual) {
      const isBM = appState.settings.language === 'bm';
      setTimeout(() => {
        showToast(isBM 
          ? `✨ Aplikasi adalah versi terkini (v${APP_VERSION})!` 
          : `✨ App is up to date (v${APP_VERSION})!`);
      }, 400);
    }
  } catch (e) {
    if (isManual) {
      const isBM = appState.settings.language === 'bm';
      showToast(isBM 
        ? `✨ Aplikasi adalah versi terkini (v${APP_VERSION})!` 
        : `✨ App is up to date (v${APP_VERSION})!`);
    }
  }
}

function downloadSafetySnapshot() {
  exportDataBackup();
  showToast(t('toast_safety_saved'));
}

function seedDemoData() {
  appState.properties = [...INITIAL_PROPERTIES];
  
  const today = new Date();
  const formatDate = (d) => d.toISOString().split('T')[0];

  const dMinus2 = new Date(today); dMinus2.setDate(today.getDate() - 2);
  const dMinus1 = new Date(today); dMinus1.setDate(today.getDate() - 1);
  const dToday = new Date(today);
  const dPlus1 = new Date(today); dPlus1.setDate(today.getDate() + 1);
  const dPlus2 = new Date(today); dPlus2.setDate(today.getDate() + 2);
  const dPlus4 = new Date(today); dPlus4.setDate(today.getDate() + 4);
  const dPlus6 = new Date(today); dPlus6.setDate(today.getDate() + 6);
  const dPlus8 = new Date(today); dPlus8.setDate(today.getDate() + 8);

  appState.bookings = [
    {
      id: 'b-demo-1',
      propertyId: 'prop-1',
      rentalType: 'daily',
      guestName: 'Sarah Jenkins',
      guestPhone: '+60123456789',
      guestNric: '900412-14-5588',
      guestEmail: 'sarah.j@example.com',
      guestAddress: 'No 45, Jalan Ampang Hilir, 55000 Kuala Lumpur',
      guestCount: 4,
      checkIn: formatDate(dMinus2),
      checkOut: formatDate(dToday),
      nights: 2,
      nightlyRate: 280,
      cleaningFee: 60,
      securityDeposit: 100,
      totalAmount: 720,
      depositPaid: 720,
      balance: 0,
      status: 'checked-in',
      channel: 'whatsapp',
      notes: 'Family vacation. Key PIN 5829# sent. Security deposit RM 100 held.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'b-demo-2',
      propertyId: 'prop-2',
      rentalType: 'daily',
      guestName: 'David Lee',
      guestPhone: '+60198765432',
      guestNric: '920820-01-6789',
      guestEmail: 'david.lee@outlook.com',
      guestAddress: 'Block B-12-3, Sri Petaling, 57000 KL',
      guestCount: 2,
      checkIn: formatDate(dToday),
      checkOut: formatDate(dPlus2),
      nights: 2,
      nightlyRate: 150,
      cleaningFee: 30,
      securityDeposit: 50,
      totalAmount: 380,
      depositPaid: 380,
      balance: 0,
      status: 'confirmed',
      channel: 'airbnb',
      notes: 'Fully paid! Booked Villa Impian Master Bedroom. Arriving at 4:00 PM.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'b-demo-3',
      propertyId: 'prop-3',
      rentalType: 'daily',
      guestName: 'Ahmad Faiz',
      guestPhone: '+60176543210',
      guestNric: '951104-10-5231',
      guestEmail: 'ahmad.faiz@gmail.com',
      guestAddress: 'No 18, Jalan Melati 3, 40000 Shah Alam',
      guestCount: 1,
      checkIn: formatDate(dPlus2),
      checkOut: formatDate(dPlus4),
      nights: 2,
      nightlyRate: 100,
      cleaningFee: 25,
      securityDeposit: 50,
      totalAmount: 275,
      depositPaid: 100,
      balance: 175,
      status: 'booked',
      channel: 'whatsapp',
      notes: 'Room 2 booking fee paid RM 100. Balance due before check-in.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'b-demo-4',
      propertyId: 'prop-1',
      rentalType: 'daily',
      guestName: 'Chloe Lim',
      guestPhone: '+60112345678',
      guestNric: '',
      guestEmail: 'chloe@example.com',
      guestAddress: '',
      guestCount: 2,
      checkIn: formatDate(dPlus4),
      checkOut: formatDate(dPlus6),
      nights: 2,
      nightlyRate: 280,
      cleaningFee: 60,
      securityDeposit: 100,
      totalAmount: 720,
      depositPaid: 0,
      balance: 720,
      status: 'quotation',
      channel: 'whatsapp',
      notes: 'Enquiry received for Sunset Ocean Villa. Quotation sent on WhatsApp.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'b-demo-5',
      propertyId: 'prop-2',
      rentalType: 'monthly',
      guestName: 'Dr. Zulkifli Rahman',
      guestPhone: '+60133445566',
      guestNric: '780612-03-5123',
      guestEmail: 'dr.zul@hospital.gov.my',
      guestAddress: 'No 99, Lorong Seri Teruntum, 25000 Kuantan, Pahang',
      guestCount: 1,
      checkIn: formatDate(dToday),
      checkOut: formatDate(new Date(today.getFullYear(), today.getMonth() + 6, today.getDate())),
      monthlyStart: formatDate(dToday),
      monthlyDuration: 6,
      monthlyRate: 750,
      rentalDeposit: 750,
      utilitiesDeposit: 200,
      agreementFee: 100,
      totalAmount: 1800,
      depositPaid: 1800,
      balance: 0,
      status: 'checked-in',
      channel: 'direct',
      notes: '6-Month Master Bedroom tenancy. Agreement signed & deposit settled.',
      createdAt: new Date().toISOString()
    }
  ];

  appState.turnovers = [
    {
      id: 't-demo-1',
      propertyId: 'prop-1',
      bookingId: 'b-demo-1',
      date: formatDate(dToday),
      status: 'pending',
      cleanerName: 'Kak Siti (Cleaner)',
      cleanerPhone: '+60129998877',
      checklist: [
        { text: 'Strip & wash bedsheets & pillowcases', done: false },
        { text: 'Sanitize bathroom & provide fresh towels', done: false },
        { text: 'Restock toiletries, coffee & mineral water', done: false },
        { text: 'Reset Smart Lock PIN code (5829#)', done: false },
        { text: 'Check air-conditioners & TV remotes', done: false },
        { text: 'Empty all trash bins', done: false }
      ]
    }
  ];

  appState.expenses = [
    {
      id: 'exp-1',
      propertyId: 'prop-1',
      date: formatDate(dMinus2),
      category: 'cleaning',
      description: 'Turnover deep cleaning fee',
      amount: 60
    },
    {
      id: 'exp-2',
      propertyId: 'prop-1',
      date: formatDate(dMinus1),
      category: 'supplies',
      description: 'Restocked shampoo, body wash & coffee packets',
      amount: 45
    },
    {
      id: 'exp-3',
      propertyId: 'prop-2',
      date: formatDate(dMinus2),
      category: 'utilities',
      description: 'High-speed WiFi monthly subscription',
      amount: 89
    }
  ];

  appState.contacts = [...DEFAULT_CONTACTS];
  appState.promotionalMedia = [...DEFAULT_PROMO_MEDIA];

  saveToStorage();
  showToast('Demo data loaded with 2 homestays & sample bookings!');
}

// ==========================================================================
// 3. EVENT LISTENERS & NAVIGATION
// ==========================================================================

function setupEventListeners() {
  // Bottom Navigation Tabs
  document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
    item.addEventListener('click', () => {
      const tab = item.getAttribute('data-tab');
      switchTab(tab);
    });
  });

  // 0. Global Delegated Click Listeners (Must register first so they are never blocked by any missing DOM elements)
  document.addEventListener('click', (e) => {
    const quickDownloadAgrBtn = e.target.closest('.btn-quick-download-agreement');
    if (quickDownloadAgrBtn) {
      e.preventDefault();
      e.stopPropagation();
      const bid = quickDownloadAgrBtn.getAttribute('data-bid');
      const b = (bid ? appState.bookings.find(x => String(x.id) === String(bid)) : null) || appState.activeWaBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'preview');
      setTimeout(() => {
        downloadAgreementPdf();
      }, 400);
      return;
    }

    const agrBtn = e.target.closest('.btn-open-agreement');
    if (agrBtn) {
      e.preventDefault();
      e.stopPropagation();
      const bid = agrBtn.getAttribute('data-bid');
      const b = (bid ? appState.bookings.find(x => String(x.id) === String(bid)) : null) || appState.activeWaBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'preview');
    }
  });

  // Header quick buttons
  document.getElementById('btnLangToggle')?.addEventListener('click', toggleLanguage);
  document.getElementById('btnThemeToggle')?.addEventListener('click', toggleTheme);
  document.getElementById('btnDemoToggle')?.addEventListener('click', () => {
    if (appState.isLicensed) {
      openProSystemModal();
    } else {
      openLicenseModal();
    }
  });

  const btnHeaderCheckUp = document.getElementById('btnHeaderCheckUpdates');
  if (btnHeaderCheckUp) {
    btnHeaderCheckUp.addEventListener('click', () => checkForAppUpdates(true));
  }

  const btnOpenAgrGen = document.getElementById('btnOpenAgreementGen');
  if (btnOpenAgrGen) {
    btnOpenAgrGen.addEventListener('click', () => {
      openAgreementModal(null, 'preview');
    });
  }

  // Pro System Hub Modal Handlers
  const btnClosePro = document.getElementById('btnCloseProSystemModal');
  if (btnClosePro) btnClosePro.addEventListener('click', closeProSystemModal);

  const btnProGuide = document.getElementById('btnProModalReadGuide');
  if (btnProGuide) {
    btnProGuide.addEventListener('click', () => {
      closeProSystemModal();
      openUserGuideModal();
    });
  }

  const btnProUp = document.getElementById('btnProModalCheckUpdate');
  if (btnProUp) {
    btnProUp.addEventListener('click', () => {
      closeProSystemModal();
      checkForAppUpdates(true);
    });
  }

  const btnProBak = document.getElementById('btnProModalBackup');
  if (btnProBak) {
    btnProBak.addEventListener('click', () => {
      closeProSystemModal();
      exportDataBackup();
    });
  }

  const btnProSet = document.getElementById('btnProModalOpenSettings');
  if (btnProSet) {
    btnProSet.addEventListener('click', () => {
      closeProSystemModal();
      switchTab('settings');
    });
  }

  // Language selector in Settings
  const langSelect = document.getElementById('settingLanguageSelect');
  if (langSelect) {
    langSelect.addEventListener('change', (e) => setLanguage(e.target.value));
  }

  // Property Switcher '+ Add' button
  document.getElementById('btnAddPropertyPill')?.addEventListener('click', () => openPropertyModal());

  // Dashboard quick triggers
  document.getElementById('btnSeeAllBookings')?.addEventListener('click', () => switchTab('bookings'));
  document.getElementById('btnManageProperties')?.addEventListener('click', () => switchTab('settings'));

  // Floating Action Button
  document.getElementById('fabAddBooking')?.addEventListener('click', () => openBookingModal());

  // Calendar Controls
  document.getElementById('calPrevMonth')?.addEventListener('click', () => changeCalMonth(-1));
  document.getElementById('calNextMonth')?.addEventListener('click', () => changeCalMonth(1));
  document.getElementById('btnQuickBookForDate')?.addEventListener('click', () => {
    openBookingModal(null, appState.selectedCalDate);
  });

  // Calendar Mode Selector (Check-In vs Check-Out vs Stays)
  document.querySelectorAll('#calModeSelector .cal-mode-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const mode = pill.getAttribute('data-cal-filter') || 'checkin';
      appState.calFilterMode = mode;
      document.querySelectorAll('#calModeSelector .cal-mode-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      renderCalendarTab();
    });
  });

  document.getElementById('calTabIncoming')?.addEventListener('click', () => {
    appState.calListingMode = 'incoming';
    document.querySelectorAll('.cal-day-cell').forEach(c => c.classList.remove('selected'));
    renderCalendarListing();
  });
  document.getElementById('calTabSelected')?.addEventListener('click', () => {
    appState.calListingMode = 'selected';
    renderCalendarListing();
  });

  // Bookings Search & Filter
  document.getElementById('bookingSearchInput')?.addEventListener('input', renderBookingsTab);
  document.querySelectorAll('#bookingStatusFilters .filter-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#bookingStatusFilters .filter-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      renderBookingsTab();
    });
  });

  // Modals close buttons
  document.getElementById('btnCloseBookingModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCancelBookingModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnClosePropertyModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCancelPropertyModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCloseWaModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCloseExpenseModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCancelExpenseModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCloseGuestGuideModal')?.addEventListener('click', closeAllModals);
  document.getElementById('btnCloseLicenseModal')?.addEventListener('click', closeAllModals);
  
  // Refund Modal Close
  const closeRefund = document.getElementById('btnCloseRefundModal');
  if (closeRefund) closeRefund.addEventListener('click', closeAllModals);
  const cancelRefund = document.getElementById('btnCancelRefundModal');
  if (cancelRefund) cancelRefund.addEventListener('click', closeAllModals);

  // Monthly Invoices Modal Close
  const closeMInv = document.getElementById('btnCloseMonthlyInvoicesModal');
  if (closeMInv) closeMInv.addEventListener('click', closeAllModals);

  // Tenancy Agreement Global Triggers (ensures clicking works regardless of caller)
  const btnAgrHub = document.getElementById('btnOpenTenancyAgreementFromHub');
  if (btnAgrHub) {
    btnAgrHub.addEventListener('click', (e) => {
      e.stopPropagation();
      const b = appState.activeWaBooking || appState.activePdfBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'preview');
    });
  }

  const btnQuickAgrHub = document.getElementById('btnQuickDownloadAgreementFromHub');
  if (btnQuickAgrHub) {
    btnQuickAgrHub.addEventListener('click', (e) => {
      e.stopPropagation();
      const b = appState.activeWaBooking || appState.activePdfBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'preview');
      setTimeout(() => {
        downloadAgreementPdf();
      }, 400);
    });
  }

  const bannerAgrHub = document.getElementById('agrHubCalloutBanner');
  if (bannerAgrHub) {
    bannerAgrHub.addEventListener('click', () => {
      const b = appState.activeWaBooking || appState.activePdfBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      openAgreementModal(b, 'preview');
    });
  }

  const btnPdfAgrTab = document.getElementById('btnPdfTabAgreement');
  if (btnPdfAgrTab) {
    btnPdfAgrTab.addEventListener('click', () => {
      const b = appState.activePdfBooking || appState.activeWaBooking || appState.bookings.find(x => x.rentalType === 'monthly') || null;
      closePdfDocModal();
      openAgreementModal(b, 'preview');
    });
  }

  // Overlap Warning & Change Homestay Modals Close Handlers
  const closeOverlap = document.getElementById('btnCloseOverlapModal');
  if (closeOverlap) closeOverlap.addEventListener('click', closeAllModals);
  const dismissOverlap = document.getElementById('btnOverlapDismiss');
  if (dismissOverlap) dismissOverlap.addEventListener('click', closeAllModals);
  const closeChange = document.getElementById('btnCloseChangeHomestayModal');
  if (closeChange) closeChange.addEventListener('click', closeAllModals);
  const cancelChange = document.getElementById('btnCancelChangeHomestay');
  if (cancelChange) cancelChange.addEventListener('click', closeAllModals);

  // Change Homestay Form Submission
  const changeHomestayForm = document.getElementById('changeHomestayForm');
  if (changeHomestayForm) changeHomestayForm.addEventListener('submit', handleConfirmChangeHomestay);

  // In-App User Guide Modal Handlers
  const btnOpenGuideHeader = document.getElementById('btnOpenUserGuide');
  if (btnOpenGuideHeader) btnOpenGuideHeader.addEventListener('click', () => openUserGuideModal());

  const btnOpenGuideSettings = document.getElementById('btnOpenUserGuideSettings');
  if (btnOpenGuideSettings) btnOpenGuideSettings.addEventListener('click', () => openUserGuideModal());

  const closeGuideModal = document.getElementById('btnCloseUserGuideModal');
  if (closeGuideModal) closeGuideModal.addEventListener('click', closeAllModals);

  // Guide Language Segment Buttons
  document.querySelectorAll('#guideLangSegmented .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#guideLangSegmented .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const glang = btn.getAttribute('data-glang') || 'en';
      renderUserGuideAccordion(glang);
    });
  });

  // WhatsApp Monthly Controls dynamic triggers
  const waMonthSel = document.getElementById('waInvoiceMonthSelect');
  if (waMonthSel) {
    waMonthSel.addEventListener('change', (e) => {
      appState.activeWaMonthIndex = parseInt(e.target.value) || 1;
      renderWhatsAppPreview();
    });
  }

  const waExtraInp = document.getElementById('waInvoiceExtraInput');
  if (waExtraInp) {
    waExtraInp.addEventListener('input', renderWhatsAppPreview);
  }

  // License & Sales Event Handlers
  document.getElementById('btnOpenActivateModal')?.addEventListener('click', openLicenseModal);
  document.getElementById('btnBuyLicense')?.addEventListener('click', handleBuyLicenseRedirect);
  document.getElementById('btnBuyLicenseViaWa')?.addEventListener('click', handleBuyLicenseRedirect);
  document.getElementById('licenseForm')?.addEventListener('submit', handleActivateLicenseSubmit);

  // Admin License Generator Handlers
  const adminGenForm = document.getElementById('adminGenForm');
  if (adminGenForm) adminGenForm.addEventListener('submit', handleGenerateAdminLicense);
  const btnCopyMagic = document.getElementById('btnCopyMagicLink');
  if (btnCopyMagic) btnCopyMagic.addEventListener('click', handleCopyMagicLink);
  const btnSendBuyer = document.getElementById('btnSendBuyerWa');
  if (btnSendBuyer) btnSendBuyer.addEventListener('click', handleSendBuyerWa);

  const btnAdminCheck = document.getElementById('btnAdminCheckUpdates');
  if (btnAdminCheck) btnAdminCheck.addEventListener('click', () => checkForAppUpdates(true));
  const btnAdminGuide = document.getElementById('btnAdminOpenGuide');
  if (btnAdminGuide) btnAdminGuide.addEventListener('click', () => openUserGuideModal());

  // Rental Type Segmented Control (Daily vs Monthly)
  document.querySelectorAll('#rentalTypeSegmented .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#rentalTypeSegmented .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const type = btn.getAttribute('data-type');
      document.getElementById('bookingRentalType').value = type;
      setBookingFormRentalType(type);
      updateBookingModalPricing();
    });
  });

  // Booking Form Submission & Dynamic Pricing Calc
  document.getElementById('bookingForm')?.addEventListener('submit', handleSaveBooking);
  [
    'bookingCheckIn', 'bookingCheckOut', 'bookingNightlyRate', 'bookingCleaningFee', 'bookingSecurityDeposit',
    'bookingMonthlyStart', 'bookingMonthlyDuration', 'bookingMonthlyRate', 'bookingRentalDeposit',
    'bookingUtilitiesDeposit', 'bookingAgreementFee', 'bookingPropertySelect'
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', updateBookingModalPricing);
      el.addEventListener('change', updateBookingModalPricing);
      if (['bookingCheckIn', 'bookingCheckOut', 'bookingMonthlyStart', 'bookingMonthlyDuration', 'bookingPropertySelect'].includes(id)) {
        el.addEventListener('input', checkBookingModalOverlap);
        el.addEventListener('change', checkBookingModalOverlap);
      }
    }
  });

  // Auto-sync Rental Deposit to 1 Month Rental by default
  const mRateEl = document.getElementById('bookingMonthlyRate');
  const rDepEl = document.getElementById('bookingRentalDeposit');
  if (mRateEl && rDepEl) {
    mRateEl.addEventListener('input', () => {
      if (rDepEl.dataset.customized !== 'true') {
        rDepEl.value = mRateEl.value;
      }
    });
    rDepEl.addEventListener('input', () => {
      rDepEl.dataset.customized = (rDepEl.value !== mRateEl.value) ? 'true' : 'false';
    });
  }

  // Tenancy Deposit Refund Form
  const refundForm = document.getElementById('depositRefundForm');
  if (refundForm) refundForm.addEventListener('submit', handleProcessDepositRefund);
  [
    'refundRentalDepInput', 'refundUtilitiesDepInput', 'refundDeductUtilitiesInput', 'refundDeductRepairsInput'
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', updateDepositRefundCalculation);
      el.addEventListener('change', updateDepositRefundCalculation);
    }
  });

  // Property Form Submission & Modals
  document.getElementById('propertyForm')?.addEventListener('submit', handleSaveProperty);
  document.getElementById('btnAddNewPropertyModal')?.addEventListener('click', () => openPropertyModal());

  // Expense Buttons & Form
  const openExpModal = () => openExpenseModal();
  document.getElementById('btnAddExpenseBtn')?.addEventListener('click', openExpModal);
  document.getElementById('btnAddExpenseBtn2')?.addEventListener('click', openExpModal);
  document.getElementById('expenseForm')?.addEventListener('submit', handleSaveExpense);

  // WhatsApp Modal Buttons & Template Switcher
  document.querySelectorAll('.wa-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.wa-tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tmpl = btn.getAttribute('data-template');
      appState.activeWaTemplate = tmpl;

      // Toggle quotation controls
      const quotationControls = document.getElementById('waQuotationControls');
      if (quotationControls) {
        quotationControls.classList.toggle('hidden', tmpl !== 'quotation');
      }

      // Toggle monthly controls
      const monthlyControls = document.getElementById('waMonthlyControls');
      if (monthlyControls) {
        const isMonthly = appState.activeWaBooking?.rentalType === 'monthly';
        monthlyControls.classList.toggle('hidden', !(isMonthly && (tmpl === 'monthly_invoice' || tmpl === 'monthly_rent_receipt')));
      }

      renderWhatsAppPreview();
    });
  });

  document.getElementById('waQuotationValidityInput')?.addEventListener('input', (e) => {
    if (appState.activeWaBooking) {
      appState.activeWaBooking.quotationValidityDays = parseInt(e.target.value) || 3;
    }
    renderWhatsAppPreview();
  });

  // Corporate & Office PDF Modal Wiring (v2.6.5)
  document.getElementById('btnOpenPdfModalFromWa')?.addEventListener('click', () => {
    const b = appState.activeWaBooking || (appState.bookings && appState.bookings[0]);
    if (b) {
      const tmpl = appState.activeWaTemplate;
      const docType = (tmpl === 'deposit_receipt') 
        ? 'deposit_receipt' 
        : (tmpl === 'full_receipt' || tmpl === 'monthly_rent_receipt' || tmpl === 'refund_receipt') 
          ? 'receipt' 
          : (tmpl === 'monthly_invoice' || tmpl === 'payment') 
            ? 'invoice' 
            : 'quotation';
      closeAllModals();
      openPdfDocModal(b, docType);
    } else {
      showToast(appState.settings.language === 'bm' ? 'Sila pilih tempahan terlebih dahulu.' : 'Please select a booking first.');
    }
  });

  document.getElementById('btnClosePdfModal')?.addEventListener('click', closePdfDocModal);
  document.getElementById('btnClosePdfModalBtn')?.addEventListener('click', closePdfDocModal);

  document.getElementById('btnPdfTabQuotation')?.addEventListener('click', () => setPdfDocType('quotation'));
  document.getElementById('btnPdfTabInvoice')?.addEventListener('click', () => setPdfDocType('invoice'));
  document.getElementById('btnPdfTabDeposit')?.addEventListener('click', () => setPdfDocType('deposit_receipt'));
  document.getElementById('btnPdfTabReceipt')?.addEventListener('click', () => setPdfDocType('receipt'));

  document.getElementById('btnPdfLangBM')?.addEventListener('click', () => setPdfLanguage('bm'));
  document.getElementById('btnPdfLangEN')?.addEventListener('click', () => setPdfLanguage('en'));

  document.getElementById('pdfQuotationValidityInput')?.addEventListener('input', (e) => {
    setPdfQuotationValidity(e.target.value);
  });

  document.querySelectorAll('.pdf-validity-preset').forEach(btn => {
    btn.addEventListener('click', () => {
      const days = btn.getAttribute('data-days');
      setPdfQuotationValidity(days);
    });
  });

  document.getElementById('pdfDepositAmountInput')?.addEventListener('input', (e) => {
    const val = parseFloat(e.target.value) || 0;
    if (appState.activePdfBooking) {
      appState.activePdfBooking.depositPaid = val;
      appState.activePdfBooking.balance = Math.max(0, (appState.activePdfBooking.totalAmount || 0) - val);
      saveToStorage();
    }
    updatePdfDocView();
  });

  document.getElementById('btnPdfResetDeposit')?.addEventListener('click', () => {
    if (appState.activePdfBooking) {
      const orig = Math.round((appState.activePdfBooking.totalAmount || 0) * (appState.settings.defaultDepositPct || 30) / 100);
      appState.activePdfBooking.depositPaid = orig;
      appState.activePdfBooking.balance = Math.max(0, (appState.activePdfBooking.totalAmount || 0) - orig);
      const depInput = document.getElementById('pdfDepositAmountInput');
      if (depInput) depInput.value = orig;
      saveToStorage();
      updatePdfDocView();
    }
  });

  document.getElementById('pdfPaymentRefInput')?.addEventListener('input', (e) => {
    if (appState.activePdfBooking) {
      appState.activePdfBooking.lastPaymentRef = e.target.value;
      saveToStorage();
    }
    updatePdfDocView();
  });

  document.getElementById('pdfClientCompanyInput')?.addEventListener('input', (e) => {
    if (appState.activePdfBooking) {
      appState.activePdfBooking.guestCompany = e.target.value;
      saveToStorage();
    }
    updatePdfDocView();
  });

  document.getElementById('pdfLpoRefInput')?.addEventListener('input', (e) => {
    if (appState.activePdfBooking) {
      appState.activePdfBooking.lpoRef = e.target.value;
      saveToStorage();
    }
    updatePdfDocView();
  });

  document.getElementById('btnPrintPdfDoc')?.addEventListener('click', printPdfDocument);
  document.getElementById('btnDownloadPdfDoc')?.addEventListener('click', downloadPdfDocument);
  document.getElementById('btnViewPdfTab')?.addEventListener('click', viewPdfInNewTab);
  document.getElementById('btnSharePdfWa')?.addEventListener('click', sharePdfViaWhatsApp);
  document.getElementById('btnPromptSendWa')?.addEventListener('click', sharePdfViaWhatsApp);
  document.getElementById('btnPromptDownload')?.addEventListener('click', downloadPdfDocument);
  document.getElementById('btnPromptViewTab')?.addEventListener('click', viewPdfInNewTab);
  document.getElementById('btnPromptDismiss')?.addEventListener('click', () => {
    const banner = document.getElementById('pdfWaPromptBanner');
    if (banner) banner.style.display = 'none';
  });

  // Direct 1-Click PDF Download from WhatsApp Modal
  document.getElementById('btnDirectDownloadPdfFromWa')?.addEventListener('click', () => {
    const b = appState.activeWaBooking || (appState.bookings && appState.bookings[0]);
    if (b) {
      const tmpl = appState.activeWaTemplate;
      const docType = (tmpl === 'deposit_receipt') 
        ? 'deposit_receipt' 
        : (tmpl === 'full_receipt' || tmpl === 'monthly_rent_receipt' || tmpl === 'refund_receipt') 
          ? 'receipt' 
          : (tmpl === 'monthly_invoice' || tmpl === 'payment') 
            ? 'invoice' 
            : 'quotation';
      closeAllModals();
      openPdfDocModal(b, docType);
      setTimeout(() => {
        downloadPdfDocument();
      }, 350);
    } else {
      showToast(appState.settings.language === 'bm' ? 'Sila pilih tempahan terlebih dahulu.' : 'Please select a booking first.');
    }
  });

  // Booking Form Status Change -> Toggle Quotation Validity Group & Auto-Settle Full Balance
  const bookingStatusSel = document.getElementById('bookingStatusSelect');
  if (bookingStatusSel) {
    bookingStatusSel.addEventListener('change', () => {
      const st = bookingStatusSel.value;
      const validityGroup = document.getElementById('bookingQuotationValidityGroup');
      if (validityGroup) {
        validityGroup.style.display = st === 'quotation' ? 'block' : 'none';
      }

      // Auto-compute current total in modal
      const rType = document.getElementById('bookingRentalType')?.value || 'daily';
      let currentTotal = 0;
      if (rType === 'monthly') {
        const mRate = parseFloat(document.getElementById('bookingMonthlyRate')?.value) || 0;
        const rDep = parseFloat(document.getElementById('bookingRentalDeposit')?.value) || 0;
        const uDep = parseFloat(document.getElementById('bookingUtilitiesDeposit')?.value) || 0;
        const aFee = parseFloat(document.getElementById('bookingAgreementFee')?.value) || 0;
        currentTotal = mRate + rDep + uDep + aFee;
      } else {
        const checkInVal = document.getElementById('bookingCheckIn')?.value;
        const checkOutVal = document.getElementById('bookingCheckOut')?.value;
        const rateVal = parseFloat(document.getElementById('bookingNightlyRate')?.value) || 0;
        const cleanVal = parseFloat(document.getElementById('bookingCleaningFee')?.value) || 0;
        const secDep = parseFloat(document.getElementById('bookingSecurityDeposit')?.value) || 0;
        let nights = 0;
        if (checkInVal && checkOutVal) {
          const d1 = new Date(checkInVal);
          const d2 = new Date(checkOutVal);
          const diff = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
          nights = diff > 0 ? diff : 0;
        }
        currentTotal = (nights * rateVal) + cleanVal + secDep;
      }

      const depInput = document.getElementById('bookingDepositPaid');
      const hintEl = document.getElementById('bookingDepositPaidHint');
      const isBM = appState.settings.language === 'bm';

      if (st === 'confirmed' || st === 'checked-in' || st === 'checked-out') {
        if (depInput && currentTotal > 0) {
          depInput.value = currentTotal;
        }
        if (hintEl) {
          hintEl.textContent = isBM ? '✓ Bayaran penuh disahkan. Baki akan menjadi RM 0.00' : '✓ Full payment confirmed. Balance will be settled to RM 0.00';
          hintEl.style.color = 'var(--success)';
        }
      } else if (st === 'quotation') {
        if (depInput) depInput.value = 0;
        if (hintEl) {
          hintEl.textContent = isBM ? 'Sebut harga sahaja — tiada bayaran dibuat.' : 'Quotation only — no payment made yet.';
          hintEl.style.color = 'var(--text-muted)';
        }
      } else if (st === 'booked') {
        if (hintEl) {
          hintEl.textContent = isBM ? 'Deposit sebahagian dibayar. Baki akan dikutip sebelum daftar masuk.' : 'Partial deposit paid. Remaining balance due before check-in.';
          hintEl.style.color = 'var(--warning)';
        }
      } else {
        if (hintEl) hintEl.textContent = '';
      }
    });
  }

  document.getElementById('btnCopyWaText')?.addEventListener('click', handleCopyWaText);
  document.getElementById('btnSendWaDirect')?.addEventListener('click', handleSendWaDirect);

  // Deposit Presets in Booking Form
  document.getElementById('btnPresetDep30')?.addEventListener('click', () => applyDepositPreset(0.30, 'booked'));
  document.getElementById('btnPresetDep50')?.addEventListener('click', () => applyDepositPreset(0.50, 'booked'));
  document.getElementById('btnPresetDepFull')?.addEventListener('click', () => applyDepositPreset(1.0, 'confirmed'));
  document.getElementById('btnPresetDepZero')?.addEventListener('click', () => applyDepositPreset(0, 'quotation'));

  // Settings & Preferences
  document.getElementById('btnSavePreferences')?.addEventListener('click', handleSavePreferences);
  document.getElementById('btnSaveBankDetails')?.addEventListener('click', handleSaveBankDetails);
  document.getElementById('btnExportData')?.addEventListener('click', exportDataBackup);
  document.getElementById('btnImportDataInput')?.addEventListener('change', importDataBackup);
  const btnRestoreSnap = document.getElementById('btnRestoreAutoBackup');
  if (btnRestoreSnap) btnRestoreSnap.addEventListener('click', restoreAutoBackup);
  document.getElementById('btnLoadDemoData')?.addEventListener('click', seedDemoData);
  document.getElementById('btnResetAllData')?.addEventListener('click', resetAllData);

  // App Update System Event Listeners
  const btnApplyUpdate = document.getElementById('btnApplyAppUpdate');
  if (btnApplyUpdate) btnApplyUpdate.addEventListener('click', applyAppUpdate);

  const btnDismissUp = document.getElementById('btnDismissUpdate');
  if (btnDismissUp) btnDismissUp.addEventListener('click', dismissUpdateBanner);

  const btnCheckUp = document.getElementById('btnCheckForUpdates');
  if (btnCheckUp) btnCheckUp.addEventListener('click', () => checkForAppUpdates(true));

  const btnForcePurge = document.getElementById('btnForcePurgeCache');
  if (btnForcePurge) btnForcePurge.addEventListener('click', forcePurgeCacheAndReload);

  const btnSafetySnap = document.getElementById('btnDownloadSafetySnapshot');
  if (btnSafetySnap) btnSafetySnap.addEventListener('click', downloadSafetySnapshot);

  // Contact Modal & Team Directory
  const btnAddContact = document.getElementById('btnAddNewContactModal');
  if (btnAddContact) btnAddContact.addEventListener('click', () => openContactModal());

  const btnCloseContact = document.getElementById('btnCloseContactModal');
  if (btnCloseContact) btnCloseContact.addEventListener('click', closeAllModals);

  const btnCancelContact = document.getElementById('btnCancelContact');
  if (btnCancelContact) btnCancelContact.addEventListener('click', closeAllModals);

  const contactForm = document.getElementById('contactForm');
  if (contactForm) contactForm.addEventListener('submit', handleSaveContact);

  // Turnovers Quick Actions
  const btnTurnoverDir = document.getElementById('btnTurnoverTeamDir');
  if (btnTurnoverDir) {
    btnTurnoverDir.addEventListener('click', () => {
      switchTab('settings');
      setTimeout(() => {
        document.getElementById('settingsContactList')?.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    });
  }

  const btnTurnoverAlert = document.getElementById('btnTurnoverServiceAlert');
  if (btnTurnoverAlert) {
    btnTurnoverAlert.addEventListener('click', () => openServiceDispatchModal());
  }

  // Service & Supply Dispatch Modal
  const btnCloseDispatch = document.getElementById('btnCloseServiceDispatchModal');
  if (btnCloseDispatch) btnCloseDispatch.addEventListener('click', closeAllModals);

  [
    'dispatchRecipientSelect', 'dispatchPropertySelect', 'dispatchServiceTypeSelect',
    'dispatchUrgencySelect', 'dispatchIncludePinCheck'
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', renderServiceDispatchPreview);
  });

  const dispatchDetails = document.getElementById('dispatchDetailsInput');
  if (dispatchDetails) dispatchDetails.addEventListener('input', renderServiceDispatchPreview);

  const btnCopyDispatch = document.getElementById('btnCopyDispatchText');
  if (btnCopyDispatch) btnCopyDispatch.addEventListener('click', handleCopyServiceDispatchText);

  const btnSendDispatch = document.getElementById('btnSendDispatchWa');
  if (btnSendDispatch) btnSendDispatch.addEventListener('click', handleSendServiceDispatchWa);

  // Finance Selectors
  document.getElementById('financeMonthSelect')?.addEventListener('change', renderFinancesTab);
  document.getElementById('financeYearSelect')?.addEventListener('change', renderFinancesTab);
  if (typeof populateFinanceDateSelectors === 'function') populateFinanceDateSelectors();

  // Payment Proof & Receipt Modals Event Handlers
  const closePayProof = document.getElementById('btnClosePaymentProofModal');
  if (closePayProof) closePayProof.addEventListener('click', closeAllModals);

  const cancelPayProof = document.getElementById('btnCancelPaymentProofModal');
  if (cancelPayProof) cancelPayProof.addEventListener('click', closeAllModals);

  const closeReceiptViewer = document.getElementById('btnCloseReceiptViewerModal');
  if (closeReceiptViewer) closeReceiptViewer.addEventListener('click', closeAllModals);

  const closeReceiptViewerBtn = document.getElementById('btnCloseReceiptViewerBtn');
  if (closeReceiptViewerBtn) closeReceiptViewerBtn.addEventListener('click', closeAllModals);

  const closeLightbox = document.getElementById('btnCloseLightbox');
  if (closeLightbox) closeLightbox.addEventListener('click', closeAllModals);

  const lightboxModal = document.getElementById('receiptLightboxModal');
  if (lightboxModal) {
    lightboxModal.addEventListener('click', (e) => {
      if (e.target.id === 'receiptLightboxModal') closeAllModals();
    });
  }

  // Receipt File Upload Dropzone
  const dropzone = document.getElementById('receiptDropzone');
  const fileInput = document.getElementById('paymentProofFileInput');
  if (dropzone && fileInput) {
    dropzone.addEventListener('click', (e) => {
      if (e.target.closest('#btnRemoveReceiptImg') || e.target.closest('#btnViewReceiptPreview')) return;
      fileInput.click();
    });

    ['dragenter', 'dragover'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
      });
    });

    dropzone.addEventListener('drop', (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        handleReceiptFileSelected(e.dataTransfer.files[0]);
      }
    });

    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files.length > 0) {
        handleReceiptFileSelected(e.target.files[0]);
      }
    });
  }

  // Remove Receipt Image Button
  const btnRemoveReceipt = document.getElementById('btnRemoveReceiptImg');
  if (btnRemoveReceipt) {
    btnRemoveReceipt.addEventListener('click', (e) => {
      e.stopPropagation();
      document.getElementById('paymentProofImageData').value = '';
      document.getElementById('paymentProofImageName').value = '';
      document.getElementById('paymentProofFileInput').value = '';
      document.getElementById('receiptPreviewImg').src = '';
      document.getElementById('receiptUploadPrompt').style.display = 'block';
      document.getElementById('receiptPreviewContainer').style.display = 'none';
    });
  }

  // View Receipt Preview Button in Form Dropzone
  const btnViewReceiptPreview = document.getElementById('btnViewReceiptPreview');
  if (btnViewReceiptPreview) {
    btnViewReceiptPreview.addEventListener('click', (e) => {
      e.stopPropagation();
      const imgData = document.getElementById('paymentProofImageData').value;
      const fName = document.getElementById('paymentProofImageName').value || 'Receipt Preview';
      if (imgData) openReceiptLightbox(imgData, fName);
    });
  }

  // Bank Pills Quick Selector
  document.querySelectorAll('#paymentProofBankPills .bank-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#paymentProofBankPills .bank-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      const bankName = pill.getAttribute('data-bank');
      document.getElementById('paymentProofBankInput').value = bankName;
    });
  });

  // Paste Reference Number Helper
  const btnPasteRef = document.getElementById('btnPastePaymentRef');
  if (btnPasteRef) {
    btnPasteRef.addEventListener('click', async () => {
      try {
        if (navigator.clipboard && navigator.clipboard.readText) {
          const text = await navigator.clipboard.readText();
          if (text) {
            document.getElementById('paymentProofRefInput').value = text.trim();
            showToast(appState.settings.language === 'bm' ? 'No. Rujukan berjaya ditampal!' : 'Reference No. pasted!');
            return;
          }
        }
      } catch (err) {
        console.warn('Clipboard read error:', err);
      }
      document.getElementById('paymentProofRefInput').focus();
    });
  }

  // Payment Proof Type Selector Change
  const payTypeSelect = document.getElementById('paymentProofTypeSelect');
  if (payTypeSelect) {
    payTypeSelect.addEventListener('change', () => {
      const type = payTypeSelect.value;
      const bId = document.getElementById('paymentProofBookingId').value;
      const booking = appState.bookings.find(b => b.id === bId);
      
      const monthGroup = document.getElementById('paymentProofMonthIndexGroup');
      if (monthGroup) {
        monthGroup.style.display = (type === 'monthly_rent') ? 'block' : 'none';
      }

      if (booking) {
        let amt = 0;
        if (type === 'deposit') {
          amt = booking.depositPaid > 0 ? booking.depositPaid : Math.round(booking.totalAmount * (appState.settings.defaultDepositPct || 30) / 100);
        } else if (type === 'balance') {
          amt = booking.balance > 0 ? booking.balance : booking.totalAmount;
        } else if (type === 'full') {
          amt = booking.totalAmount;
        } else if (type === 'monthly_rent') {
          amt = booking.monthlyRate || 0;
        } else if (type === 'security_deposit') {
          amt = booking.securityDeposit || booking.utilitiesDeposit || 0;
        } else {
          amt = booking.balance > 0 ? booking.balance : 0;
        }
        document.getElementById('paymentProofAmountInput').value = amt;
      }
    });
  }

  // Save Payment Proof Form Submit
  const paymentProofForm = document.getElementById('paymentProofForm');
  if (paymentProofForm) {
    paymentProofForm.addEventListener('submit', handleSavePaymentProof);
  }

  // ==========================================
  // Promotional Media & Marketing Hub Listeners
  // ==========================================
  const btnOpenPromo = document.getElementById('btnOpenPromoMedia');
  if (btnOpenPromo) btnOpenPromo.addEventListener('click', () => openPromotionalMediaModal());

  const btnOpenPromoSettings = document.getElementById('btnOpenPromoMediaSettings');
  if (btnOpenPromoSettings) btnOpenPromoSettings.addEventListener('click', () => openPromotionalMediaModal());

  const btnClosePromo = document.getElementById('btnClosePromotionalMediaModal');
  if (btnClosePromo) btnClosePromo.addEventListener('click', closeAllModals);

  const btnAddPromo = document.getElementById('btnAddNewPromoMediaModal');
  if (btnAddPromo) btnAddPromo.addEventListener('click', () => openPromoMediaEditModal());

  const btnEmptyAddPromo = document.getElementById('btnEmptyAddPromoMedia');
  if (btnEmptyAddPromo) btnEmptyAddPromo.addEventListener('click', () => openPromoMediaEditModal());

  const btnClosePromoEdit = document.getElementById('btnClosePromoMediaEditModal');
  if (btnClosePromoEdit) btnClosePromoEdit.addEventListener('click', closeAllModals);

  const btnCancelPromoEdit = document.getElementById('btnCancelPromoMediaEdit');
  if (btnCancelPromoEdit) btnCancelPromoEdit.addEventListener('click', closeAllModals);

  const promoForm = document.getElementById('promoMediaEditForm');
  if (promoForm) promoForm.addEventListener('submit', savePromoMediaItem);

  // Promo Property Filter Change
  const promoPropFilter = document.getElementById('promoPropertyFilter');
  if (promoPropFilter) {
    promoPropFilter.addEventListener('change', (e) => {
      appState.selectedPromoPropertyId = e.target.value;
      renderPromotionalMediaList();
    });
  }

  // Promo Category Pills
  document.querySelectorAll('#promoCategoryFilter .cal-mode-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#promoCategoryFilter .cal-mode-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      appState.selectedPromoCategory = pill.getAttribute('data-category');
      renderPromotionalMediaList();
    });
  });

  // Promo Search Input
  const promoSearchInput = document.getElementById('promoSearchInput');
  if (promoSearchInput) {
    promoSearchInput.addEventListener('input', (e) => {
      appState.promoSearchQuery = e.target.value;
      renderPromotionalMediaList();
    });
  }

  // Promo Image File Upload Dropzone
  const promoDropzone = document.getElementById('promoImageDropzone');
  const promoFileInput = document.getElementById('promoMediaFileInput');
  if (promoDropzone && promoFileInput) {
    promoDropzone.addEventListener('click', (e) => {
      if (e.target.closest('#btnRemovePromoImage') || e.target.closest('#btnViewPromoImagePreview')) return;
      promoFileInput.click();
    });

    ['dragenter', 'dragover'].forEach(eventName => {
      promoDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        promoDropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      promoDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        promoDropzone.classList.remove('dragover');
      });
    });

    promoDropzone.addEventListener('drop', (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        handlePromoImageFileSelected(e.dataTransfer.files[0]);
      }
    });

    promoFileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files.length > 0) {
        handlePromoImageFileSelected(e.target.files[0]);
      }
    });
  }

  // Remove Promo Image Button
  const btnRemovePromoImg = document.getElementById('btnRemovePromoImage');
  if (btnRemovePromoImg) {
    btnRemovePromoImg.addEventListener('click', (e) => {
      e.stopPropagation();
      document.getElementById('promoMediaImageData').value = '';
      document.getElementById('promoMediaFileInput').value = '';
      document.getElementById('promoImagePreviewImg').src = '';
      document.getElementById('promoImageDropPrompt').style.display = 'block';
      document.getElementById('promoImagePreviewContainer').style.display = 'none';
    });
  }

  // View Promo Image Preview in Edit Modal
  const btnViewPromoPreview = document.getElementById('btnViewPromoImagePreview');
  if (btnViewPromoPreview) {
    btnViewPromoPreview.addEventListener('click', (e) => {
      e.stopPropagation();
      const imgData = document.getElementById('promoMediaImageData').value;
      const title = document.getElementById('promoMediaTitleInput').value || 'Image Preview';
      if (imgData) openReceiptLightbox(imgData, title);
    });
  }

  // Preset Template Button in Promo Edit Form
  const btnInsertPitch = document.getElementById('btnInsertPitchPreset');
  if (btnInsertPitch) btnInsertPitch.addEventListener('click', insertPromoPitchTemplate);

  // WhatsApp Quick Send Modal Listeners
  const btnClosePromoWa = document.getElementById('btnClosePromoWaQuickModal');
  if (btnClosePromoWa) btnClosePromoWa.addEventListener('click', closeAllModals);

  const btnCancelPromoWa = document.getElementById('btnCancelPromoWaQuick');
  if (btnCancelPromoWa) btnCancelPromoWa.addEventListener('click', closeAllModals);

  const btnExecutePromoWa = document.getElementById('btnExecutePromoWaSend');
  if (btnExecutePromoWa) btnExecutePromoWa.addEventListener('click', executePromoWaSend);

  const promoWaRecipient = document.getElementById('promoWaRecipientSelect');
  if (promoWaRecipient) {
    promoWaRecipient.addEventListener('change', (e) => {
      const isCustom = e.target.value === 'custom';
      const customGroup = document.getElementById('promoWaCustomPhoneGroup');
      const customInput = document.getElementById('promoWaCustomPhoneInput');
      if (customGroup) customGroup.style.display = isCustom ? 'block' : 'none';
      if (!isCustom && customInput) customInput.value = e.target.value;
    });
  }

  // WhatsApp Modal Attach Button
  const btnAttachPromo = document.getElementById('btnAttachPromoMediaWa');
  if (btnAttachPromo) btnAttachPromo.addEventListener('click', attachPromoMediaToWaMessage);

  // Universal Modal Dismissal: Click outside on backdrop or press Escape
  document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        closeAllModals();
      }
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeAllModals();
    }
  });
}

function applyDepositPreset(pct, targetStatus) {
  const checkInVal = document.getElementById('bookingCheckIn').value;
  const checkOutVal = document.getElementById('bookingCheckOut').value;
  const rateVal = parseFloat(document.getElementById('bookingNightlyRate').value) || 0;
  const cleanVal = parseFloat(document.getElementById('bookingCleaningFee').value) || 0;

  let nights = 0;
  if (checkInVal && checkOutVal) {
    const d1 = new Date(checkInVal);
    const d2 = new Date(checkOutVal);
    const diff = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
    nights = diff > 0 ? diff : 0;
  }

  const total = (nights * rateVal) + cleanVal;
  const depositAmount = Math.round(total * pct * 100) / 100;
  document.getElementById('bookingDepositPaid').value = depositAmount;
  if (targetStatus) {
    document.getElementById('bookingStatusSelect').value = targetStatus;
    const validityGroup = document.getElementById('bookingQuotationValidityGroup');
    if (validityGroup) {
      validityGroup.style.display = targetStatus === 'quotation' ? 'block' : 'none';
    }
  }
}

function handleSaveBankDetails() {
  appState.settings.bankName = document.getElementById('settingBankNameInput').value.trim() || 'Maybank';
  appState.settings.bankAccNum = document.getElementById('settingBankAccNumInput').value.trim() || '';
  appState.settings.bankAccHolder = document.getElementById('settingBankAccHolderInput').value.trim() || '';
  appState.settings.duitNow = document.getElementById('settingDuitNowInput').value.trim() || '';
  saveToStorage();
  showToast(t('Bank & payment details saved!'));
}

// ==========================================================================
// LANGUAGE / I18N SYSTEM
// ==========================================================================

function toggleLanguage() {
  const currentLang = appState.settings.language || 'en';
  const newLang = currentLang === 'en' ? 'bm' : 'en';
  setLanguage(newLang);
}

function setLanguage(lang) {
  appState.settings.language = lang;
  saveToStorage();
  applyLanguageUI();
  renderApp();
  showToast(lang === 'bm' ? '🇲🇾 Bahasa Melayu diaktifkan!' : '🇬🇧 English language activated!');
}

function applyLanguageUI() {
  const lang = appState.settings.language || 'en';

  // 1. Scan and translate all elements with data-i18n
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (key) {
      el.textContent = t(key);
    }
  });

  // 2. Scan and translate all elements with data-i18n-placeholder
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (key) {
      el.placeholder = t(key);
    }
  });

  // 3. Header language pill
  const langLabel = document.getElementById('currentLangLabel');
  if (langLabel) langLabel.textContent = lang.toUpperCase();

  // 4. Update language dropdown in settings
  const langSelect = document.getElementById('settingLanguageSelect');
  if (langSelect && langSelect.value !== lang) {
    langSelect.value = lang;
  }

  // 5. Header Subtitle
  const dateSub = document.getElementById('currentDateStr');
  if (dateSub) {
    const locale = lang === 'bm' ? 'ms-MY' : 'en-US';
    dateSub.textContent = new Date().toLocaleDateString(locale, { weekday: 'short', month: 'short', day: 'numeric' });
  }

  // 6. Navigation items
  const navItems = document.querySelectorAll('.bottom-nav .nav-item');
  if (navItems.length >= 6) {
    navItems[0].querySelector('span').textContent = t('nav_today');
    navItems[1].querySelector('span').textContent = t('nav_calendar');
    navItems[2].querySelector('span').textContent = t('nav_bookings');
    navItems[3].querySelector('span').textContent = t('nav_turnovers');
    navItems[4].querySelector('span').textContent = t('nav_finances');
    navItems[5].querySelector('span').textContent = t('nav_settings');
  }

  // 7. Booking status filter pills
  const filterPills = document.querySelectorAll('#bookingStatusFilters .filter-pill');
  if (filterPills.length >= 7) {
    filterPills[0].textContent = t('filter_all');
    filterPills[1].textContent = t('filter_quotations');
    filterPills[2].textContent = t('filter_booked');
    filterPills[3].textContent = t('filter_confirmed');
    filterPills[4].textContent = t('filter_inhouse');
    filterPills[5].textContent = t('filter_completed');
    filterPills[6].textContent = t('filter_blocked');
  }

  // 8. Calendar Weekdays
  const calWeekdays = document.querySelectorAll('.cal-weekdays span');
  if (calWeekdays.length === 7) {
    const dayKeys = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
    calWeekdays.forEach((span, idx) => {
      span.textContent = t(dayKeys[idx]);
    });
  }

  // 9. WhatsApp Template tabs
  const waTabs = document.querySelectorAll('.wa-template-selector .wa-tab-btn');
  waTabs.forEach(btn => {
    const template = btn.getAttribute('data-template');
    if (template === 'quotation') btn.textContent = t('wa_tab_quotation');
    else if (template === 'deposit_receipt') btn.textContent = t('wa_tab_deposit');
    else if (template === 'checkin_reminder') btn.textContent = t('wa_tab_checkin');
    else if (template === 'full_receipt') btn.textContent = t('wa_tab_full');
    else if (template === 'monthly_invoice') btn.textContent = t('wa_tab_invoice');
    else if (template === 'monthly_rent_receipt') btn.textContent = t('wa_tab_rent_receipt');
    else if (template === 'refund_receipt') btn.textContent = t('wa_tab_refund');
    else if (template === 'checkout') btn.textContent = t('wa_tab_checkout');
    else if (template === 'cleaner') btn.textContent = t('wa_tab_cleaner');
    else if (template === 'payment') btn.textContent = t('wa_tab_payment');
  });

  // 10. Rental Type segment buttons
  const dailySeg = document.querySelector('#rentalTypeSegmented [data-type="daily"]');
  const monthlySeg = document.querySelector('#rentalTypeSegmented [data-type="monthly"]');
  if (dailySeg) dailySeg.innerHTML = `<i class="fa-solid fa-sun"></i> ${t('type_daily')}`;
  if (monthlySeg) monthlySeg.innerHTML = `<i class="fa-solid fa-calendar-days"></i> ${t('type_monthly')}`;

  // 11. Booking status dropdown options
  const statusSelect = document.getElementById('bookingStatusSelect');
  if (statusSelect && statusSelect.options.length >= 7) {
    statusSelect.options[0].text = lang === 'bm' ? '📋 Sebut Harga / Quotation' : '📋 Quotation / Sebut Harga';
    statusSelect.options[1].text = lang === 'bm' ? '🟡 Ditempah (Deposit Dibayar)' : '🟡 Booked (Deposit Paid)';
    statusSelect.options[2].text = lang === 'bm' ? '🟢 Disahkan (Bayar Penuh)' : '🟢 Confirmed (Fully Paid)';
    statusSelect.options[3].text = lang === 'bm' ? '🔑 Sedang Menginap (Check-In)' : '🔑 In-House (Checked In)';
    statusSelect.options[4].text = lang === 'bm' ? '🏁 Selesai / Tamat Sewaan' : '🏁 Checked Out / Tenancy Ended';
    statusSelect.options[5].text = lang === 'bm' ? '🚫 Disekat / Penyelenggaraan' : '🚫 Blocked / Maintenance';
    statusSelect.options[6].text = lang === 'bm' ? '❌ Dibatalkan' : '❌ Cancelled';
  }

  // 12. Property Type dropdown options
  const propTypeSelect = document.getElementById('propertyTypeSelect');
  if (propTypeSelect && propTypeSelect.options.length >= 5) {
    propTypeSelect.options[0].text = t('cat_entire');
    propTypeSelect.options[1].text = t('cat_master');
    propTypeSelect.options[2].text = t('cat_medium');
    propTypeSelect.options[3].text = t('cat_single');
    propTypeSelect.options[4].text = t('cat_studio');
  }

  // 13. Expense Category dropdown options
  const expCatSelect = document.getElementById('expenseCategorySelect');
  if (expCatSelect && expCatSelect.options.length >= 6) {
    expCatSelect.options[0].text = t('cat_cleaning');
    expCatSelect.options[1].text = t('cat_utilities');
    expCatSelect.options[2].text = t('cat_supplies');
    expCatSelect.options[3].text = t('cat_maintenance');
    expCatSelect.options[4].text = t('cat_commission');
    expCatSelect.options[5].text = t('cat_other');
  }
}

// ==========================================================================
// LICENSE & PHONE-BOUND CRYPTOGRAPHIC ENGINE
// ==========================================================================

function normalizePhoneNumber(rawPhone) {
  if (!rawPhone) return '';
  let digits = rawPhone.replace(/[^0-9]/g, '');
  // Normalize Malaysian phone prefixes (01x -> 601x)
  if (digits.startsWith('01') && digits.length >= 10 && digits.length <= 11) {
    digits = '6' + digits;
  } else if (digits.startsWith('0') && digits.length >= 9) {
    digits = '6' + digits;
  }
  return digits;
}

function computeSimpleHash(str) {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash) + str.charCodeAt(i);
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16).toUpperCase().padStart(4, '0').slice(-4);
}

function generatePhoneLicenseKey(rawPhone) {
  const cleanPhone = normalizePhoneNumber(rawPhone);
  if (!cleanPhone || cleanPhone.length < 8) return null;

  const part1 = computeSimpleHash(cleanPhone + LICENSE_SECRET_SALT);
  const part2 = computeSimpleHash(LICENSE_SECRET_SALT + cleanPhone + 'PRO_2026');
  return `STAY-${cleanPhone}-${part1}-${part2}`;
}

function verifyLicenseKey(rawKey, targetPhone = null) {
  if (!rawKey) return { valid: false, isMaster: false, phone: null, reason: 'Empty key' };
  const key = rawKey.trim().toUpperCase();

  // 1. Check Master Admin Key (Secret Signature Check)
  if (isMasterAdminKey(key)) {
    return { valid: true, isMaster: true, phone: null, key };
  }

  // 2. Check Phone-Bound License Key: STAY-<CLEAN_PHONE>-<HASH1>-<HASH2>
  const parts = key.split('-');
  if (parts.length === 4 && parts[0] === 'STAY') {
    const keyPhone = parts[1];
    const expectedKey = generatePhoneLicenseKey(keyPhone);

    if (expectedKey === key) {
      if (targetPhone) {
        const cleanTarget = normalizePhoneNumber(targetPhone);
        if (cleanTarget && cleanTarget !== keyPhone) {
          return { valid: false, isMaster: false, phone: keyPhone, reason: 'Phone mismatch' };
        }
      }
      return { valid: true, isMaster: false, phone: keyPhone, key };
    }
  }

  return { valid: false, isMaster: false, phone: null, reason: 'Invalid signature' };
}

function openLicenseModal() {
  const phoneInput = document.getElementById('licensePhoneInput');
  const keyInput = document.getElementById('licenseKeyInput');
  
  if (phoneInput) phoneInput.value = appState.settings.ownerPhone || '';
  if (keyInput) keyInput.value = appState.licenseKey || '';
  
  document.getElementById('licenseModal').classList.add('active');
}

function handleActivateLicenseSubmit(e) {
  e.preventDefault();
  const inputPhone = document.getElementById('licensePhoneInput').value.trim();
  const inputKey = document.getElementById('licenseKeyInput').value.trim().toUpperCase();

  if (!inputKey) {
    alert('Please enter your license key.');
    return;
  }

  const result = verifyLicenseKey(inputKey, inputPhone);

  if (result.valid) {
    appState.isLicensed = true;
    appState.licenseKey = inputKey;
    appState.isMasterAdmin = result.isMaster;

    if (result.phone) {
      appState.settings.ownerPhone = '+' + result.phone;
      appState.settings.sellerPhone = '+' + result.phone;
    } else if (inputPhone) {
      appState.settings.ownerPhone = inputPhone;
    }

    saveToStorage();
    closeAllModals();
    renderApp();
    showToast('🎉 Congratulations! Lifetime License activated successfully!');
  } else {
    if (result.reason === 'Phone mismatch') {
      alert(`⚠️ License Key mismatch!\n\nThis license key is locked to phone number: +${result.phone}.\nPlease ensure you enter the registered phone number.`);
    } else {
      alert('❌ Invalid License Key.\n\nPlease verify your registered WhatsApp number and license key, or contact support via WhatsApp to get a valid key.');
    }
  }
}

function handleBuyLicenseRedirect() {
  const sellerNumber = (appState.settings.sellerPhone || '+60123456789').replace(/[^0-9]/g, '');
  const message = `Hi! I am using the StayManager Homestay app demo and would like to buy the Lifetime License. Please provide the price and payment details. Thank you!`;
  const url = `https://wa.me/${sellerNumber}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

// ==========================================================================
// ADMIN LICENSE GENERATOR (SELLER TOOL)
// ==========================================================================

function handleGenerateAdminLicense(e) {
  e.preventDefault();
  const buyerPhone = document.getElementById('adminBuyerPhoneInput').value.trim();
  const buyerName = document.getElementById('adminBuyerNameInput').value.trim();

  const cleanPhone = normalizePhoneNumber(buyerPhone);
  if (!cleanPhone || cleanPhone.length < 8) {
    alert('Please enter a valid international phone number (e.g. +60123456789 or 0123456789).');
    return;
  }

  const licenseKey = generatePhoneLicenseKey(cleanPhone);
  const baseUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
  const magicUrl = `${baseUrl}?phone=${cleanPhone}&key=${licenseKey}`;

  document.getElementById('resBuyerPhone').textContent = `+${cleanPhone} ${buyerName ? `(${buyerName})` : ''}`;
  document.getElementById('resLicenseKey').textContent = licenseKey;
  document.getElementById('resMagicUrl').value = magicUrl;
  document.getElementById('adminGenResultBox').classList.remove('hidden');

  showToast('License Key & Magic Link generated!');
}

function handleCopyMagicLink() {
  const magicUrl = document.getElementById('resMagicUrl').value;
  if (!magicUrl) return;

  navigator.clipboard.writeText(magicUrl).then(() => {
    showToast('1-Click Magic Activation URL copied!');
  }).catch(() => {
    showToast('Copied URL!');
  });
}

function handleSendBuyerWa() {
  const magicUrl = document.getElementById('resMagicUrl').value;
  const licenseKey = document.getElementById('resLicenseKey').textContent;
  const buyerPhone = normalizePhoneNumber(document.getElementById('adminBuyerPhoneInput').value);
  const buyerName = document.getElementById('adminBuyerNameInput').value.trim();
  const isBM = appState.settings.language === 'bm';

  if (!magicUrl || !buyerPhone) return;

  let msg = '';
  if (isBM) {
    msg = `🎉 *TERIMA KASIH! LESEN APLIKASI HOMESTAY ANDA SUDAH DIAKTIFKAN*\n\n` +
      `Salam sejahtera ${buyerName ? `*${buyerName}*` : ''}! Berikut adalah maklumat lesen dan pautan pemasangan peribadi anda:\n\n` +
      `📱 *Nombor WhatsApp Berdaftar:* +${buyerPhone}\n` +
      `🔑 *Kunci Lesen Anda:* *${licenseKey}*\n\n` +
      `🚀 *PAUTAN AKTIVASI 1-KLIK:*\n${magicUrl}\n\n` +
      `📌 *PANDUAN PEMASANGAN:*\n` +
      `1. Tekan pautan di atas pada telefon anda.\n` +
      `2. Aplikasi akan diaktifkan serta-merta tanpa had homestay.\n` +
      `3. Untuk jadikan seperti app di telefon: Tekan Menu / Share ➔ "Add to Home Screen".\n\n` +
      `💡 *JAMINAN TUKAR TELEFON:*\n` +
      `Jika anda menukar telefon baru pada masa hadapan, simpan kunci lesen ini. Anda boleh menggunakannya semula pada telefon baru anda asalkan menggunakan nombor WhatsApp yang sama! ✨🏡`;
  } else {
    msg = `🎉 *THANK YOU! YOUR STAYMANAGER HOMESTAY LICENSE IS ACTIVE*\n\n` +
      `Hello ${buyerName ? `*${buyerName}*` : ''}! Here are your private app license details and installation link:\n\n` +
      `📱 *Registered WhatsApp:* +${buyerPhone}\n` +
      `🔑 *Your License Key:* *${licenseKey}*\n\n` +
      `🚀 *1-CLICK MAGIC ACTIVATION LINK:*\n${magicUrl}\n\n` +
      `📌 *INSTALLATION STEPS:*\n` +
      `1. Tap the link above on your smartphone.\n` +
      `2. The app will unlock full unlimited features immediately.\n` +
      `3. To install on phone: Tap Safari Share or Chrome Menu ➔ "Add to Home Screen".\n\n` +
      `💡 *NEW PHONE FRIENDLY:*\n` +
      `If you change or upgrade your phone in the future, your license remains valid forever under your WhatsApp number! ✨🏡`;
  }

  const waUrl = `https://wa.me/${buyerPhone}?text=${encodeURIComponent(msg)}`;
  window.open(waUrl, '_blank');
}

// ==========================================================================
// 4. TAB & PROPERTY SWITCHING
// ==========================================================================

function switchTab(tabId) {
  closeAllModals();
  appState.activeTab = tabId;
  document.querySelectorAll('.bottom-nav .nav-item').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-tab') === tabId);
  });
  document.querySelectorAll('.tab-view').forEach(view => {
    view.classList.toggle('active', view.id === `view-${tabId}`);
  });

  // Render specific tab with defensive error boundary
  try {
    if (tabId === 'dashboard') renderDashboardTab();
    else if (tabId === 'calendar') renderCalendarTab();
    else if (tabId === 'bookings') renderBookingsTab();
    else if (tabId === 'turnovers') renderTurnoversTab();
    else if (tabId === 'finances') renderFinancesTab();
    else if (tabId === 'settings') renderSettingsTab();
  } catch (tabErr) {
    console.error(`Error rendering tab ${tabId}:`, tabErr);
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderApp() {
  applyLanguageUI();
  renderHeader();
  renderPropertyPills();
  switchTab(appState.activeTab);
}

function renderHeader() {
  document.getElementById('appBusinessName').textContent = appState.settings.businessName;
  const locale = appState.settings.language === 'bm' ? 'ms-MY' : 'en-US';
  const todayStr = new Date().toLocaleDateString(locale, { weekday: 'short', month: 'short', day: 'numeric' });
  document.getElementById('currentDateStr').textContent = todayStr;

  // Toggle Demo Sales Banner based on License state
  const demoBanner = document.getElementById('demoSalesBanner');
  if (demoBanner) {
    if (appState.isLicensed) {
      demoBanner.style.display = 'none';
      demoBanner.classList.add('hidden');
    } else {
      demoBanner.style.display = 'flex';
      demoBanner.classList.remove('hidden');
    }
  }

  // Update Header Status Badge (Top-right pill)
  const demoBtn = document.getElementById('btnDemoToggle');
  if (demoBtn) {
    if (appState.isLicensed) {
      if (appState.isMasterAdmin) {
        demoBtn.innerHTML = `<i class="fa-solid fa-crown" style="color:#f59e0b;"></i> <span class="demo-badge-text" style="color:var(--primary); font-weight:800;">Admin</span>`;
        demoBtn.title = 'Master Admin Mode (Click to open Generator & Settings)';
        demoBtn.style.background = 'var(--primary-light)';
        demoBtn.style.borderColor = 'rgba(2, 132, 199, 0.4)';
      } else {
        demoBtn.innerHTML = `<i class="fa-solid fa-circle-check" style="color:var(--success);"></i> <span class="demo-badge-text" style="color:var(--success-text); font-weight:800;">Pro</span>`;
        demoBtn.title = 'Lifetime Pro Active';
        demoBtn.style.background = 'var(--success-light)';
        demoBtn.style.borderColor = 'rgba(16, 185, 129, 0.4)';
      }
    } else {
      demoBtn.innerHTML = `<i class="fa-solid fa-sparkles"></i> <span class="demo-badge-text">${t('demo_badge') || 'Demo'}</span>`;
      demoBtn.title = 'Demo Mode (Click to activate)';
      demoBtn.style.background = 'var(--warning-light)';
      demoBtn.style.borderColor = 'rgba(245, 158, 11, 0.4)';
    }
  }
}

function renderPropertyPills() {
  const container = document.getElementById('propertyPills');
  container.innerHTML = '';

  // "All Properties" pill
  const allPill = document.createElement('button');
  allPill.className = `property-pill ${appState.selectedPropertyId === 'all' ? 'active' : ''}`;
  allPill.innerHTML = `<span class="property-dot" style="background:#0284c7;"></span> ${t('all_units')} (${appState.properties.length})`;
  allPill.addEventListener('click', () => {
    appState.selectedPropertyId = 'all';
    renderPropertyPills();
    renderApp();
  });
  container.appendChild(allPill);

  // Individual Property pills
  appState.properties.forEach(prop => {
    const pill = document.createElement('button');
    pill.className = `property-pill ${appState.selectedPropertyId === prop.id ? 'active' : ''}`;
    pill.innerHTML = `<span class="property-dot" style="background:${prop.color || '#0284c7'};"></span> ${prop.name}`;
    pill.addEventListener('click', () => {
      appState.selectedPropertyId = prop.id;
      renderPropertyPills();
      renderApp();
    });
    container.appendChild(pill);
  });
}

function getFilteredBookings() {
  if (appState.selectedPropertyId === 'all') return appState.bookings;
  return appState.bookings.filter(b => b.propertyId === appState.selectedPropertyId);
}

function isCompletedTenancy(b, todayStr = new Date().toISOString().split('T')[0]) {
  if (!b) return false;
  if (b.rentalType === 'monthly') {
    return b.status === 'checked-out' || b.status === 'completed' || b.isHistorical === true || (b.checkOut && b.checkOut < todayStr);
  }
  return false;
}

function isHistoricalStay(b, todayStr = new Date().toISOString().split('T')[0]) {
  if (!b) return false;
  if (b.rentalType === 'monthly') {
    return isCompletedTenancy(b, todayStr);
  }
  return b.status === 'checked-out' || b.status === 'completed' || b.isHistorical === true || (b.checkOut && b.checkOut < todayStr && b.status !== 'cancelled' && b.status !== 'quotation');
}

function getFilteredTurnovers() {
  if (appState.selectedPropertyId === 'all') return appState.turnovers;
  return appState.turnovers.filter(t => t.propertyId === appState.selectedPropertyId);
}

function getFilteredExpenses() {
  if (appState.selectedPropertyId === 'all') return appState.expenses;
  return appState.expenses.filter(e => e.propertyId === appState.selectedPropertyId);
}

function getPropertyById(id) {
  return appState.properties.find(p => p.id === id) || { name: 'Homestay', color: '#0284c7', doorCode: '1234', wifiName: '', wifiPass: '' };
}

function formatCurrency(amount) {
  const curr = appState.settings.currency || 'RM';
  return `${curr} ${Number(amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

// ==========================================================================
// 5. DASHBOARD (TODAY & ACTIONS) TAB
// ==========================================================================

function renderDashboardTab() {
  const todayStr = new Date().toISOString().split('T')[0];
  const bookings = getFilteredBookings();
  const turnovers = getFilteredTurnovers();

  // KPIs (completed historical tenancies and checked-out stays do not appear in active dashboard)
  const todayCheckIns = bookings.filter(b => b.checkIn === todayStr && b.status !== 'cancelled' && !isHistoricalStay(b, todayStr));
  const todayCheckOuts = bookings.filter(b => b.checkOut === todayStr && b.status !== 'cancelled' && b.status !== 'checked-out' && b.status !== 'completed' && !isCompletedTenancy(b, todayStr));
  const inHouse = bookings.filter(b => b.checkIn <= todayStr && b.checkOut > todayStr && b.status !== 'cancelled' && b.status !== 'checked-out' && b.status !== 'completed' && !isCompletedTenancy(b, todayStr));
  const pendingTurnovers = turnovers.filter(t => t.status !== 'completed');

  document.getElementById('kpiCheckInsCount').textContent = todayCheckIns.length;
  document.getElementById('kpiCheckOutsCount').textContent = todayCheckOuts.length;
  document.getElementById('kpiInHouseCount').textContent = inHouse.length;
  document.getElementById('kpiTurnoversCount').textContent = pendingTurnovers.length;

  // Monthly Performance Mini Widget
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const currentMonthBookings = bookings.filter(b => {
    if (b.status === 'cancelled') return false;
    const d = new Date(b.checkIn);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const monthRev = currentMonthBookings.reduce((sum, b) => sum + (Number(b.totalAmount) || 0), 0);
  const bookedNights = currentMonthBookings.reduce((sum, b) => sum + (Number(b.nights) || 0), 0);

  // Total possible nights this month for filtered properties
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const propCount = appState.selectedPropertyId === 'all' ? appState.properties.length : 1;
  const totalCapacity = daysInMonth * Math.max(1, propCount);
  const occupancyRate = propCount > 0 ? Math.min(100, Math.round((bookedNights / totalCapacity) * 100)) : 0;

  document.getElementById('dashMonthRevenue').textContent = formatCurrency(monthRev);
  document.getElementById('dashOccupancyRate').textContent = `${occupancyRate}%`;
  document.getElementById('dashOccupancyProgress').style.width = `${occupancyRate}%`;
  document.getElementById('dashBookedNightsCount').textContent = `${bookedNights} nights booked`;
  document.getElementById('dashActivePropertiesCount').textContent = `${appState.properties.length} Homestay${appState.properties.length !== 1 ? 's' : ''}`;

  // Action Feed: Priority Check-ins, Check-outs, and Turnovers
  const actionFeed = document.getElementById('dashboardActionFeed');
  actionFeed.innerHTML = '';

  const actionItems = [];

  todayCheckIns.forEach(b => {
    const prop = getPropertyById(b.propertyId);
    actionItems.push({
      type: 'checkin',
      tag: t('tag_checkin_today'),
      title: `${b.guestName} → ${prop.name}`,
      detail: `${b.guestCount} ${t('guests')} • ${t('checkin_time')}: ${prop.checkInTime || '3:00 PM'}`,
      booking: b,
      prop: prop
    });
  });

  todayCheckOuts.forEach(b => {
    const prop = getPropertyById(b.propertyId);
    actionItems.push({
      type: 'checkout',
      tag: t('tag_checkout_today'),
      title: `${b.guestName} ← ${prop.name}`,
      detail: `${t('checkout_time')}: ${prop.checkOutTime || '12:00 PM'} • ${t('turnover_required')}`,
      booking: b,
      prop: prop
    });
  });

  pendingTurnovers.forEach(tItem => {
    const prop = getPropertyById(tItem.propertyId);
    actionItems.push({
      type: 'cleaning',
      tag: t('tag_turnover_needed'),
      title: `${t('turnover')}: ${prop.name}`,
      detail: `${t('exp_date')}: ${tItem.date} • ${tItem.cleanerName || t('assign_cleaner')}`,
      turnover: tItem,
      prop: prop
    });
  });

  if (actionItems.length === 0) {
    actionFeed.innerHTML = `
      <div class="card" style="text-align:center; padding: 24px 16px;">
        <i class="fa-solid fa-circle-check" style="font-size: 32px; color: var(--success); margin-bottom: 8px;"></i>
        <h4 style="font-size: 14px; font-weight:700;">${appState.settings.language === 'bm' ? 'Semua Urusan Hari Ini Selesai!' : 'All Clear for Today!'}</h4>
        <p class="card-subtitle">${t('no_actions_today')}</p>
      </div>
    `;
  } else {
    actionItems.forEach(item => {
      const card = document.createElement('div');
      card.className = 'action-card';
      if (item.type === 'checkin') card.style.borderLeftColor = 'var(--primary)';
      if (item.type === 'checkout') card.style.borderLeftColor = 'var(--warning)';
      if (item.type === 'cleaning') card.style.borderLeftColor = 'var(--danger)';

      const tagClass = item.type === 'checkin' ? 'tag-checkin' : (item.type === 'checkout' ? 'tag-checkout' : 'tag-cleaning');

      card.innerHTML = `
        <div class="action-card-header">
          <span class="action-card-tag ${tagClass}">${item.tag}</span>
          <span class="card-subtitle"><i class="fa-solid fa-clock"></i> ${t('today')}</span>
        </div>
        <h3 class="action-card-title">${item.title}</h3>
        <p class="action-card-detail"><i class="fa-solid fa-info-circle"></i> ${item.detail}</p>
        <div class="action-card-btns">
          ${item.booking ? `
            <button class="btn btn-whatsapp btn-xs btn-wa-trigger" data-bid="${item.booking.id}" data-type="${item.type}">
              <i class="fa-brands fa-whatsapp"></i> ${item.type === 'checkin' ? t('btn_send_full_receipt') : t('btn_checkout_reminder')}
            </button>
            <button class="btn btn-outline btn-xs btn-open-pdf-doc" data-bid="${item.booking.id}" title="${appState.settings.language === 'bm' ? 'Jana Dokumen PDF Rasmi' : 'Generate Official PDF'}" style="color:var(--primary); font-weight:700;">
              <i class="fa-solid fa-file-pdf"></i> PDF
            </button>
          ` : ''}
          ${item.turnover ? `
            <button class="btn btn-whatsapp btn-xs btn-wa-cleaner" data-tid="${item.turnover.id}">
              <i class="fa-brands fa-whatsapp"></i> ${t('btn_wa_cleaner')}
            </button>
            <button class="btn btn-outline btn-xs btn-view-turnovers">
              <i class="fa-solid fa-list-check"></i> ${t('checklist')}
            </button>
          ` : ''}
        </div>
      `;

      actionFeed.appendChild(card);
    });

    // Attach event listeners for action feed buttons
    actionFeed.querySelectorAll('.btn-open-pdf-doc').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const bid = e.currentTarget.getAttribute('data-bid');
        const b = appState.bookings.find(x => x.id === bid);
        if (b) {
          const docType = (b.status === 'confirmed' || b.status === 'completed' || b.status === 'checked-in') ? 'receipt' : b.status === 'booked' ? 'deposit_receipt' : 'quotation';
          openPdfDocModal(b, docType);
        }
      });
    });

    actionFeed.querySelectorAll('.btn-wa-trigger').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const bid = e.currentTarget.getAttribute('data-bid');
        const type = e.currentTarget.getAttribute('data-type');
        const booking = appState.bookings.find(b => b.id === bid);
        if (booking) {
          openWhatsAppModal(booking, type === 'checkin' ? 'full_receipt' : 'checkout');
        }
      });
    });

    actionFeed.querySelectorAll('.btn-wa-cleaner').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tid = e.currentTarget.getAttribute('data-tid');
        const turnover = appState.turnovers.find(tItem => tItem.id === tid);
        if (turnover) {
          openWhatsAppCleanerJob(turnover);
        }
      });
    });

    actionFeed.querySelectorAll('.btn-view-turnovers').forEach(btn => {
      btn.addEventListener('click', () => switchTab('turnovers'));
    });
  }

  // Homestay Units Overview List
  const propList = document.getElementById('dashboardPropertyStatusList');
  propList.innerHTML = '';

  const displayProps = appState.selectedPropertyId === 'all' 
    ? appState.properties 
    : appState.properties.filter(p => p.id === appState.selectedPropertyId);

  if (displayProps.length === 0) {
    propList.innerHTML = `
      <div style="text-align:center; padding:20px; background:var(--bg-surface-subtle); border-radius:var(--radius-md); border:1px dashed var(--border-color);">
        <p style="font-size:12px; color:var(--text-muted); margin-bottom:8px;">${appState.settings.language === 'bm' ? 'Tiada unit homestay didaftarkan lagi.' : 'No homestay units added yet.'}</p>
        <button class="btn btn-primary btn-xs" onclick="openPropertyModal()"><i class="fa-solid fa-plus"></i> ${t('add_unit_btn')}</button>
      </div>
    `;
  } else {
    displayProps.forEach(prop => {
      // Check if property is currently occupied today (completed tenancies do NOT mark property as occupied)
      const currentStay = appState.bookings.find(b => 
        b.propertyId === prop.id && 
        b.checkIn <= todayStr && 
        b.checkOut > todayStr && 
        b.status !== 'cancelled' &&
        b.status !== 'checked-out' &&
        b.status !== 'completed' &&
        !isCompletedTenancy(b, todayStr)
      );

      const hasTurnover = appState.turnovers.some(tItem => tItem.propertyId === prop.id && tItem.status !== 'completed');

      let statusText = t('vacant_ready');
      let badgeClass = 'badge-vacant';

      if (currentStay) {
        statusText = `${t('occupied_by')} ${currentStay.guestName}`;
        badgeClass = 'badge-occupied';
      } else if (hasTurnover) {
        statusText = t('turnover_required');
        badgeClass = 'badge-turnover';
      }

      const card = document.createElement('div');
      card.className = 'prop-status-card';
      card.innerHTML = `
        <div class="prop-status-info">
          <h4 style="display:flex; align-items:center; gap:6px;">
            <span class="property-dot" style="background:${prop.color};"></span>
            ${prop.name}
          </h4>
          <p>${statusText}</p>
        </div>
        <span class="prop-status-badge ${badgeClass}">${currentStay ? t('occupied') : (hasTurnover ? t('turnover') : t('available'))}</span>
      `;
      propList.appendChild(card);
    });
  }

  // Update Dashboard Historical Tenancies quick link
  const historicalTenancies = appState.bookings.filter(b => isCompletedTenancy(b, todayStr));
  const btnHist = document.getElementById('btnDashHistoricalTenancies');
  const histCountEl = document.getElementById('dashHistoricalTenancyCount');
  if (btnHist && histCountEl) {
    if (historicalTenancies.length > 0) {
      btnHist.style.display = 'inline-flex';
      histCountEl.textContent = historicalTenancies.length;
      btnHist.onclick = () => {
        switchTab('bookings');
        const histPill = document.querySelector('#bookingStatusFilters .filter-pill[data-filter="historical_tenancy"]');
        if (histPill) histPill.click();
      };
    } else {
      btnHist.style.display = 'none';
    }
  }
}

// ==========================================================================
// 6. CALENDAR TAB
// ==========================================================================

function changeCalMonth(offset) {
  appState.currentCalDate.setMonth(appState.currentCalDate.getMonth() + offset);
  renderCalendarTab();
}

function renderCalendarTab() {
  const currentMonth = appState.currentCalDate.getMonth();
  const currentYear = appState.currentCalDate.getFullYear();
  
  // Sync Calendar Mode pills active state
  const currentCalMode = appState.calFilterMode || 'checkin';
  document.querySelectorAll('#calModeSelector .cal-mode-pill').forEach(pill => {
    pill.classList.toggle('active', pill.getAttribute('data-cal-filter') === currentCalMode);
  });
  
  const locale = appState.settings.language === 'bm' ? 'ms-MY' : 'en-US';
  const monthName = appState.currentCalDate.toLocaleDateString(locale, { month: 'long', year: 'numeric' });
  document.getElementById('calMonthTitle').textContent = monthName;

  const firstDay = new Date(currentYear, currentMonth, 1).getDay();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const daysInPrevMonth = new Date(currentYear, currentMonth, 0).getDate();

  const grid = document.getElementById('calDaysGrid');
  grid.innerHTML = '';

  const bookings = getFilteredBookings();
  const todayStr = new Date().toISOString().split('T')[0];

  // Previous month trailing days
  for (let i = firstDay - 1; i >= 0; i--) {
    const dayNum = daysInPrevMonth - i;
    const prevDate = new Date(currentYear, currentMonth - 1, dayNum);
    const dateStr = prevDate.toISOString().split('T')[0];
    const cell = createCalDayCell(dayNum, dateStr, true, bookings, todayStr);
    grid.appendChild(cell);
  }

  // Current month days
  for (let day = 1; day <= daysInMonth; day++) {
    const currDate = new Date(currentYear, currentMonth, day);
    const dateStr = currDate.toISOString().split('T')[0];
    const cell = createCalDayCell(day, dateStr, false, bookings, todayStr);
    grid.appendChild(cell);
  }

  // Next month leading days (fill up to 42 cells grid if needed)
  const totalCells = grid.children.length;
  const remaining = (totalCells <= 35 ? 35 : 42) - totalCells;
  for (let day = 1; day <= remaining; day++) {
    const nextDate = new Date(currentYear, currentMonth + 1, day);
    const dateStr = nextDate.toISOString().split('T')[0];
    const cell = createCalDayCell(day, dateStr, true, bookings, todayStr);
    grid.appendChild(cell);
  }

  // Render Legend
  const legend = document.getElementById('calPropertyLegend');
  legend.innerHTML = '';
  appState.properties.forEach(p => {
    const item = document.createElement('div');
    item.className = 'cal-legend-item';
    item.innerHTML = `<span class="property-dot" style="background:${p.color};"></span> ${p.name}`;
    legend.appendChild(item);
  });

  // Render Calendar Listing (Incoming Bookings or Selected Day)
  renderCalendarListing();
}

function createCalDayCell(dayNum, dateStr, isOtherMonth, bookings, todayStr) {
  const isSelected = dateStr === appState.selectedCalDate && appState.calListingMode === 'selected';
  const calFilter = appState.calFilterMode || 'checkin';
  const cell = document.createElement('div');
  cell.className = `cal-day-cell ${isOtherMonth ? 'other-month' : ''} ${dateStr === todayStr ? 'today' : ''} ${isSelected ? 'selected' : ''}`;
  cell.setAttribute('data-date', dateStr);

  const numSpan = document.createElement('span');
  numSpan.className = 'cal-day-num';
  numSpan.textContent = dayNum;
  cell.appendChild(numSpan);

  const activeBookings = bookings.filter(b => b.status !== 'cancelled');
  const checkins = activeBookings.filter(b => b.checkIn === dateStr);
  const checkouts = activeBookings.filter(b => b.checkOut === dateStr);
  const stays = activeBookings.filter(b => {
    if (b.checkIn === b.checkOut) return b.checkIn === dateStr;
    return b.checkIn <= dateStr && b.checkOut > dateStr;
  });

  if (calFilter === 'checkin') {
    if (checkins.length > 0) {
      cell.classList.add('has-checkin', 'has-booking');
      const isConfirmed = checkins.some(b => ['booked', 'confirmed', 'checked-in', 'active', 'blocked'].includes(b.status));
      if (isConfirmed) cell.classList.add('is-confirmed-booked');

      const badge = document.createElement('span');
      badge.className = 'cal-day-mode-badge badge-checkin';
      badge.innerHTML = `<i class="fa-solid fa-arrow-right-to-bracket"></i> ${checkins.length}`;
      cell.appendChild(badge);

      const dotsContainer = document.createElement('div');
      dotsContainer.className = 'cal-dots-container';
      checkins.forEach(b => {
        const prop = getPropertyById(b.propertyId);
        const dot = document.createElement('span');
        dot.className = 'cal-stay-dot';
        dot.style.backgroundColor = prop.color || '#16a34a';
        dot.title = `${prop.name}: ${b.guestName} (${t('cal_mode_checkin')})`;
        if (b.status === 'quotation') dot.classList.add('is-quotation');
        dotsContainer.appendChild(dot);
      });
      cell.appendChild(dotsContainer);
    }
  } else if (calFilter === 'checkout') {
    if (checkouts.length > 0) {
      cell.classList.add('has-checkout', 'has-booking');
      const isConfirmed = checkouts.some(b => ['booked', 'confirmed', 'checked-in', 'active', 'blocked'].includes(b.status));
      if (isConfirmed) cell.classList.add('is-confirmed-booked');

      const badge = document.createElement('span');
      badge.className = 'cal-day-mode-badge badge-checkout';
      badge.innerHTML = `<i class="fa-solid fa-arrow-right-from-bracket"></i> ${checkouts.length}`;
      cell.appendChild(badge);

      const dotsContainer = document.createElement('div');
      dotsContainer.className = 'cal-dots-container';
      checkouts.forEach(b => {
        const prop = getPropertyById(b.propertyId);
        const dot = document.createElement('span');
        dot.className = 'cal-stay-dot';
        dot.style.backgroundColor = prop.color || '#ea580c';
        dot.title = `${prop.name}: ${b.guestName} (${t('cal_mode_checkout')})`;
        if (b.status === 'quotation') dot.classList.add('is-quotation');
        dotsContainer.appendChild(dot);
      });
      cell.appendChild(dotsContainer);
    }
  } else {
    // 'stays' mode
    if (stays.length > 0) {
      cell.classList.add('has-booking');
      const isConfirmed = stays.some(b => ['booked', 'confirmed', 'checked-in', 'active', 'blocked'].includes(b.status));
      if (isConfirmed) cell.classList.add('is-confirmed-booked');

      const badge = document.createElement('span');
      badge.className = 'cal-day-mode-badge badge-stays';
      badge.style.background = 'rgba(2, 132, 199, 0.15)';
      badge.style.color = 'var(--primary)';
      badge.innerHTML = `<i class="fa-solid fa-bed"></i> ${stays.length}`;
      cell.appendChild(badge);

      const dotsContainer = document.createElement('div');
      dotsContainer.className = 'cal-dots-container';
      stays.forEach(b => {
        const prop = getPropertyById(b.propertyId);
        const dot = document.createElement('span');
        dot.className = 'cal-stay-dot';
        dot.style.backgroundColor = prop.color || '#0284c7';
        dot.title = `${prop.name}: ${b.guestName} (${b.status})`;
        if (b.status === 'quotation') dot.classList.add('is-quotation');
        dotsContainer.appendChild(dot);
      });
      cell.appendChild(dotsContainer);
    }
  }

  cell.addEventListener('click', () => {
    if (appState.selectedCalDate === dateStr && appState.calListingMode === 'selected') {
      appState.calListingMode = 'incoming';
      document.querySelectorAll('.cal-day-cell').forEach(c => c.classList.remove('selected'));
    } else {
      appState.selectedCalDate = dateStr;
      appState.calListingMode = 'selected';
      document.querySelectorAll('.cal-day-cell').forEach(c => c.classList.remove('selected'));
      cell.classList.add('selected');
    }
    renderCalendarListing();
  });

  return cell;
}

function getIncomingBookings() {
  const allBookings = getFilteredBookings();
  const todayStr = new Date().toISOString().split('T')[0];
  const calFilter = appState.calFilterMode || 'checkin';

  const active = allBookings.filter(b => b.status !== 'cancelled' && b.status !== 'checked-out' && b.status !== 'completed' && !isCompletedTenancy(b, todayStr));

  if (calFilter === 'checkout') {
    // In checkout mode: show upcoming check-outs (from today onwards)
    const checkouts = active.filter(b => b.checkOut >= todayStr);
    checkouts.sort((a, b) => {
      if (a.checkOut !== b.checkOut) return a.checkOut.localeCompare(b.checkOut);
      return a.checkIn.localeCompare(b.checkIn);
    });
    return checkouts;
  }

  // Check-In or Stays mode: incoming bookings
  const incoming = active.filter(b => b.checkOut >= todayStr);
  incoming.sort((a, b) => {
    const aInHouse = (a.checkIn <= todayStr && a.checkOut >= todayStr);
    const bInHouse = (b.checkIn <= todayStr && b.checkOut >= todayStr);

    if (aInHouse && bInHouse) {
      if (a.checkIn !== b.checkIn) return a.checkIn.localeCompare(b.checkIn);
      return a.checkOut.localeCompare(b.checkOut);
    }
    if (aInHouse && !bInHouse) return -1;
    if (!aInHouse && bInHouse) return 1;

    // Both future check-ins: sort by earliest checkIn date first (ascending)
    if (a.checkIn !== b.checkIn) {
      return a.checkIn.localeCompare(b.checkIn);
    }
    return a.checkOut.localeCompare(b.checkOut);
  });

  return incoming;
}

function renderCalendarListing() {
  const mode = appState.calListingMode || 'incoming';
  const calFilter = appState.calFilterMode || 'checkin';
  const list = document.getElementById('selectedDayBookingsList');
  if (!list) return;
  list.innerHTML = '';

  const incomingBookings = getIncomingBookings();
  const todayStr = new Date().toISOString().split('T')[0];
  const lang = appState.settings.language || 'en';
  const isBM = lang === 'bm';

  // Update tabs
  const tabIncoming = document.getElementById('calTabIncoming');
  const tabSelected = document.getElementById('calTabSelected');
  const tabSelectedLabel = document.getElementById('calSelectedTabLabel');

  if (tabIncoming && tabSelected) {
    if (mode === 'incoming') {
      tabIncoming.classList.add('active');
      tabSelected.classList.remove('active');
    } else {
      tabIncoming.classList.remove('active');
      tabSelected.classList.add('active');
    }

    if (tabSelectedLabel) {
      if (appState.selectedCalDate) {
        const d = new Date(appState.selectedCalDate + 'T00:00:00');
        const dStr = d.toLocaleDateString(isBM ? 'ms-MY' : 'en-US', { day: 'numeric', month: 'short' });
        tabSelectedLabel.textContent = `🎯 ${dStr}`;
      } else {
        tabSelectedLabel.textContent = isBM ? '🎯 Tarikh Dipilih' : '🎯 Selected Date';
      }
    }
  }

  const titleEl = document.getElementById('selectedDayTitle');
  const subtitleEl = document.querySelector('#selectedDayDetails .card-subtitle');

  if (mode === 'incoming') {
    let modeTitle = isBM ? 'Tempahan Akan Datang' : 'Incoming Bookings';
    let modeSubtitle = isBM ? 'Susunan mengikut tarikh terdekat' : 'Ordered by nearest dates';
    let modeIcon = 'fa-calendar-days';

    if (calFilter === 'checkin') {
      modeTitle = isBM ? 'Daftar Masuk Akan Datang' : 'Upcoming Check-Ins';
      modeSubtitle = isBM ? 'Susunan tarikh daftar masuk terdekat' : 'Ordered by nearest check-in dates';
      modeIcon = 'fa-arrow-right-to-bracket';
    } else if (calFilter === 'checkout') {
      modeTitle = isBM ? 'Daftar Keluar & Kekosongan' : 'Upcoming Check-Outs & Vacancies';
      modeSubtitle = isBM ? 'Susunan tarikh daftar keluar terdekat' : 'Ordered by nearest check-out dates';
      modeIcon = 'fa-arrow-right-from-bracket';
    }

    if (subtitleEl) subtitleEl.textContent = modeSubtitle;
    if (titleEl) {
      titleEl.innerHTML = `<i class="fa-solid ${modeIcon}" style="color:var(--primary); margin-right:6px;"></i>${modeTitle} <span class="badge-count" style="font-size:12px; font-weight:700; background:var(--primary-light); color:var(--primary); padding:2px 8px; border-radius:12px; margin-left:6px; vertical-align:middle;">${incomingBookings.length}</span>`;
    }

    if (incomingBookings.length === 0) {
      const emptyMsg = calFilter === 'checkout'
        ? (isBM ? 'Tiada daftar keluar dijadualkan.' : 'No check-outs scheduled.')
        : (isBM ? 'Semua unit kini tiada tempahan baharu. Tekan + untuk tambah tempahan.' : 'All units currently have no upcoming bookings. Tap + to add a booking.');

      list.innerHTML = `
        <div class="empty-hint" style="padding: 24px 16px; text-align: center;">
          <i class="fa-solid fa-calendar-xmark" style="font-size: 28px; color: var(--text-muted); opacity: 0.5; margin-bottom: 8px; display: block;"></i>
          <p style="font-size: 14px; font-weight: 600; color: var(--text-main); margin-bottom: 4px;">
            ${isBM ? 'Tiada Rekod Dijumpai' : 'No Records Found'}
          </p>
          <p style="font-size: 12.5px; color: var(--text-muted); margin-bottom: 14px;">
            ${emptyMsg}
          </p>
          <button class="btn btn-primary btn-sm" id="btnCalAddBookingEmpty">
            <i class="fa-solid fa-plus"></i> ${isBM ? 'Tambah Tempahan' : 'Add Booking'}
          </button>
        </div>
      `;
      const emptyAddBtn = document.getElementById('btnCalAddBookingEmpty');
      if (emptyAddBtn) emptyAddBtn.addEventListener('click', () => openBookingModal());
      return;
    }

    // Render incoming bookings cards
    incomingBookings.forEach(b => {
      const card = createCalendarBookingCard(b, todayStr, isBM, false);
      list.appendChild(card);
    });

  } else {
    // Mode is 'selected' (date selected on calendar)
    const dateStr = appState.selectedCalDate || todayStr;
    const d = new Date(dateStr + 'T00:00:00');
    const formattedDate = d.toLocaleDateString(isBM ? 'ms-MY' : 'en-US', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' });

    if (subtitleEl) {
      subtitleEl.textContent = isBM ? 'Tarikh Dipilih' : 'Selected Date';
    }
    if (titleEl) {
      titleEl.innerHTML = `<i class="fa-regular fa-calendar-check" style="color:var(--primary); margin-right:6px;"></i>${formattedDate}`;
    }

    const allFiltered = getFilteredBookings().filter(b => b.status !== 'cancelled');
    const dayCheckIns = allFiltered.filter(b => b.checkIn === dateStr);
    const dayCheckOuts = allFiltered.filter(b => b.checkOut === dateStr);
    const dayInStays = allFiltered.filter(b => {
      if (b.checkIn === b.checkOut) return b.checkIn === dateStr;
      return b.checkIn <= dateStr && b.checkOut > dateStr;
    });

    const activeProps = appState.selectedPropertyId === 'all'
      ? appState.properties
      : appState.properties.filter(p => p.id === appState.selectedPropertyId);
    const occupiedPropIds = new Set(dayInStays.map(b => b.propertyId));
    const vacantCount = Math.max(0, activeProps.length - occupiedPropIds.size);

    // 1. Render Metrics Bar
    const metricsBar = document.createElement('div');
    metricsBar.className = 'cal-date-metrics-bar';
    metricsBar.innerHTML = `
      <div class="cal-metric-chip ${calFilter === 'checkin' ? 'active-in' : ''}">
        <span class="metric-num">${dayCheckIns.length}</span>
        <span class="metric-lbl"><i class="fa-solid fa-arrow-right-to-bracket"></i> ${isBM ? 'Masuk' : 'Check-In'}</span>
      </div>
      <div class="cal-metric-chip ${calFilter === 'checkout' ? 'active-out' : ''}">
        <span class="metric-num">${dayCheckOuts.length}</span>
        <span class="metric-lbl"><i class="fa-solid fa-arrow-right-from-bracket"></i> ${isBM ? 'Keluar' : 'Check-Out'}</span>
      </div>
      <div class="cal-metric-chip ${calFilter === 'stays' ? 'active-in' : ''}">
        <span class="metric-num">${dayInStays.length}</span>
        <span class="metric-lbl"><i class="fa-solid fa-bed"></i> ${isBM ? 'Menginap' : 'In-Stay'}</span>
      </div>
      <div class="cal-metric-chip active-avail">
        <span class="metric-num">${vacantCount}</span>
        <span class="metric-lbl"><i class="fa-solid fa-door-open"></i> ${isBM ? 'Kosong' : 'Available'}</span>
      </div>
    `;
    list.appendChild(metricsBar);

    // 2. Render content according to calFilter
    if (calFilter === 'checkout') {
      if (dayCheckOuts.length > 0) {
        dayCheckOuts.forEach(b => {
          const prop = getPropertyById(b.propertyId);
          const alertCard = document.createElement('div');
          alertCard.className = 'cal-vacating-alert-card';
          alertCard.innerHTML = `
            <div class="alert-icon">
              <i class="fa-solid fa-door-open"></i>
            </div>
            <div class="alert-content">
              <strong>✨ ${prop.name} — ${isBM ? 'Daftar Keluar Hari Ini' : 'Checking Out Today'}</strong>
              <p>${isBM 
                ? `Tetamu <b>${b.guestName}</b> keluar jam ${prop.checkOutTime || '12:00 PM'}. Unit dibersihkan &amp; sedia untuk tetamu baharu mendaftar masuk jam ${prop.checkInTime || '3:00 PM'}!` 
                : `Guest <b>${b.guestName}</b> departs by ${prop.checkOutTime || '12:00 PM'}. Unit will be cleaned &amp; ready for a new guest check-in at ${prop.checkInTime || '3:00 PM'}!`}</p>
              <button class="btn btn-primary btn-sm btn-book-vacating-unit" data-pid="${prop.id}" data-date="${dateStr}">
                <i class="fa-solid fa-calendar-plus"></i> ${isBM ? '+ Tempah Unit Ini Mulai Hari Ini' : '+ Book This Unit Starting Today'}
              </button>
            </div>
          `;
          list.appendChild(alertCard);

          const card = createCalendarBookingCard(b, todayStr, isBM, true, dateStr);
          list.appendChild(card);
        });
      } else {
        list.innerHTML += `
          <div class="empty-hint" style="padding: 20px 16px; text-align: center;">
            <i class="fa-solid fa-circle-info" style="font-size: 26px; color: var(--text-muted); opacity: 0.6; margin-bottom: 8px; display: block;"></i>
            <p style="font-size: 14px; font-weight: 700; color: var(--text-main); margin-bottom: 4px;">
              ${isBM ? 'Tiada Daftar Keluar pada Tarikh Ini' : 'No Check-Outs on this Date'}
            </p>
            <p style="font-size: 12.5px; color: var(--text-muted); margin-bottom: 14px;">
              ${vacantCount > 0 
                ? (isBM ? `${vacantCount} unit homestay sedia ditempah.` : `${vacantCount} homestay unit(s) available for new booking.`)
                : (isBM ? 'Semua unit sedang diduduki tetamu.' : 'All units occupied by in-house guests.')}
            </p>
            <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
              <button class="btn btn-primary btn-sm" id="btnQuickBookForDateEmpty">
                <i class="fa-solid fa-plus"></i> ${isBM ? 'Tempah Tarikh Ini' : 'Book This Date'}
              </button>
              <button class="btn btn-outline btn-sm" id="btnSwitchToIncoming">
                <i class="fa-regular fa-clock"></i> ${isBM ? '📅 Semua Akan Datang' : '📅 All Incoming Bookings'}
              </button>
            </div>
          </div>
        `;
      }
    } else if (calFilter === 'checkin') {
      if (dayCheckIns.length > 0) {
        dayCheckIns.forEach(b => {
          const card = createCalendarBookingCard(b, todayStr, isBM, true, dateStr);
          list.appendChild(card);
        });

        if (vacantCount > 0) {
          const availBanner = document.createElement('div');
          availBanner.style.cssText = 'background:var(--bg-surface-subtle); border:1px dashed var(--border-color); border-radius:var(--radius-md); padding:10px 14px; margin-top:10px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;';
          availBanner.innerHTML = `
            <span style="font-size:12.5px; color:var(--text-muted);">
              <i class="fa-solid fa-circle-check" style="color:var(--success);"></i> <strong>${vacantCount}</strong> ${isBM ? 'lagi unit kosong pada tarikh ini.' : 'more unit(s) available on this date.'}
            </span>
            <button class="btn btn-outline btn-xs" id="btnAddCheckinTodayBtn">
              <i class="fa-solid fa-plus"></i> ${isBM ? 'Tambah Tempahan' : 'Add Booking'}
            </button>
          `;
          list.appendChild(availBanner);
          const addBtn = availBanner.querySelector('#btnAddCheckinTodayBtn');
          if (addBtn) addBtn.addEventListener('click', () => openBookingModal(null, dateStr));
        }
      } else {
        list.innerHTML += `
          <div class="empty-hint" style="padding: 20px 16px; text-align: center;">
            <i class="fa-solid fa-calendar-check" style="font-size: 26px; color: var(--success); margin-bottom: 8px; display: block;"></i>
            <p style="font-size: 14px; font-weight: 700; color: var(--text-main); margin-bottom: 4px;">
              ${isBM ? 'Tiada Daftar Masuk pada Tarikh Ini' : 'No Check-Ins on this Date'}
            </p>
            <p style="font-size: 12.5px; color: var(--text-muted); margin-bottom: 14px;">
              ${vacantCount > 0 
                ? (isBM ? `${vacantCount} unit sedia untuk ditempah.` : `${vacantCount} unit(s) available for new booking.`)
                : (isBM ? 'Tiada daftar masuk baharu (unit sedang menginap).' : 'No new check-in arrivals scheduled.')}
            </p>
            <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
              <button class="btn btn-primary btn-sm" id="btnQuickBookForDateEmpty">
                <i class="fa-solid fa-plus"></i> ${isBM ? 'Tempah Tarikh Ini' : 'Book This Date'}
              </button>
              <button class="btn btn-outline btn-sm" id="btnSwitchToIncoming">
                <i class="fa-regular fa-clock"></i> ${isBM ? '📅 Semua Akan Datang' : '📅 All Incoming Bookings'}
              </button>
            </div>
          </div>
        `;
      }
    } else {
      // Stays mode
      if (dayInStays.length > 0) {
        dayInStays.forEach(b => {
          const card = createCalendarBookingCard(b, todayStr, isBM, true, dateStr);
          list.appendChild(card);
        });
      } else {
        list.innerHTML += `
          <div class="empty-hint" style="padding: 20px 16px; text-align: center;">
            <i class="fa-solid fa-bed" style="font-size: 26px; color: var(--success); margin-bottom: 8px; display: block;"></i>
            <p style="font-size: 14px; font-weight: 700; color: var(--text-main); margin-bottom: 4px;">
              ${isBM ? 'Tiada Penginapan pada Tarikh Ini' : 'No Stays on this Date'}
            </p>
            <p style="font-size: 12.5px; color: var(--text-muted); margin-bottom: 14px;">
              ${isBM ? 'Semua unit kosong & sedia ditempah.' : 'All units vacant & ready for booking.'}
            </p>
            <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
              <button class="btn btn-primary btn-sm" id="btnQuickBookForDateEmpty">
                <i class="fa-solid fa-plus"></i> ${isBM ? 'Tempah Tarikh Ini' : 'Book This Date'}
              </button>
              <button class="btn btn-outline btn-sm" id="btnSwitchToIncoming">
                <i class="fa-regular fa-clock"></i> ${isBM ? '📅 Semua Akan Datang' : '📅 All Incoming Bookings'}
              </button>
            </div>
          </div>
        `;
      }
    }

    const qbBtn = document.getElementById('btnQuickBookForDateEmpty');
    if (qbBtn) qbBtn.addEventListener('click', () => openBookingModal(null, dateStr));

    const swBtn = document.getElementById('btnSwitchToIncoming');
    if (swBtn) swBtn.addEventListener('click', () => {
      appState.calListingMode = 'incoming';
      document.querySelectorAll('.cal-day-cell').forEach(c => c.classList.remove('selected'));
      renderCalendarListing();
    });
  }

  // Bind actions
  attachCalendarCardActions(list);
}

function createCalendarBookingCard(b, todayStr, isBM, isSelectedDayMode, selectedDateStr = null) {
  const prop = getPropertyById(b.propertyId);
  const card = document.createElement('div');
  card.className = 'booking-card cal-listing-booking-card';
  card.style.borderLeft = `4px solid ${prop.color}`;

  const proximity = getBookingProximityInfo(b, todayStr, isBM);
  let badgeText = proximity.label;
  let badgeClass = proximity.badgeClass;

  if (isSelectedDayMode && selectedDateStr) {
    if (b.checkIn === selectedDateStr) {
      badgeText = isBM ? '📥 Daftar Masuk' : '📥 Check-In Day';
      badgeClass = 'cal-prox-today';
    } else if (b.checkOut === selectedDateStr) {
      badgeText = isBM ? '📤 Daftar Keluar' : '📤 Check-Out Day';
      badgeClass = 'cal-prox-checkout';
    } else {
      badgeText = isBM ? '🔑 Sedang Menginap' : '🔑 In-Stay';
      badgeClass = 'cal-prox-instay';
    }
  }

  // Status tag
  let statusBadge = '';
  if (b.status === 'confirmed') {
    statusBadge = `<span class="badge-pill badge-confirmed">${isBM ? '🟢 Sah' : '🟢 Confirmed'}</span>`;
  } else if (b.status === 'booked') {
    statusBadge = `<span class="badge-pill badge-booked">${isBM ? '🟡 Ditempah' : '🟡 Booked'}</span>`;
  } else if (b.status === 'checked-in') {
    statusBadge = `<span class="badge-pill badge-inhouse">${isBM ? '🔑 Menginap' : '🔑 In-House'}</span>`;
  } else if (b.status === 'quotation') {
    statusBadge = `<span class="badge-pill badge-quotation">${isBM ? '📋 Sebut Harga' : '📋 Quotation'}</span>`;
  }

  const isCheckinReminderEligible = (b.status === 'booked' || b.status === 'confirmed') && b.checkIn >= todayStr;

  card.innerHTML = `
    <div class="booking-card-top">
      <span class="booking-prop-badge" style="background:${prop.color}20; color:${prop.color};">
        <span class="property-dot" style="background:${prop.color};"></span> ${prop.name}
      </span>
      <div style="display:flex; gap:6px; align-items:center;">
        ${(b.payments && b.payments.length > 0) ? `
          <button type="button" class="btn-open-receipt-gallery" data-bid="${b.id}" style="font-size:10px; font-weight:800; padding:1px 6px; border-radius:999px; background:#eff6ff; color:#1d4ed8; border:1px solid #93c5fd; cursor:pointer;" title="${t('receipt_gallery_title')}">
            <i class="fa-solid fa-receipt"></i> ${b.payments.length}
          </button>
        ` : ''}
        ${statusBadge}
        <span class="cal-proximity-badge ${badgeClass}">${badgeText}</span>
      </div>
    </div>
    <h3 class="booking-guest-title">${b.guestName} <span style="font-size:13px; font-weight:600; color:var(--text-muted);">(${b.guestCount || 1} ${t('guests')})</span></h3>
    <p class="booking-dates-row">
      <i class="fa-regular fa-calendar"></i> <strong>${b.checkIn}</strong> → <strong>${b.checkOut}</strong> (${b.nights || 1} ${t('nights')})
    </p>
    <div class="booking-financial-pill">
      <span>${t('total')}: <strong>${formatCurrency(b.totalAmount)}</strong></span>
      <span>${t('balance')}: <strong style="color:${b.balance > 0 ? 'var(--danger)' : 'var(--success)'};">${formatCurrency(b.balance)}</strong></span>
    </div>
    <div class="booking-actions-row" style="flex-wrap: wrap;">
      <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}">
        <i class="fa-brands fa-whatsapp"></i> ${t('btn_wa')}
      </button>
      ${isCheckinReminderEligible ? `
      <button class="btn btn-primary btn-xs btn-open-wa-reminder" data-bid="${b.id}" title="${isBM ? 'Hantar peringatan daftar masuk' : 'Send check-in reminder'}">
        <i class="fa-regular fa-bell"></i> ${isBM ? 'Peringatan Masuk' : 'Check-In Reminder'}
      </button>
      ` : ''}
      <button class="btn btn-outline btn-xs btn-change-homestay" data-bid="${b.id}" title="${t('btn_change_homestay')}">
        <i class="fa-solid fa-arrow-right-arrow-left"></i> ${t('btn_change_homestay')}
      </button>
      <button class="btn btn-outline btn-xs btn-open-pdf-doc" data-bid="${b.id}" title="${isBM ? 'Jana Dokumen PDF Rasmi (Sebut Harga / Invois / Resit)' : 'Generate Official PDF (Quotation / Invoice / Receipt)'}" style="color:var(--primary); font-weight:700;">
        <i class="fa-solid fa-file-pdf"></i> PDF
      </button>
      <button class="btn btn-outline btn-xs btn-edit-booking" data-bid="${b.id}">
        <i class="fa-solid fa-pen"></i> ${t('btn_edit')}
      </button>
    </div>
  `;

  return card;
}

function getBookingProximityInfo(b, todayStr, isBM) {
  const checkInDate = new Date(b.checkIn + 'T00:00:00');
  const checkOutDate = new Date(b.checkOut + 'T00:00:00');
  const todayDate = new Date(todayStr + 'T00:00:00');

  const diffMs = checkInDate - todayDate;
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (b.checkIn <= todayStr && b.checkOut >= todayStr) {
    if (b.checkIn === todayStr) {
      return {
        label: isBM ? '🟢 Masuk Hari Ini' : '🟢 Check-In Today',
        badgeClass: 'cal-prox-today'
      };
    }
    if (b.checkOut === todayStr) {
      return {
        label: isBM ? '🔴 Keluar Hari Ini' : '🔴 Check-Out Today',
        badgeClass: 'cal-prox-checkout'
      };
    }
    const remDays = Math.round((checkOutDate - todayDate) / (1000 * 60 * 60 * 24));
    return {
      label: isBM ? `🔑 Menginap (Baki ${remDays} mlm)` : `🔑 In-Stay (${remDays} nights left)`,
      badgeClass: 'cal-prox-instay'
    };
  }

  if (diffDays === 1) {
    return {
      label: isBM ? '🟡 Esok (Daftar Masuk)' : '🟡 Tomorrow (Check-In)',
      badgeClass: 'cal-prox-tomorrow'
    };
  }
  if (diffDays === 2) {
    return {
      label: isBM ? '⏳ 2 Hari Lagi' : '⏳ In 2 Days',
      badgeClass: 'cal-prox-soon'
    };
  }
  if (diffDays > 2 && diffDays <= 7) {
    return {
      label: isBM ? `📅 ${diffDays} Hari Lagi` : `📅 In ${diffDays} Days`,
      badgeClass: 'cal-prox-soon'
    };
  }
  if (diffDays > 7) {
    return {
      label: isBM ? `📅 Dalam ${diffDays} Hari` : `📅 In ${diffDays} Days`,
      badgeClass: 'cal-prox-future'
    };
  }

  return {
    label: isBM ? 'Akan Datang' : 'Upcoming',
    badgeClass: 'cal-prox-future'
  };
}

function attachCalendarCardActions(container) {
  container.querySelectorAll('.btn-open-wa').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openWhatsAppModal(b);
    });
  });

  container.querySelectorAll('.btn-open-wa-reminder').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openWhatsAppModal(b, 'checkin_reminder');
    });
  });

  container.querySelectorAll('.btn-change-homestay').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openChangeHomestayModal(b);
    });
  });

  container.querySelectorAll('.btn-open-pdf-doc').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        const docType = (b.status === 'confirmed' || b.status === 'completed') ? 'receipt' : b.status === 'booked' ? 'deposit_receipt' : 'quotation';
        openPdfDocModal(b, docType);
      }
    });
  });

  container.querySelectorAll('.btn-edit-booking').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openBookingModal(b);
    });
  });

  container.querySelectorAll('.btn-book-vacating-unit').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pid = e.currentTarget.getAttribute('data-pid');
      const dStr = e.currentTarget.getAttribute('data-date');
      openBookingModal(null, dStr, pid);
    });
  });

  container.querySelectorAll('.btn-open-receipt-gallery').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openReceiptViewerModal(b);
    });
  });
}

function renderSelectedDayDetails() {
  renderCalendarListing();
}

// ==========================================================================
// 7. BOOKINGS (GUEST CRM) TAB
// ==========================================================================

function renderBookingsTab() {
  const container = document.getElementById('bookingsContainer');
  container.innerHTML = '';

  const query = (document.getElementById('bookingSearchInput')?.value || '').toLowerCase().trim();
  const activeFilterBtn = document.querySelector('#bookingStatusFilters .filter-pill.active');
  const filterType = activeFilterBtn ? activeFilterBtn.getAttribute('data-filter') : 'all';

  let bookings = getFilteredBookings();
  const todayStr = new Date().toISOString().split('T')[0];

  // Apply status filter
  if (filterType === 'all') {
    // Active operational workflow: completed historical monthly tenancies are archived
    bookings = bookings.filter(b => !isCompletedTenancy(b, todayStr));
  } else if (filterType === 'quotation') {
    bookings = bookings.filter(b => b.status === 'quotation');
  } else if (filterType === 'booked') {
    bookings = bookings.filter(b => b.status === 'booked');
  } else if (filterType === 'confirmed') {
    bookings = bookings.filter(b => b.status === 'confirmed');
  } else if (filterType === 'active') {
    bookings = bookings.filter(b => b.status === 'checked-in' || (b.checkIn <= todayStr && b.checkOut >= todayStr && b.status !== 'cancelled' && b.status !== 'quotation' && !isCompletedTenancy(b, todayStr)));
  } else if (filterType === 'completed') {
    bookings = bookings.filter(b => b.status === 'checked-out' || b.status === 'completed' || b.checkOut < todayStr);
  } else if (filterType === 'historical_tenancy') {
    bookings = bookings.filter(b => isCompletedTenancy(b, todayStr));
  } else if (filterType === 'blocked') {
    bookings = bookings.filter(b => b.status === 'blocked');
  }

  // Apply search query
  if (query) {
    bookings = bookings.filter(b => 
      b.guestName.toLowerCase().includes(query) ||
      (b.guestPhone && b.guestPhone.includes(query)) ||
      (b.notes && b.notes.toLowerCase().includes(query))
    );
  }

  // Sort by check-in date descending
  bookings.sort((a, b) => new Date(b.checkIn) - new Date(a.checkIn));

  const isBM = appState.settings.language === 'bm';

  if (bookings.length === 0) {
    const isHist = filterType === 'historical_tenancy';
    container.innerHTML = `
      <div class="card" style="text-align:center; padding:32px 16px;">
        <i class="fa-solid ${isHist ? 'fa-clock-rotate-left' : 'fa-address-book'}" style="font-size:32px; color:var(--text-subtle); margin-bottom:8px;"></i>
        <h4 style="font-size:14px; font-weight:700;">${isHist ? (isBM ? 'Tiada Rekod Sejarah Sewaan' : 'No Historical Tenancies Found') : t('no_bookings_found')}</h4>
        <p class="card-subtitle">${isHist ? (isBM ? 'Semua sewaan bulanan yang telah tamat atau diselesaikan akan disimpan secara automatik di sini.' : 'All monthly tenancies that have completed or ended will be archived here automatically.') : t('no_bookings_hint')}</p>
      </div>
    `;
    return;
  }

  // If in 'All' active view and historical tenancies exist, show helpful access banner
  const allHistoricalTenancies = getFilteredBookings().filter(b => isCompletedTenancy(b, todayStr));
  if (filterType === 'all' && allHistoricalTenancies.length > 0 && !query) {
    const banner = document.createElement('div');
    banner.style.cssText = 'display:flex; align-items:center; justify-content:space-between; gap:10px; padding:10px 14px; background:var(--bg-surface-subtle); border:1px dashed var(--border-color); border-radius:var(--radius-md); margin-bottom:12px; font-size:12px;';
    banner.innerHTML = `
      <span style="color:var(--text-muted);"><i class="fa-solid fa-clock-rotate-left" style="color:var(--primary); margin-right:4px;"></i> ${isBM ? `<strong>${allHistoricalTenancies.length}</strong> sewaan bulanan tamat diarkibkan dalam Sejarah Sewaan.` : `<strong>${allHistoricalTenancies.length}</strong> completed monthly tenancies archived in Historical.`}</span>
      <button class="btn btn-outline btn-xs" id="btnBannerViewHistTenancies" style="font-weight:700; white-space:nowrap; border-radius:999px;">
        ${isBM ? 'Lihat Sejarah Sewaan' : 'View Historical'}
      </button>
    `;
    container.appendChild(banner);
    banner.querySelector('#btnBannerViewHistTenancies')?.addEventListener('click', () => {
      const histPill = document.querySelector('#bookingStatusFilters .filter-pill[data-filter="historical_tenancy"]');
      if (histPill) histPill.click();
    });
  }

  bookings.forEach(b => {
    const prop = getPropertyById(b.propertyId);
    const card = document.createElement('div');
    card.className = 'booking-card';
    card.style.borderLeft = `4px solid ${prop.color}`;

    const isHistTenancy = isCompletedTenancy(b, todayStr);

    const statusBadgeColors = {
      'quotation': 'background: var(--primary-light); color: var(--primary-text);',
      'booked': 'background: var(--warning-light); color: var(--warning-text); border: 1px solid rgba(245,158,11,0.4);',
      'confirmed': 'background: var(--success-light); color: var(--success-text); border: 1px solid rgba(16,185,129,0.4);',
      'checked-in': 'background: #dbeafe; color: #1e40af;',
      'checked-out': isHistTenancy ? 'background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1;' : 'background: var(--bg-surface-subtle); color: var(--text-muted);',
      'completed': 'background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1;',
      'blocked': 'background: var(--danger-light); color: var(--danger-text);',
      'cancelled': 'background: var(--danger-light); color: var(--danger-text);'
    };

    const statusLabels = isBM ? {
      'quotation': '📋 SEBUT HARGA',
      'booked': '🟡 DITEMPAH (DEPOSIT)',
      'confirmed': '🟢 DISAHKAN (PENUH)',
      'checked-in': '🔑 MENGINAP (CHECK-IN)',
      'checked-out': isHistTenancy ? '📜 SEJARAH SEWAAN (TAMAT)' : '🏁 SELESAI',
      'completed': isHistTenancy ? '📜 SEJARAH SEWAAN (SELESAI)' : '🏁 SELESAI',
      'blocked': '🚫 DISEKAT',
      'cancelled': '❌ DIBATALKAN'
    } : {
      'quotation': '📋 QUOTATION',
      'booked': '🟡 BOOKED (DEPOSIT PAID)',
      'confirmed': '🟢 CONFIRMED (PAID FULL)',
      'checked-in': '🔑 IN-HOUSE (CHECKED IN)',
      'checked-out': isHistTenancy ? '📜 HISTORICAL TENANCY (ENDED)' : '🏁 COMPLETED',
      'completed': isHistTenancy ? '📜 HISTORICAL TENANCY (COMPLETED)' : '🏁 COMPLETED',
      'blocked': '🚫 BLOCKED',
      'cancelled': '❌ CANCELLED'
    };

    const channelIcons = {
      'whatsapp': '<i class="fa-brands fa-whatsapp" style="color:var(--whatsapp)"></i> WhatsApp',
      'airbnb': '<i class="fa-solid fa-house" style="color:#ff385c"></i> Airbnb',
      'booking': '<i class="fa-solid fa-b" style="color:#003580"></i> Booking.com',
      'agoda': '<i class="fa-solid fa-globe" style="color:#7c3aed"></i> Agoda',
      'direct': '<i class="fa-solid fa-user-check"></i> Direct',
      'friends': '<i class="fa-solid fa-handshake"></i> Friends',
      'walkin': '<i class="fa-solid fa-person-walking"></i> Walk-In'
    };

    card.innerHTML = `
      <div class="booking-card-top">
        <span class="booking-prop-badge" style="background:${prop.color}20; color:${prop.color};">
          <span class="property-dot" style="background:${prop.color};"></span> ${prop.name}
        </span>
        <span class="booking-channel-badge">${channelIcons[b.channel] || b.channel}</span>
      </div>
      
      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:2px;">
        <h3 class="booking-guest-title">${b.guestName}</h3>
        <div style="display:flex; gap:4px; align-items:center; flex-wrap:wrap;">
          ${(b.payments && b.payments.length > 0) ? `
            <button type="button" class="btn-open-receipt-gallery" data-bid="${b.id}" style="font-size:10px; font-weight:800; padding:2px 7px; border-radius:999px; background:#eff6ff; color:#1d4ed8; border:1px solid #93c5fd; cursor:pointer; display:inline-flex; align-items:center; gap:4px;">
              <i class="fa-solid fa-receipt"></i> ${b.payments.length} ${isBM ? 'Resit' : (b.payments.length === 1 ? 'Receipt' : 'Receipts')}
            </button>
          ` : ''}
          ${b.rentalType === 'monthly' ? `<span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:999px; background:#e0e7ff; color:#3730a3;"><i class="fa-solid fa-calendar-days"></i> ${b.monthlyDuration || 6} ${t('months')}</span>` : ''}
          ${b.rentalType === 'monthly' ? (() => {
            const invs = getOrInitMonthlyInvoices(b);
            const paidCnt = invs.filter(x => x.status === 'paid').length;
            const totalCnt = invs.length;
            const allPaid = paidCnt === totalCnt;
            return `<span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:999px; background:${allPaid ? '#dcfce7; color:#166534;' : '#fef3c7; color:#92400e;'}"><i class="fa-solid fa-file-invoice-dollar"></i> ${paidCnt}/${totalCnt} ${isBM ? 'Invois' : 'Invoices'}</span>`;
          })() : ''}
          <span style="font-size:10px; font-weight:800; padding:3px 8px; border-radius:999px; ${statusBadgeColors[b.status] || ''}">${statusLabels[b.status] || b.status.toUpperCase()}</span>
        </div>
      </div>

      <p class="booking-dates-row">
        <i class="fa-regular fa-calendar"></i> ${b.checkIn} → ${b.checkOut} (${b.rentalType === 'monthly' ? `${b.monthlyDuration || 6} ${t('months')}` : `${b.nights} ${t('nights')}`}) • ${b.guestCount} ${t('guests')}
      </p>

      ${b.notes ? `<p style="font-size:12px; color:var(--text-muted); font-style:italic;"><i class="fa-regular fa-note-sticky"></i> "${b.notes}"</p>` : ''}

      <div class="booking-financial-pill">
        <span>${t('total')}: <strong>${formatCurrency(b.totalAmount)}</strong></span>
        <span>${isBM ? 'Dibayar' : 'Paid'}: <strong style="color:var(--success);">${formatCurrency(b.depositPaid)}</strong></span>
        <span>${isBM ? 'Baki' : 'Due'}: <strong style="color:${b.balance > 0 ? 'var(--danger)' : 'var(--success)'};">${formatCurrency(b.balance)}</strong></span>
        ${b.lastPaymentRef ? `
          <span style="display:flex; align-items:center; gap:4px; font-size:11px; margin-left:auto;">
            <i class="fa-solid fa-receipt" style="color:var(--primary);"></i>
            <span>Ref: <strong><code>${b.lastPaymentRef}</code></strong></span>
          </span>
        ` : ''}
      </div>

      <!-- Contextual Quick Action Workflow Bar -->
      <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:4px;">
        <button class="btn btn-outline btn-xs btn-open-receipt-gallery" data-bid="${b.id}" title="${t('receipt_gallery_title')}">
          <i class="fa-solid fa-receipt"></i> ${(b.payments && b.payments.length > 0) ? `${b.payments.length} ${isBM ? 'Resit' : 'Receipts'}` : (isBM ? '+ Resit' : '+ Receipt')}
        </button>
        ${b.rentalType === 'monthly' ? `
          <button class="btn btn-outline btn-xs btn-open-monthly-invoices" data-bid="${b.id}" style="color:var(--primary); font-weight:700; border-color:var(--primary);">
            <i class="fa-solid fa-file-invoice-dollar"></i> ${t('btn_view_invoices')}
          </button>
          <button class="btn btn-outline btn-xs btn-open-agreement" data-bid="${b.id}" style="color:#0284c7; font-weight:700; border-color:#0284c7; background:rgba(2,132,199,0.08);" title="${isBM ? 'Penjana Surat Perjanjian Sewa (Tenancy Agreement)' : 'Residential Tenancy Agreement Generator'}">
            <i class="fa-solid fa-file-contract"></i> ${isBM ? 'Perjanjian Sewa' : 'Tenancy Agreement'}
          </button>
          <button class="btn btn-primary btn-xs btn-quick-download-agreement" data-bid="${b.id}" style="font-weight:700; background:linear-gradient(135deg, #0284c7, #0369a1); border-color:#0284c7;" title="${isBM ? 'Muat Turun Terus PDF Perjanjian ke Folder Downloads' : 'Download Agreement PDF directly to Downloads folder'}">
            <i class="fa-solid fa-file-arrow-down"></i> ${isBM ? 'PDF Perjanjian' : 'Agreement PDF'}
          </button>
        ` : ''}

        ${b.status === 'quotation' ? `
          <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="quotation">
            <i class="fa-solid fa-file-lines"></i> ${t('btn_send_quotation')}
          </button>
          <button class="btn btn-outline btn-xs btn-mark-booked" data-bid="${b.id}">
            <i class="fa-solid fa-hand-holding-dollar" style="color:var(--warning);"></i> ${t('btn_mark_booked')}
          </button>
        ` : ''}

        ${b.status === 'booked' ? `
          <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="deposit_receipt">
            <i class="fa-solid fa-receipt"></i> ${t('btn_send_deposit_receipt')}
          </button>
          <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="checkin_reminder" style="color:var(--primary); font-weight:700;">
            <i class="fa-solid fa-bell"></i> ${t('btn_checkin_reminder')}
          </button>
          ${b.rentalType === 'monthly' ? `
            <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="monthly_invoice">
              <i class="fa-solid fa-file-invoice"></i> ${t('btn_send_invoice')}
            </button>
          ` : `
            <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="invoice">
              <i class="fa-solid fa-file-invoice"></i> ${t('btn_send_invoice')}
            </button>
          `}
          <button class="btn btn-outline btn-xs btn-mark-confirmed" data-bid="${b.id}">
            <i class="fa-solid fa-key" style="color:var(--success);"></i> ${t('btn_mark_confirmed')}
          </button>
        ` : ''}

        ${b.status === 'confirmed' ? `
          <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="full_receipt">
            <i class="fa-solid fa-key"></i> ${t('btn_send_full_receipt')}
          </button>
          <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="checkin_reminder" style="color:var(--primary); font-weight:700;">
            <i class="fa-solid fa-bell"></i> ${t('btn_checkin_reminder')}
          </button>
          <button class="btn btn-outline btn-xs btn-mark-checkin" data-bid="${b.id}">
            <i class="fa-solid fa-door-open" style="color:var(--primary);"></i> ${t('btn_checkin')}
          </button>
          ${b.rentalType === 'monthly' ? `
            <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="monthly_invoice">
              <i class="fa-solid fa-file-invoice"></i> ${t('btn_send_invoice')}
            </button>
          ` : ''}
        ` : ''}

        ${b.status === 'checked-in' ? `
          ${b.rentalType === 'monthly' ? `
            <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="monthly_invoice">
              <i class="fa-solid fa-file-invoice"></i> ${t('btn_send_invoice')}
            </button>
            <button class="btn btn-outline btn-xs btn-open-refund" data-bid="${b.id}">
              <i class="fa-solid fa-money-bill-transfer" style="color:var(--success);"></i> ${isBM ? 'Tamat Sewa & Pulang Deposit' : 'End Tenancy & Refund Deposit'}
            </button>
          ` : `
            <button class="btn btn-whatsapp btn-xs btn-open-wa" data-bid="${b.id}" data-wa="checkout">
              <i class="fa-solid fa-flag-checkered"></i> ${t('btn_checkout_reminder')}
            </button>
            ${b.securityDeposit > 0 ? `
              <button class="btn btn-outline btn-xs btn-open-refund" data-bid="${b.id}">
                <i class="fa-solid fa-money-bill-transfer" style="color:var(--success);"></i> ${isBM ? 'Pulang Deposit Keselamatan' : 'Refund Security Deposit'}
              </button>
            ` : ''}
            <button class="btn btn-outline btn-xs btn-mark-checkout" data-bid="${b.id}">
              <i class="fa-solid fa-check"></i> ${t('btn_complete_checkout')}
            </button>
          `}
        ` : ''}

        ${(b.status === 'checked-out' || b.status === 'completed' || isHistTenancy) ? `
          ${(b.rentalDeposit || b.securityDeposit) ? `
            <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="refund_receipt">
              <i class="fa-solid fa-file-invoice-dollar"></i> ${isBM ? 'Lihat Penyata Pulangan' : 'View Refund Statement'}
            </button>
          ` : ''}
          ${isHistTenancy ? `
            <button class="btn btn-outline btn-xs btn-reopen-tenancy" data-bid="${b.id}" style="color:var(--primary); font-weight:700;">
              <i class="fa-solid fa-arrow-rotate-left"></i> ${isBM ? 'Aktifkan Semula' : 'Reactivate'}
            </button>
          ` : ''}
        ` : ''}

        <button class="btn btn-outline btn-xs btn-open-wa" data-bid="${b.id}" data-wa="payment" title="${t('btn_wa')}">
          <i class="fa-brands fa-whatsapp"></i>
        </button>
        <button class="btn btn-outline btn-xs btn-change-homestay" data-bid="${b.id}" title="${t('btn_change_homestay')}">
          <i class="fa-solid fa-arrow-right-arrow-left"></i> ${t('btn_change_homestay')}
        </button>
        <button class="btn btn-outline btn-xs btn-open-pdf-doc" data-bid="${b.id}" title="${isBM ? 'Jana Dokumen PDF Rasmi (Sebut Harga / Invois / Resit)' : 'Generate Official PDF (Quotation / Invoice / Receipt)'}" style="color:var(--primary); font-weight:700;">
          <i class="fa-solid fa-file-pdf"></i> PDF
        </button>
        <button class="btn btn-outline btn-xs btn-edit-booking" data-bid="${b.id}" title="${t('edit')}">
          <i class="fa-solid fa-pen"></i> ${t('edit')}
        </button>
        <button class="btn btn-danger-outline btn-xs btn-delete-booking" data-bid="${b.id}" title="${t('delete')}">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </div>
    `;

    container.appendChild(card);
  });

  // Attach event handlers
  container.querySelectorAll('.btn-open-monthly-invoices').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openMonthlyInvoicesModal(b);
    });
  });

  container.querySelectorAll('.btn-open-agreement').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => String(x.id) === String(bid));
      if (b) openAgreementModal(b, 'preview');
    });
  });

  container.querySelectorAll('.btn-open-wa').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const waTemplate = e.currentTarget.getAttribute('data-wa') || 'quotation';
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        // If monthly invoice template, pick first pending month
        if (b.rentalType === 'monthly' && waTemplate === 'monthly_invoice') {
          const invs = getOrInitMonthlyInvoices(b);
          const firstPending = invs.find(x => x.status === 'pending');
          const mIdx = firstPending ? firstPending.monthIndex : 1;
          openWhatsAppModal(b, waTemplate, mIdx);
        } else {
          openWhatsAppModal(b, waTemplate);
        }
      }
    });
  });

  container.querySelectorAll('.btn-open-refund').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openDepositRefundModal(b);
    });
  });

  container.querySelectorAll('.btn-mark-booked').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        const defaultDep = b.depositPaid > 0 ? b.depositPaid : Math.round(b.totalAmount * (appState.settings.defaultDepositPct || 30) / 100);
        openPaymentProofModal(b, 'deposit', null, defaultDep);
      }
    });
  });

  container.querySelectorAll('.btn-mark-confirmed').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        const defaultBal = b.balance > 0 ? b.balance : b.totalAmount;
        openPaymentProofModal(b, 'balance', null, defaultBal);
      }
    });
  });

  container.querySelectorAll('.btn-open-receipt-gallery').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openReceiptViewerModal(b);
    });
  });

  container.querySelectorAll('.btn-mark-checkin').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        b.status = 'checked-in';
        saveToStorage();
        renderBookingsTab();
        showToast(isBM ? 'Tetamu didaftar masuk!' : 'Guest checked in!');
      }
    });
  });

  container.querySelectorAll('.btn-mark-checkout').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        b.status = 'checked-out';
        if (b.rentalType === 'monthly') {
          b.isHistorical = true;
        }
        if (b.balance > 0) {
          b.depositPaid = b.totalAmount;
          b.balance = 0;
        }
        saveToStorage();
        renderBookingsTab();
        renderDashboardTab();
        showToast(isBM 
          ? (b.rentalType === 'monthly' ? 'Sewaan selesai & telah dimasukkan ke Sejarah Sewaan.' : 'Tempahan selesai & baki diselesaikan.') 
          : (b.rentalType === 'monthly' ? 'Tenancy completed & archived into Historical Tenancies.' : 'Booking marked as completed & balance settled.'));
      }
    });
  });

  container.querySelectorAll('.btn-reopen-tenancy').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        if (confirm(isBM ? `Adakah anda ingin mengaktifkan semula sewaan bagi ${b.guestName}?` : `Do you want to reactivate the tenancy for ${b.guestName}?`)) {
          b.status = 'confirmed';
          b.isHistorical = false;
          saveToStorage();
          renderBookingsTab();
          renderDashboardTab();
          showToast(isBM ? 'Sewaan berjaya diaktifkan semula!' : 'Tenancy reactivated successfully!');
        }
      }
    });
  });

  container.querySelectorAll('.btn-change-homestay').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openChangeHomestayModal(b);
    });
  });

  container.querySelectorAll('.btn-open-pdf-doc').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        const docType = (b.status === 'confirmed' || b.status === 'completed') ? 'receipt' : b.status === 'booked' ? 'deposit_receipt' : 'quotation';
        openPdfDocModal(b, docType);
      }
    });
  });

  container.querySelectorAll('.btn-edit-booking').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const b = appState.bookings.find(x => x.id === bid);
      if (b) openBookingModal(b);
    });
  });

  container.querySelectorAll('.btn-delete-booking').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const bid = e.currentTarget.getAttribute('data-bid');
      const confirmText = isBM ? 'Adakah anda pasti mahu memadamkan tempahan ini?' : 'Are you sure you want to delete this booking?';
      if (confirm(confirmText)) {
        appState.bookings = appState.bookings.filter(x => x.id !== bid);
        appState.turnovers = appState.turnovers.filter(tItem => tItem.bookingId !== bid);
        saveToStorage();
        renderBookingsTab();
        showToast(isBM ? 'Tempahan dipadamkan.' : 'Booking deleted successfully.');
      }
    });
  });
}

// ==========================================================================
// 8. TURNOVERS & CLEANING TAB
// ==========================================================================

function renderTurnoversTab() {
  const container = document.getElementById('turnoversContainer');
  container.innerHTML = '';

  const turnovers = getFilteredTurnovers();
  turnovers.sort((a, b) => new Date(a.date) - new Date(b.date));

  if (turnovers.length === 0) {
    container.innerHTML = `
      <div class="card" style="text-align:center; padding:32px 16px;">
        <i class="fa-solid fa-broom" style="font-size:32px; color:var(--text-subtle); margin-bottom:8px;"></i>
        <h4 style="font-size:14px; font-weight:700;">${t('no_turnovers')}</h4>
        <p class="card-subtitle">${t('all_clean_hint')}</p>
      </div>
    `;
    return;
  }

  const isBM = appState.settings.language === 'bm';

  turnovers.forEach(tItem => {
    const prop = getPropertyById(tItem.propertyId);
    const checklist = Array.isArray(tItem.checklist) ? tItem.checklist : [];
    const completedCount = checklist.filter(c => c.done).length;
    const isAllDone = completedCount === checklist.length && checklist.length > 0;

    const card = document.createElement('div');
    card.className = 'turnover-card';
    card.style.borderLeft = `4px solid ${isAllDone ? 'var(--success)' : prop.color}`;

    card.innerHTML = `
      <div class="card-header-flex">
        <div>
          <span class="booking-prop-badge" style="background:${prop.color}20; color:${prop.color};">
            <span class="property-dot" style="background:${prop.color};"></span> ${prop.name}
          </span>
          <h4 style="font-size:15px; font-weight:700; margin-top:4px;">${t('turnover')}: ${tItem.date}</h4>
          <p class="card-subtitle">${booking ? `${isBM ? 'Selepas tetamu' : 'After guest'}: ${booking.guestName}` : (isBM ? 'Pembersihan Menyeluruh Rutin' : 'Routine Deep Clean')}</p>
        </div>
        <span style="font-size:11px; font-weight:700; padding:3px 8px; border-radius:999px; ${isAllDone ? 'background:var(--success-light);color:var(--success-text);' : 'background:var(--warning-light);color:var(--warning-text);'}">
          ${isAllDone ? (isBM ? 'SEDIA UNTUK TETAMU' : 'READY FOR GUEST') : `${completedCount}/${checklist.length} ${isBM ? 'SIAP' : 'DONE'}`}
        </span>
      </div>

      <div class="turnover-checklist">
        ${checklist.map((item, idx) => `
          <label class="checklist-item">
            <input type="checkbox" data-tid="${tItem.id}" data-idx="${idx}" ${item.done ? 'checked' : ''}>
            <span style="${item.done ? 'text-decoration:line-through; opacity:0.6;' : ''}">${item.text}</span>
          </label>
        `).join('')}
      </div>

      <div class="card-header-flex" style="margin-top:8px; margin-bottom:0;">
        <button class="btn btn-whatsapp btn-xs btn-wa-cleaner" data-tid="${tItem.id}">
          <i class="fa-brands fa-whatsapp"></i> ${t('btn_wa_cleaner')}
        </button>
        <button class="btn btn-outline btn-xs btn-toggle-turnover" data-tid="${tItem.id}">
          ${isAllDone ? `<i class="fa-solid fa-rotate-left"></i> ${isBM ? 'Buka Semula' : 'Reopen'}` : `<i class="fa-solid fa-check"></i> ${isBM ? 'Tanda Selesai' : 'Mark Complete'}`}
        </button>
      </div>
    `;

    container.appendChild(card);
  });

  // Handle checklist checkboxes
  container.querySelectorAll('input[type="checkbox"]').forEach(chk => {
    chk.addEventListener('change', (e) => {
      const tid = e.target.getAttribute('data-tid');
      const idx = parseInt(e.target.getAttribute('data-idx'));
      const turnover = appState.turnovers.find(tItem => tItem.id === tid);
      if (turnover && turnover.checklist[idx]) {
        turnover.checklist[idx].done = e.target.checked;
        const allDone = turnover.checklist.every(c => c.done);
        turnover.status = allDone ? 'completed' : 'in_progress';
        saveToStorage();
        renderTurnoversTab();
      }
    });
  });

  // Handle cleaner WhatsApp & Mark complete buttons
  container.querySelectorAll('.btn-wa-cleaner').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tid = e.currentTarget.getAttribute('data-tid');
      const tItem = appState.turnovers.find(x => x.id === tid);
      if (tItem) openWhatsAppCleanerJob(tItem);
    });
  });

  container.querySelectorAll('.btn-toggle-turnover').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tid = e.currentTarget.getAttribute('data-tid');
      const tItem = appState.turnovers.find(x => x.id === tid);
      if (tItem) {
        const setDone = tItem.status !== 'completed';
        tItem.checklist.forEach(c => c.done = setDone);
        tItem.status = setDone ? 'completed' : 'pending';
        saveToStorage();
        renderTurnoversTab();
        showToast(setDone ? (isBM ? 'Pembersihan ditanda siap & sedia!' : 'Turnover marked as ready!') : (isBM ? 'Pembersihan dibuka semula.' : 'Turnover reopened.'));
      }
    });
  });
}

// ==========================================================================
// 9. FINANCES & REPORTS TAB
// ==========================================================================

function populateFinanceDateSelectors() {
  const monthSelect = document.getElementById('financeMonthSelect');
  const yearSelect = document.getElementById('financeYearSelect');
  if (!monthSelect || !yearSelect) return;
  
  const currentVal = monthSelect.value !== '' ? parseInt(monthSelect.value) : new Date().getMonth();
  monthSelect.innerHTML = '';

  const isBM = appState.settings.language === 'bm';
  const months = isBM 
    ? ['Januari', 'Februari', 'Mac', 'April', 'Mei', 'Jun', 'Julai', 'Ogos', 'September', 'Oktober', 'November', 'Disember']
    : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
  months.forEach((m, idx) => {
    const opt = document.createElement('option');
    opt.value = idx;
    opt.textContent = m;
    if (idx === currentVal) opt.selected = true;
    monthSelect.appendChild(opt);
  });

  const yearVal = yearSelect.value !== '' ? parseInt(yearSelect.value) : new Date().getFullYear();
  yearSelect.innerHTML = '';
  const currentYear = new Date().getFullYear();
  for (let y = currentYear - 2; y <= currentYear + 2; y++) {
    const opt = document.createElement('option');
    opt.value = y;
    opt.textContent = y;
    if (y === yearVal) opt.selected = true;
    yearSelect.appendChild(opt);
  }
}

function renderFinancesTab() {
  populateFinanceDateSelectors();
  
  const selMonth = parseInt(document.getElementById('financeMonthSelect').value);
  const selYear = parseInt(document.getElementById('financeYearSelect').value);

  const bookings = getFilteredBookings();
  const expenses = getFilteredExpenses();

  // Filter for selected month
  const monthBookings = bookings.filter(b => {
    if (b.status === 'cancelled') return false;
    const d = new Date(b.checkIn);
    return d.getMonth() === selMonth && d.getFullYear() === selYear;
  });

  const monthExpenses = expenses.filter(e => {
    const d = new Date(e.date);
    return d.getMonth() === selMonth && d.getFullYear() === selYear;
  });

  const totalRev = monthBookings.reduce((sum, b) => sum + (Number(b.totalAmount) || 0), 0);
  const totalExp = monthExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const netProfit = totalRev - totalExp;

  document.getElementById('finTotalRevenue').textContent = formatCurrency(totalRev);
  document.getElementById('finTotalExpenses').textContent = formatCurrency(totalExp);
  document.getElementById('finNetProfit').textContent = formatCurrency(netProfit);
  document.getElementById('finNetProfit').style.color = netProfit >= 0 ? 'var(--success-text)' : 'var(--danger-text)';

  // Revenue by Property breakdown
  const propRevList = document.getElementById('finPropertyRevenueList');
  propRevList.innerHTML = '';

  const displayProps = appState.selectedPropertyId === 'all' 
    ? appState.properties 
    : appState.properties.filter(p => p.id === appState.selectedPropertyId);

  displayProps.forEach(prop => {
    const pBookings = monthBookings.filter(b => b.propertyId === prop.id);
    const pRev = pBookings.reduce((sum, b) => sum + (Number(b.totalAmount) || 0), 0);
    const percentage = totalRev > 0 ? Math.round((pRev / totalRev) * 100) : 0;

    const row = document.createElement('div');
    row.className = 'property-rev-row';
    row.innerHTML = `
      <div class="property-rev-meta">
        <span style="display:flex; align-items:center; gap:6px;">
          <span class="property-dot" style="background:${prop.color};"></span> ${prop.name}
        </span>
        <span>${formatCurrency(pRev)} (${percentage}%)</span>
      </div>
      <div class="progress-bar-bg">
        <div class="progress-bar-fill" style="width:${percentage}%; background:${prop.color};"></div>
      </div>
    `;
    propRevList.appendChild(row);
  });

  // Expense Log List
  const expList = document.getElementById('finExpenseList');
  expList.innerHTML = '';

  if (monthExpenses.length === 0) {
    expList.innerHTML = `<p class="empty-hint">${t('no_expenses')}</p>`;
  } else {
    monthExpenses.forEach(exp => {
      const prop = getPropertyById(exp.propertyId);
      const row = document.createElement('div');
      row.className = 'expense-item-row';
      row.innerHTML = `
        <div>
          <strong style="font-size:13px;">${exp.description || exp.category.toUpperCase()}</strong>
          <p class="card-subtitle">${exp.date} • ${prop.name}</p>
        </div>
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-weight:700; color:var(--danger);">${formatCurrency(exp.amount)}</span>
          <button class="icon-btn btn-xs btn-delete-expense" data-eid="${exp.id}" style="width:24px; height:24px;">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
      `;
      expList.appendChild(row);
    });

    expList.querySelectorAll('.btn-delete-expense').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const eid = e.currentTarget.getAttribute('data-eid');
        appState.expenses = appState.expenses.filter(x => x.id !== eid);
        saveToStorage();
        renderFinancesTab();
        showToast(appState.settings.language === 'bm' ? 'Perbelanjaan dipadamkan.' : 'Expense removed.');
      });
    });
  }
}

// ==========================================================================
// 10. SETTINGS & PROPERTY MANAGEMENT
// ==========================================================================

function renderSettingsTab() {
  document.getElementById('settingBusinessNameInput').value = appState.settings.businessName || 'My Homestay';
  const ssmInput = document.getElementById('settingBusinessSsmInput');
  if (ssmInput) ssmInput.value = appState.settings.businessSsm || '';
  const addrInput = document.getElementById('settingBusinessAddressInput');
  if (addrInput) addrInput.value = appState.settings.businessAddress || '';
  const emailInput = document.getElementById('settingBusinessEmailInput');
  if (emailInput) emailInput.value = appState.settings.businessEmail || '';
  document.getElementById('settingCurrencySelect').value = appState.settings.currency || 'RM';
  
  const ownerPhoneInput = document.getElementById('settingOwnerPhoneInput');
  if (ownerPhoneInput) ownerPhoneInput.value = appState.settings.ownerPhone || '+60123456789';

  document.getElementById('settingSellerPhoneInput').value = appState.settings.sellerPhone || '+60123456789';
  document.getElementById('settingDefaultDepositPctInput').value = appState.settings.defaultDepositPct || 30;
  
  const langSelect = document.getElementById('settingLanguageSelect');
  if (langSelect) langSelect.value = appState.settings.language || 'en';

  document.getElementById('settingBankNameInput').value = appState.settings.bankName || 'Maybank';
  document.getElementById('settingBankAccNumInput').value = appState.settings.bankAccNum || '';
  document.getElementById('settingBankAccHolderInput').value = appState.settings.bankAccHolder || '';
  document.getElementById('settingDuitNowInput').value = appState.settings.duitNow || '';

  const quotationValidityInput = document.getElementById('settingQuotationValidityInput');
  if (quotationValidityInput) quotationValidityInput.value = appState.settings.quotationValidityDays || 3;

  const standardNotesInput = document.getElementById('settingStandardNotesInput');
  if (standardNotesInput) standardNotesInput.value = appState.settings.standardNotes || '';

  const propList = document.getElementById('settingsPropertyList');
  propList.innerHTML = '';

  const isBM = appState.settings.language === 'bm';

  if (appState.properties.length === 0) {
    propList.innerHTML = `
      <div style="text-align:center; padding:24px 16px; background:var(--bg-surface-subtle); border-radius:var(--radius-md); border:1px dashed var(--border-color);">
        <i class="fa-solid fa-house-chimney" style="font-size:28px; color:var(--text-muted); margin-bottom:8px;"></i>
        <p style="font-size:13px; font-weight:700; color:var(--text-main); margin-bottom:4px;">${isBM ? 'Tiada unit homestay didaftarkan lagi' : 'No homestay units added yet'}</p>
        <p style="font-size:11px; color:var(--text-muted); margin-bottom:12px;">${isBM ? 'Tambah unit homestay atau bilik anda sendiri untuk mula merekod tempahan sebenar.' : 'Add your own homestays or room rentals to start recording real bookings.'}</p>
        <button class="btn btn-primary btn-sm" id="btnSettingsAddFirstProp"><i class="fa-solid fa-plus"></i> ${isBM ? 'Tambah Unit Pertama Anda' : 'Add Your First Unit'}</button>
      </div>
    `;
    const addFirstBtn = document.getElementById('btnSettingsAddFirstProp');
    if (addFirstBtn) addFirstBtn.addEventListener('click', () => openPropertyModal());
  } else {
    appState.properties.forEach(prop => {
      const card = document.createElement('div');
      card.className = 'settings-prop-card';
      const typeLabel = prop.propType === 'room_master' ? (isBM ? '🚪 Bilik Master' : '🚪 Master Room') :
                        prop.propType === 'room_medium' ? (isBM ? '🚪 Bilik Medium' : '🚪 Medium Room') :
                        prop.propType === 'room_single' ? (isBM ? '🚪 Bilik Single' : '🚪 Single Room') :
                        prop.propType === 'studio' ? '🏢 Studio' : (isBM ? '🏡 Seluruh Unit' : '🏡 Whole Unit');

      card.innerHTML = `
        <div class="settings-prop-details">
          <h4 style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
            <span class="property-dot" style="background:${prop.color};"></span>
            ${prop.name}
            <span style="font-size:10px; font-weight:700; background:var(--bg-surface-subtle); padding:2px 6px; border-radius:999px; color:var(--primary);">${typeLabel}</span>
          </h4>
          <p><i class="fa-solid fa-location-dot" style="color:var(--primary);"></i> ${prop.address || (isBM ? 'Alamat belum diisi' : 'No address set')}${prop.gpsLocation ? ` • <a href="${prop.gpsLocation}" target="_blank" style="color:var(--primary); font-weight:700; text-decoration:none;"><i class="fa-solid fa-map-location-dot"></i> GPS / Maps</a>` : ''}</p>
          <p>🔑 PIN: <strong>${prop.doorCode || (isBM ? 'Tiada' : 'None')}</strong> • 📶 WiFi: <strong>${prop.wifiName || (isBM ? 'Tiada' : 'None')}</strong></p>
          <p>${isBM ? 'Kadar' : 'Rate'}: ${formatCurrency(prop.defaultRate)}/${isBM ? 'malam' : 'night'} • ${isBM ? 'Pembersihan' : 'Clean fee'}: ${formatCurrency(prop.cleaningFee)}</p>
        </div>
        <div style="display:flex; gap:6px;">
          <button class="btn btn-outline btn-xs btn-edit-prop" data-pid="${prop.id}"><i class="fa-solid fa-pen"></i></button>
          <button class="btn btn-danger-outline btn-xs btn-delete-prop" data-pid="${prop.id}" title="${t('delete')}"><i class="fa-solid fa-trash"></i></button>
        </div>
      `;
      propList.appendChild(card);
    });

    propList.querySelectorAll('.btn-edit-prop').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pid = e.currentTarget.getAttribute('data-pid');
        const p = appState.properties.find(x => x.id === pid);
        if (p) openPropertyModal(p);
      });
    });

    propList.querySelectorAll('.btn-delete-prop').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pid = e.currentTarget.getAttribute('data-pid');
        const confirmDelete = isBM ? 'Padamkan unit ini? Rekod tempahan sedia ada akan kekal.' : 'Delete this homestay unit? All associated bookings will remain.';
        if (confirm(confirmDelete)) {
          appState.properties = appState.properties.filter(x => x.id !== pid);
          if (appState.selectedPropertyId === pid) appState.selectedPropertyId = 'all';
          saveToStorage();
          renderApp();
          showToast(isBM ? 'Unit homestay dipadamkan.' : 'Homestay removed.');
        }
      });
    });
  }

  // Render License Status in Settings
  const subTitle = document.getElementById('settingsLicenseSubtitle');
  const badge = document.getElementById('settingsLicenseBadge');
  const actions = document.getElementById('settingsLicenseActions');
  const adminGenCard = document.getElementById('adminLicenseGenCard');

  if (appState.isLicensed) {
    const isMaster = appState.isMasterAdmin || isMasterAdminKey(appState.licenseKey);
    
    if (isMaster) {
      subTitle.textContent = `Key: ${appState.licenseKey} (Master Admin)`;
      badge.textContent = '👑 MASTER ADMIN';
      badge.style.background = 'var(--primary-light)';
      badge.style.color = 'var(--primary-text)';
      if (adminGenCard) adminGenCard.classList.remove('hidden');
    } else {
      const boundPhone = appState.licenseKey.split('-')[1] || appState.settings.ownerPhone;
      subTitle.textContent = `Key: ${appState.licenseKey} (${isBM ? 'Terkunci ke' : 'Tied to'} +${boundPhone})`;
      badge.textContent = isBM ? '✨ LESEN AKTIF' : '✨ LIFETIME ACTIVE';
      badge.style.background = 'var(--success-light)';
      badge.style.color = 'var(--success-text)';
      if (adminGenCard) adminGenCard.classList.add('hidden');
    }

    actions.innerHTML = `
      <div style="background:var(--bg-surface-subtle); padding:10px 12px; border-radius:var(--radius-sm); border:1px solid var(--border-color); margin-bottom:10px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
          <span style="font-size:12px; font-weight:700; color:var(--text-main);">
            <i class="fa-solid fa-shield-halved" style="color:var(--primary);"></i> ${isMaster ? 'Master Admin Pro System' : (isBM ? 'Sistem Pro Diaktifkan' : 'Pro Lifetime License')}
          </span>
          <span style="font-size:11px; font-weight:800; padding:2px 8px; border-radius:999px; background:var(--primary-light); color:var(--primary-text);">
            v${APP_VERSION}
          </span>
        </div>
        <p style="font-size:11.5px; color:var(--text-muted); margin:0 0 10px 0;">
          <i class="fa-solid fa-circle-check" style="color:var(--success);"></i> ${isBM ? 'Akses penuh tanpa had & data peribadi luar talian aktif.' : 'Full unlimited access & private offline data active.'}
        </p>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <button type="button" class="btn btn-primary btn-sm" id="btnLicenseCheckUpdates" style="font-weight:700; flex:1; min-width:140px; justify-content:center;">
            <i class="fa-solid fa-rotate"></i> ${isBM ? 'Semak Kemas Kini' : 'Check for Updates'}
          </button>
          <button type="button" class="btn btn-outline btn-sm" id="btnLicenseOpenGuide" style="color:var(--primary); font-weight:700; border-color:var(--primary); flex:1; min-width:140px; justify-content:center;">
            <i class="fa-solid fa-book-open"></i> ${isBM ? 'Panduan Pengguna' : 'User Manual'}
          </button>
        </div>
        <div style="margin-top:8px; padding-top:8px; border-top:1px dashed var(--border-color); display:flex; justify-content:space-between; align-items:center;">
          <span style="font-size:11px; color:var(--text-muted);">
            <i class="fa-solid fa-clock-rotate-left"></i> Zero Data Loss Update
          </span>
          <button type="button" class="btn btn-outline btn-xs" id="btnChangeLicenseKey">
            <i class="fa-solid fa-arrows-rotate"></i> ${isBM ? 'Tukar Lesen' : 'Change Key'}
          </button>
        </div>
      </div>
    `;
    document.getElementById('btnLicenseCheckUpdates')?.addEventListener('click', () => checkForAppUpdates(true));
    document.getElementById('btnLicenseOpenGuide')?.addEventListener('click', () => openUserGuideModal());
    document.getElementById('btnChangeLicenseKey')?.addEventListener('click', openLicenseModal);

    // Wire Admin License card update & guide buttons if present
    document.getElementById('btnAdminCheckUpdates')?.addEventListener('click', () => checkForAppUpdates(true));
    document.getElementById('btnAdminOpenGuide')?.addEventListener('click', () => openUserGuideModal());
  } else {
    subTitle.textContent = isBM ? 'Tiada Lesen (Mod Demo)' : 'Unlicensed (Demo Mode)';
    badge.textContent = isBM ? 'DEMO' : 'DEMO';
    badge.style.background = 'var(--warning-light)';
    badge.style.color = 'var(--warning-text)';
    if (adminGenCard) adminGenCard.classList.add('hidden');

    actions.innerHTML = `
      <div style="display:flex; gap:8px;">
        <button class="btn btn-primary btn-sm" id="btnActivateFromSettings">
          <i class="fa-solid fa-key"></i> ${isBM ? 'Masukkan Kunci Lesen' : 'Enter License Key'}
        </button>
        <button class="btn btn-whatsapp btn-sm" id="btnBuyFromSettings">
          <i class="fa-brands fa-whatsapp"></i> ${isBM ? 'Beli Lesen' : 'Buy License'}
        </button>
      </div>
    `;
    document.getElementById('btnActivateFromSettings').addEventListener('click', openLicenseModal);
    document.getElementById('btnBuyFromSettings').addEventListener('click', handleBuyLicenseRedirect);
  }

  const verBadge = document.getElementById('appCurrentVersionBadge');
  if (verBadge) verBadge.textContent = `v${APP_VERSION}`;

  // Render Maintenance Team & Suppliers Directory
  renderSettingsContactList();
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(new RegExp('"', 'g'), '&quot;')
    .replace(new RegExp("'", 'g'), '&#039;');
}

function getContactCategoryBadge(cat) {
  const isBM = appState.settings.language === 'bm';
  switch (cat) {
    case 'cleaner':
      return { label: isBM ? '🧹 Tukang Cuci' : '🧹 Cleaner', class: 'cat-cleaner' };
    case 'aircond':
      return { label: isBM ? '❄️ Juruteknik Aircond' : '❄️ Aircond Tech', class: 'cat-aircond' };
    case 'plumber':
      return { label: isBM ? '🔧 Tukang Paip' : '🔧 Plumber', class: 'cat-plumber' };
    case 'electrician':
      return { label: isBM ? '⚡ Juruelektrik' : '⚡ Electrician', class: 'cat-electrician' };
    case 'handyman':
      return { label: isBM ? '🔨 Baiki Am / Handyman' : '🔨 Handyman', class: 'cat-handyman' };
    case 'linen_supplier':
      return { label: isBM ? '🧺 Pembekal Linen & Dobi' : '🧺 Linen Supplier', class: 'cat-linen_supplier' };
    case 'gas_supplier':
      return { label: isBM ? '⛽ Pembekal Gas & Barang' : '⛽ Gas / Amenities', class: 'cat-gas_supplier' };
    case 'locksmith':
      return { label: isBM ? '🔐 Tukang Kunci' : '🔐 Locksmith', class: 'cat-locksmith' };
    default:
      return { label: isBM ? '📦 Vendor / Pembekal' : '📦 Contractor / Vendor', class: 'cat-other' };
  }
}

function renderSettingsContactList() {
  const container = document.getElementById('settingsContactList');
  if (!container) return;
  container.innerHTML = '';

  const isBM = appState.settings.language === 'bm';
  const contacts = appState.contacts || [];

  if (contacts.length === 0) {
    container.innerHTML = `
      <div style="text-align:center; padding:24px 16px; background:var(--bg-surface-subtle); border-radius:var(--radius-md); border:1px dashed var(--border-color);">
        <i class="fa-solid fa-users-gear" style="font-size:28px; color:var(--text-muted); margin-bottom:8px;"></i>
        <p style="font-size:13px; font-weight:700; color:var(--text-main); margin-bottom:4px;">${isBM ? 'Tiada kenalan / pembekal disimpan lagi' : 'No team members or suppliers added yet'}</p>
        <p style="font-size:11px; color:var(--text-muted); margin-bottom:12px;">${isBM ? 'Simpan tukang cuci, juruteknik aircond, tukang paip dan pembekal untuk notis kerja pantas 1-klik WhatsApp.' : 'Save cleaners, aircond techs, plumbers & supply vendors for 1-click WhatsApp alerts.'}</p>
        <button class="btn btn-primary btn-sm" id="btnSettingsAddFirstContact"><i class="fa-solid fa-plus"></i> ${isBM ? 'Tambah Kenalan Pertama' : 'Add First Contact'}</button>
      </div>
    `;
    const addFirst = document.getElementById('btnSettingsAddFirstContact');
    if (addFirst) addFirst.addEventListener('click', () => openContactModal());
    return;
  }

  contacts.forEach(contact => {
    const card = document.createElement('div');
    card.className = 'contact-card';
    const badgeInfo = getContactCategoryBadge(contact.category);
    const cleanPhone = (contact.phone || '').replace(/[^0-9]/g, '');

    card.innerHTML = `
      <div class="contact-card-header">
        <div>
          <div class="contact-card-title">${escapeHtml(contact.name)}</div>
          ${contact.company ? `<div class="contact-company-text"><i class="fa-solid fa-briefcase"></i> ${escapeHtml(contact.company)}</div>` : ''}
        </div>
        <span class="contact-category-badge ${badgeInfo.class}">
          ${badgeInfo.label}
        </span>
      </div>

      <div class="contact-card-body">
        <a href="https://wa.me/${cleanPhone}" target="_blank" class="contact-phone-link">
          <i class="fa-brands fa-whatsapp" style="color:var(--success);"></i> ${escapeHtml(contact.phone)}
        </a>
        ${contact.notes ? `<div class="contact-notes-text">${escapeHtml(contact.notes)}</div>` : ''}
      </div>

      <div class="contact-card-actions">
        <button class="btn btn-whatsapp btn-xs btn-contact-dispatch" data-cid="${contact.id}" title="${isBM ? 'Hantar Notis Servis / Bekalan' : 'Dispatch Service / Supply'}">
          <i class="fa-brands fa-whatsapp"></i> ${isBM ? 'Hantar Notis' : 'Dispatch Alert'}
        </button>
        <div style="display:flex; gap:6px;">
          <button class="btn btn-outline btn-xs btn-edit-contact" data-cid="${contact.id}" title="${t('edit')}">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button class="btn btn-danger-outline btn-xs btn-delete-contact" data-cid="${contact.id}" title="${t('delete')}">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </div>
    `;

    container.appendChild(card);
  });

  // Action listeners
  container.querySelectorAll('.btn-contact-dispatch').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cid = e.currentTarget.getAttribute('data-cid');
      const c = appState.contacts.find(x => x.id === cid);
      if (c) openServiceDispatchModal(null, c.category, c.id);
    });
  });

  container.querySelectorAll('.btn-edit-contact').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cid = e.currentTarget.getAttribute('data-cid');
      openContactModal(cid);
    });
  });

  container.querySelectorAll('.btn-delete-contact').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cid = e.currentTarget.getAttribute('data-cid');
      handleDeleteContact(cid);
    });
  });
}

function openContactModal(contactId = null) {
  const isBM = appState.settings.language === 'bm';
  const modal = document.getElementById('contactModal');
  const title = document.getElementById('contactModalTitle');
  const idInput = document.getElementById('contactIdInput');
  const nameInput = document.getElementById('contactNameInput');
  const catSelect = document.getElementById('contactCategorySelect');
  const phoneInput = document.getElementById('contactPhoneInput');
  const compInput = document.getElementById('contactCompanyInput');
  const notesInput = document.getElementById('contactNotesInput');

  if (contactId) {
    const contact = (appState.contacts || []).find(c => c.id === contactId);
    if (contact) {
      if (title) title.textContent = isBM ? 'Kemaskini Butiran Kenalan' : 'Edit Contact Details';
      if (idInput) idInput.value = contact.id;
      if (nameInput) nameInput.value = contact.name || '';
      if (catSelect) catSelect.value = contact.category || 'cleaner';
      if (phoneInput) phoneInput.value = contact.phone || '';
      if (compInput) compInput.value = contact.company || '';
      if (notesInput) notesInput.value = contact.notes || '';
    }
  } else {
    if (title) title.textContent = isBM ? 'Tambah Pasukan / Pembekal' : 'Add Team Member / Supplier';
    if (idInput) idInput.value = '';
    if (nameInput) nameInput.value = '';
    if (catSelect) catSelect.value = 'cleaner';
    if (phoneInput) phoneInput.value = '';
    if (compInput) compInput.value = '';
    if (notesInput) notesInput.value = '';
  }

  if (modal) modal.classList.add('active');
}

function handleSaveContact(e) {
  e.preventDefault();
  const idInput = document.getElementById('contactIdInput').value;
  const name = document.getElementById('contactNameInput').value.trim();
  const category = document.getElementById('contactCategorySelect').value;
  const phone = document.getElementById('contactPhoneInput').value.trim();
  const company = document.getElementById('contactCompanyInput').value.trim();
  const notes = document.getElementById('contactNotesInput').value.trim();

  if (!name || !phone) {
    alert(appState.settings.language === 'bm' ? 'Sila masukkan nama dan nombor WhatsApp.' : 'Please enter contact name and WhatsApp phone number.');
    return;
  }

  if (!Array.isArray(appState.contacts)) appState.contacts = [];

  if (idInput) {
    // Update
    const idx = appState.contacts.findIndex(c => c.id === idInput);
    if (idx !== -1) {
      appState.contacts[idx] = {
        ...appState.contacts[idx],
        name,
        category,
        phone,
        company,
        notes
      };
    }
  } else {
    // New
    const newContact = {
      id: 'c-' + Date.now(),
      name,
      category,
      phone,
      company,
      notes
    };
    appState.contacts.push(newContact);
  }

  saveToStorage();
  renderSettingsContactList();
  closeAllModals();
  showToast(appState.settings.language === 'bm' ? 'Kenalan berjaya disimpan!' : 'Contact saved successfully!');
}

function handleDeleteContact(contactId) {
  const isBM = appState.settings.language === 'bm';
  const contact = (appState.contacts || []).find(c => c.id === contactId);
  if (!contact) return;

  const msg = isBM ? `Padamkan ${contact.name} daripada direktori pasukan?` : `Remove ${contact.name} from your team directory?`;
  if (confirm(msg)) {
    appState.contacts = appState.contacts.filter(c => c.id !== contactId);
    saveToStorage();
    renderSettingsContactList();
    showToast(isBM ? 'Kenalan telah dipadamkan.' : 'Contact removed.');
  }
}

function handleSavePreferences() {
  const newOwnerPhone = document.getElementById('settingOwnerPhoneInput') ? document.getElementById('settingOwnerPhoneInput').value.trim() : appState.settings.ownerPhone;
  const oldOwnerPhone = appState.settings.ownerPhone;

  appState.settings.businessName = document.getElementById('settingBusinessNameInput').value || 'My Homestay';
  appState.settings.businessSsm = document.getElementById('settingBusinessSsmInput') ? document.getElementById('settingBusinessSsmInput').value.trim() : (appState.settings.businessSsm || '');
  appState.settings.businessAddress = document.getElementById('settingBusinessAddressInput') ? document.getElementById('settingBusinessAddressInput').value.trim() : (appState.settings.businessAddress || '');
  appState.settings.businessEmail = document.getElementById('settingBusinessEmailInput') ? document.getElementById('settingBusinessEmailInput').value.trim() : (appState.settings.businessEmail || '');
  appState.settings.currency = document.getElementById('settingCurrencySelect').value || 'RM';
  appState.settings.ownerPhone = newOwnerPhone || '+60123456789';
  appState.settings.sellerPhone = newOwnerPhone || appState.settings.sellerPhone || '+60123456789';
  appState.settings.language = document.getElementById('settingLanguageSelect') ? document.getElementById('settingLanguageSelect').value : (appState.settings.language || 'en');
  appState.settings.defaultDepositPct = parseInt(document.getElementById('settingDefaultDepositPctInput').value) || 30;
  appState.settings.quotationValidityDays = parseInt(document.getElementById('settingQuotationValidityInput')?.value) || 3;
  appState.settings.standardNotes = document.getElementById('settingStandardNotesInput') ? document.getElementById('settingStandardNotesInput').value.trim() : (appState.settings.standardNotes || '');

  saveToStorage();
  applyLanguageUI();
  renderApp();
  showToast(appState.settings.language === 'bm' ? 'Tetapan berjaya disimpan!' : 'Preferences & WhatsApp settings saved!');
}

// ==========================================================================
// 10B. BOOKING OVERLAP PREVENTION & CHANGE HOMESTAY (v2.6.3)
// ==========================================================================

function getBookingOverlaps(propertyId, checkIn, checkOut, excludeBookingId = null) {
  if (!propertyId || !checkIn || !checkOut) return [];
  if (checkIn >= checkOut) return [];

  const todayStr = new Date().toISOString().split('T')[0];

  return appState.bookings.filter(b => {
    if (b.propertyId !== propertyId) return false;
    if (excludeBookingId && b.id === excludeBookingId) return false;
    if (b.status === 'cancelled') return false;
    // Completed historical tenancies and ended stays should not block future reservations
    if (b.status === 'checked-out' || b.status === 'completed' || isCompletedTenancy(b, todayStr)) return false;
    // Standard hotel interval overlap: (checkInA < checkOutB) && (checkOutA > checkInB)
    return (checkIn < b.checkOut) && (checkOut > b.checkIn);
  });
}

function checkBookingModalOverlap() {
  const alertEl = document.getElementById('bookingModalOverlapAlert');
  if (!alertEl) return;

  const modal = document.getElementById('bookingModal');
  if (!modal || !modal.classList.contains('active')) {
    alertEl.style.display = 'none';
    return;
  }

  const propertyId = document.getElementById('bookingPropertySelect')?.value;
  const rentalType = document.getElementById('bookingRentalType')?.value || 'daily';
  const id = document.getElementById('bookingIdInput')?.value || null;
  const status = document.getElementById('bookingStatusSelect')?.value || 'booked';

  if (status === 'cancelled' || !propertyId) {
    alertEl.style.display = 'none';
    return;
  }

  let checkIn = '';
  let checkOut = '';

  if (rentalType === 'monthly') {
    const mStart = document.getElementById('bookingMonthlyStart')?.value;
    const mDuration = parseInt(document.getElementById('bookingMonthlyDuration')?.value) || 1;
    if (!mStart) {
      alertEl.style.display = 'none';
      return;
    }
    checkIn = mStart;
    const dStart = new Date(mStart + 'T00:00:00');
    const dEnd = new Date(dStart);
    dEnd.setMonth(dEnd.getMonth() + mDuration);
    checkOut = dEnd.toISOString().split('T')[0];
  } else {
    checkIn = document.getElementById('bookingCheckIn')?.value;
    checkOut = document.getElementById('bookingCheckOut')?.value;
  }

  if (!checkIn || !checkOut || checkIn >= checkOut) {
    alertEl.style.display = 'none';
    return;
  }

  const overlaps = getBookingOverlaps(propertyId, checkIn, checkOut, id);
  if (overlaps.length > 0) {
    const isBM = appState.settings.language === 'bm';
    const c = overlaps[0];
    const cDates = `${c.checkIn} → ${c.checkOut}`;
    
    document.getElementById('bookingModalOverlapTitle').textContent = isBM 
      ? '⚠️ Perhatian: Tarikh Bertindih dengan Tempahan Sedia Ada!' 
      : '⚠️ Warning: Clashes with an Existing Booking!';

    document.getElementById('bookingModalOverlapDetails').innerHTML = isBM
      ? `Unit ini telah ditempah oleh <strong>${c.guestName}</strong> (${cDates}). Sila pilih homestay lain atau tukar tarikh.`
      : `This unit is already booked by <strong>${c.guestName}</strong> (${cDates}). Please switch homestay or select different dates.`;

    const switchBtn = document.getElementById('btnModalSwitchHomestay');
    if (switchBtn) {
      const freeProps = appState.properties.filter(p => p.id !== propertyId && getBookingOverlaps(p.id, checkIn, checkOut, id).length === 0);
      if (freeProps.length > 0) {
        switchBtn.style.display = 'inline-flex';
        switchBtn.innerHTML = `<i class="fa-solid fa-arrow-right-arrow-left"></i> ${isBM ? `Tukar ke ${freeProps[0].name}` : `Switch to ${freeProps[0].name}`}`;
        switchBtn.onclick = () => {
          document.getElementById('bookingPropertySelect').value = freeProps[0].id;
          updateBookingModalPricing();
          checkBookingModalOverlap();
        };
      } else {
        switchBtn.style.display = 'none';
      }
    }

    alertEl.style.display = 'flex';
  } else {
    alertEl.style.display = 'none';
  }
}

function openOverlapWarningModal(overlaps, propertyId, checkIn, checkOut, guestName, currentBookingId) {
  const isBM = appState.settings.language === 'bm';
  const prop = getPropertyById(propertyId);

  document.getElementById('overlapModalPropName').textContent = `${prop.name}`;
  document.getElementById('overlapModalDatesText').textContent = `${checkIn} → ${checkOut} (${guestName || (isBM ? 'Tetamu Baru' : 'New Guest')})`;

  const conflictList = document.getElementById('overlapConflictDetailsList');
  conflictList.innerHTML = overlaps.map(c => {
    const statusLabels = isBM ? {
      'quotation': '📋 SEBUT HARGA',
      'booked': '🟡 DITEMPAH',
      'confirmed': '🟢 DISAHKAN',
      'checked-in': '🔑 MENGINAP',
      'checked-out': '🏁 SELESAI',
      'blocked': '🚫 DISEKAT'
    } : {
      'quotation': '📋 QUOTATION',
      'booked': '🟡 BOOKED',
      'confirmed': '🟢 CONFIRMED',
      'checked-in': '🔑 IN-HOUSE',
      'checked-out': '🏁 COMPLETED',
      'blocked': '🚫 BLOCKED'
    };
    return `
      <div class="overlap-conflict-item">
        <div>
          <div class="overlap-conflict-guest">
            <i class="fa-solid fa-user" style="color:var(--primary); font-size:11px; margin-right:4px;"></i>${c.guestName}
            ${c.guestPhone ? `<span style="font-weight:normal; font-size:11.5px; color:var(--text-muted); margin-left:6px;">(${c.guestPhone})</span>` : ''}
          </div>
          <div class="overlap-conflict-dates">
            <i class="fa-regular fa-calendar" style="margin-right:4px;"></i>${c.checkIn} → ${c.checkOut} (${c.rentalType === 'monthly' ? `${c.monthlyDuration} bln` : `${c.nights} mlm`})
          </div>
        </div>
        <div>
          <span style="font-size:10.5px; font-weight:800; padding:3px 8px; border-radius:999px; background:var(--bg-surface-subtle); border:1px solid var(--border-color); color:var(--text-main);">
            ${statusLabels[c.status] || c.status.toUpperCase()}
          </span>
        </div>
      </div>
    `;
  }).join('');

  // Find alternative properties available for this exact interval
  const availableProps = appState.properties.filter(p => {
    if (p.id === propertyId) return false;
    const clashing = getBookingOverlaps(p.id, checkIn, checkOut, currentBookingId);
    return clashing.length === 0;
  });

  const altContainer = document.getElementById('overlapAlternativesContainer');
  const altList = document.getElementById('overlapAvailablePropsList');
  const btnSwitchToAvail = document.getElementById('btnOverlapSwitchToAvailable');

  if (availableProps.length > 0) {
    altContainer.style.display = 'block';
    altList.innerHTML = availableProps.map(p => `
      <div class="avail-prop-item" data-pid="${p.id}">
        <div class="avail-prop-name">
          <span class="property-dot" style="background:${p.color};"></span>
          <span>${p.name}</span>
        </div>
        <div style="display:flex; align-items:center; gap:8px;">
          <span class="avail-prop-rate">${formatCurrency(p.defaultRate)}/mlm</span>
          <button type="button" class="btn btn-outline btn-xs btn-pick-alt-prop" data-pid="${p.id}" style="color:var(--primary); font-weight:700;">
            ${isBM ? 'Pilih Unit Ini' : 'Select Unit'}
          </button>
        </div>
      </div>
    `).join('');

    altList.querySelectorAll('.btn-pick-alt-prop').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pid = e.currentTarget.getAttribute('data-pid');
        document.getElementById('bookingPropertySelect').value = pid;
        updateBookingModalPricing();
        checkBookingModalOverlap();
        document.getElementById('overlapWarningModal').classList.remove('active');
        showToast(isBM ? `Unit ditukar ke ${getPropertyById(pid).name}` : `Unit changed to ${getPropertyById(pid).name}`);
      });
    });

    btnSwitchToAvail.style.display = 'block';
    btnSwitchToAvail.innerHTML = `<i class="fa-solid fa-arrow-right-arrow-left"></i> ${isBM ? `Tukar ke ${availableProps[0].name} (Tersedia)` : `Switch to ${availableProps[0].name} (Available)`}`;
    btnSwitchToAvail.onclick = () => {
      document.getElementById('bookingPropertySelect').value = availableProps[0].id;
      updateBookingModalPricing();
      checkBookingModalOverlap();
      document.getElementById('overlapWarningModal').classList.remove('active');
      showToast(isBM ? `Unit ditukar ke ${availableProps[0].name}` : `Unit changed to ${availableProps[0].name}`);
    };
  } else {
    altContainer.style.display = 'none';
    btnSwitchToAvail.style.display = 'none';
  }

  // Change dates action
  document.getElementById('btnOverlapChangeDates').onclick = () => {
    document.getElementById('overlapWarningModal').classList.remove('active');
    const dIn = document.getElementById('bookingCheckIn');
    if (dIn) dIn.focus();
  };

  document.getElementById('btnOverlapDismiss').onclick = () => {
    document.getElementById('overlapWarningModal').classList.remove('active');
  };

  document.getElementById('btnCloseOverlapModal').onclick = () => {
    document.getElementById('overlapWarningModal').classList.remove('active');
  };

  document.getElementById('overlapWarningModal').classList.add('active');
}

function openChangeHomestayModal(booking) {
  if (!booking) return;

  const isBM = appState.settings.language === 'bm';
  const currentProp = getPropertyById(booking.propertyId);

  document.getElementById('changeHomestayBookingId').value = booking.id;
  document.getElementById('changeHomestayGuestName').textContent = booking.guestName;
  document.getElementById('changeHomestayGuestMeta').textContent = 
    `${booking.guestPhone || '-'} • ${booking.guestNric ? `KP: ${booking.guestNric} • ` : ''}${booking.guestCount || 2} ${isBM ? 'Tetamu' : 'Guests'}`;

  const statusBadge = document.getElementById('changeHomestayStatusBadge');
  statusBadge.textContent = (booking.status || 'booked').toUpperCase();
  statusBadge.className = `badge badge-${booking.status || 'booked'}`;

  const durationStr = booking.rentalType === 'monthly' 
    ? `${booking.monthlyDuration || 1} ${isBM ? 'bulan' : 'months'}` 
    : `${booking.nights || 1} ${isBM ? 'malam' : 'nights'}`;

  document.getElementById('changeHomestayDatesText').textContent = 
    `${booking.checkIn} → ${booking.checkOut} (${durationStr})`;

  document.getElementById('changeHomestayCurrentPropName').textContent = currentProp.name;
  document.getElementById('changeHomestayCurrentTotal').textContent = 
    `${formatCurrency(booking.totalAmount)} (${isBM ? 'Dibayar' : 'Paid'}: ${formatCurrency(booking.depositPaid)})`;

  // Populate Target Homestay Select with live availability inspection
  const targetSelect = document.getElementById('changeHomestayTargetSelect');
  targetSelect.innerHTML = '';

  const otherProps = appState.properties.filter(p => p.id !== booking.propertyId);

  if (otherProps.length === 0) {
    alert(isBM 
      ? 'Anda perlu mempunyai sekurang-kurangnya 2 unit homestay berdaftar untuk membuat pertukaran unit.' 
      : 'You need at least 2 homestay units registered in the app to transfer bookings.');
    return;
  }

  let firstAvailableId = null;

  otherProps.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    const clashes = getBookingOverlaps(p.id, booking.checkIn, booking.checkOut, booking.id);
    const isFree = clashes.length === 0;

    if (isFree) {
      if (!firstAvailableId) firstAvailableId = p.id;
      opt.textContent = `✅ ${p.name} - ${isBM ? 'Tersedia' : 'Available'} (${formatCurrency(p.defaultRate)}/mlm)`;
    } else {
      const clashGuest = clashes[0].guestName;
      opt.textContent = `❌ ${p.name} - [${isBM ? 'Bertindih' : 'Conflict'}: ${clashGuest}]`;
      opt.disabled = true; // Cannot select occupied homestay
    }
    targetSelect.appendChild(opt);
  });

  // Select first available or first option
  if (firstAvailableId) {
    targetSelect.value = firstAvailableId;
  } else {
    targetSelect.selectedIndex = 0;
  }

  // Function to update live feedback and recalculation preview
  function updateTargetFeedback() {
    const selectedPropId = targetSelect.value;
    const selectedProp = getPropertyById(selectedPropId);
    const clashes = getBookingOverlaps(selectedPropId, booking.checkIn, booking.checkOut, booking.id);
    const feedbackEl = document.getElementById('changeHomestayTargetFeedback');
    const confirmBtn = document.getElementById('btnConfirmChangeHomestay');

    if (clashes.length > 0) {
      const c = clashes[0];
      feedbackEl.innerHTML = `
        <span style="color:var(--danger); font-weight:700;">
          <i class="fa-solid fa-circle-xmark"></i> ${isBM ? 'Tidak boleh dipindahkan: Bertindih dengan tempahan tetamu' : 'Cannot transfer: Clashes with booking for'} ${c.guestName} (${c.checkIn} → ${c.checkOut}).
        </span>
      `;
      confirmBtn.disabled = true;
    } else {
      feedbackEl.innerHTML = `
        <span style="color:var(--success); font-weight:700;">
          <i class="fa-solid fa-circle-check"></i> ${isBM ? 'Unit ini KOSONG & tersedia untuk tarikh tersebut.' : 'Unit is VACANT & available for these stay dates.'}
        </span>
      `;
      confirmBtn.disabled = false;
    }

    // Recalculate preview
    const previewEl = document.getElementById('changeHomestayRecalcPreview');
    if (previewEl && selectedProp) {
      if (booking.rentalType === 'monthly') {
        const mRate = selectedProp.defaultRate ? selectedProp.defaultRate * 10 : (booking.monthlyRate || 1200);
        const newTotal = mRate + (booking.rentalDeposit || mRate) + (booking.utilitiesDeposit || 300) + (booking.agreementFee || 150);
        previewEl.innerHTML = isBM
          ? `Kadar baru: <strong>${formatCurrency(mRate)}/bulan</strong> → Anggaran Jumlah Baru: <strong>${formatCurrency(newTotal)}</strong> (Deposit dibayar ${formatCurrency(booking.depositPaid)} kekal).`
          : `New rate: <strong>${formatCurrency(mRate)}/month</strong> → Est. New Total: <strong>${formatCurrency(newTotal)}</strong> (Deposit paid ${formatCurrency(booking.depositPaid)} preserved).`;
      } else {
        const nRate = selectedProp.defaultRate || booking.nightlyRate || 250;
        const cFee = selectedProp.cleaningFee || booking.cleaningFee || 0;
        const sDep = booking.securityDeposit || 0;
        const newRental = (booking.nights * nRate) + cFee;
        const newTotal = newRental + sDep;
        previewEl.innerHTML = isBM
          ? `Kadar baru: <strong>${formatCurrency(nRate)}/mlm</strong> + Pembersihan <strong>${formatCurrency(cFee)}</strong> → Jumlah Baru: <strong>${formatCurrency(newTotal)}</strong> (Deposit dibayar ${formatCurrency(booking.depositPaid)} kekal).`
          : `New rate: <strong>${formatCurrency(nRate)}/night</strong> + Cleaning <strong>${formatCurrency(cFee)}</strong> → New Total: <strong>${formatCurrency(newTotal)}</strong> (Deposit paid ${formatCurrency(booking.depositPaid)} preserved).`;
      }
    }
  }

  targetSelect.onchange = updateTargetFeedback;
  updateTargetFeedback();

  // Reset radio to 'keep' by default
  const keepRadio = document.querySelector('input[name="changePricingMode"][value="keep"]');
  if (keepRadio) keepRadio.checked = true;

  document.getElementById('changeHomestayModal').classList.add('active');
}

function handleConfirmChangeHomestay(e) {
  e.preventDefault();

  const bookingId = document.getElementById('changeHomestayBookingId').value;
  const targetPropId = document.getElementById('changeHomestayTargetSelect').value;
  const pricingMode = document.querySelector('input[name="changePricingMode"]:checked')?.value || 'keep';

  const booking = appState.bookings.find(b => b.id === bookingId);
  if (!booking) {
    alert('Booking not found!');
    return;
  }

  const oldProp = getPropertyById(booking.propertyId);
  const newProp = getPropertyById(targetPropId);

  // Validate overlap one more time for safety
  const clashes = getBookingOverlaps(targetPropId, booking.checkIn, booking.checkOut, booking.id);
  if (clashes.length > 0) {
    alert(appState.settings.language === 'bm'
      ? `Pertindihan dikesan! Unit ${newProp.name} telah ditempah oleh ${clashes[0].guestName}.`
      : `Overlap detected! Unit ${newProp.name} is already booked by ${clashes[0].guestName}.`);
    return;
  }

  // Transfer property ID
  booking.propertyId = targetPropId;

  // Pricing adjustment
  if (pricingMode === 'recalc') {
    if (booking.rentalType === 'monthly') {
      const mRate = newProp.defaultRate ? newProp.defaultRate * 10 : (booking.monthlyRate || 1200);
      booking.monthlyRate = mRate;
      booking.totalAmount = mRate + (booking.rentalDeposit || mRate) + (booking.utilitiesDeposit || 300) + (booking.agreementFee || 150);
      booking.balance = Math.max(0, booking.totalAmount - (booking.depositPaid || 0));
    } else {
      booking.nightlyRate = newProp.defaultRate || booking.nightlyRate || 250;
      booking.cleaningFee = newProp.cleaningFee || 0;
      const totalRental = (booking.nights * booking.nightlyRate) + booking.cleaningFee;
      booking.totalAmount = totalRental + (booking.securityDeposit || 0);
      booking.balance = Math.max(0, booking.totalAmount - (booking.depositPaid || 0));
    }
  }

  // Update turnover cleaning tasks associated with this booking
  appState.turnovers.forEach(t => {
    if (t.bookingId === booking.id) {
      t.propertyId = targetPropId;
    }
  });

  // Append audit note
  const isBM = appState.settings.language === 'bm';
  const timeStr = new Date().toLocaleDateString();
  const auditNote = isBM
    ? `[Tukar Homestay: ${oldProp.name} → ${newProp.name} pada ${timeStr}]`
    : `[Transferred Unit: ${oldProp.name} → ${newProp.name} on ${timeStr}]`;
  booking.notes = booking.notes ? `${booking.notes}\n${auditNote}` : auditNote;

  saveToStorage();
  closeAllModals();
  renderApp();

  const successMsg = isBM
    ? `Tempahan untuk ${booking.guestName} berjaya dipindahkan ke "${newProp.name}"!`
    : `Booking for ${booking.guestName} successfully transferred to "${newProp.name}"!`;
  showToast(successMsg);
}

// ==========================================================================
// 11. BOOKING MODAL LOGIC (DAILY & MONTHLY TENANCY)
// ==========================================================================

function setBookingFormRentalType(type) {
  const isMonthly = type === 'monthly';
  document.getElementById('bookingRentalType').value = type;

  // Toggle Section Visibility
  const dailySection = document.getElementById('sectionDailyPricing');
  const monthlySection = document.getElementById('sectionMonthlyPricing');
  
  if (dailySection) dailySection.classList.toggle('hidden', isMonthly);
  if (monthlySection) monthlySection.classList.toggle('hidden', !isMonthly);

  // Daily input elements to enable/disable
  const dailyInputs = [
    'bookingCheckIn', 'bookingCheckOut', 'bookingNightlyRate', 
    'bookingCleaningFee', 'bookingSecurityDeposit',
    'btnPresetDep30', 'btnPresetDep50', 'btnPresetDepFull', 'btnPresetDepZero'
  ];

  // Monthly input elements to enable/disable
  const monthlyInputs = [
    'bookingMonthlyStart', 'bookingMonthlyDuration', 'bookingMonthlyRate', 
    'bookingRentalDeposit', 'bookingUtilitiesDeposit', 'bookingAgreementFee'
  ];

  if (isMonthly) {
    // Completely BLOCK / DISABLE all Daily inputs
    dailyInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.disabled = true;
        el.required = false;
        el.setAttribute('tabindex', '-1');
        el.style.pointerEvents = 'none';
      }
    });

    // UNBLOCK / ENABLE all Monthly inputs
    monthlyInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.disabled = false;
        el.removeAttribute('tabindex');
        el.style.pointerEvents = 'auto';
      }
    });

    const mStart = document.getElementById('bookingMonthlyStart');
    if (mStart) mStart.required = true;
    const mRate = document.getElementById('bookingMonthlyRate');
    if (mRate) mRate.required = true;

  } else {
    // Completely BLOCK / DISABLE all Monthly inputs
    monthlyInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.disabled = true;
        el.required = false;
        el.setAttribute('tabindex', '-1');
        el.style.pointerEvents = 'none';
      }
    });

    // UNBLOCK / ENABLE all Daily inputs
    dailyInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.disabled = false;
        el.removeAttribute('tabindex');
        el.style.pointerEvents = 'auto';
      }
    });

    const bCheckIn = document.getElementById('bookingCheckIn');
    if (bCheckIn) bCheckIn.required = true;
    const bCheckOut = document.getElementById('bookingCheckOut');
    if (bCheckOut) bCheckOut.required = true;
  }

  // Update segmented control buttons UI
  document.querySelectorAll('#rentalTypeSegmented .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-type') === type);
  });
}

function openBookingModal(existingBooking = null, prefillDate = null, prefillPropertyId = null) {
  if (appState.properties.length === 0) {
    alert(appState.settings.language === 'bm' 
      ? 'Sila tambah sekurang-kurangnya satu unit homestay atau bilik sebelum membuat tempahan.' 
      : 'Please add at least one homestay or room rental unit first before creating a quotation / booking.');
    openPropertyModal();
    return;
  }

  const form = document.getElementById('bookingForm');
  form.reset();

  // Populate Property Dropdown with Unit / Room Category
  const propSelect = document.getElementById('bookingPropertySelect');
  propSelect.innerHTML = '';
  appState.properties.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    const typeLabel = p.propType === 'room_master' ? '🚪 Master Room' : 
                      p.propType === 'room_medium' ? '🚪 Medium Room' :
                      p.propType === 'room_single' ? '🚪 Single Room' :
                      p.propType === 'studio' ? '🏢 Studio' : '🏡 Whole Unit';
    opt.textContent = `${p.name} [${typeLabel}]`;
    propSelect.appendChild(opt);
  });

  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];

  if (existingBooking) {
    document.getElementById('bookingModalTitle').textContent = 'Edit Booking / Tenancy';
    document.getElementById('bookingIdInput').value = existingBooking.id;
    document.getElementById('bookingPropertySelect').value = existingBooking.propertyId;
    document.getElementById('bookingGuestName').value = existingBooking.guestName;
    document.getElementById('bookingGuestPhone').value = existingBooking.guestPhone || '';
    document.getElementById('bookingGuestNric').value = existingBooking.guestNric || '';
    document.getElementById('bookingGuestEmail').value = existingBooking.guestEmail || '';
    document.getElementById('bookingGuestAddress').value = existingBooking.guestAddress || '';
    document.getElementById('bookingGuestCount').value = existingBooking.guestCount || 2;
    document.getElementById('bookingChannel').value = existingBooking.channel || 'whatsapp';
    document.getElementById('bookingDepositPaid').value = existingBooking.depositPaid || 0;
    const currentSt = existingBooking.status || 'booked';
    document.getElementById('bookingStatusSelect').value = currentSt;
    const isBM = appState.settings.language === 'bm';
    const hintEl = document.getElementById('bookingDepositPaidHint');
    if (hintEl) {
      if (currentSt === 'confirmed' || currentSt === 'checked-in' || currentSt === 'checked-out') {
        hintEl.textContent = isBM ? '✓ Bayaran penuh disahkan. Baki: RM 0.00' : '✓ Full payment confirmed. Balance: RM 0.00';
        hintEl.style.color = 'var(--success)';
      } else if (currentSt === 'booked') {
        hintEl.textContent = isBM ? `Deposit: ${formatCurrency(existingBooking.depositPaid)}. Baki: ${formatCurrency(existingBooking.balance)}` : `Deposit: ${formatCurrency(existingBooking.depositPaid)}. Balance: ${formatCurrency(existingBooking.balance)}`;
        hintEl.style.color = 'var(--warning)';
      } else {
        hintEl.textContent = '';
      }
    }
    document.getElementById('bookingNotes').value = existingBooking.notes || '';

    const qVal = existingBooking.quotationValidityDays || appState.settings.quotationValidityDays || 3;
    const qValEl = document.getElementById('bookingQuotationValidity');
    if (qValEl) qValEl.value = qVal;
    const qGroup = document.getElementById('bookingQuotationValidityGroup');
    if (qGroup) {
      qGroup.style.display = (existingBooking.status === 'quotation') ? 'block' : 'none';
    }

    const rType = existingBooking.rentalType || 'daily';
    setBookingFormRentalType(rType);

    if (rType === 'monthly') {
      document.getElementById('bookingMonthlyStart').value = existingBooking.monthlyStart || existingBooking.checkIn;
      document.getElementById('bookingMonthlyDuration').value = existingBooking.monthlyDuration || 6;
      document.getElementById('bookingMonthlyRate').value = existingBooking.monthlyRate || 1200;
      document.getElementById('bookingRentalDeposit').value = existingBooking.rentalDeposit || 1200;
      document.getElementById('bookingUtilitiesDeposit').value = existingBooking.utilitiesDeposit || 300;
      document.getElementById('bookingAgreementFee').value = existingBooking.agreementFee || 150;
    } else {
      document.getElementById('bookingCheckIn').value = existingBooking.checkIn;
      document.getElementById('bookingCheckOut').value = existingBooking.checkOut;
      document.getElementById('bookingNightlyRate').value = existingBooking.nightlyRate || 250;
      document.getElementById('bookingCleaningFee').value = existingBooking.cleaningFee || 0;
      document.getElementById('bookingSecurityDeposit').value = existingBooking.securityDeposit || 0;
    }

    // Populate Attached Receipts Section
    const receiptsSec = document.getElementById('bookingReceiptsSection');
    const receiptsList = document.getElementById('bookingModalReceiptsList');
    if (receiptsSec && receiptsList) {
      receiptsSec.style.display = 'block';
      const payments = existingBooking.payments || [];
      if (payments.length === 0) {
        receiptsList.innerHTML = `<p style="font-size:11.5px; color:var(--text-muted); margin:0;">${t('no_receipts_recorded')}</p>`;
      } else {
        receiptsList.innerHTML = payments.map(p => `
          <div style="display:flex; justify-content:space-between; align-items:center; background:var(--bg-surface); padding:5px 8px; border-radius:4px; border:1px solid var(--border-color); margin-top:4px; font-size:12px;">
            <span><i class="fa-solid fa-building-columns" style="color:var(--primary); margin-right:4px;"></i><strong>${p.bankName || 'Bank'}</strong> • <code>${p.referenceNo || '-'}</code></span>
            <span style="font-weight:700; color:var(--success);">${formatCurrency(p.amount)}</span>
          </div>
        `).join('');
      }

      const btnAddReceipt = document.getElementById('btnBookingModalAddReceipt');
      if (btnAddReceipt) {
        btnAddReceipt.onclick = () => {
          openPaymentProofModal(existingBooking);
        };
      }
    }

    const btnChangeUnit = document.getElementById('btnBookingModalChangeUnit');
    if (btnChangeUnit) {
      btnChangeUnit.style.display = 'inline-flex';
      btnChangeUnit.onclick = () => {
        closeAllModals();
        openChangeHomestayModal(existingBooking);
      };
    }
  } else {
    const btnChangeUnit = document.getElementById('btnBookingModalChangeUnit');
    if (btnChangeUnit) btnChangeUnit.style.display = 'none';

    document.getElementById('bookingModalTitle').textContent = 'New Booking / Quotation';
    document.getElementById('bookingIdInput').value = '';
    document.getElementById('bookingGuestNric').value = '';
    document.getElementById('bookingGuestEmail').value = '';
    document.getElementById('bookingGuestAddress').value = '';

    const receiptsSec = document.getElementById('bookingReceiptsSection');
    if (receiptsSec) receiptsSec.style.display = 'none';
    
    if (prefillPropertyId) {
      document.getElementById('bookingPropertySelect').value = prefillPropertyId;
    } else if (appState.selectedPropertyId !== 'all') {
      document.getElementById('bookingPropertySelect').value = appState.selectedPropertyId;
    }

    setBookingFormRentalType('daily');

    const checkIn = prefillDate || todayStr;
    const dIn = new Date(checkIn + 'T00:00:00');
    const dOut = new Date(dIn); dOut.setDate(dIn.getDate() + 1);
    
    document.getElementById('bookingCheckIn').value = checkIn;
    document.getElementById('bookingCheckOut').value = dOut.toISOString().split('T')[0];

    document.getElementById('bookingMonthlyStart').value = checkIn;
    document.getElementById('bookingMonthlyDuration').value = 6;

    const prop = getPropertyById(document.getElementById('bookingPropertySelect').value);
    document.getElementById('bookingNightlyRate').value = prop.defaultRate || 250;
    document.getElementById('bookingCleaningFee').value = prop.cleaningFee || 50;
    document.getElementById('bookingSecurityDeposit').value = 100;

    document.getElementById('bookingMonthlyRate').value = prop.defaultRate ? prop.defaultRate * 10 : 1500;
    document.getElementById('bookingRentalDeposit').value = prop.defaultRate ? prop.defaultRate * 10 : 1500;
    document.getElementById('bookingUtilitiesDeposit').value = 300;
    document.getElementById('bookingAgreementFee').value = 150;

    document.getElementById('bookingDepositPaid').value = 0;
    document.getElementById('bookingStatusSelect').value = 'quotation';

    const qValEl = document.getElementById('bookingQuotationValidity');
    if (qValEl) qValEl.value = appState.settings.quotationValidityDays || 3;
    const qGroup = document.getElementById('bookingQuotationValidityGroup');
    if (qGroup) {
      qGroup.style.display = 'block';
    }
  }

  updateBookingModalPricing();
  checkBookingModalOverlap();
  document.getElementById('bookingModal').classList.add('active');
}

function updateBookingModalPricing() {
  const rType = document.getElementById('bookingRentalType').value;

  if (rType === 'monthly') {
    const mRate = parseFloat(document.getElementById('bookingMonthlyRate').value) || 0;
    const rDep = parseFloat(document.getElementById('bookingRentalDeposit').value) || 0;
    const uDep = parseFloat(document.getElementById('bookingUtilitiesDeposit').value) || 0;
    const aFee = parseFloat(document.getElementById('bookingAgreementFee').value) || 0;

    const totalMoveIn = mRate + rDep + uDep + aFee;
    document.getElementById('calcMonthlyTotalAmount').textContent = formatCurrency(totalMoveIn);
  } else {
    const checkInVal = document.getElementById('bookingCheckIn').value;
    const checkOutVal = document.getElementById('bookingCheckOut').value;
    const rateVal = parseFloat(document.getElementById('bookingNightlyRate').value) || 0;
    const cleanVal = parseFloat(document.getElementById('bookingCleaningFee').value) || 0;
    const secDep = parseFloat(document.getElementById('bookingSecurityDeposit').value) || 0;

    let nights = 0;
    if (checkInVal && checkOutVal) {
      const d1 = new Date(checkInVal);
      const d2 = new Date(checkOutVal);
      const diff = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
      nights = diff > 0 ? diff : 0;
    }

    document.getElementById('calcNightsCount').textContent = nights;
    const totalRental = (nights * rateVal) + cleanVal;
    const grandTotal = totalRental + secDep;
    document.getElementById('calcTotalAmount').textContent = formatCurrency(grandTotal);

    // Update 30% deposit label on rental portion
    const dep30 = Math.round(totalRental * 0.30 * 100) / 100;
    const txt30 = document.getElementById('txtPreset30');
    if (txt30) txt30.textContent = formatCurrency(dep30);
  }
}

function handleSaveBooking(e) {
  e.preventDefault();

  const id = document.getElementById('bookingIdInput').value;
  const propertyId = document.getElementById('bookingPropertySelect').value;
  const rentalType = document.getElementById('bookingRentalType').value || 'daily';
  const guestName = document.getElementById('bookingGuestName').value.trim();
  const guestPhone = document.getElementById('bookingGuestPhone').value.trim();
  const guestNric = document.getElementById('bookingGuestNric') ? document.getElementById('bookingGuestNric').value.trim() : '';
  const guestEmail = document.getElementById('bookingGuestEmail') ? document.getElementById('bookingGuestEmail').value.trim() : '';
  const guestAddress = document.getElementById('bookingGuestAddress') ? document.getElementById('bookingGuestAddress').value.trim() : '';
  const guestCount = parseInt(document.getElementById('bookingGuestCount').value) || 2;
  const channel = document.getElementById('bookingChannel').value;
  const depositPaid = parseFloat(document.getElementById('bookingDepositPaid').value) || 0;
  let status = document.getElementById('bookingStatusSelect').value;
  const notes = document.getElementById('bookingNotes').value.trim();
  const quotationValidityDays = parseInt(document.getElementById('bookingQuotationValidity')?.value) || appState.settings.quotationValidityDays || 3;

  let checkIn = '';
  let checkOut = '';
  let nights = 1;
  let nightlyRate = 0;
  let cleaningFee = 0;
  let securityDeposit = 0;

  let monthlyStart = '';
  let monthlyDuration = 1;
  let monthlyRate = 0;
  let rentalDeposit = 0;
  let utilitiesDeposit = 0;
  let agreementFee = 0;
  let totalAmount = 0;

  if (rentalType === 'monthly') {
    monthlyStart = document.getElementById('bookingMonthlyStart').value;
    monthlyDuration = parseInt(document.getElementById('bookingMonthlyDuration').value) || 1;
    monthlyRate = parseFloat(document.getElementById('bookingMonthlyRate').value) || 0;
    rentalDeposit = parseFloat(document.getElementById('bookingRentalDeposit').value) || 0;
    utilitiesDeposit = parseFloat(document.getElementById('bookingUtilitiesDeposit').value) || 0;
    agreementFee = parseFloat(document.getElementById('bookingAgreementFee').value) || 0;

    if (!monthlyStart) {
      alert('Please enter tenancy start date.');
      return;
    }

    checkIn = monthlyStart;
    const dStart = new Date(monthlyStart + 'T00:00:00');
    const dEnd = new Date(dStart);
    dEnd.setMonth(dEnd.getMonth() + monthlyDuration);
    checkOut = dEnd.toISOString().split('T')[0];

    const dDiff = Math.ceil((dEnd - dStart) / (1000 * 60 * 60 * 24));
    nights = dDiff > 0 ? dDiff : monthlyDuration * 30;

    totalAmount = monthlyRate + rentalDeposit + utilitiesDeposit + agreementFee;
  } else {
    checkIn = document.getElementById('bookingCheckIn').value;
    checkOut = document.getElementById('bookingCheckOut').value;
    nightlyRate = parseFloat(document.getElementById('bookingNightlyRate').value) || 0;
    cleaningFee = parseFloat(document.getElementById('bookingCleaningFee').value) || 0;
    securityDeposit = parseFloat(document.getElementById('bookingSecurityDeposit').value) || 0;

    if (!checkIn || !checkOut || checkIn >= checkOut) {
      alert('Check-out date must be after check-in date!');
      return;
    }

    const d1 = new Date(checkIn);
    const d2 = new Date(checkOut);
    nights = Math.max(1, Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24)));
    const totalRental = (nights * nightlyRate) + cleaningFee;
    totalAmount = totalRental + securityDeposit;
  }

  let finalDepositPaid = depositPaid;

  // Auto-settle: If user picked Confirmed (Fully Paid), In-House, or Checked-Out (Ended), ensure depositPaid equals totalAmount and balance is 0
  if ((status === 'confirmed' || status === 'checked-in' || status === 'checked-out') && finalDepositPaid < totalAmount) {
    finalDepositPaid = totalAmount;
  }

  const balance = Math.max(0, totalAmount - finalDepositPaid);

  // Auto-refine status if user didn't manually pick a specific state
  if (!id) {
    if (finalDepositPaid >= totalAmount && totalAmount > 0) {
      status = 'confirmed';
    } else if (finalDepositPaid > 0) {
      status = 'booked';
    } else {
      status = 'quotation';
    }
  }

  // 1. STRICT OVERLAP CHECK: Prevent double-booking if status is not cancelled
  if (status !== 'cancelled') {
    const overlaps = getBookingOverlaps(propertyId, checkIn, checkOut, id);
    if (overlaps.length > 0) {
      openOverlapWarningModal(overlaps, propertyId, checkIn, checkOut, guestName, id);
      return; // STRICTLY BLOCK SAVE!
    }
  }

  const existingBooking = id ? appState.bookings.find(b => b.id === id) : null;
  let finalNotes = notes;

  // If changing homestay property on existing booking, update turnover tasks & append audit note
  if (id && existingBooking && existingBooking.propertyId !== propertyId) {
    const oldProp = getPropertyById(existingBooking.propertyId);
    const newProp = getPropertyById(propertyId);
    const isBM = appState.settings.language === 'bm';
    const auditText = isBM 
      ? `[Tukar Homestay: ${oldProp.name} → ${newProp.name} pada ${new Date().toLocaleDateString()}]`
      : `[Transferred Unit: ${oldProp.name} → ${newProp.name} on ${new Date().toLocaleDateString()}]`;
    finalNotes = finalNotes ? `${finalNotes}\n${auditText}` : auditText;

    // Sync property on any associated turnover cleaning tasks
    appState.turnovers.forEach(t => {
      if (t.bookingId === id) {
        t.propertyId = propertyId;
      }
    });
  }

  const bookingData = {
    id: id || `b-${Date.now()}`,
    propertyId,
    rentalType,
    guestName,
    guestPhone,
    guestNric,
    guestEmail,
    guestAddress,
    checkIn,
    checkOut,
    nights,
    guestCount,
    channel,
    nightlyRate,
    cleaningFee,
    securityDeposit,
    monthlyStart,
    monthlyDuration,
    monthlyRate,
    rentalDeposit,
    utilitiesDeposit,
    agreementFee,
    totalAmount,
    depositPaid: finalDepositPaid,
    balance,
    status,
    quotationValidityDays,
    notes: finalNotes,
    createdAt: new Date().toISOString()
  };

  if (id) {
    const idx = appState.bookings.findIndex(b => b.id === id);
    if (idx !== -1) appState.bookings[idx] = { ...appState.bookings[idx], ...bookingData };
  } else {
    appState.bookings.push(bookingData);

    // Auto-create turnover task for check-out date
    const prop = getPropertyById(propertyId);
    appState.turnovers.push({
      id: `t-${Date.now()}`,
      propertyId,
      bookingId: bookingData.id,
      date: checkOut,
      status: 'pending',
      cleanerName: 'Cleaner Team',
      cleanerPhone: '',
      checklist: [
        { text: 'Wash bed linens & pillow covers', done: false },
        { text: 'Sanitize bathroom & provide fresh towels', done: false },
        { text: 'Restock amenities & coffee', done: false },
        { text: `Reset Smart Lock PIN (${prop.doorCode || 'PIN'})`, done: false },
        { text: 'Inspect appliances & air conditioner', done: false },
        { text: 'Dispose all trash', done: false }
      ]
    });
  }

  saveToStorage();
  closeAllModals();
  renderApp();
  showToast(id ? 'Booking updated!' : `Booking saved as "${status.toUpperCase()}"!`);
}

// ==========================================================================
// 11B. TENANCY DEPOSIT REFUND MODAL LOGIC
// ==========================================================================

function openDepositRefundModal(booking) {
  appState.activeWaBooking = booking;
  const prop = getPropertyById(booking.propertyId);

  document.getElementById('refundBookingIdInput').value = booking.id;
  document.getElementById('refundTenantMeta').textContent = `Tenant: ${booking.guestName} (${booking.guestPhone || '-'}) • Unit: ${prop.name}`;

  const rentalDep = booking.rentalDeposit || 0;
  const utilitiesDep = booking.utilitiesDeposit || booking.securityDeposit || 0;

  document.getElementById('refundRentalDepInput').value = rentalDep;
  document.getElementById('refundUtilitiesDepInput').value = utilitiesDep;
  document.getElementById('refundDeductUtilitiesInput').value = 0;
  document.getElementById('refundDeductRepairsInput').value = 0;
  document.getElementById('refundNotesInput').value = '';

  updateDepositRefundCalculation();
  document.getElementById('depositRefundModal').classList.add('active');
}

function updateDepositRefundCalculation() {
  const rentalDep = parseFloat(document.getElementById('refundRentalDepInput').value) || 0;
  const utilDep = parseFloat(document.getElementById('refundUtilitiesDepInput').value) || 0;
  const dedUtil = parseFloat(document.getElementById('refundDeductUtilitiesInput').value) || 0;
  const dedRepair = parseFloat(document.getElementById('refundDeductRepairsInput').value) || 0;

  const netRefund = Math.max(0, (rentalDep + utilDep) - (dedUtil + dedRepair));
  document.getElementById('calcNetRefundAmount').textContent = formatCurrency(netRefund);
}

function handleProcessDepositRefund(e) {
  e.preventDefault();

  const bookingId = document.getElementById('refundBookingIdInput').value;
  const booking = appState.bookings.find(b => b.id === bookingId);
  if (!booking) return;

  const rentalDep = parseFloat(document.getElementById('refundRentalDepInput').value) || 0;
  const utilDep = parseFloat(document.getElementById('refundUtilitiesDepInput').value) || 0;
  const dedUtil = parseFloat(document.getElementById('refundDeductUtilitiesInput').value) || 0;
  const dedRepair = parseFloat(document.getElementById('refundDeductRepairsInput').value) || 0;
  const netRefund = Math.max(0, (rentalDep + utilDep) - (dedUtil + dedRepair));
  const notes = document.getElementById('refundNotesInput').value.trim();

  booking.refundDetails = {
    rentalDep,
    utilDep,
    dedUtil,
    dedRepair,
    netRefund,
    notes,
    refundedAt: new Date().toISOString()
  };
  booking.status = 'checked-out';

  saveToStorage();
  closeAllModals();
  renderApp();
  showToast('Deposit refund recorded! Opening WhatsApp statement...');
  openWhatsAppModal(booking, 'refund_receipt');
}

// ==========================================================================
// 11C. MULTI-MONTH TENANCY INVOICING ENGINE
// ==========================================================================

function getOrInitMonthlyInvoices(booking) {
  const duration = booking.monthlyDuration || 1;
  if (!booking.monthlyInvoices || !Array.isArray(booking.monthlyInvoices) || booking.monthlyInvoices.length === 0) {
    const invoices = [];
    const startD = new Date(booking.checkIn + 'T00:00:00');
    
    for (let i = 1; i <= duration; i++) {
      const curStart = new Date(startD);
      curStart.setMonth(curStart.getMonth() + (i - 1));
      const curEnd = new Date(curStart);
      curEnd.setMonth(curEnd.getMonth() + 1);
      curEnd.setDate(curEnd.getDate() - 1);

      const dueDate = new Date(curStart);
      dueDate.setDate(dueDate.getDate() + 6); // 7th day of cycle

      // Month 1 is marked paid if booking is confirmed / checked-in or depositPaid >= monthlyRate
      const isFirstMonthPaid = (i === 1 && (booking.status === 'confirmed' || booking.status === 'checked-in' || booking.status === 'checked-out' || (booking.depositPaid && booking.depositPaid >= (booking.monthlyRate || 0))));

      invoices.push({
        monthIndex: i,
        invoiceNo: `INV-M${i}-${booking.id.slice(-5).toUpperCase()}`,
        periodStart: curStart.toISOString().split('T')[0],
        periodEnd: curEnd.toISOString().split('T')[0],
        dueDate: dueDate.toISOString().split('T')[0],
        rentAmount: booking.monthlyRate || 0,
        utilityCharges: 0,
        totalAmount: booking.monthlyRate || 0,
        status: isFirstMonthPaid ? 'paid' : 'pending',
        paidAt: isFirstMonthPaid ? (booking.createdAt || new Date().toISOString()) : null,
        notes: isFirstMonthPaid ? 'Settled in move-in package' : ''
      });
    }
    booking.monthlyInvoices = invoices;
    saveToStorage();
  }
  return booking.monthlyInvoices;
}

function openMonthlyInvoicesModal(booking) {
  appState.activeWaBooking = booking;
  const prop = getPropertyById(booking.propertyId);
  const isBM = appState.settings.language === 'bm';

  document.getElementById('monthlyInvoicesTenantSubtitle').textContent = `${isBM ? 'Penyewa' : 'Tenant'}: ${booking.guestName} (${booking.guestPhone || '-'}) • ${prop.name}`;
  document.getElementById('mInvRateDisplay').textContent = `${formatCurrency(booking.monthlyRate || 0)} / ${isBM ? 'bulan' : 'month'}`;
  document.getElementById('mInvPeriodDisplay').textContent = `${booking.checkIn} → ${booking.checkOut} (${booking.monthlyDuration || 6} ${t('months')})`;

  const btnAgr = document.getElementById('btnOpenTenancyAgreementFromHub');
  if (btnAgr) {
    btnAgr.onclick = (e) => {
      e.stopPropagation();
      openAgreementModal(booking, 'preview');
    };
  }

  const bannerAgr = document.getElementById('agrHubCalloutBanner');
  if (bannerAgr) {
    bannerAgr.onclick = () => {
      openAgreementModal(booking, 'preview');
    };
  }

  renderMonthlyInvoicesList(booking);
  document.getElementById('monthlyInvoicesModal').classList.add('active');
}

function renderMonthlyInvoicesList(booking) {
  const container = document.getElementById('monthlyInvoicesList');
  container.innerHTML = '';

  const invoices = getOrInitMonthlyInvoices(booking);
  const isBM = appState.settings.language === 'bm';

  const paidCount = invoices.filter(x => x.status === 'paid').length;
  const totalMonths = invoices.length;
  const badge = document.getElementById('mInvPaidProgressBadge');
  if (badge) {
    badge.textContent = `${paidCount}/${totalMonths} ${isBM ? 'DIBAYAR' : 'PAID'}`;
    badge.style.background = paidCount === totalMonths ? 'var(--success-light)' : 'var(--primary-light)';
    badge.style.color = paidCount === totalMonths ? 'var(--success-text)' : 'var(--primary-text)';
  }

  invoices.forEach(inv => {
    const isPaid = inv.status === 'paid';
    const card = document.createElement('div');
    card.className = 'card';
    card.style.padding = '10px 12px';
    card.style.marginBottom = '0';
    card.style.borderLeft = `4px solid ${isPaid ? 'var(--success)' : 'var(--warning)'}`;
    card.style.background = 'var(--bg-surface-subtle)';

    card.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">
        <div>
          <strong style="font-size:13px; color:var(--text-main); display:flex; align-items:center; gap:6px;">
            <i class="fa-solid fa-calendar-check" style="color:${isPaid ? 'var(--success)' : 'var(--warning)'};"></i>
            ${isBM ? `Bulan ke-${inv.monthIndex}` : `Month ${inv.monthIndex}`} (${inv.periodStart} → ${inv.periodEnd})
          </strong>
          <p style="font-size:11px; color:var(--text-muted); margin-top:2px; margin-bottom:0;">
            No: <code style="font-weight:700; color:var(--primary);">${inv.invoiceNo}</code> • ${isBM ? 'Tarikh Akhir' : 'Due'}: <strong>${inv.dueDate}</strong>
            ${inv.paidAt ? ` • <span style="color:var(--success);">Paid: ${inv.paidAt.split('T')[0]}</span>` : ''}
          </p>
        </div>
        <span style="font-size:10px; font-weight:800; padding:2px 8px; border-radius:999px; ${isPaid ? 'background:var(--success-light);color:var(--success-text);' : 'background:var(--warning-light);color:var(--warning-text);'}">
          ${isPaid ? (isBM ? 'DIBAYAR' : 'PAID') : (isBM ? 'BELUM BAYAR' : 'PENDING')}
        </span>
      </div>

      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px; padding-top:8px; border-top:1px dashed var(--border-color); flex-wrap:wrap; gap:6px;">
        <div style="font-size:12px; font-weight:800; color:var(--primary);">
          ${formatCurrency(inv.totalAmount || inv.rentAmount)}
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
          <button class="btn btn-whatsapp btn-xs btn-send-month-inv" data-m="${inv.monthIndex}">
            <i class="fa-brands fa-whatsapp"></i> ${isBM ? 'Invois' : 'Invoice'}
          </button>
          ${isPaid ? `
            <button class="btn btn-whatsapp btn-xs btn-send-month-rec" data-m="${inv.monthIndex}" title="${isBM ? 'Hantar Resit Bayaran' : 'Send Payment Receipt'}">
              <i class="fa-solid fa-receipt"></i> ${isBM ? 'Resit' : 'Receipt'}
            </button>
          ` : ''}
          <button class="btn btn-outline btn-xs btn-open-month-pdf" data-m="${inv.monthIndex}" title="${isBM ? 'Jana / Cetak Fail PDF Rasmi' : 'Generate / Print Official PDF'}">
            <i class="fa-solid fa-file-pdf" style="color:var(--danger, #dc2626);"></i> PDF
          </button>
          <button class="btn btn-outline btn-xs btn-toggle-month-paid" data-m="${inv.monthIndex}">
            <i class="fa-solid fa-${isPaid ? 'rotate-left' : 'check'}" style="color:${isPaid ? 'var(--warning)' : 'var(--success)'};"></i>
            ${isPaid ? (isBM ? 'Batal Tanda' : 'Unmark') : (isBM ? 'Tanda Bayar' : 'Mark Paid')}
          </button>
        </div>
      </div>
    `;

    container.appendChild(card);
  });

  // Attach handlers
  container.querySelectorAll('.btn-send-month-inv').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const mIdx = parseInt(e.currentTarget.getAttribute('data-m')) || 1;
      openWhatsAppModal(booking, 'monthly_invoice', mIdx);
    });
  });

  container.querySelectorAll('.btn-send-month-rec').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const mIdx = parseInt(e.currentTarget.getAttribute('data-m')) || 1;
      openWhatsAppModal(booking, 'monthly_rent_receipt', mIdx);
    });
  });

  container.querySelectorAll('.btn-open-month-pdf').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const mIdx = parseInt(e.currentTarget.getAttribute('data-m')) || 1;
      const inv = invoices.find(x => x.monthIndex === mIdx);
      const isPaid = inv && inv.status === 'paid';
      openPdfDocModal(booking, isPaid ? 'receipt' : 'invoice', mIdx);
    });
  });

  container.querySelectorAll('.btn-toggle-month-paid').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const mIdx = parseInt(e.currentTarget.getAttribute('data-m')) || 1;
      toggleMonthlyInvoicePaid(booking.id, mIdx);
    });
  });
}

function toggleMonthlyInvoicePaid(bookingId, monthIndex) {
  const booking = appState.bookings.find(b => b.id === bookingId);
  if (!booking) return;

  const invoices = getOrInitMonthlyInvoices(booking);
  const inv = invoices.find(x => x.monthIndex === monthIndex);
  if (!inv) return;

  const isBM = appState.settings.language === 'bm';

  if (inv.status === 'paid') {
    inv.status = 'pending';
    inv.paidAt = null;
    showToast(isBM ? `Bulan ke-${monthIndex} ditanda sebagai belum dibayar.` : `Month ${monthIndex} marked as pending.`);
    saveToStorage();
    renderMonthlyInvoicesList(booking);
    if (appState.activeTab === 'bookings') renderBookingsTab();
  } else {
    // Open payment proof modal to attach the tenant's bank receipt!
    closeAllModals();
    openPaymentProofModal(booking, 'monthly_rent', monthIndex, inv.totalAmount || inv.rentAmount);
  }
}

// ==========================================================================
// 11D. DIGITAL PAYMENT RECEIPTS & PROOF CAPTURE ENGINE
// ==========================================================================

function compressReceiptImage(file, maxWidth = 900, maxHeight = 900, quality = 0.78) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error('No file provided'));

    if (file.type === 'application/pdf') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target.result;
        const sizeBytes = Math.round((dataUrl.length * 3) / 4);
        resolve({
          dataUrl,
          sizeBytes,
          isPdf: true,
          fileName: file.name
        });
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        const sizeBytes = Math.round((dataUrl.length * 3) / 4);

        resolve({
          dataUrl,
          sizeBytes,
          width,
          height,
          isPdf: false,
          fileName: file.name
        });
      };
      img.onerror = (err) => reject(err);
      img.src = e.target.result;
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

function handleReceiptFileSelected(file) {
  if (!file) return;
  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Memampatkan gambar resit...' : 'Compressing receipt slip...');

  compressReceiptImage(file, 900, 900, 0.78)
    .then(result => {
      document.getElementById('paymentProofImageData').value = result.dataUrl;
      document.getElementById('paymentProofImageName').value = result.fileName;

      const previewImg = document.getElementById('receiptPreviewImg');
      if (result.isPdf) {
        previewImg.src = 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Crect width=%22100%22 height=%22100%22 fill=%22%23ef4444%22/%3E%3Ctext x=%2250%22 y=%2255%22 font-size=%2218%22 font-weight=%22bold%22 text-anchor=%22middle%22 fill=%22%23ffffff%22%3EPDF%3C/text%3E%3C/svg%3E';
      } else {
        previewImg.src = result.dataUrl;
      }

      document.getElementById('receiptPreviewFileName').textContent = result.fileName;
      const sizeKb = Math.round(result.sizeBytes / 1024);
      document.getElementById('receiptPreviewSize').textContent = `${sizeKb} KB (Compressed & sharp)`;

      document.getElementById('receiptUploadPrompt').style.display = 'none';
      document.getElementById('receiptPreviewContainer').style.display = 'block';
    })
    .catch(err => {
      alert('Error reading receipt file: ' + err.message);
    });
}

function openPaymentProofModal(booking, defaultType = 'deposit', defaultMonth = null, defaultAmount = null) {
  if (!booking) return;
  const prop = getPropertyById(booking.propertyId);
  const isBM = appState.settings.language === 'bm';

  document.getElementById('paymentProofBookingId').value = booking.id;
  document.getElementById('paymentProofId').value = '';

  const titleEl = document.getElementById('paymentProofModalTitle');
  if (titleEl) titleEl.textContent = t('receipt_modal_title');

  document.getElementById('paymentProofGuestPropertyDisplay').textContent = `${prop.name} • ${booking.guestName} (${booking.guestPhone || '-'})`;
  document.getElementById('paymentProofFinancialSummary').textContent = `${t('total')}: ${formatCurrency(booking.totalAmount)} • ${isBM ? 'Dibayar' : 'Paid'}: ${formatCurrency(booking.depositPaid)} • ${isBM ? 'Baki' : 'Balance'}: ${formatCurrency(booking.balance)}`;

  const typeSelect = document.getElementById('paymentProofTypeSelect');
  typeSelect.value = defaultType;

  const monthGroup = document.getElementById('paymentProofMonthIndexGroup');
  const monthSelect = document.getElementById('paymentProofMonthIndexSelect');
  if (booking.rentalType === 'monthly') {
    monthSelect.innerHTML = '';
    const duration = booking.monthlyDuration || 6;
    for (let i = 1; i <= duration; i++) {
      const opt = document.createElement('option');
      opt.value = i;
      opt.textContent = isBM ? `Bulan ke-${i}` : `Month ${i}`;
      if (defaultMonth && i === defaultMonth) opt.selected = true;
      monthSelect.appendChild(opt);
    }
    monthGroup.style.display = (defaultType === 'monthly_rent') ? 'block' : 'none';
  } else {
    monthGroup.style.display = 'none';
  }

  let targetAmount = 0;
  if (defaultAmount !== null && defaultAmount !== undefined) {
    targetAmount = defaultAmount;
  } else if (defaultType === 'deposit') {
    targetAmount = booking.depositPaid > 0 ? booking.depositPaid : Math.round(booking.totalAmount * (appState.settings.defaultDepositPct || 30) / 100);
  } else if (defaultType === 'balance') {
    targetAmount = booking.balance > 0 ? booking.balance : booking.totalAmount;
  } else if (defaultType === 'full') {
    targetAmount = booking.totalAmount;
  } else if (defaultType === 'monthly_rent') {
    targetAmount = booking.monthlyRate || 0;
  } else {
    targetAmount = booking.balance > 0 ? booking.balance : 0;
  }
  document.getElementById('paymentProofAmountInput').value = targetAmount;

  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  document.getElementById('paymentProofDateTimeInput').value = `${year}-${month}-${day}T${hours}:${minutes}`;

  const defaultBank = booking.lastPaymentBank || appState.settings.bankName || 'Maybank';
  document.getElementById('paymentProofBankInput').value = defaultBank;
  document.querySelectorAll('#paymentProofBankPills .bank-pill').forEach(pill => {
    pill.classList.toggle('active', pill.getAttribute('data-bank').toLowerCase() === defaultBank.toLowerCase());
  });

  document.getElementById('paymentProofRefInput').value = '';
  document.getElementById('paymentProofNotesInput').value = '';

  document.getElementById('paymentProofFileInput').value = '';
  document.getElementById('paymentProofImageData').value = '';
  document.getElementById('paymentProofImageName').value = '';
  document.getElementById('receiptUploadPrompt').style.display = 'block';
  document.getElementById('receiptPreviewContainer').style.display = 'none';

  document.getElementById('paymentProofModal').classList.add('active');
}

function handleSavePaymentProof(e) {
  e.preventDefault();

  const bookingId = document.getElementById('paymentProofBookingId').value;
  const booking = appState.bookings.find(b => b.id === bookingId);
  if (!booking) {
    alert('Booking not found!');
    return;
  }

  const type = document.getElementById('paymentProofTypeSelect').value;
  const monthIndex = type === 'monthly_rent' ? parseInt(document.getElementById('paymentProofMonthIndexSelect').value) || 1 : null;
  const amount = parseFloat(document.getElementById('paymentProofAmountInput').value) || 0;
  const dateTime = document.getElementById('paymentProofDateTimeInput').value;
  const bankName = document.getElementById('paymentProofBankInput').value.trim() || 'Bank Transfer';
  const referenceNo = document.getElementById('paymentProofRefInput').value.trim();
  const receiptImage = document.getElementById('paymentProofImageData').value || null;
  const receiptFileName = document.getElementById('paymentProofImageName').value || null;
  const notes = document.getElementById('paymentProofNotesInput').value.trim();

  if (amount <= 0) {
    alert(appState.settings.language === 'bm' ? 'Sila masukkan jumlah bayaran yang sah.' : 'Please enter a valid payment amount.');
    return;
  }

  if (!referenceNo) {
    alert(appState.settings.language === 'bm' ? 'Sila masukkan No. Rujukan Bank / Resit Transaksi.' : 'Please enter the Bank Reference No. / Transaction ID.');
    return;
  }

  const newPayment = {
    id: 'pay-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
    type,
    amount,
    monthIndex,
    date: dateTime ? dateTime.split('T')[0] : new Date().toISOString().split('T')[0],
    time: dateTime ? dateTime.split('T')[1] : '',
    dateTime: dateTime || new Date().toISOString(),
    bankName,
    referenceNo,
    receiptImage,
    receiptFileName,
    notes,
    createdAt: new Date().toISOString()
  };

  booking.payments = booking.payments || [];
  booking.payments.push(newPayment);

  const totalPaid = booking.payments.reduce((sum, p) => sum + (p.amount || 0), 0);
  booking.depositPaid = totalPaid;
  booking.balance = Math.max(0, booking.totalAmount - totalPaid);
  booking.lastPaymentRef = referenceNo;
  booking.lastPaymentBank = bankName;

  const oldStatus = booking.status;
  if (booking.balance <= 0 && booking.totalAmount > 0) {
    booking.status = 'confirmed';
  } else if (booking.depositPaid > 0 && booking.status === 'quotation') {
    booking.status = 'booked';
  }

  if (type === 'monthly_rent' && monthIndex) {
    const invoices = getOrInitMonthlyInvoices(booking);
    const targetInv = invoices.find(x => x.monthIndex === monthIndex);
    if (targetInv) {
      targetInv.status = 'paid';
      targetInv.paidAt = dateTime || new Date().toISOString();
      targetInv.referenceNo = referenceNo;
      targetInv.bankName = bankName;
      booking.monthlyInvoices = invoices;
    }
  }

  saveToStorage();
  closeAllModals();
  renderApp();

  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? `Resit bayaran ${formatCurrency(amount)} berjaya disimpan!` : `Payment receipt of ${formatCurrency(amount)} recorded successfully!`);

  if (oldStatus === 'quotation' && booking.status === 'booked') {
    openWhatsAppModal(booking, 'deposit_receipt');
  } else if (booking.status === 'confirmed' && oldStatus !== 'confirmed') {
    openWhatsAppModal(booking, 'full_receipt');
  } else if (type === 'monthly_rent' && monthIndex) {
    openWhatsAppModal(booking, 'monthly_rent_receipt', monthIndex);
  }
}

function openReceiptViewerModal(booking) {
  if (!booking) return;
  const prop = getPropertyById(booking.propertyId);
  const isBM = appState.settings.language === 'bm';

  document.getElementById('receiptViewerSubtitle').textContent = `${booking.guestName} (${booking.guestPhone || '-'}) • ${prop.name}`;

  const banner = document.getElementById('receiptViewerFinancialBanner');
  const totalPaid = (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0);
  const pctPaid = booking.totalAmount > 0 ? Math.min(100, Math.round((totalPaid / booking.totalAmount) * 100)) : 100;

  banner.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px;">
      <div>
        <span style="font-size:11px; font-weight:700; color:var(--text-muted); text-transform:uppercase;">${t('total')}: <strong>${formatCurrency(booking.totalAmount)}</strong></span>
        <div style="font-size:16px; font-weight:800; color:var(--success-text); margin-top:1px;">
          ${isBM ? 'Telah Dibayar' : 'Total Paid'}: ${formatCurrency(totalPaid)}
        </div>
      </div>
      <div style="text-align:right;">
        <span style="font-size:11px; font-weight:700; color:${booking.balance > 0 ? 'var(--danger)' : 'var(--success)'};">
          ${isBM ? 'Baki Bayaran' : 'Balance Due'}: <strong>${formatCurrency(booking.balance)}</strong>
        </span>
        <div style="font-size:11px; font-weight:800; color:var(--text-muted); margin-top:2px;">
          ${pctPaid}% ${isBM ? 'Selesai' : 'Settled'}
        </div>
      </div>
    </div>
    <div class="progress-bar-bg" style="margin-top:8px; margin-bottom:0; height:6px;">
      <div class="progress-bar-fill" style="width:${pctPaid}%;"></div>
    </div>
  `;

  const listContainer = document.getElementById('receiptViewerList');
  listContainer.innerHTML = '';

  const payments = booking.payments || [];
  if (payments.length === 0) {
    listContainer.innerHTML = `
      <div class="empty-hint" style="padding:28px 16px; text-align:center;">
        <i class="fa-solid fa-receipt" style="font-size:32px; color:var(--text-muted); opacity:0.4; margin-bottom:8px; display:block;"></i>
        <p style="font-size:14px; font-weight:700; color:var(--text-main); margin-bottom:4px;">
          ${t('no_receipts_recorded')}
        </p>
        <p style="font-size:12.5px; color:var(--text-muted); margin-bottom:14px;">
          ${isBM ? 'Tangkap resit atau rekod rujukan pindahan bank yang dikongsi oleh tetamu.' : 'Capture receipt screenshots and record bank transfer references shared by the guest.'}
        </p>
        <button type="button" class="btn btn-primary btn-sm" id="btnEmptyAddReceipt">
          <i class="fa-solid fa-plus"></i> ${t('add_payment_receipt')}
        </button>
      </div>
    `;
    const emptyBtn = document.getElementById('btnEmptyAddReceipt');
    if (emptyBtn) emptyBtn.addEventListener('click', () => {
      closeAllModals();
      openPaymentProofModal(booking);
    });
  } else {
    payments.forEach((p, idx) => {
      const card = document.createElement('div');
      card.className = `receipt-record-card type-${p.type || 'deposit'}`;

      let typeBadge = '';
      if (p.type === 'deposit') {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:#fef3c7; color:#92400e; padding:2px 8px; border-radius:999px;">🟡 ${isBM ? 'Deposit Tempahan' : 'Booking Deposit'}</span>`;
      } else if (p.type === 'balance' || p.type === 'full') {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:#dcfce7; color:#166534; padding:2px 8px; border-radius:999px;">🟢 ${p.type === 'full' ? (isBM ? 'Bayaran Penuh' : 'Full Payment') : (isBM ? 'Baki Bayaran' : 'Balance Settlement')}</span>`;
      } else if (p.type === 'monthly_rent') {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:#e0e7ff; color:#3730a3; padding:2px 8px; border-radius:999px;">📑 ${isBM ? `Sewa Bulan ke-${p.monthIndex || 1}` : `Month ${p.monthIndex || 1} Rent`}</span>`;
      } else if (p.type === 'security_deposit') {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:#f3e8ff; color:#6b21a8; padding:2px 8px; border-radius:999px;">🔒 ${isBM ? 'Deposit Keselamatan' : 'Security Deposit'}</span>`;
      } else {
        typeBadge = `<span style="font-size:10.5px; font-weight:800; background:var(--bg-surface-subtle); color:var(--text-main); padding:2px 8px; border-radius:999px;">📦 ${p.type}</span>`;
      }

      const formattedDate = p.dateTime ? p.dateTime.replace('T', ' ') : (p.date || '-');

      card.innerHTML = `
        <div class="receipt-record-header">
          <div>
            ${typeBadge}
            <span style="font-size:11px; color:var(--text-muted); margin-left:6px;"><i class="fa-regular fa-clock"></i> ${formattedDate}</span>
          </div>
          <strong style="font-size:15px; font-weight:800; color:var(--success-text);">
            ${formatCurrency(p.amount)}
          </strong>
        </div>

        <div class="receipt-record-body">
          ${p.receiptImage ? `
            <img src="${p.receiptImage}" alt="Receipt Slip" class="receipt-record-thumb" data-idx="${idx}" title="${isBM ? 'Tekan untuk lihat resit penuh' : 'Click to zoom slip'}">
          ` : `
            <div style="width:56px; height:56px; border-radius:6px; background:var(--bg-surface-subtle); border:1px dashed var(--border-color); display:flex; flex-direction:column; align-items:center; justify-content:center; color:var(--text-muted); font-size:10px; text-align:center; padding:2px;">
              <i class="fa-solid fa-file-circle-xmark" style="font-size:16px; margin-bottom:2px;"></i> No Slip
            </div>
          `}
          <div style="flex:1; min-width:0;">
            <div style="font-size:12.5px; font-weight:700; color:var(--text-main); display:flex; align-items:center; gap:6px;">
              <i class="fa-solid fa-building-columns" style="color:var(--primary);"></i> ${p.bankName || 'Bank Transfer'}
            </div>
            <div style="margin-top:3px;">
              <span class="receipt-ref-pill">
                <code>${p.referenceNo || '-'}</code>
                <button type="button" class="btn-copy-ref-pill" data-ref="${p.referenceNo || ''}" title="${isBM ? 'Salin No. Rujukan' : 'Copy Reference No'}" style="background:none; border:none; color:var(--primary); cursor:pointer; padding:0 2px;">
                  <i class="fa-solid fa-copy"></i>
                </button>
              </span>
            </div>
            ${p.notes ? `<p style="font-size:11.5px; color:var(--text-muted); margin:4px 0 0 0; font-style:italic;"><i class="fa-regular fa-note-sticky"></i> ${p.notes}</p>` : ''}
          </div>
        </div>

        <div class="receipt-actions-row">
          ${p.receiptImage ? `
            <button type="button" class="btn btn-outline btn-xs btn-view-full-slip" data-idx="${idx}">
              <i class="fa-solid fa-magnifying-glass-plus"></i> ${isBM ? 'Lihat Penuh' : 'View Slip'}
            </button>
            <button type="button" class="btn btn-outline btn-xs btn-download-slip" data-idx="${idx}">
              <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun' : 'Download'}
            </button>
          ` : ''}
          <button type="button" class="btn btn-outline btn-xs btn-delete-receipt-record" data-pid="${p.id}" data-bid="${booking.id}" style="color:var(--danger); border-color:var(--danger); margin-left:auto;">
            <i class="fa-solid fa-trash"></i> ${isBM ? 'Padam' : 'Delete'}
          </button>
        </div>
      `;

      listContainer.appendChild(card);
    });

    listContainer.querySelectorAll('.btn-copy-ref-pill').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const ref = e.currentTarget.getAttribute('data-ref');
        if (ref) {
          navigator.clipboard.writeText(ref).then(() => {
            showToast(t('ref_copied'));
          }).catch(() => {
            showToast(`Copied: ${ref}`);
          });
        }
      });
    });

    listContainer.querySelectorAll('.btn-view-full-slip, .receipt-record-thumb').forEach(el => {
      el.addEventListener('click', (e) => {
        const idx = parseInt(e.currentTarget.getAttribute('data-idx'));
        const p = payments[idx];
        if (p && p.receiptImage) {
          openReceiptLightbox(p.receiptImage, `${p.bankName} • ${p.referenceNo} (${formatCurrency(p.amount)})`);
        }
      });
    });

    listContainer.querySelectorAll('.btn-download-slip').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.currentTarget.getAttribute('data-idx'));
        const p = payments[idx];
        if (p && p.receiptImage) {
          const a = document.createElement('a');
          a.href = p.receiptImage;
          a.download = p.receiptFileName || `Receipt_${p.referenceNo || 'Payment'}.jpg`;
          document.body.appendChild(a);
          a.click();
          a.remove();
        }
      });
    });

    listContainer.querySelectorAll('.btn-delete-receipt-record').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pId = e.currentTarget.getAttribute('data-pid');
        const bId = e.currentTarget.getAttribute('data-bid');
        deletePaymentReceipt(bId, pId);
      });
    });
  }

  const addBtn = document.getElementById('btnAddReceiptFromViewer');
  if (addBtn) {
    addBtn.onclick = () => {
      closeAllModals();
      openPaymentProofModal(booking, booking.balance > 0 ? 'balance' : 'deposit');
    };
  }

  document.getElementById('receiptViewerModal').classList.add('active');
}

function openReceiptLightbox(imageUrl, title = 'Bank Receipt Proof') {
  const modal = document.getElementById('receiptLightboxModal');
  const img = document.getElementById('lightboxImage');
  const titleEl = document.getElementById('lightboxTitle');
  const downloadBtn = document.getElementById('btnDownloadLightboxImg');

  if (!modal || !img) return;

  img.src = imageUrl;
  if (titleEl) titleEl.textContent = title;

  if (downloadBtn) {
    downloadBtn.onclick = () => {
      const a = document.createElement('a');
      a.href = imageUrl;
      a.download = `Receipt_${new Date().toISOString().split('T')[0]}.jpg`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    };
  }

  modal.classList.add('active');
}

function deletePaymentReceipt(bookingId, paymentId) {
  const isBM = appState.settings.language === 'bm';
  if (!confirm(t('delete_receipt_confirm'))) return;

  const booking = appState.bookings.find(b => b.id === bookingId);
  if (!booking || !booking.payments) return;

  booking.payments = booking.payments.filter(p => p.id !== paymentId);

  const totalPaid = booking.payments.reduce((sum, p) => sum + (p.amount || 0), 0);
  booking.depositPaid = totalPaid;
  booking.balance = Math.max(0, booking.totalAmount - totalPaid);

  if (booking.payments.length > 0) {
    const lastP = booking.payments[booking.payments.length - 1];
    booking.lastPaymentRef = lastP.referenceNo;
    booking.lastPaymentBank = lastP.bankName;
  } else {
    booking.lastPaymentRef = null;
    booking.lastPaymentBank = null;
    if (booking.depositPaid === 0 && booking.status === 'booked') {
      booking.status = 'quotation';
    }
  }

  saveToStorage();
  renderApp();
  openReceiptViewerModal(booking);
  showToast(isBM ? 'Rekod resit telah dipadam.' : 'Payment receipt record deleted.');
}

// ==========================================================================
// 11E. PROMOTIONAL MEDIA & MARKETING HUB ENGINE
// ==========================================================================

function compressPromoMediaImage(file, maxWidth = 1000, maxHeight = 1000, quality = 0.8) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error('No file provided'));

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        const sizeBytes = Math.round((dataUrl.length * 3) / 4);
        resolve({
          dataUrl,
          sizeBytes,
          fileName: file.name
        });
      };
      img.onerror = (err) => reject(err);
      img.src = e.target.result;
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

function openPromotionalMediaModal(defaultPropertyId = null) {
  if (defaultPropertyId) {
    appState.selectedPromoPropertyId = defaultPropertyId;
  }
  
  // Populate property filter
  const propSelect = document.getElementById('promoPropertyFilter');
  if (propSelect) {
    const isBM = appState.settings.language === 'bm';
    let options = `<option value="all">${isBM ? 'Semua Homestay & Umum' : 'All Homestays & General'}</option>`;
    appState.properties.forEach(p => {
      options += `<option value="${p.id}">${escapeHtml(p.name)}</option>`;
    });
    propSelect.innerHTML = options;
    propSelect.value = appState.selectedPromoPropertyId || 'all';
  }

  // Set category pills active state
  const pills = document.querySelectorAll('#promoCategoryFilter .cal-mode-pill');
  pills.forEach(p => {
    if (p.getAttribute('data-category') === (appState.selectedPromoCategory || 'all')) {
      p.classList.add('active');
    } else {
      p.classList.remove('active');
    }
  });

  const searchInput = document.getElementById('promoSearchInput');
  if (searchInput) searchInput.value = appState.promoSearchQuery || '';

  renderPromotionalMediaList();
  document.getElementById('promotionalMediaModal').classList.add('active');
}

function renderPromotionalMediaList() {
  const container = document.getElementById('promoMediaGrid');
  const emptyState = document.getElementById('promoMediaEmptyState');
  if (!container) return;

  const isBM = appState.settings.language === 'bm';
  const filterProp = appState.selectedPromoPropertyId || 'all';
  const filterCat = appState.selectedPromoCategory || 'all';
  const query = (appState.promoSearchQuery || '').trim().toLowerCase();

  const filtered = appState.promotionalMedia.filter(item => {
    // Property match
    if (filterProp !== 'all' && item.propertyId !== 'all' && item.propertyId !== filterProp) {
      return false;
    }
    // Category match
    if (filterCat !== 'all' && item.category !== filterCat) {
      return false;
    }
    // Search query match
    if (query) {
      const prop = item.propertyId !== 'all' ? getPropertyById(item.propertyId) : null;
      const propName = prop ? prop.name.toLowerCase() : '';
      const title = (item.title || '').toLowerCase();
      const caption = (item.caption || '').toLowerCase();
      if (!title.includes(query) && !caption.includes(query) && !propName.includes(query)) {
        return false;
      }
    }
    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';

  let html = '';
  filtered.forEach(item => {
    const prop = item.propertyId !== 'all' ? getPropertyById(item.propertyId) : null;
    const propLabel = prop ? prop.name : (isBM ? 'Umum / Semua' : 'General / All');
    const propColor = prop ? prop.color : '#0284c7';

    // Category badge label
    let catLabel = 'Photo';
    let catIcon = 'fa-image';
    if (item.category === 'photo') {
      catLabel = isBM ? 'Foto' : 'Photo';
      catIcon = 'fa-image';
    } else if (item.category === 'poster') {
      catLabel = isBM ? 'Poster' : 'Poster';
      catIcon = 'fa-bullhorn';
    } else if (item.category === 'video_tour') {
      catLabel = isBM ? 'Video Tour' : 'Video Tour';
      catIcon = 'fa-video';
    } else if (item.category === 'copywriting') {
      catLabel = isBM ? 'Ayat Iklan' : 'Copywriting';
      catIcon = 'fa-pen-nib';
    }

    // Thumbnail area
    let thumbArea = '';
    if (item.imageData) {
      thumbArea = `
        <div class="promo-thumb-container" data-action="lightbox" data-id="${item.id}" title="${isBM ? 'Ketik untuk lihat saiz penuh' : 'Tap to view full-size'}">
          <img src="${item.imageData}" alt="${escapeHtml(item.title)}" class="promo-thumb-img" loading="lazy">
          <div class="promo-badge-overlay">
            <span class="promo-cat-badge cat-${item.category}"><i class="fa-solid ${catIcon}"></i> ${catLabel}</span>
            <span class="promo-prop-badge" style="border-left: 3px solid ${propColor};"><i class="fa-solid fa-house"></i> ${escapeHtml(propLabel)}</span>
          </div>
        </div>
      `;
    } else if (item.mediaUrl) {
      thumbArea = `
        <div class="promo-thumb-container" data-action="link" data-url="${escapeHtml(item.mediaUrl)}" style="background:linear-gradient(135deg, #1e293b, #0f172a);" title="${isBM ? 'Buka pautan' : 'Open external link'}">
          <div class="promo-thumb-placeholder" style="color:#38bdf8;">
            <i class="fa-solid ${item.category === 'video_tour' ? 'fa-circle-play' : 'fa-arrow-up-right-from-square'}" style="font-size:36px;"></i>
            <span style="font-size:11px; font-weight:700; color:#e2e8f0;">${isBM ? 'Pautan Video / Awan' : 'Video / Cloud Link'}</span>
          </div>
          <div class="promo-badge-overlay">
            <span class="promo-cat-badge cat-${item.category}"><i class="fa-solid ${catIcon}"></i> ${catLabel}</span>
            <span class="promo-prop-badge" style="border-left: 3px solid ${propColor};"><i class="fa-solid fa-house"></i> ${escapeHtml(propLabel)}</span>
          </div>
        </div>
      `;
    } else {
      thumbArea = `
        <div class="promo-thumb-container" style="background:linear-gradient(135deg, #f8fafc, #e2e8f0);">
          <div class="promo-thumb-placeholder" style="color:#d97706;">
            <i class="fa-solid fa-quote-left" style="font-size:32px; opacity:0.8;"></i>
            <span style="font-size:11px; font-weight:700; color:var(--text-muted);">${isBM ? 'Teks Iklan' : 'Marketing Pitch'}</span>
          </div>
          <div class="promo-badge-overlay">
            <span class="promo-cat-badge cat-${item.category}"><i class="fa-solid ${catIcon}"></i> ${catLabel}</span>
            <span class="promo-prop-badge" style="border-left: 3px solid ${propColor};"><i class="fa-solid fa-house"></i> ${escapeHtml(propLabel)}</span>
          </div>
        </div>
      `;
    }

    html += `
      <div class="promo-card" data-id="${item.id}">
        ${thumbArea}
        <div class="promo-card-body">
          <h4 class="promo-card-title">${escapeHtml(item.title)}</h4>
          <div class="promo-card-caption-preview">${escapeHtml(item.caption)}</div>
          
          <div class="promo-card-actions">
            <button type="button" class="btn btn-sm btn-promo-wa" data-action="wa" data-id="${item.id}" title="${isBM ? 'Hantar ke WhatsApp' : 'Send via WhatsApp'}">
              <i class="fa-brands fa-whatsapp"></i> <span>WhatsApp</span>
            </button>
            <button type="button" class="btn btn-sm btn-promo-share" data-action="native-share" data-id="${item.id}" title="${isBM ? 'Kongsi ke Apps' : 'Share to apps'}">
              <i class="fa-solid fa-share-nodes"></i>
            </button>
            <button type="button" class="btn btn-outline btn-xs" data-action="copy-pitch" data-id="${item.id}" title="${isBM ? 'Salin Ayat' : 'Copy Pitch'}">
              <i class="fa-solid fa-copy"></i>
            </button>
            ${item.mediaUrl ? `
              <button type="button" class="btn btn-outline btn-xs" data-action="copy-link" data-id="${item.id}" title="${isBM ? 'Salin Pautan' : 'Copy Link'}">
                <i class="fa-solid fa-link"></i>
              </button>
            ` : ''}
            <div style="margin-left:auto; display:flex; gap:2px;">
              <button type="button" class="promo-menu-btn" data-action="edit" data-id="${item.id}" title="${isBM ? 'Kemas Kini' : 'Edit'}">
                <i class="fa-solid fa-pen-to-square"></i>
              </button>
              <button type="button" class="promo-menu-btn" data-action="delete" data-id="${item.id}" title="${isBM ? 'Padam' : 'Delete'}">
                <i class="fa-solid fa-trash-can"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;

  // Attach card interaction listeners
  container.querySelectorAll('[data-action="lightbox"]').forEach(el => {
    el.addEventListener('click', () => {
      const id = el.getAttribute('data-id');
      openPromoLightbox(id);
    });
  });

  container.querySelectorAll('[data-action="link"]').forEach(el => {
    el.addEventListener('click', () => {
      const url = el.getAttribute('data-url');
      if (url) window.open(url, '_blank');
    });
  });

  container.querySelectorAll('[data-action="wa"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      openPromoWaQuickModal(id);
    });
  });

  container.querySelectorAll('[data-action="native-share"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      sharePromoMediaNative(id);
    });
  });

  container.querySelectorAll('[data-action="copy-pitch"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      copyPromoCaption(id);
    });
  });

  container.querySelectorAll('[data-action="copy-link"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      copyPromoLink(id);
    });
  });

  container.querySelectorAll('[data-action="edit"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      openPromoMediaEditModal(id);
    });
  });

  container.querySelectorAll('[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      deletePromoMediaItem(id);
    });
  });
}

function openPromoMediaEditModal(mediaId = null) {
  const isBM = appState.settings.language === 'bm';
  const modal = document.getElementById('promoMediaEditModal');
  const titleEl = document.getElementById('promoMediaEditTitle');
  const idInput = document.getElementById('promoMediaIdInput');
  const propSelect = document.getElementById('promoMediaPropertySelect');
  const catSelect = document.getElementById('promoMediaCategorySelect');
  const titleInput = document.getElementById('promoMediaTitleInput');
  const urlInput = document.getElementById('promoMediaUrlInput');
  const captionInput = document.getElementById('promoMediaCaptionInput');
  const imgDataInput = document.getElementById('promoMediaImageData');
  const fileInput = document.getElementById('promoMediaFileInput');
  const promptEl = document.getElementById('promoImageDropPrompt');
  const previewContainer = document.getElementById('promoImagePreviewContainer');
  const previewImg = document.getElementById('promoImagePreviewImg');
  const fileNameEl = document.getElementById('promoImageFileName');
  const fileSizeEl = document.getElementById('promoImageFileSize');

  // Populate property select
  let propOptions = `<option value="all">${isBM ? 'Umum / Semua Homestay' : 'General / All Homestays'}</option>`;
  appState.properties.forEach(p => {
    propOptions += `<option value="${p.id}">${escapeHtml(p.name)}</option>`;
  });
  propSelect.innerHTML = propOptions;

  fileInput.value = '';

  const existing = mediaId ? appState.promotionalMedia.find(m => m.id === mediaId) : null;
  if (existing) {
    if (titleEl) titleEl.textContent = isBM ? 'Kemaskini Media Promosi' : 'Edit Promotional Media';
    idInput.value = existing.id;
    propSelect.value = existing.propertyId || 'all';
    catSelect.value = existing.category || 'photo';
    titleInput.value = existing.title || '';
    urlInput.value = existing.mediaUrl || '';
    captionInput.value = existing.caption || '';
    imgDataInput.value = existing.imageData || '';

    if (existing.imageData) {
      previewImg.src = existing.imageData;
      fileNameEl.textContent = 'Current Image';
      const approxKb = Math.round((existing.imageData.length * 3) / 4096);
      fileSizeEl.textContent = `~${approxKb} KB`;
      promptEl.style.display = 'none';
      previewContainer.style.display = 'block';
    } else {
      promptEl.style.display = 'block';
      previewContainer.style.display = 'none';
    }
  } else {
    if (titleEl) titleEl.textContent = isBM ? 'Tambah Media Promosi' : 'Add Promotional Media';
    idInput.value = '';
    propSelect.value = appState.selectedPromoPropertyId !== 'all' ? appState.selectedPromoPropertyId : 'all';
    catSelect.value = appState.selectedPromoCategory !== 'all' ? appState.selectedPromoCategory : 'photo';
    titleInput.value = '';
    urlInput.value = '';
    captionInput.value = '';
    imgDataInput.value = '';
    promptEl.style.display = 'block';
    previewContainer.style.display = 'none';
  }

  modal.classList.add('active');
}

function handlePromoImageFileSelected(file) {
  if (!file) return;

  const isBM = appState.settings.language === 'bm';
  showToast(isBM ? 'Memampatkan gambar...' : 'Optimizing & compressing image...');

  compressPromoMediaImage(file, 1000, 1000, 0.8)
    .then(res => {
      document.getElementById('promoMediaImageData').value = res.dataUrl;
      document.getElementById('promoImagePreviewImg').src = res.dataUrl;
      document.getElementById('promoImageFileName').textContent = res.fileName;
      document.getElementById('promoImageFileSize').textContent = `${Math.round(res.sizeBytes / 1024)} KB (Compressed)`;
      document.getElementById('promoImageDropPrompt').style.display = 'none';
      document.getElementById('promoImagePreviewContainer').style.display = 'block';
      showToast(isBM ? 'Gambar sedia disimpan!' : 'Image optimized for storage!');
    })
    .catch(err => {
      console.error('Compression error:', err);
      alert(isBM ? 'Gagal memproses gambar.' : 'Failed to compress image.');
    });
}

function savePromoMediaItem(e) {
  e.preventDefault();

  const isBM = appState.settings.language === 'bm';
  const idInput = document.getElementById('promoMediaIdInput').value;
  const propertyId = document.getElementById('promoMediaPropertySelect').value;
  const category = document.getElementById('promoMediaCategorySelect').value;
  const title = document.getElementById('promoMediaTitleInput').value.trim();
  const mediaUrl = document.getElementById('promoMediaUrlInput').value.trim();
  const caption = document.getElementById('promoMediaCaptionInput').value.trim();
  const imageData = document.getElementById('promoMediaImageData').value;

  if (!title || !caption) {
    alert(isBM ? 'Sila isikan tajuk dan teks promosi.' : 'Please provide a title and promo copywriting text.');
    return;
  }

  const existingIndex = idInput ? appState.promotionalMedia.findIndex(m => m.id === idInput) : -1;
  const mediaObj = {
    id: idInput || `promo-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    propertyId,
    category,
    title,
    caption,
    mediaUrl,
    imageData,
    createdAt: existingIndex >= 0 ? (appState.promotionalMedia[existingIndex].createdAt || new Date().toISOString()) : new Date().toISOString()
  };

  if (existingIndex >= 0) {
    appState.promotionalMedia[existingIndex] = mediaObj;
  } else {
    appState.promotionalMedia.unshift(mediaObj);
  }

  saveToStorage();
  renderPromotionalMediaList();
  document.getElementById('promoMediaEditModal').classList.remove('active');
  showToast(isBM ? 'Media promosi berjaya disimpan!' : 'Promotional media asset saved!');
}

function deletePromoMediaItem(mediaId) {
  if (!confirm(t('delete_promo_confirm'))) return;

  appState.promotionalMedia = appState.promotionalMedia.filter(m => m.id !== mediaId);
  saveToStorage();
  renderPromotionalMediaList();
  showToast(appState.settings.language === 'bm' ? 'Media promosi telah dipadam.' : 'Promotional media deleted.');
}

function openPromoLightbox(mediaId) {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (item && item.imageData) {
    openReceiptLightbox(item.imageData, item.title);
  }
}

function copyPromoCaption(mediaId) {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item) return;

  let textToCopy = item.caption;
  if (item.mediaUrl && !textToCopy.includes(item.mediaUrl)) {
    textToCopy += `\n\n🔗 ${item.mediaUrl}`;
  }

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(textToCopy).then(() => {
      showToast(t('pitch_copied'));
    }).catch(() => {
      copyViaFallback(textToCopy, t('pitch_copied'));
    });
  } else {
    copyViaFallback(textToCopy, t('pitch_copied'));
  }
}

function copyPromoLink(mediaId) {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item || !item.mediaUrl) return;

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(item.mediaUrl).then(() => {
      showToast(t('link_copied'));
    }).catch(() => {
      copyViaFallback(item.mediaUrl, t('link_copied'));
    });
  } else {
    copyViaFallback(item.mediaUrl, t('link_copied'));
  }
}

function copyViaFallback(text, successMsg) {
  const ta = document.createElement('textarea');
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  document.execCommand('copy');
  document.body.removeChild(ta);
  showToast(successMsg);
}

function sharePromoMediaNative(mediaId) {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item) return;

  let shareText = item.caption;
  const shareUrl = item.mediaUrl || '';

  if (navigator.share) {
    navigator.share({
      title: item.title,
      text: shareText,
      url: shareUrl || undefined
    }).catch(err => {
      if (err.name !== 'AbortError') {
        openPromoWaQuickModal(mediaId);
      }
    });
  } else {
    openPromoWaQuickModal(mediaId);
  }
}

function openPromoWaQuickModal(mediaId, defaultPhone = '') {
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item) return;

  const isBM = appState.settings.language === 'bm';
  document.getElementById('promoWaQuickMediaId').value = mediaId;

  // Populate recipients dropdown with recent bookings
  const recipientSelect = document.getElementById('promoWaRecipientSelect');
  const customPhoneGroup = document.getElementById('promoWaCustomPhoneGroup');
  const customPhoneInput = document.getElementById('promoWaCustomPhoneInput');

  let opts = `<option value="custom">${isBM ? '✏️ Masukkan / Pilih Nombor WhatsApp' : '✏️ Enter / Custom Phone Number'}</option>`;
  
  // Get unique recent guests with phone numbers
  const recentGuests = [];
  const seenPhones = new Set();

  appState.bookings.forEach(b => {
    if (b.guestPhone && !seenPhones.has(b.guestPhone)) {
      seenPhones.add(b.guestPhone);
      const prop = getPropertyById(b.propertyId);
      recentGuests.push({
        name: b.guestName,
        phone: b.guestPhone,
        property: prop ? prop.name : ''
      });
    }
  });

  recentGuests.slice(0, 8).forEach(g => {
    opts += `<option value="${escapeHtml(g.phone)}">👤 ${escapeHtml(g.name)} (${g.phone}) • ${escapeHtml(g.property)}</option>`;
  });

  recipientSelect.innerHTML = opts;

  if (defaultPhone) {
    recipientSelect.value = 'custom';
    customPhoneInput.value = defaultPhone;
    customPhoneGroup.style.display = 'block';
  } else if (recentGuests.length > 0) {
    recipientSelect.value = recentGuests[0].phone;
    customPhoneInput.value = recentGuests[0].phone;
    customPhoneGroup.style.display = 'none';
  } else {
    recipientSelect.value = 'custom';
    customPhoneInput.value = '';
    customPhoneGroup.style.display = 'block';
  }

  // Format message text
  let msg = item.caption;
  if (item.mediaUrl && !msg.includes(item.mediaUrl)) {
    msg += `\n\n🔗 ${item.mediaUrl}`;
  }

  document.getElementById('promoWaMessagePreview').textContent = msg;
  document.getElementById('promoWaQuickModal').classList.add('active');
}

function executePromoWaSend() {
  const isBM = appState.settings.language === 'bm';
  const mediaId = document.getElementById('promoWaQuickMediaId').value;
  const item = appState.promotionalMedia.find(m => m.id === mediaId);
  if (!item) return;

  const recipientSelect = document.getElementById('promoWaRecipientSelect');
  const customPhoneInput = document.getElementById('promoWaCustomPhoneInput');
  
  let rawPhone = recipientSelect.value === 'custom' ? customPhoneInput.value.trim() : recipientSelect.value;
  let cleanPhone = rawPhone.replace(/[^\d+]/g, '');
  if (cleanPhone.startsWith('0')) {
    cleanPhone = '60' + cleanPhone.slice(1);
  } else if (cleanPhone.startsWith('+')) {
    cleanPhone = cleanPhone.slice(1);
  }

  let text = item.caption;
  if (item.mediaUrl && !text.includes(item.mediaUrl)) {
    text += `\n\n🔗 ${item.mediaUrl}`;
  }

  const encoded = encodeURIComponent(text);
  let waUrl = '';
  if (cleanPhone && cleanPhone.length >= 8) {
    waUrl = `https://wa.me/${cleanPhone}?text=${encoded}`;
  } else {
    waUrl = `https://wa.me/?text=${encoded}`;
  }

  window.open(waUrl, '_blank');
  document.getElementById('promoWaQuickModal').classList.remove('active');
  showToast(isBM ? 'Membuka WhatsApp...' : 'Opening WhatsApp...');
}

function insertPromoPitchTemplate() {
  const isBM = appState.settings.language === 'bm';
  const cat = document.getElementById('promoMediaCategorySelect').value;
  const propId = document.getElementById('promoMediaPropertySelect').value;
  const prop = propId !== 'all' ? getPropertyById(propId) : null;
  const propName = prop ? prop.name : (isBM ? 'Homestay Eksklusif Kami' : 'Our Exclusive Homestay');
  const rate = prop ? (prop.defaultRate || 200) : 200;

  let template = '';
  if (cat === 'photo' || cat === 'poster') {
    if (isBM) {
      template = `✨ *${propName}* ✨\nPercutian selesa & mendamaikan untuk anda sekeluarga!\n\n🏡 *Kemudahan Lengkap:*\n• Bilik tidur luas & selesa berhawa dingin\n• Dapur lengkap memasak & ruang tamu selesa\n• WiFi laju & Smart TV\n• Lokasi strategik berdekatan tempat menarik\n\n💰 *Kadar dari:* RM ${rate} / malam\n📲 WhatsApp kami untuk semak kekosongan tarikh pilihan anda!`;
    } else {
      template = `✨ *${propName}* ✨\nThe perfect retreat for your relaxing getaway!\n\n🏡 *Key Amenities:*\n• Fully air-conditioned & sparkling clean\n• High-speed WiFi & Smart Entertainment\n• Equipped kitchen & dining area\n• Prime location near local attractions\n\n💰 *Rates from:* RM ${rate} / night\n📲 Message us now to reserve your dates!`;
    }
  } else if (cat === 'video_tour') {
    if (isBM) {
      template = `🎥 *Video Tour Maya: ${propName}*\nLihat sendiri suasana selesa unit kami sebelum anda menempah!\n\n👇 *Tonton Video di sini:*\nhttps://youtu.be/sample-tour\n\n💬 Hubungi kami segera untuk tempahan & tawaran istimewa!`;
    } else {
      template = `🎥 *Virtual Tour: ${propName}*\nTake an exclusive walkthrough inside our cozy unit!\n\n👇 *Watch the video here:*\nhttps://youtu.be/sample-tour\n\n💬 Send us a message today to secure your stay!`;
    }
  } else {
    if (isBM) {
      template = `🎉 *Tawaran Terhad: Diskaun Khas Homestay!* 🌟\nTempah awal untuk percutian seterusnya dan nikmati diskaun eksklusif.\n\n• Sesuai untuk keluarga & rakan\n• Suasana tenang & privasi terjamin\n• Tempah terus tanpa caj tersembunyi\n\n📲 Balas mesej ini dengan tarikh pilihan anda untuk dapatkan diskaun!`;
    } else {
      template = `🎉 *Limited-Time Special Offer!* 🌟\nBook your upcoming getaway early and enjoy exclusive rates.\n\n• Ideal for families & group getaways\n• Total comfort, cleanliness & privacy\n• Direct booking guaranteed best price\n\n📲 Reply to this message with your dates to lock in your discount!`;
    }
  }

  const captionInput = document.getElementById('promoMediaCaptionInput');
  if (captionInput) {
    captionInput.value = template;
    captionInput.focus();
  }
}

function attachPromoMediaToWaMessage() {
  const isBM = appState.settings.language === 'bm';
  if (!appState.activeWaBooking) return;

  const bPropId = appState.activeWaBooking.propertyId;
  const available = appState.promotionalMedia.filter(m => m.propertyId === 'all' || m.propertyId === bPropId);

  if (available.length === 0) {
    alert(isBM ? 'Tiada media promosi dijumpai bagi unit ini. Sila tambah media dalam Hab Media.' : 'No promo media found for this unit. Please add media in the Media Hub.');
    return;
  }

  // Pick the first relevant media item
  const chosen = available[0];
  let extraText = `\n\n📸 *${chosen.title}*:\n${chosen.caption}`;
  if (chosen.mediaUrl && !extraText.includes(chosen.mediaUrl)) {
    extraText += `\n🔗 ${chosen.mediaUrl}`;
  }

  const previewEl = document.getElementById('waMessagePreviewText');
  if (previewEl) {
    previewEl.textContent += extraText;
    showToast(isBM ? 'Media promosi disertakan!' : 'Promo media attached to message!');
  }
}

// ==========================================================================
// 12. PROPERTY MODAL LOGIC
// ==========================================================================

function openPropertyModal(existingProp = null) {
  const form = document.getElementById('propertyForm');
  form.reset();

  if (existingProp) {
    document.getElementById('propertyModalTitle').textContent = 'Edit Rental Unit / Homestay';
    document.getElementById('propertyIdInput').value = existingProp.id;
    document.getElementById('propertyNameInput').value = existingProp.name;
    document.getElementById('propertyRoomNoInput').value = existingProp.roomNo || '';
    document.getElementById('propertyTypeSelect').value = existingProp.propType || 'entire';
    document.getElementById('propertyAddressInput').value = existingProp.address || '';
    document.getElementById('propertyGpsInput').value = existingProp.gpsLocation || '';
    document.getElementById('propertyWifiNameInput').value = existingProp.wifiName || '';
    document.getElementById('propertyWifiPassInput').value = existingProp.wifiPass || '';
    document.getElementById('propertyDoorPinInput').value = existingProp.doorCode || '';
    document.getElementById('propertyDefaultRateInput').value = existingProp.defaultRate || 250;
    document.getElementById('propertyCleaningFeeInput').value = existingProp.cleaningFee || 50;
    document.getElementById('propertyCheckInTimeInput').value = existingProp.checkInTime || '15:00';
    document.getElementById('propertyCheckOutTimeInput').value = existingProp.checkOutTime || '12:00';
    document.getElementById('propertyRulesInput').value = existingProp.rules || '';
  } else {
    document.getElementById('propertyModalTitle').textContent = 'Add Rental Unit / Homestay';
    document.getElementById('propertyIdInput').value = '';
    document.getElementById('propertyRoomNoInput').value = '';
    document.getElementById('propertyTypeSelect').value = 'entire';
    document.getElementById('propertyAddressInput').value = '';
    document.getElementById('propertyGpsInput').value = '';
    document.getElementById('propertyDefaultRateInput').value = 250;
    document.getElementById('propertyCleaningFeeInput').value = 50;
  }

  document.getElementById('propertyModal').classList.add('active');
}

function handleSaveProperty(e) {
  e.preventDefault();

  const id = document.getElementById('propertyIdInput').value;
  const name = document.getElementById('propertyNameInput').value.trim();
  const roomNo = document.getElementById('propertyRoomNoInput') ? document.getElementById('propertyRoomNoInput').value.trim() : '';
  const propType = document.getElementById('propertyTypeSelect') ? document.getElementById('propertyTypeSelect').value : 'entire';
  const address = document.getElementById('propertyAddressInput').value.trim();
  const gpsLocation = document.getElementById('propertyGpsInput') ? document.getElementById('propertyGpsInput').value.trim() : '';
  const wifiName = document.getElementById('propertyWifiNameInput').value.trim();
  const wifiPass = document.getElementById('propertyWifiPassInput').value.trim();
  const doorCode = document.getElementById('propertyDoorPinInput').value.trim();
  const defaultRate = parseFloat(document.getElementById('propertyDefaultRateInput').value) || 250;
  const cleaningFee = parseFloat(document.getElementById('propertyCleaningFeeInput').value) || 50;
  const checkInTime = document.getElementById('propertyCheckInTimeInput').value || '15:00';
  const checkOutTime = document.getElementById('propertyCheckOutTimeInput').value || '12:00';
  const rules = document.getElementById('propertyRulesInput').value.trim();

  const colorRadio = document.querySelector('input[name="propColor"]:checked');
  const color = colorRadio ? colorRadio.value : '#0284c7';

  const propData = {
    id: id || `prop-${Date.now()}`,
    name,
    roomNo,
    propType,
    address,
    gpsLocation,
    wifiName,
    wifiPass,
    doorCode,
    color,
    defaultRate,
    cleaningFee,
    checkInTime,
    checkOutTime,
    rules
  };

  if (id) {
    const idx = appState.properties.findIndex(p => p.id === id);
    if (idx !== -1) appState.properties[idx] = { ...appState.properties[idx], ...propData };
  } else {
    appState.properties.push(propData);
  }

  saveToStorage();
  closeAllModals();
  renderApp();
  showToast(id ? 'Rental unit updated!' : 'New rental unit added!');
}

// ==========================================================================
// 13. EXPENSE MODAL LOGIC
// ==========================================================================

function openExpenseModal() {
  const form = document.getElementById('expenseForm');
  form.reset();

  const propSelect = document.getElementById('expensePropertySelect');
  propSelect.innerHTML = '';
  appState.properties.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.name;
    propSelect.appendChild(opt);
  });

  document.getElementById('expenseDateInput').value = new Date().toISOString().split('T')[0];
  document.getElementById('expenseModal').classList.add('active');
}

function handleSaveExpense(e) {
  e.preventDefault();

  const propertyId = document.getElementById('expensePropertySelect').value;
  const amount = parseFloat(document.getElementById('expenseAmountInput').value) || 0;
  const date = document.getElementById('expenseDateInput').value;
  const category = document.getElementById('expenseCategorySelect').value;
  const description = document.getElementById('expenseDescInput').value.trim();

  appState.expenses.push({
    id: `exp-${Date.now()}`,
    propertyId,
    amount,
    date,
    category,
    description: description || category.toUpperCase()
  });

  saveToStorage();
  closeAllModals();
  if (appState.activeTab === 'finances') renderFinancesTab();
  showToast('Expense logged successfully!');
}

// ==========================================================================
// 14. 1-TAP WHATSAPP AUTOMATION ENGINE
// ==========================================================================

function openWhatsAppModal(booking, templateType = 'quotation', monthIndex = 1) {
  appState.activeWaBooking = booking;
  appState.activeWaTemplate = templateType;
  appState.activeWaMonthIndex = monthIndex || 1;

  const prop = getPropertyById(booking.propertyId);
  document.getElementById('waGuestRecipient').textContent = `${t('wa_to')}: ${booking.guestName} (${booking.guestPhone || 'No Phone Entered'})`;

  const isMonthly = booking.rentalType === 'monthly';

  // Toggle visible tabs based on rental type
  document.querySelectorAll('.wa-tab-btn').forEach(btn => {
    const tmpl = btn.getAttribute('data-template');
    btn.classList.toggle('active', tmpl === templateType);
    if (tmpl === 'monthly_invoice' || tmpl === 'monthly_rent_receipt') {
      btn.style.display = isMonthly ? 'inline-flex' : 'none';
    } else if (tmpl === 'refund_receipt') {
      btn.style.display = (isMonthly || booking.securityDeposit > 0) ? 'inline-flex' : 'none';
    } else {
      btn.style.display = 'inline-flex';
    }
  });

  // Setup monthly dropdown if monthly booking
  const monthlyControls = document.getElementById('waMonthlyControls');
  const monthSelect = document.getElementById('waInvoiceMonthSelect');
  
  if (isMonthly && (templateType === 'monthly_invoice' || templateType === 'monthly_rent_receipt')) {
    if (monthlyControls) monthlyControls.classList.remove('hidden');
    if (monthSelect) {
      monthSelect.innerHTML = '';
      const invs = getOrInitMonthlyInvoices(booking);
      invs.forEach(inv => {
        const opt = document.createElement('option');
        opt.value = inv.monthIndex;
        const isBM = appState.settings.language === 'bm';
        opt.textContent = `${isBM ? 'Bulan ke-' : 'Month '}${inv.monthIndex} (${inv.periodStart} → ${inv.periodEnd}) [${inv.status === 'paid' ? (isBM ? 'DIBAYAR' : 'PAID') : (isBM ? 'BELUM' : 'DUE')}]`;
        if (inv.monthIndex === appState.activeWaMonthIndex) opt.selected = true;
        monthSelect.appendChild(opt);
      });
    }
  } else {
    if (monthlyControls) monthlyControls.classList.add('hidden');
  }

  // Setup quotation validity input if quotation template
  const waQuotationControls = document.getElementById('waQuotationControls');
  const waQuotationValidityInput = document.getElementById('waQuotationValidityInput');
  if (waQuotationControls) {
    waQuotationControls.classList.toggle('hidden', templateType !== 'quotation');
  }
  if (waQuotationValidityInput) {
    waQuotationValidityInput.value = booking.quotationValidityDays || appState.settings.quotationValidityDays || 3;
  }

  renderWhatsAppPreview();
  document.getElementById('whatsappModal').classList.add('active');
}

function populateDispatchRecipients(selectedContactId = null, preselectedCategory = null) {
  const select = document.getElementById('dispatchRecipientSelect');
  if (!select) return;
  select.innerHTML = '';

  const contacts = appState.contacts || [];
  const isBM = appState.settings.language === 'bm';

  if (contacts.length === 0) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = isBM ? '-- Tiada Kenalan (Tambah di Tetapan) --' : '-- No Contacts Saved (Add in Settings) --';
    select.appendChild(opt);
    return;
  }

  contacts.forEach(c => {
    const opt = document.createElement('option');
    opt.value = c.id;
    const badge = getContactCategoryBadge(c.category);
    opt.textContent = `${c.name} (${badge.label})${c.company ? ' - ' + c.company : ''}`;
    select.appendChild(opt);
  });

  if (selectedContactId && contacts.some(c => c.id === selectedContactId)) {
    select.value = selectedContactId;
  } else if (preselectedCategory) {
    const matched = contacts.find(c => c.category === preselectedCategory);
    if (matched) {
      select.value = matched.id;
    } else {
      select.value = contacts[0].id;
    }
  } else {
    select.value = contacts[0].id;
  }
}

function populateDispatchProperties(selectedPropId = null) {
  const select = document.getElementById('dispatchPropertySelect');
  if (!select) return;
  select.innerHTML = '';

  const props = appState.properties || [];
  props.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.name;
    select.appendChild(opt);
  });

  if (selectedPropId && props.some(p => p.id === selectedPropId)) {
    select.value = selectedPropId;
  } else if (appState.selectedPropertyId && appState.selectedPropertyId !== 'all' && props.some(p => p.id === appState.selectedPropertyId)) {
    select.value = appState.selectedPropertyId;
  } else if (props.length > 0) {
    select.value = props[0].id;
  }
}

function openServiceDispatchModal(turnover = null, preselectedCategory = null, preselectedContactId = null) {
  appState.activeDispatchTurnover = turnover;
  const isBM = appState.settings.language === 'bm';

  const tidInput = document.getElementById('dispatchTurnoverId');
  if (tidInput) tidInput.value = turnover ? turnover.id : '';

  const targetPropId = turnover ? turnover.propertyId : null;
  populateDispatchProperties(targetPropId);

  let cat = preselectedCategory;
  if (turnover) {
    cat = 'cleaner';
    const sType = document.getElementById('dispatchServiceTypeSelect');
    if (sType) sType.value = 'turnover_clean';
    const sUrg = document.getElementById('dispatchUrgencySelect');
    if (sUrg) sUrg.value = 'normal';
    const details = document.getElementById('dispatchDetailsInput');
    if (details) {
      details.value = isBM
        ? `Pembersihan unit homestay dijadualkan pada ${turnover.date}. Sila pastikan cadar ditukar dan tuala bersih disediakan.`
        : `Turnover cleaning scheduled for ${turnover.date}. Please ensure fresh linens and towels are provided.`;
    }
  } else if (preselectedCategory) {
    const catToType = {
      cleaner: 'turnover_clean',
      aircond: 'aircond_service',
      plumber: 'plumbing_repair',
      electrician: 'electrical_repair',
      handyman: 'handyman_repair',
      linen_supplier: 'linen_order',
      gas_supplier: 'gas_order',
      locksmith: 'inspection',
      other: 'other_task'
    };
    const sType = document.getElementById('dispatchServiceTypeSelect');
    if (sType && catToType[preselectedCategory]) {
      sType.value = catToType[preselectedCategory];
    }
  }

  populateDispatchRecipients(preselectedContactId, cat);
  renderServiceDispatchPreview();
  const modal = document.getElementById('serviceDispatchModal');
  if (modal) modal.classList.add('active');
}

function openWhatsAppCleanerJob(turnover) {
  openServiceDispatchModal(turnover, 'cleaner');
}

function generateServiceDispatchMessage() {
  const isBM = appState.settings.language === 'bm';
  const recipientId = document.getElementById('dispatchRecipientSelect')?.value;
  const propId = document.getElementById('dispatchPropertySelect')?.value;
  const serviceType = document.getElementById('dispatchServiceTypeSelect')?.value || 'turnover_clean';
  const urgency = document.getElementById('dispatchUrgencySelect')?.value || 'normal';
  const customDetails = document.getElementById('dispatchDetailsInput')?.value.trim() || '';
  const includePin = document.getElementById('dispatchIncludePinCheck')?.checked;

  const contact = (appState.contacts || []).find(c => c.id === recipientId);
  const prop = getPropertyById(propId) || (appState.properties[0] || { name: 'Homestay Unit', address: '' });
  const turnover = appState.activeDispatchTurnover;
  const settings = appState.settings;

  let headerTitle = '';
  let defaultTaskDesc = '';

  switch (serviceType) {
    case 'turnover_clean':
      headerTitle = isBM ? '🧹 *ARAHAN KERJA PEMBERSIHAN / TURNOVER*' : '🧹 *TURNOVER CLEANING JOB ALERT*';
      defaultTaskDesc = isBM ? 'Pembersihan unit menyeluruh, tukar cadar, basuh tuala dan kemas bilik.' : 'Full turnover cleaning, fresh bed linens, sanitized towels & amenities restock.';
      break;
    case 'aircond_service':
      headerTitle = isBM ? '❄️ *NOTIS SERVIS & BAIKI AIRCOND*' : '❄️ *AIRCOND SERVICE & REPAIR REQUEST*';
      defaultTaskDesc = isBM ? 'Servis aircond tidak sejuk / cuci filter / pemeriksaan kebocoran.' : 'Aircond servicing, filter cleaning, or cooling troubleshooting.';
      break;
    case 'plumbing_repair':
      headerTitle = isBM ? '🔧 *NOTIS BAIKI PAIP & SALIRAN*' : '🔧 *PLUMBING REPAIR REQUEST*';
      defaultTaskDesc = isBM ? 'Baiki paip bocor, mangkuk tandas tersumbat atau water heater.' : 'Plumbing inspection, leak repair, or toilet drain troubleshooting.';
      break;
    case 'electrical_repair':
      headerTitle = isBM ? '⚡ *NOTIS PENDAWAIAN & ELEKTRIK*' : '⚡ *ELECTRICAL REPAIR REQUEST*';
      defaultTaskDesc = isBM ? 'Periksa masalah elektrik, suis rosak atau trip elektrik.' : 'Electrical wiring check, power trip, socket or lighting issue.';
      break;
    case 'handyman_repair':
      headerTitle = isBM ? '🔨 *NOTIS KERJA BAIKI AM (HANDYMAN)*' : '🔨 *GENERAL HANDYMAN REPAIR REQUEST*';
      defaultTaskDesc = isBM ? 'Kerja baiki kerosakan am pintu, perabot atau perkakasan unit.' : 'General repair for doors, hinges, furniture, or fixture maintenance.';
      break;
    case 'linen_order':
      headerTitle = isBM ? '🧺 *PESANAN BEKALAN LINEN & DOBI*' : '🧺 *LINEN & LAUNDRY SUPPLY ORDER*';
      defaultTaskDesc = isBM ? 'Pesanan tambahan cadar, sarung bantal, duvet dan tuala putih.' : 'Restock order for bedsheet sets, duvet covers, and bath towels.';
      break;
    case 'gas_order':
      headerTitle = isBM ? '⛽ *PESANAN TONG GAS & KEPERLUAN UNIT*' : '⛽ *GAS / AMENITIES RESTOCK ORDER*';
      defaultTaskDesc = isBM ? 'Penghantaran tong gas memasak atau stok sabun / syampu / kopi.' : 'Delivery order for cooking gas cylinder, toiletries, or guest amenities.';
      break;
    case 'inspection':
      headerTitle = isBM ? '🔍 *NOTIS PEMERIKSAAN UNIT*' : '🔍 *UNIT INSPECTION REQUEST*';
      defaultTaskDesc = isBM ? 'Pemeriksaan status unit, kunci pintu, peralatan dan kebersihan.' : 'General inspection of unit condition, appliances, and access.';
      break;
    default:
      headerTitle = isBM ? '📝 *ARAHAN TUGASAN KHAS*' : '📝 *SERVICE / MAINTENANCE REQUEST*';
      defaultTaskDesc = isBM ? 'Tugasan perkhidmatan berkaitan unit homestay.' : 'Service task for homestay property.';
  }

  let urgencyText = '';
  if (urgency === 'urgent') {
    urgencyText = isBM ? '🔴 *Tahap Keperluan:* SEGERA / KECEMASAN (Sila hadir secepat mungkin)\n' : '🔴 *Urgency:* URGENT / IMMEDIATE (Please attend ASAP)\n';
  } else if (urgency === 'high') {
    urgencyText = isBM ? '🟡 *Tahap Keperluan:* KEUTAMAAN TINGGI (Hari ini)\n' : '🟡 *Urgency:* HIGH PRIORITY (Today)\n';
  } else {
    urgencyText = isBM ? '🟢 *Tahap Keperluan:* Jadual Biasa\n' : '🟢 *Urgency:* Normal Schedule\n';
  }

  const recipientGreeting = contact ? (isBM ? `Salam ${contact.name}` : `Hello ${contact.name}`) : (isBM ? 'Salam sejahtera' : 'Hello');

  let body = `${headerTitle}\n\n` +
    `${recipientGreeting}, ${isBM ? 'kami memerlukan bantuan anda bagi perkhidmatan berikut:' : 'we require your service for the following property:'}\n\n` +
    `🏠 *${isBM ? 'Unit / Homestay' : 'Property'}:* ${prop.name}\n` +
    `📍 *${isBM ? 'Alamat' : 'Address'}:* ${prop.address || (isBM ? 'Alamat unit standard' : 'Standard Address')}\n` +
    (prop.gpsLocation ? `🗺️ *${isBM ? 'Peta Google Maps' : 'Google Maps GPS'}:* ${prop.gpsLocation}\n` : '') +
    urgencyText;

  if (serviceType === 'turnover_clean' || turnover) {
    const targetDate = turnover ? turnover.date : new Date().toISOString().split('T')[0];
    body += `📅 *${isBM ? 'Tarikh Tugasan' : 'Target Date'}:* ${targetDate}\n` +
            `⏰ *${isBM ? 'Waktu Pembersihan' : 'Cleaning Window'}:* ${prop.checkOutTime || '12:00 PM'} - ${prop.checkInTime || '3:00 PM'}\n`;
  }

  if (includePin && prop.doorCode) {
    body += `🔑 *${isBM ? 'Kod PIN Pintu (Smart Lock)' : 'Smart Lock Door PIN'}:* ${prop.doorCode}\n`;
  }

  const detailsText = customDetails || defaultTaskDesc;
  body += `\n📋 *${isBM ? 'ARAHAN / PERINCIAN' : 'TASK DETAILS / INSTRUCTIONS'}:*\n${detailsText}\n\n`;

  body += isBM
    ? `Sila sahkan penerimaan mesej ini dan maklumkan waktu kehadiran/penghantaran anda. Terima kasih! 🙏\n_${settings.businessName || 'Pengurusan Homestay'}_`
    : `Please acknowledge receipt and advise your estimated arrival/delivery time. Thank you! 🙏\n_${settings.businessName || 'Homestay Management'}_`;

  return body;
}

function renderServiceDispatchPreview() {
  const bubble = document.getElementById('dispatchPreviewText');
  const badge = document.getElementById('dispatchRecipientBadge');
  const time = document.getElementById('dispatchTimestamp');
  if (!bubble) return;

  const msg = generateServiceDispatchMessage();
  bubble.textContent = msg;

  const recipientId = document.getElementById('dispatchRecipientSelect')?.value;
  const contact = (appState.contacts || []).find(c => c.id === recipientId);
  if (badge) {
    if (contact) {
      badge.textContent = `To: ${contact.name} (${contact.phone})`;
    } else {
      badge.textContent = 'To: Unspecified Contact';
    }
  }

  if (time) {
    const now = new Date();
    const hrs = String(now.getHours()).padStart(2, '0');
    const mins = String(now.getMinutes()).padStart(2, '0');
    time.textContent = `${hrs}:${mins} ✓✓`;
  }
}

function handleSendServiceDispatchWa() {
  const recipientId = document.getElementById('dispatchRecipientSelect')?.value;
  const contact = (appState.contacts || []).find(c => c.id === recipientId);
  const msg = generateServiceDispatchMessage();

  let phone = '';
  if (contact && contact.phone) {
    phone = contact.phone.replace(/[^0-9]/g, '');
  }

  const waUrl = phone ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}` : `https://wa.me/?text=${encodeURIComponent(msg)}`;
  window.open(waUrl, '_blank');
  closeAllModals();
  showToast(appState.settings.language === 'bm' ? 'Mesej WhatsApp dihantar!' : 'WhatsApp dispatch opened!');
}

function handleCopyServiceDispatchText() {
  const msg = generateServiceDispatchMessage();
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(msg).then(() => {
      showToast(appState.settings.language === 'bm' ? 'Teks notis disalin!' : 'Message text copied to clipboard!');
    }).catch(() => {
      showToast('Copied to clipboard');
    });
  } else {
    showToast('Copied to clipboard');
  }
}

function generateWhatsAppMessage(booking, templateType, langOverride = null) {
  const prop = getPropertyById(booking.propertyId);
  const currency = appState.settings.currency || 'RM';
  const settings = appState.settings;
  const isBM = langOverride ? (langOverride === 'bm') : ((appState.activeWaLang || settings.language || 'bm') === 'bm');
  const isMonthly = booking.rentalType === 'monthly';
  const isRoom = prop.propType && prop.propType.startsWith('room');

  const unitTitleBM = isRoom ? `🚪 *Bilik / Unit:* ${prop.name} ${prop.roomNo ? `(${prop.roomNo})` : ''}` : `🏠 *Homestay:* ${prop.name}`;
  const unitTitleEN = isRoom ? `🚪 *Homestay Room:* ${prop.name} ${prop.roomNo ? `(${prop.roomNo})` : ''}` : `🏠 *Homestay:* ${prop.name}`;

  const tenantParticularsBM = (booking.guestNric || booking.guestEmail || booking.guestAddress)
    ? `👤 *BUTIRAN PENYEWA:*\n• Nama: *${booking.guestName}*\n` +
      (booking.guestNric ? `• No. KP / Pasport: *${booking.guestNric}*\n` : '') +
      (booking.guestPhone ? `• No. Telefon / WA: *${booking.guestPhone}*\n` : '') +
      (booking.guestEmail ? `• Emel: *${booking.guestEmail}*\n` : '') +
      (booking.guestAddress ? `• Alamat: *${booking.guestAddress}*\n` : '') + `\n`
    : `*Kepada:* ${booking.guestName} (${booking.guestPhone || 'Penyewa'})\n\n`;

  const tenantParticularsEN = (booking.guestNric || booking.guestEmail || booking.guestAddress)
    ? `👤 *TENANT PARTICULARS:*\n• Name: *${booking.guestName}*\n` +
      (booking.guestNric ? `• NRIC / Passport: *${booking.guestNric}*\n` : '') +
      (booking.guestPhone ? `• Phone / WA: *${booking.guestPhone}*\n` : '') +
      (booking.guestEmail ? `• Email: *${booking.guestEmail}*\n` : '') +
      (booking.guestAddress ? `• Address: *${booking.guestAddress}*\n` : '') + `\n`
    : `*Bill To:* ${booking.guestName} (${booking.guestPhone || 'Tenant'})\n\n`;

  const bankInfoEN = (settings.bankName && settings.bankAccNum) 
    ? `\n🏦 *BANK PAYMENT DETAILS:*\n• Bank: *${settings.bankName}*\n• Account No: *${settings.bankAccNum}*\n• Name: *${settings.bankAccHolder || settings.businessName}*${settings.duitNow ? `\n• DuitNow ID: *${settings.duitNow}*` : ''}\n` 
    : '';

  const bankInfoBM = (settings.bankName && settings.bankAccNum) 
    ? `\n🏦 *MAKLUMAT PEMBAYARAN BANK / DUITNOW:*\n• Bank: *${settings.bankName}*\n• No Akaun: *${settings.bankAccNum}*\n• Nama Pemegang: *${settings.bankAccHolder || settings.businessName}*${settings.duitNow ? `\n• DuitNow ID: *${settings.duitNow}*` : ''}\n` 
    : '';

  // Daily calculations
  const totalRental = ((booking.nights || 1) * (booking.nightlyRate || 0)) + (booking.cleaningFee || 0);
  const secDep = booking.securityDeposit || 0;
  const dep30 = Math.round(totalRental * (settings.defaultDepositPct || 30) / 100 * 100) / 100;
  const bookingFee = booking.depositPaid > 0 ? booking.depositPaid : dep30;

  // Monthly calculations
  const mRate = booking.monthlyRate || 0;
  const rDep = booking.rentalDeposit || 0;
  const uDep = booking.utilitiesDeposit || 0;
  const aFee = booking.agreementFee || 0;
  const totalMoveIn = mRate + rDep + uDep + aFee;

  // Dynamic multi-month period calculation
  const mIndex = appState.activeWaMonthIndex || 1;
  const rawDateStr = booking.checkIn || booking.monthlyStart || new Date().toISOString().split('T')[0];
  const parsedStart = new Date(rawDateStr.includes('T') ? rawDateStr : rawDateStr + 'T00:00:00');
  const startD = isNaN(parsedStart.getTime()) ? new Date() : parsedStart;
  const curMonthStart = new Date(startD);
  curMonthStart.setMonth(curMonthStart.getMonth() + (mIndex - 1));
  const curMonthEnd = new Date(curMonthStart);
  curMonthEnd.setMonth(curMonthEnd.getMonth() + 1);
  curMonthEnd.setDate(curMonthEnd.getDate() - 1);

  const startStr = curMonthStart.toISOString().split('T')[0];
  const endStr = curMonthEnd.toISOString().split('T')[0];

  const dueDate = new Date(curMonthStart);
  dueDate.setDate(dueDate.getDate() + 6);
  const dueStr = dueDate.toISOString().split('T')[0];

  const extraUtility = parseFloat(document.getElementById('waInvoiceExtraInput')?.value) || 0;
  const rentAmt = booking.monthlyRate || 0;
  const totalMonthDue = rentAmt + extraUtility;
  const invNo = `INV-M${mIndex}-${booking.id.slice(-5).toUpperCase()}`;
  const recNo = `REC-RENT-M${mIndex}-${booking.id.slice(-5).toUpperCase()}`;

  // Quotation Validity Calculation
  const validityDays = parseInt(booking.quotationValidityDays) || parseInt(settings.quotationValidityDays) || 3;
  const expDateObj = new Date();
  expDateObj.setDate(expDateObj.getDate() + validityDays);
  const expDateStr = expDateObj.toISOString().split('T')[0];

  let msg = '';

  if (isBM) {
    switch (templateType) {
      case 'quotation':
        if (isMonthly) {
          msg = `📋 *SEBUT HARGA SEWAAN BULANAN - ${prop.name.toUpperCase()}*\n` +
            `No Rujukan: QUO-M-${booking.id.slice(-6).toUpperCase()}\n\n` +
            `Salam sejahtera *${booking.guestName}*, terima kasih atas pertanyaan sewaan bulanan anda! Berikut adalah perincian pakej sewaan:\n\n` +
            `${unitTitleBM}\n` +
            `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
            (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
            `📅 *Tarikh Mula:* ${booking.checkIn}\n` +
            `⏳ *Tempoh Sewaan:* ${booking.monthlyDuration || 6} Bulan\n` +
            `⏳ *Tempoh Sah Sebut Harga:* *${validityDays} Hari* (Sah sehingga: *${expDateStr}*)\n\n` +
            tenantParticularsBM +
            `💰 *PERINCIAN PAKEJ KEMASUKAN (MOVE-IN):*\n` +
            `• Sewa Bulan Pertama (Pendahuluan): ${currency} ${mRate.toFixed(2)}\n` +
            `• Deposit Keselamatan Sewaan (1 Bulan Sewa): ${currency} ${rDep.toFixed(2)}\n` +
            `• Deposit Utiliti / Air & Elektrik (Dipulangkan): ${currency} ${uDep.toFixed(2)}\n` +
            (aFee > 0 ? `• Yuran Perjanjian Sewa & Duti Setem: ${currency} ${aFee.toFixed(2)}\n` : '') +
            `----------------------------------------\n` +
            `💵 *JUMLAH BAYARAN KEMASUKAN:* *${currency} ${totalMoveIn.toFixed(2)}*\n` +
            `🔒 *Bayaran Booking Diperlukan untuk Kunci Unit:* *${currency} ${(booking.depositPaid > 0 ? booking.depositPaid : Math.round(mRate * 0.5)).toFixed(2)}*\n` +
            `⏳ *Baki Bayaran Sebelum Serahan Kunci:* ${currency} ${(totalMoveIn - (booking.depositPaid > 0 ? booking.depositPaid : Math.round(mRate * 0.5))).toFixed(2)}\n` +
            bankInfoBM +
            `\n📌 *SYARAT & POLISI SEWAAN BULANAN:*\n` +
            `1. Bayaran sewa bulanan dikutip secara pendahuluan (advance) pada awal setiap bulan sewaan melalui Invois Rasmi.\n` +
            `2. Bagi sewaan jangka panjang melebihi 1 bulan, bil utiliti (elektrik & air) adalah mengikut kadar penggunaan bulanan sebenar (dibayar terus oleh penyewa atau dimasukkan ke dalam invois sewa bulanan).\n` +
            `3. Deposit Keselamatan (1 bulan sewa: RM ${rDep.toFixed(2)}) dan Deposit Utiliti (RM ${uDep.toFixed(2)}) akan dipulangkan sepenuhnya pada akhir tempoh sewaan tertakluk kepada penyelesaian bil utiliti dan pemeriksaan unit.\n` +
            `4. Sebut harga ini sah selama *${validityDays} hari* sehingga *${expDateStr}*. ✨🏡`;
        } else {
          msg = `📋 *SEBUT HARGA RASMI - ${prop.name.toUpperCase()}*\n` +
            `No Rujukan: QUO-${booking.id.slice(-6).toUpperCase()}\n\n` +
            `Salam sejahtera *${booking.guestName}*, terima kasih atas pertanyaan anda! Berikut adalah perincian harga bagi penginapan anda:\n\n` +
            `${unitTitleBM}\n` +
            `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
            (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
            `📅 *Daftar Masuk (Check-In):* ${booking.checkIn} (${prop.checkInTime || '3:00 PM'})\n` +
            `🏁 *Daftar Keluar (Check-Out):* ${booking.checkOut} (${prop.checkOutTime || '12:00 PM'})\n` +
            `🌙 *Tempoh:* ${booking.nights} Malam • ${booking.guestCount} Tetamu\n` +
            `⏳ *Tempoh Sah Sebut Harga:* *${validityDays} Hari* (Sah sehingga: *${expDateStr}*)\n\n` +
            `💰 *PERINCIAN HARGA:*\n` +
            `• Kadar Sewa: ${currency} ${(booking.nightlyRate || 0).toFixed(2)} × ${booking.nights} malam = ${currency} ${(booking.nights * booking.nightlyRate).toFixed(2)}\n` +
            `• Yuran Pembersihan: ${currency} ${(booking.cleaningFee || 0).toFixed(2)}\n` +
            (secDep > 0 ? `• Deposit Keselamatan (Dipulangkan): ${currency} ${secDep.toFixed(2)}\n` : '') +
            `----------------------------------------\n` +
            `💵 *JUMLAH KESELURUHAN:* *${currency} ${booking.totalAmount.toFixed(2)}*\n` +
            `🔒 *Bayaran Booking Diperlukan (${settings.defaultDepositPct || 30}%):* *${currency} ${bookingFee.toFixed(2)}*\n` +
            `⏳ *Baki Bayaran Sebelum Serahan Kunci:* ${currency} ${(booking.totalAmount - bookingFee).toFixed(2)}\n` +
            bankInfoBM +
            `\n📌 *Nota:* Tarikh akan ditanda sebagai *"DITEMPAH"* selepas slip bayaran booking diterima. Sebut harga ini sah selama *${validityDays} hari* sehingga *${expDateStr}*. ✨🏡`;
        }
        break;

      case 'deposit_receipt':
        if (isMonthly) {
          msg = `🧾 *RESIT BAYARAN BOOKING & DEPOSIT SEWAAN - ${prop.name.toUpperCase()}*\n` +
            `No Resit: REC-BOOK-M-${booking.id.slice(-6).toUpperCase()}\n\n` +
            `Salam *${booking.guestName}*, bayaran booking sewaan bulanan anda telah disahkan! 🎉\n` +
            `Unit kini berstatus *DITEMPAH & DIKUNCI* untuk kemasukan anda.\n\n` +
            `${unitTitleBM}\n` +
            `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
            (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
            `📅 *Tarikh Kemasukan:* ${booking.checkIn}\n` +
            `⏳ *Tempoh Sewaan:* ${booking.monthlyDuration || 6} Bulan\n\n` +
            tenantParticularsBM +
            `💰 *REKOD BAYARAN:*\n` +
            `• Jumlah Pakej Kemasukan: ${currency} ${totalMoveIn.toFixed(2)}\n` +
            `• ✅ *Bayaran Booking Diterima:* *${currency} ${booking.depositPaid.toFixed(2)}*\n` +
            (booking.lastPaymentRef ? `• 🔖 *No. Rujukan Bank:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Pindahan Bank'})\n` : '') +
            `----------------------------------------\n` +
            `💳 *Baki Perlu Dibayar Sebelum Serahan Kunci:* *${currency} ${booking.balance.toFixed(2)}*\n\n` +
            `🔑 *Kunci & Smart Lock PIN:* Akan diserahkan selepas baki pakej kemasukan dijelaskan sepenuhnya. Terima kasih! 🙏`;
        } else {
          msg = `🧾 *RESIT BAYARAN BOOKING & DEPOSIT - ${prop.name.toUpperCase()}*\n` +
            `No Resit: REC-DEP-${booking.id.slice(-6).toUpperCase()}\n\n` +
            `Salam *${booking.guestName}*, bayaran booking dan deposit anda telah diterima! 🎉\n` +
            `Unit anda kini secara rasmi berstatus *DITEMPAH & DIKUNCI* di kalendar kami.\n\n` +
            `${unitTitleBM}\n` +
            `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
            (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
            `📅 *Daftar Masuk:* ${booking.checkIn} (${prop.checkInTime || '3:00 PM'})\n` +
            `🏁 *Daftar Keluar:* ${booking.checkOut} (${prop.checkOutTime || '12:00 PM'})\n\n` +
            `💰 *REKOD BAYARAN:*\n` +
            `• Jumlah Penginapan: ${currency} ${booking.totalAmount.toFixed(2)}\n` +
            `• ✅ *Deposit / Booking Diterima:* *${currency} ${booking.depositPaid.toFixed(2)}*\n` +
            (booking.lastPaymentRef ? `• 🔖 *No. Rujukan Bank:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Pindahan Bank'})\n` : '') +
            `----------------------------------------\n` +
            `💳 *Baki Bayaran Sebelum Daftar Masuk:* *${currency} ${booking.balance.toFixed(2)}*\n\n` +
            `🔑 *Kod PIN Kunci Pintu:* Akan diberikan selepas pengesahan bayaran penuh sebelum waktu daftar masuk. Terima kasih! 🏡✨`;
        }
        break;

      case 'checkin_reminder':
        msg = `📅 *PERINGATAN DAFTAR MASUK (CHECK-IN) - ${prop.name.toUpperCase()}*\n\n` +
          `Salam mesra *${booking.guestName}*, kami menantikan kehadiran anda tidak lama lagi! Berikut adalah maklumat penting bagi persediaan daftar masuk anda:\n\n` +
          `${unitTitleBM}\n` +
          `📅 *Tarikh Daftar Masuk:* ${booking.checkIn}\n` +
          `⏰ *Waktu Masuk:* Mulai jam *${prop.checkInTime || '3:00 PM'}* ke atas\n` +
          `🏁 *Tarikh Daftar Keluar:* ${booking.checkOut} (sebelum ${prop.checkOutTime || '12:00 PM'})\n\n` +
          `📍 *Alamat Homestay:* ${prop.address || 'Alamat Unit'}\n` +
          (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `\n🔑 *MAKLUMAT AKSES & KUNCI:*\n` +
          (booking.status === 'confirmed' || booking.balance <= 0 
            ? `• Kod PIN Smart Lock Pintu: *${prop.doorCode || '123456#'}*\n• Nama WiFi: *${prop.wifiName || 'Homestay_WiFi'}*\n• Kata Laluan WiFi: *${prop.wifiPass || 'welcome123'}*\n` 
            : `• Kod PIN pintu & kata laluan WiFi akan diserahkan serta-merta selepas baki bayaran dijelaskan.\n`) +
          (booking.balance > 0 
            ? `\n💳 *Peringatan Baki Bayaran:* *${currency} ${booking.balance.toFixed(2)}* (Sila jelaskan sebelum waktu masuk).\n` + bankInfoBM 
            : `\n✅ *Status Bayaran:* Selesai Dibayar Penuh (${currency} ${booking.totalAmount.toFixed(2)})\n`) +
          `\n📜 *Peraturan Homestay:* ${prop.rules || 'Dilarang merokok di dalam unit, jaga ketenteraman selepas 10 malam.'}\n\n` +
          `Jika anda memerlukan sebarang bantuan atau panduan arah, sila balas mesej ini pada bila-bila masa. Selamat bertolak dan semoga perjalanan anda lancar & selamat! ✨🏡`;
        break;

      case 'full_receipt':
        msg = `🔑 *RESIT BAYARAN PENUH & PANDUAN MASUK - ${prop.name.toUpperCase()}*\n` +
          `No Resit: REC-FULL-${booking.id.slice(-6).toUpperCase()}\n\n` +
          `Salam *${booking.guestName}*! Bayaran penuh telah disahkan dan tempahan anda kini *100% DISAHKAN*. Berikut adalah maklumat akses masuk anda:\n\n` +
          `${unitTitleBM}\n` +
          `💰 *STATUS BAYARAN: SELESAI DIBAYAR PENUH (100%) ✅*\n` +
          `• Jumlah Dibayar: ${currency} ${booking.totalAmount.toFixed(2)}\n` +
          (booking.lastPaymentRef ? `• 🔖 *No. Rujukan Bank:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Pindahan Bank'})\n` : '') +
          `• Baki Bayaran: ${currency} 0.00\n\n` +
          `========================================\n` +
          `🔑 *MAKLUMAT AKSES & KUNCI PINTU PINTAR:*\n` +
          `========================================\n` +
          `📍 *Alamat:* ${prop.address || 'Alamat Unit'}\n` +
          (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `⏰ *Waktu Daftar Masuk:* Hari ini dari jam ${prop.checkInTime || '3:00 PM'} ke atas\n` +
          `🔐 *Kod PIN Smart Lock Pintu:* *${prop.doorCode || '123456#'}*\n` +
          `📶 *Nama WiFi:* ${prop.wifiName || 'Homestay_WiFi'}\n` +
          `🔑 *Kata Laluan WiFi:* *${prop.wifiPass || 'welcome123'}*\n\n` +
          `📜 *Peraturan:* ${prop.rules || 'Dilarang merokok di dalam rumah, jaga ketenteraman selepas 10 malam.'}\n\n` +
          `Selamat menikmati penginapan anda! Sila hubungi kami bila-bila masa jika memerlukan bantuan. ✨🏡`;
        break;

      case 'monthly_invoice':
        msg = `📑 *INVOIS SEWAAN BULANAN (BULAN KE-${mIndex} DRPD ${booking.monthlyDuration || 6})*\n` +
          `No. Invois: *${invNo}*\n` +
          `Tarikh Invois: *${todayStr}*\n` +
          `Tarikh Akhir Bayaran: *${dueStr}*\n\n` +
          tenantParticularsBM +
          `${unitTitleBM}\n` +
          `📍 *Lokasi:* ${prop.address || 'Alamat Unit'}\n` +
          (prop.gpsLocation ? `🗺️ *Lokasi GPS / Google Maps:* ${prop.gpsLocation}\n` : '') + `\n` +
          `📅 *TEMPOH BIL SEWAAN:*\n` +
          `• Dari: *${startStr}* Hingga: *${endStr}* (Bulan ke-${mIndex})\n\n` +
          `💵 *PERINCIAN BAYARAN:*\n` +
          `• Sewa Bulanan: *${currency} ${rentAmt.toFixed(2)}*\n` +
          (extraUtility > 0 ? `• Caj Utiliti / Tambahan: *${currency} ${extraUtility.toFixed(2)}*\n` : '') +
          `----------------------------------------\n` +
          `💳 *JUMLAH PERLU DIBAYAR:* *${currency} ${totalMonthDue.toFixed(2)}*\n` +
          bankInfoBM +
          `\n📌 *Nota:* Sila jelaskan bayaran sebelum *${dueStr}* dan hantar salinan resit transaksi ke WhatsApp ini. Terima kasih atas kerjasama anda! 🙏✨`;
        break;

      case 'monthly_rent_receipt':
        msg = `🧾 *RESIT RASMI BAYARAN SEWA (BULAN KE-${mIndex})*\n` +
          `No. Resit: *${recNo}*\n` +
          `Tarikh: *${todayStr}*\n\n` +
          `Salam *${booking.guestName}*, bayaran sewa bulanan anda bagi *Bulan ke-${mIndex}* telah diterima dan disahkan! 🎉\n\n` +
          tenantParticularsBM +
          `${unitTitleBM}\n` +
          `📅 *Tempoh Sewaan:* ${startStr} hingga ${endStr} (Bulan ke-${mIndex})\n` +
          `💰 *Jumlah Diterima:* *${currency} ${totalMonthDue.toFixed(2)}*\n` +
          (booking.lastPaymentRef ? `• 🔖 *No. Rujukan Bank:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Pindahan Bank'})\n` : '') +
          `✅ *Status Bayaran:* SELESAI DIBAYAR (PAID)\n\n` +
          `Terima kasih atas pembayaran anda yang tepat pada masanya! 🙏✨`;
        break;

      case 'refund_receipt':
        const ref = booking.refundDetails || {
          rentalDep: booking.rentalDeposit || 0,
          utilDep: booking.utilitiesDeposit || booking.securityDeposit || 0,
          dedUtil: 0,
          dedRepair: 0,
          netRefund: (booking.rentalDeposit || 0) + (booking.utilitiesDeposit || booking.securityDeposit || 0),
          notes: 'Deposit dipulangkan sepenuhnya.'
        };
        msg = `💰 *PENYATA PEMULANGAN DEPOSIT SEWAAN - ${prop.name.toUpperCase()}*\n` +
          `No Rujukan: REF-${booking.id.slice(-6).toUpperCase()}\n\n` +
          tenantParticularsBM +
          `${unitTitleBM}\n` +
          `📅 *Tarikh Tamat Sewaan:* ${booking.checkOut}\n\n` +
          `📊 *RINGKASAN DEPOSIT:*\n` +
          `• Deposit Sewa Dipegang: ${currency} ${ref.rentalDep.toFixed(2)}\n` +
          `• Deposit Utiliti Dipegang: ${currency} ${ref.utilDep.toFixed(2)}\n` +
          `----------------------------------------\n` +
          `➕ *Jumlah Deposit Dipegang:* ${currency} ${(ref.rentalDep + ref.utilDep).toFixed(2)}\n\n` +
          `📉 *TOLAKAN / DEDUCTIONS:*\n` +
          `• Tunggakan Bil Utiliti (TNB/Air): - ${currency} ${ref.dedUtil.toFixed(2)}\n` +
          `• Kos Pembaikan / Pembersihan: - ${currency} ${ref.dedRepair.toFixed(2)}\n` +
          `----------------------------------------\n` +
          `💵 *JUMLAH BERSIH DIPULANGKAN:* *${currency} ${ref.netRefund.toFixed(2)}* ✅\n\n` +
          `📝 *Catatan Tolakan:* ${ref.notes || 'Tiada'}\n\n` +
          `Terima kasih kerana menyewa bersama kami dan menjaga unit dengan baik! Semoga maju jaya. 🙏✨`;
        break;

      case 'checkout':
        msg = `🏁 *Peringatan Daftar Keluar / Tamat Sewaan - ${prop.name}*\n\n` +
          `Salam *${booking.guestName}*, semoga anda menikmati penginapan yang menyenangkan bersama kami!\n\n` +
          `⏰ *Waktu Daftar Keluar:* Hari ini sebelum jam ${prop.checkOutTime || '12:00 PM'}\n\n` +
          `Sebelum bertolak, mohon kerjasama untuk:\n` +
          `1. Padamkan semua suis lampu dan penyaman udara (air-cond)\n` +
          `2. Pastikan semua pintu dan tingkap dikunci rapi\n` +
          `3. Serahkan kembali kunci atau masukkan ke dalam peti kunci pintar\n\n` +
          `Pemeriksaan unit dan pemulangan baki deposit keselamatan akan diproses selepas pemeriksaan selesai. Terima kasih! ⭐⭐⭐⭐⭐`;
        break;

      case 'cleaner':
        msg = `🧹 *Notis Pembersihan / Turnover - ${prop.name}*\n\n` +
          `Kerja pembersihan diperlukan untuk ${prop.name} pada ${booking.checkOut}.\n` +
          `Tetamu ${booking.guestName} daftar keluar jam ${prop.checkOutTime || '12:00 PM'}.\n` +
          (prop.address ? `Alamat: ${prop.address}\n` : '') +
          (prop.gpsLocation ? `Lokasi GPS: ${prop.gpsLocation}\n` : '') +
          `Kod PIN Smart Lock untuk diset: ${prop.doorCode || '1234'}.`;
        break;

      case 'payment':
        msg = `💳 *Peringatan Baki Bayaran - ${prop.name}*\n\n` +
          `Salam *${booking.guestName}*, ini adalah peringatan mesra bagi baki bayaran penginapan anda:\n\n` +
          `📅 *Tarikh:* ${booking.checkIn} hingga ${booking.checkOut}\n` +
          `💰 *Baki Bayaran:* *${currency} ${booking.balance.toFixed(2)}*\n` +
          bankInfoBM +
          `\nSila jelaskan baki sebelum daftar masuk untuk menerima kod akses masuk. Terima kasih! 🙏`;
        break;

      default:
        msg = '';
        break;
    }
    return msg;
  }

  // English Templates
  switch (templateType) {
    case 'quotation':
      if (isMonthly) {
        msg = `📋 *MONTHLY TENANCY QUOTATION - ${prop.name.toUpperCase()}*\n` +
          `Ref: QUO-M-${booking.id.slice(-6).toUpperCase()}\n\n` +
          `Hi *${booking.guestName}*, thank you for your monthly rental enquiry! Here is the tenancy move-in package breakdown:\n\n` +
          `${unitTitleEN}\n` +
          `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
          (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `📅 *Tenancy Start Date:* ${booking.checkIn}\n` +
          `⏳ *Duration:* ${booking.monthlyDuration || 6} Months\n` +
          `⏳ *Quotation Validity:* *${validityDays} Day(s)* (Valid until: *${expDateStr}*)\n\n` +
          tenantParticularsEN +
          `💰 *MOVE-IN INITIAL PACKAGE BREAKDOWN:*\n` +
          `• 1st Month Advance Rent: ${currency} ${mRate.toFixed(2)}\n` +
          `• Rental Security Deposit (1 Month Rent): ${currency} ${rDep.toFixed(2)}\n` +
          `• Utilities Deposit (Water & Electricity): ${currency} ${uDep.toFixed(2)}\n` +
          (aFee > 0 ? `• Tenancy Agreement & Stamp Duty: ${currency} ${aFee.toFixed(2)}\n` : '') +
          `----------------------------------------\n` +
          `💵 *TOTAL MOVE-IN PACKAGE:* *${currency} ${totalMoveIn.toFixed(2)}*\n` +
          `🔒 *Booking Fee Required to Reserve Unit:* *${currency} ${(booking.depositPaid > 0 ? booking.depositPaid : Math.round(mRate * 0.5)).toFixed(2)}*\n` +
          `⏳ *Balance Due upon Key Handover:* ${currency} ${(totalMoveIn - (booking.depositPaid > 0 ? booking.depositPaid : Math.round(mRate * 0.5))).toFixed(2)}\n` +
          bankInfoEN +
          `\n📌 *MONTHLY TENANCY TERMS & POLICIES:*\n` +
          `1. Monthly rental is collected in advance at the beginning of each rental month via official invoice.\n` +
          `2. For long-term rentals exceeding 1 month, utilities (electricity & water) are charged based on actual monthly usage (paid directly by tenant or added into monthly rental invoice).\n` +
          `3. Rental Deposit (1 month rent: ${currency} ${rDep.toFixed(2)}) and Utilities Deposit (${currency} ${uDep.toFixed(2)}) are fully refundable at the end of tenancy subject to utility clearance and unit inspection.\n` +
          `4. Quotation is valid for *${validityDays} day(s)* until *${expDateStr}*. ✨🏡`;
      } else {
        msg = `📋 *OFFICIAL QUOTATION - ${prop.name.toUpperCase()}*\n` +
          `Ref: QUO-${booking.id.slice(-6).toUpperCase()}\n\n` +
          `Hi *${booking.guestName}*, thank you for your enquiry! Here is the price breakdown for your stay:\n\n` +
          `${unitTitleEN}\n` +
          `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
          (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `📅 *Check-In:* ${booking.checkIn} (${prop.checkInTime || '3:00 PM'})\n` +
          `🏁 *Check-Out:* ${booking.checkOut} (${prop.checkOutTime || '12:00 PM'})\n` +
          `🌙 *Stay Duration:* ${booking.nights} Night(s) • ${booking.guestCount} Guest(s)\n` +
          `⏳ *Quotation Validity:* *${validityDays} Day(s)* (Valid until: *${expDateStr}*)\n\n` +
          `💰 *PRICE BREAKDOWN:*\n` +
          `• Nightly Rate: ${currency} ${(booking.nightlyRate || 0).toFixed(2)} × ${booking.nights} nights = ${currency} ${(booking.nights * booking.nightlyRate).toFixed(2)}\n` +
          `• Cleaning Fee: ${currency} ${(booking.cleaningFee || 0).toFixed(2)}\n` +
          (secDep > 0 ? `• Security Deposit (Refundable): ${currency} ${secDep.toFixed(2)}\n` : '') +
          `----------------------------------------\n` +
          `💵 *TOTAL STAY PRICE:* *${currency} ${booking.totalAmount.toFixed(2)}*\n` +
          `🔒 *Booking Fee Required to Lock Dates (${settings.defaultDepositPct || 30}%):* *${currency} ${bookingFee.toFixed(2)}*\n` +
          `⏳ *Balance Due upon Key Handover:* ${currency} ${(booking.totalAmount - bookingFee).toFixed(2)}\n` +
          bankInfoEN +
          `\n📌 *Next Step:* Unit will be reserved and labelled *"BOOKED"* immediately upon booking fee receipt. Quotation valid for *${validityDays} day(s)* until *${expDateStr}*. Let us know to secure your dates! ✨🏡`;
      }
      break;

    case 'deposit_receipt':
      if (isMonthly) {
        msg = `🧾 *TENANCY BOOKING & DEPOSIT RECEIPT - ${prop.name.toUpperCase()}*\n` +
          `Receipt No: REC-BOOK-M-${booking.id.slice(-6).toUpperCase()}\n\n` +
          `Hi *${booking.guestName}*, your tenancy booking fee has been received! 🎉\n` +
          `The property is now officially *BOOKED & RESERVED* for your move-in.\n\n` +
          `${unitTitleEN}\n` +
          `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
          (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `📅 *Move-In Date:* ${booking.checkIn}\n` +
          `⏳ *Tenancy Period:* ${booking.monthlyDuration || 6} Months\n\n` +
          tenantParticularsEN +
          `💰 *PAYMENT RECORD:*\n` +
          `• Total Move-In Package: ${currency} ${totalMoveIn.toFixed(2)}\n` +
          `• ✅ *Booking Fee Received:* *${currency} ${booking.depositPaid.toFixed(2)}*\n` +
          (booking.lastPaymentRef ? `• 🔖 *Bank Reference No:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Bank Transfer'})\n` : '') +
          `----------------------------------------\n` +
          `💳 *Remaining Balance Due Before Keys Handover:* *${currency} ${booking.balance.toFixed(2)}*\n\n` +
          `🔑 *Keys & Smart Lock PIN:* Will be released upon full settlement of the remaining move-in balance. Thank you! 🙏`;
      } else {
        msg = `🧾 *BOOKING & DEPOSIT PAYMENT RECEIPT - ${prop.name.toUpperCase()}*\n` +
          `Receipt No: REC-DEP-${booking.id.slice(-6).toUpperCase()}\n\n` +
          `Hi *${booking.guestName}*, we have received your booking fee & deposit! 🎉\n` +
          `Your unit is now officially *BOOKED & RESERVED* on our calendar.\n\n` +
          `${unitTitleEN}\n` +
          `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
          (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
          `📅 *Check-In:* ${booking.checkIn} (${prop.checkInTime || '3:00 PM'})\n` +
          `🏁 *Check-Out:* ${booking.checkOut} (${prop.checkOutTime || '12:00 PM'})\n\n` +
          `💰 *PAYMENT RECORD:*\n` +
          `• Total Stay Amount: ${currency} ${booking.totalAmount.toFixed(2)}\n` +
          `• ✅ *Deposit / Booking Received:* *${currency} ${booking.depositPaid.toFixed(2)}*\n` +
          (booking.lastPaymentRef ? `• 🔖 *Bank Reference No:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Bank Transfer'})\n` : '') +
          `----------------------------------------\n` +
          `💳 *Remaining Balance to Pay Before Check-In:* *${currency} ${booking.balance.toFixed(2)}*\n\n` +
          `🔑 *Smart Lock Access Code:* Will be released upon full payment confirmation before check-in. Thank you! 🏡✨`;
      }
      break;

    case 'checkin_reminder':
      msg = `📅 *CHECK-IN REMINDER & ARRIVAL GUIDE - ${prop.name.toUpperCase()}*\n\n` +
        `Hi *${booking.guestName}*, we look forward to welcoming you soon! Here are the essential details for your upcoming stay:\n\n` +
        `${unitTitleEN}\n` +
        `📅 *Check-In Date:* ${booking.checkIn}\n` +
        `⏰ *Check-In Time:* From *${prop.checkInTime || '3:00 PM'}* onwards\n` +
        `🏁 *Check-Out Date:* ${booking.checkOut} (by ${prop.checkOutTime || '12:00 PM'})\n\n` +
        `📍 *Address:* ${prop.address || 'Standard Address'}\n` +
        (prop.gpsLocation ? `🗺️ *GPS / Google Maps Link:* ${prop.gpsLocation}\n` : '') +
        `\n🔑 *SELF CHECK-IN & ACCESS:*\n` +
        (booking.status === 'confirmed' || booking.balance <= 0
          ? `• Door Smart Lock PIN: *${prop.doorCode || '123456#'}*\n• WiFi Network: *${prop.wifiName || 'Homestay_WiFi'}*\n• WiFi Password: *${prop.wifiPass || 'welcome123'}*\n`
          : `• Door access PIN and WiFi credentials will be released immediately upon balance settlement before check-in.\n`) +
        (booking.balance > 0
          ? `\n💳 *Remaining Balance Due:* *${currency} ${booking.balance.toFixed(2)}* (Kindly settle before arrival).\n` + bankInfoEN
          : `\n✅ *Payment Status:* Paid in Full (${currency} ${booking.totalAmount.toFixed(2)})\n`) +
        `\n📜 *House Rules:* ${prop.rules || 'No smoking indoors, quiet hours after 10 PM.'}\n\n` +
        `If you need any assistance or driving directions, feel free to message us here anytime. Safe travels and see you soon! ✨🏡`;
      break;

    case 'full_receipt':
      msg = `🔑 *FULL PAYMENT RECEIPT & ACCESS GUIDE - ${prop.name.toUpperCase()}*\n` +
        `Receipt No: REC-FULL-${booking.id.slice(-6).toUpperCase()}\n\n` +
        `Hi *${booking.guestName}*! Full payment has been received and your booking is *100% CONFIRMED*. Here are your self check-in access keys:\n\n` +
        `${unitTitleEN}\n` +
        `💰 *PAYMENT STATUS: PAID IN FULL (100%) ✅*\n` +
        `• Total Paid: ${currency} ${booking.totalAmount.toFixed(2)}\n` +
        (booking.lastPaymentRef ? `• 🔖 *Bank Reference No:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Bank Transfer'})\n` : '') +
        `• Balance Due: ${currency} 0.00\n\n` +
        `========================================\n` +
        `🔑 *YOUR ACCESS & DOOR LOCK DETAILS:*\n` +
        `========================================\n` +
        `📍 *Address:* ${prop.address || 'Standard Address'}\n` +
        (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
        `⏰ *Check-In Time:* Today from ${prop.checkInTime || '3:00 PM'} onwards\n` +
        `🔐 *Door Smart Lock PIN:* *${prop.doorCode || '123456#'}*\n` +
        `📶 *WiFi Name:* ${prop.wifiName || 'Homestay_WiFi'}\n` +
        `🔑 *WiFi Password:* *${prop.wifiPass || 'welcome123'}*\n\n` +
        `📜 *House Rules:* ${prop.rules || 'No smoking inside, quiet hours after 10 PM.'}\n\n` +
        `Have a wonderful stay with us! If you need anything, message us anytime. ✨🏡`;
      break;

    case 'monthly_invoice':
      msg = `📑 *MONTHLY RENTAL INVOICE (MONTH ${mIndex} OF ${booking.monthlyDuration || 6})*\n` +
        `Invoice No: *${invNo}*\n` +
        `Invoice Date: *${todayStr}*\n` +
        `Payment Due Date: *${dueStr}*\n\n` +
        tenantParticularsEN +
        `${unitTitleEN}\n` +
        `📍 *Location:* ${prop.address || 'Standard Address'}\n` +
        (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') + `\n` +
        `📅 *BILLING PERIOD:*\n` +
        `• Period: *${startStr} to ${endStr}* (Month ${mIndex})\n\n` +
        `💵 *PAYMENT BREAKDOWN:*\n` +
        `• Monthly Rental: *${currency} ${rentAmt.toFixed(2)}*\n` +
        (extraUtility > 0 ? `• Utilities / Extra Surcharge: *${currency} ${extraUtility.toFixed(2)}*\n` : '') +
        `----------------------------------------\n` +
        `💳 *TOTAL AMOUNT DUE:* *${currency} ${totalMonthDue.toFixed(2)}*\n` +
        bankInfoEN +
        `\n📌 *Note:* Please settle payment on or before *${dueStr}* and forward the transfer receipt. Thank you for your cooperation! 🙏✨`;
      break;

    case 'monthly_rent_receipt':
      msg = `🧾 *OFFICIAL RENT PAYMENT RECEIPT (MONTH ${mIndex})*\n` +
        `Receipt No: *${recNo}*\n` +
        `Date: *${todayStr}*\n\n` +
        `Dear *${booking.guestName}*, your monthly rent payment for *Month ${mIndex}* has been received and verified! 🎉\n\n` +
        tenantParticularsEN +
        `${unitTitleEN}\n` +
        `📅 *Rental Period:* ${startStr} to ${endStr} (Month ${mIndex})\n` +
        `💰 *Amount Received:* *${currency} ${totalMonthDue.toFixed(2)}*\n` +
        (booking.lastPaymentRef ? `• 🔖 *Bank Reference No:* \`${booking.lastPaymentRef}\` (${booking.lastPaymentBank || 'Bank Transfer'})\n` : '') +
        `✅ *Status:* PAID IN FULL\n\n` +
        `Thank you for your prompt payment! 🙏✨`;
      break;

    case 'refund_receipt':
      const refEN = booking.refundDetails || {
        rentalDep: booking.rentalDeposit || 0,
        utilDep: booking.utilitiesDeposit || booking.securityDeposit || 0,
        dedUtil: 0,
        dedRepair: 0,
        netRefund: (booking.rentalDeposit || 0) + (booking.utilitiesDeposit || booking.securityDeposit || 0),
        notes: 'Full deposit refunded.'
      };
      msg = `💰 *TENANCY DEPOSIT REFUND STATEMENT - ${prop.name.toUpperCase()}*\n` +
        `Ref: REF-${booking.id.slice(-6).toUpperCase()}\n\n` +
        tenantParticularsEN +
        `${unitTitleEN}\n` +
        `📅 *Tenancy End Date:* ${booking.checkOut}\n\n` +
        `📊 *DEPOSITS HELD:*\n` +
        `• Rental Deposit Held: ${currency} ${refEN.rentalDep.toFixed(2)}\n` +
        `• Utilities Deposit Held: ${currency} ${refEN.utilDep.toFixed(2)}\n` +
        `----------------------------------------\n` +
        `➕ *Total Deposits Held:* ${currency} ${(refEN.rentalDep + refEN.utilDep).toFixed(2)}\n\n` +
        `📉 *DEDUCTIONS:*\n` +
        `• Utility Arrears (TNB/Water): - ${currency} ${refEN.dedUtil.toFixed(2)}\n` +
        `• Repairs / Cleaning Costs: - ${currency} ${refEN.dedRepair.toFixed(2)}\n` +
        `----------------------------------------\n` +
        `💵 *NET REFUND TO TENANT:* *${currency} ${refEN.netRefund.toFixed(2)}* ✅\n\n` +
        `📝 *Deduction Notes:* ${refEN.notes || 'None'}\n\n` +
        `Thank you for staying with us and taking care of the property! Wishing you all the best. 🙏✨`;
      break;

    case 'checkout':
      msg = `🏁 *Check-Out / Tenancy End Reminder - ${prop.name}*\n\n` +
        `Hi *${booking.guestName}*, we hope you had a fantastic stay with us!\n\n` +
        `⏰ *Check-Out Time:* Today by ${prop.checkOutTime || '12:00 PM'}\n\n` +
        `Before you depart, kindly:\n` +
        `1. Turn off all lights and air-conditioners\n` +
        `2. Ensure doors/windows are safely locked\n` +
        `3. Return keys or lock in the smart lockbox\n\n` +
        `Deposit refunds will be inspected and processed promptly after key return. Thank you! ⭐⭐⭐⭐⭐`;
      break;

    case 'cleaner':
      msg = `🧹 *Turnover Notice - ${prop.name}*\n\n` +
        `Turnover required for ${prop.name} on ${booking.checkOut}.\n` +
        `Guest ${booking.guestName} checking out at ${prop.checkOutTime || '12:00 PM'}.\n` +
        (prop.address ? `Address: ${prop.address}\n` : '') +
        (prop.gpsLocation ? `GPS Location: ${prop.gpsLocation}\n` : '') +
        `Smart Lock PIN to reset: ${prop.doorCode || '1234'}.`;
      break;

    case 'payment':
      msg = `💳 *Payment Reminder - ${prop.name}*\n\n` +
        `Hi *${booking.guestName}*, gentle reminder regarding the remaining balance for your stay:\n\n` +
        `📅 *Dates:* ${booking.checkIn} to ${booking.checkOut}\n` +
        `💰 *Balance Due:* *${currency} ${booking.balance.toFixed(2)}*\n` +
        bankInfoEN +
        `\nKindly settle the balance before check-in to receive your door access PIN. Thank you! 🙏`;
      break;

    default:
      msg = '';
      break;
  }

  // Append Standard Notes / Footer (Customer-facing templates only)
  if (msg) {
    const stdNotes = (settings.standardNotes || '').trim();
    if (stdNotes && templateType !== 'cleaner') {
      const header = isBM ? '\n\n📝 *NOTA PENTING:*' : '\n\n📝 *IMPORTANT NOTES:*';
      msg = msg.trim() + `${header}\n${stdNotes}`;
    }
  }

  return msg;
}

function renderWhatsAppPreview() {
  if (!appState.activeWaBooking) return;
  const msg = generateWhatsAppMessage(appState.activeWaBooking, appState.activeWaTemplate);
  document.getElementById('waMessagePreviewText').textContent = msg;

  const now = new Date();
  document.getElementById('waTimestamp').textContent = `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')} ✓✓`;
}

function handleCopyWaText() {
  const text = document.getElementById('waMessagePreviewText').textContent;
  navigator.clipboard.writeText(text).then(() => {
    showToast('Message copied to clipboard!');
  }).catch(() => {
    showToast('Copied text!');
  });
}

function handleSendWaDirect() {
  if (!appState.activeWaBooking) return;
  const text = document.getElementById('waMessagePreviewText').textContent;
  const phone = (appState.activeWaBooking.guestPhone || '').replace(/[^0-9]/g, '');
  const url = phone ? `https://wa.me/${phone}?text=${encodeURIComponent(text)}` : `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

// ==========================================================================
// 14B. CORPORATE & OFFICE PDF DOCUMENT GENERATION (v2.6.5)
// ==========================================================================

const PDF_DOC_I18N = {
  bm: {
    docBadgeQuotation: 'SEBUT HARGA RASMI',
    docTitleQuotation: 'Sebut Harga',
    docBadgeInvoice: 'INVOIS RASMI',
    docTitleInvoice: 'Invois',
    docBadgeDepositReceipt: 'RESIT DEPOSIT DITERIMA',
    docTitleDepositReceipt: 'Resit Bayaran Deposit',
    docBadgeReceipt: 'RESIT RASMI PEMBAYARAN',
    docTitleReceipt: 'Resit Rasmi Bayaran Penuh',

    lblPdfDocNoTitleQuotation: 'No. Sebut Harga:',
    lblPdfDocNoTitleInvoice: 'No. Invois:',
    lblPdfDocNoTitleDepositReceipt: 'No. Resit Deposit:',
    lblPdfDocNoTitleReceipt: 'No. Resit Rasmi:',
    lblPdfDocDateTitleQuotation: 'Tarikh Sebut Harga:',
    lblPdfDocDateTitleInvoice: 'Tarikh Invois:',
    lblPdfDocDateTitleDepositReceipt: 'Tarikh Resit:',
    lblPdfDocDateTitleReceipt: 'Tarikh Resit:',
    lblPdfValidityTitle: 'Tempoh Sah:',
    lblPdfLpoTitle: 'No. LPO / Ruj:',
    lblPdfPayMethodTitle: 'Kaedah Bayaran:',
    lblPdfBillTo: 'Dikeluarkan Kepada',

    thPdfItem: 'Perkara / Huraian',
    thPdfHsn: 'Kod / HSN',
    thPdfQty: 'Kuantiti',
    thPdfRate: 'Kadar Seunit',
    thPdfTax: 'Cukai / SST',
    thPdfAmount: 'Jumlah',

    lblPdfSubTotalTable: 'Jumlah Kasar Pakej',
    lblPdfExtraCharges: 'Caj Tambahan (+)',
    lblPdfTaxableAmount: 'Jumlah Kasar Pakej Penginapan',
    lblPdfCgst: 'SST / Cukai Perkhidmatan @ 0%',
    lblPdfSgst: 'Cukai Warisan / Pelancongan @ RM 0.00',
    lblPdfDepositReq: 'Deposit Komitmen Diperlukan:',
    lblPdfDepositPaidRow: 'Bayaran Deposit Diterima (+):',
    lblPdfDepositDeductedRow: 'Tolak: Deposit Telah Dibayar (-):',
    lblPdfPaid: 'Jumlah Telah Dibayar:',
    lblPdfBalance: 'Baki Belum Jelas (Sebelum Masuk):',
    lblPdfDiscount: 'Diskaun (-)',
    
    lblPdfGrandTotalQuotation: 'Jumlah Anggaran Keseluruhan',
    lblPdfGrandTotalInvoice: 'Baki Perlu Dijelaskan (Amount Due)',
    lblPdfGrandTotalInvoiceNoDep: 'Jumlah Invois Keseluruhan',
    lblPdfGrandTotalDepositReceipt: 'JUMLAH BAYARAN DEPOSIT DITERIMA',
    lblPdfGrandTotalReceipt: 'JUMLAH BAYARAN PENUH DITERIMA',

    lblPdfWordsTitleDeposit: 'Jumlah Bayaran Deposit Diterima Dalam Perkataan',
    lblPdfWordsTitleGeneral: 'Jumlah Keseluruhan Dalam Perkataan',
    lblPdfAuthorized: 'Tandatangan Pengurus',

    lblPdfBankTitle: 'Butiran Akaun Bank',
    lblPdfAccHolder: 'Penama Akaun:',
    lblPdfAccNum: 'Nombor Akaun:',
    lblPdfBankName: 'Nama Bank:',
    lblPdfBranch: 'Cawangan:',
    lblPdfDuitNow: 'DuitNow ID:',
    lblPdfTermsTitle: 'Syarat & Catatan Dokumen',

    txtWaPromptTitle: 'Hantar Dokumen ini ke WhatsApp Tetamu?',
    txtWaPromptSub: 'Fail PDF rasmi ini sedia untuk dihantar dan dilampirkan terus ke perbualan WhatsApp tetamu.',
    txtBtnPromptYes: 'Ya, Hantar ke WhatsApp',
    txtBtnPromptNo: 'Hanya Lihat / Muat Turun',

    termsQuotation: [
      'Sila kemukakan dokumen ini ke bahagian kewangan / pentadbiran bagi tujuan kelulusan atau pesanan tempatan (LPO).',
      'Kadar dan tarikh tertakluk kepada kekosongan semasa pengesahan deposit dibuat.',
      'Waktu Daftar Masuk: 3:00 PM | Daftar Keluar: 12:00 PM.'
    ],
    termsInvoice: [
      'Invois ini dikeluarkan untuk tujuan pembayaran sewaan penginapan homestay bagi urusan rasmi.',
      'Sila jelaskan baki sewaan selewat-lewatnya sebelum atau semasa pendaftaran masuk.',
      'Resit rasmi akan dikeluarkan serta-merta sebaik sahaja baki bayaran diterima.'
    ],
    termsDepositReceipt: [
      'Resit rasmi pengesahan penerimaan bayaran deposit / tempahan awal bagi penginapan homestay seperti butiran di atas.',
      'Tarikh penginapan anda kini telah dikunci dan disahkan di sistem kami.',
      'Baki bayaran sewaan hendaklah dijelaskan selewat-lewatnya sebelum atau semasa penyerahan kunci / pendaftaran masuk.'
    ],
    termsReceipt: [
      'Pengesahan rasmi penerimaan bayaran penuh untuk penginapan homestay bagi urusan rasmi seperti butiran di atas.',
      'Deposit keselamatan (jika berkenaan) akan dipulangkan selepas semakan daftar keluar.',
      'Terima kasih kerana memilih homestay kami untuk urusan rasmi organisasi anda.'
    ],
    docBadgeQuotationMonthly: 'SEBUT HARGA SEWAAN BULANAN',
    docTitleQuotationMonthly: 'Sebut Harga Sewaan Bulanan',
    docBadgeInvoiceMonthly: 'INVOIS SEWAAN BULANAN',
    docTitleInvoiceMonthly: 'Invois Sewaan Bulanan',
    docBadgeDepositReceiptMonthly: 'RESIT BAYARAN BOOKING SEWAAN',
    docTitleDepositReceiptMonthly: 'Resit Bayaran Booking Sewaan',
    docBadgeReceiptMonthly: 'RESIT RASMI BAYARAN KEMASUKAN',
    docTitleReceiptMonthly: 'Resit Rasmi Bayaran Kemasukan',

    termsQuotationMonthly: [
      'Bayaran Sewa Pendahuluan: Sewa bulanan dikutip secara pendahuluan bagi setiap bulan (bukan bayaran sekaligus bagi keseluruhan tempoh sewaan).',
      'Invois Sewaan Bulanan: Invois sewaan bulanan bagi bulan-bulan seterusnya akan dikeluarkan pada setiap awal bulan sebelum tarikh akhir bayaran.',
      'Caj Bil Utiliti: Bagi sewaan jangka panjang melebihi 1 bulan, penyewa membayar bil utiliti (elektrik & air) terus kepada pembekal atau ditambah ke dalam invois sewa bulanan mengikut kadar penggunaan bulanan sebenar.',
      'Pemulangan Deposit: Deposit Sewaan (1 bulan sewa) dan Deposit Utiliti (RM 300.00) akan dipulangkan sepenuhnya dalam tempoh 14 hari selepas tamat tempoh sewaan dan penyerahan kunci, tertakluk kepada penyelesaian bil utiliti tertunggak dan pemeriksaan keadaan unit yang baik.',
      'Pengesahan Tempahan: Dokumen ini sah selama tempoh yang dinyatakan. Unit hanya disahkan dan dikunci selepas bayaran tempahan/booking awal diterima.'
    ],
    termsInvoiceMonthly: [
      'Invois ini dikeluarkan untuk bayaran sewaan bulanan bagi kitaran bulan yang dinyatakan di atas.',
      'Sila jelaskan bayaran selewat-lewatnya sebelum atau pada tarikh akhir bayaran (Due Date).',
      'Caj bil utiliti (elektrik & air) dicaj secara berasingan mengikut penggunaan bulanan sebenar.',
      'Resit rasmi pembayaran sewaan bulanan akan dikeluarkan serta-merta sebaik sahaja transaksi bank disahkan.'
    ]
  },
  en: {
    docBadgeQuotation: 'OFFICIAL QUOTATION',
    docTitleQuotation: 'Quotation',
    docBadgeInvoice: 'OFFICIAL INVOICE',
    docTitleInvoice: 'Invoice',
    docBadgeDepositReceipt: 'DEPOSIT PAYMENT RECEIPT',
    docTitleDepositReceipt: 'Deposit Payment Receipt',
    docBadgeReceipt: 'OFFICIAL RECEIPT',
    docTitleReceipt: 'Official Payment Receipt',

    lblPdfDocNoTitleQuotation: 'Quotation No:',
    lblPdfDocNoTitleInvoice: 'Invoice No:',
    lblPdfDocNoTitleDepositReceipt: 'Deposit Receipt No:',
    lblPdfDocNoTitleReceipt: 'Receipt No:',
    lblPdfDocDateTitleQuotation: 'Quotation Date:',
    lblPdfDocDateTitleInvoice: 'Invoice Date:',
    lblPdfDocDateTitleDepositReceipt: 'Receipt Date:',
    lblPdfDocDateTitleReceipt: 'Receipt Date:',
    lblPdfValidityTitle: 'Validity Date:',
    lblPdfLpoTitle: 'LPO / Ref No:',
    lblPdfPayMethodTitle: 'Payment Mode / Ref:',
    lblPdfBillTo: 'Bill To',

    thPdfItem: 'Items',
    thPdfHsn: 'HSN/Code',
    thPdfQty: 'Quantity',
    thPdfRate: 'Rate Per Unit',
    thPdfTax: 'Tax Per Unit',
    thPdfAmount: 'Amount',

    lblPdfSubTotalTable: 'Package Sub Total',
    lblPdfExtraCharges: 'Extra Charges (+)',
    lblPdfTaxableAmount: 'Total Accommodation Package',
    lblPdfCgst: 'SST / Service Tax @ 0%',
    lblPdfSgst: 'Tourism / Heritage Tax @ RM 0.00',
    lblPdfDepositReq: 'Deposit Required:',
    lblPdfDepositPaidRow: 'Deposit Payment Received (+):',
    lblPdfDepositDeductedRow: 'Less: Deposit Paid (-):',
    lblPdfPaid: 'Amount Paid:',
    lblPdfBalance: 'Outstanding Balance Due:',
    lblPdfDiscount: 'Discount (-)',

    lblPdfGrandTotalQuotation: 'Total Estimated Amount',
    lblPdfGrandTotalInvoice: 'Balance Amount Due',
    lblPdfGrandTotalInvoiceNoDep: 'Total Invoice Amount',
    lblPdfGrandTotalDepositReceipt: 'TOTAL DEPOSIT RECEIVED',
    lblPdfGrandTotalReceipt: 'TOTAL AMOUNT SETTLED',

    lblPdfWordsTitleDeposit: 'Total Deposit Received in Words',
    lblPdfWordsTitleGeneral: 'Total Amount in Words',
    lblPdfAuthorized: 'Authorized Signature',

    lblPdfBankTitle: 'Bank Details',
    lblPdfAccHolder: 'Account holder:',
    lblPdfAccNum: 'Account number:',
    lblPdfBankName: 'Bank:',
    lblPdfBranch: 'Branch:',
    lblPdfDuitNow: 'DuitNow ID:',
    lblPdfTermsTitle: 'Terms & Conditions',

    txtWaPromptTitle: 'Send this Document to Guest via WhatsApp?',
    txtWaPromptSub: 'This official PDF document is ready to be sent and attached directly to guest\'s WhatsApp.',
    txtBtnPromptYes: 'Yes, Send to WhatsApp',
    txtBtnPromptNo: 'View / Download Only',

    termsQuotation: [
      'Please submit this formal quotation to your accounts/finance department for LPO or disbursement processing.',
      'Rates and dates remain subject to availability until booking deposit is confirmed.',
      'Standard Check-In: 3:00 PM | Check-Out: 12:00 PM.'
    ],
    termsInvoice: [
      'This invoice is rendered for official corporate/department homestay accommodation claims.',
      'Full settlement is respectfully requested prior to or upon guest check-in arrival.',
      'An official payment receipt will be issued immediately upon receipt of bank remittance.'
    ],
    termsDepositReceipt: [
      'Official acknowledgement of booking deposit payment received for the homestay stay stated above.',
      'Your reservation dates are now officially locked and secured in our calendar.',
      'The remaining balance is due prior to or upon guest arrival / keys handover.'
    ],
    termsReceipt: [
      'Official acknowledgement of full payment received for accommodation particulars stated above.',
      'Refundable security deposit (if applicable) will be refunded within 24 hours following checkout inspection.',
      'Thank you for staying with us for your official corporate engagement.'
    ],
    docBadgeQuotationMonthly: 'MONTHLY TENANCY QUOTATION',
    docTitleQuotationMonthly: 'Monthly Tenancy Quotation',
    docBadgeInvoiceMonthly: 'MONTHLY RENTAL INVOICE',
    docTitleInvoiceMonthly: 'Monthly Rental Invoice',
    docBadgeDepositReceiptMonthly: 'TENANCY BOOKING RECEIPT',
    docTitleDepositReceiptMonthly: 'Tenancy Booking Receipt',
    docBadgeReceiptMonthly: 'MOVE-IN PAYMENT RECEIPT',
    docTitleReceiptMonthly: 'Move-in Payment Receipt',

    termsQuotationMonthly: [
      'Advance Monthly Rental: Rental is collected in advance for each month and not as a lump sum for the entire tenancy duration.',
      'Subsequent Monthly Invoices: Rental invoice for each subsequent month will be issued at the beginning of each month prior to payment due date.',
      'Utility Usage Policy: For long-term rental exceeding 1 month, tenant will pay utility bills (electricity & water) directly to utility providers or added into the monthly rental invoice based on actual usage charges.',
      'Refundable Deposits: Rental Deposit (1 month rental) and Utilities Deposit (RM 300.00) are fully refundable at the end of tenancy subject to utility arrears settlement and satisfactory unit condition.',
      'Reservation Confirmation: Unit is secured and confirmed only upon receipt of the initial booking commitment fee.'
    ],
    termsInvoiceMonthly: [
      'This invoice is issued for monthly rental charges covering the billing period stated above.',
      'Please settle payment on or before the specified due date.',
      'Utility charges (electricity & water) are billed based on actual monthly consumption.',
      'An official payment receipt will be issued immediately upon payment verification.'
    ]
  }
};

/**
 * Convert numeric Ringgit currency into words (Malay & English)
 */
function numberToWordsMYR(amount, lang = 'bm') {
  amount = parseFloat(amount) || 0;
  if (amount < 0) amount = Math.abs(amount);
  const ringgit = Math.floor(amount);
  const sen = Math.round((amount - ringgit) * 100);

  const unitsBM = ['', 'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Lapan', 'Sembilan'];
  const unitsEN = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const teensEN = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tensEN = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertBM(n) {
    if (n === 0) return '';
    if (n < 10) return unitsBM[n];
    if (n === 10) return 'Sepuluh';
    if (n === 11) return 'Sebelas';
    if (n < 20) return unitsBM[n - 10] + ' Belas';
    if (n < 100) {
      const ten = Math.floor(n / 10);
      const rem = n % 10;
      return (ten === 1 ? 'Sepuluh' : unitsBM[ten] + ' Puluh') + (rem > 0 ? ' ' + unitsBM[rem] : '');
    }
    if (n < 1000) {
      const hundred = Math.floor(n / 100);
      const rem = n % 100;
      return (hundred === 1 ? 'Seratus' : unitsBM[hundred] + ' Ratus') + (rem > 0 ? ' ' + convertBM(rem) : '');
    }
    if (n < 1000000) {
      const thousand = Math.floor(n / 1000);
      const rem = n % 1000;
      return (thousand === 1 ? 'Seribu' : convertBM(thousand) + ' Ribu') + (rem > 0 ? ' ' + convertBM(rem) : '');
    }
    if (n < 1000000000) {
      const million = Math.floor(n / 1000000);
      const rem = n % 1000000;
      return convertBM(million) + ' Juta' + (rem > 0 ? ' ' + convertBM(rem) : '');
    }
    return n.toString();
  }

  function convertEN(n) {
    if (n === 0) return '';
    if (n < 10) return unitsEN[n];
    if (n < 20) return teensEN[n - 10];
    if (n < 100) {
      const ten = Math.floor(n / 10);
      const rem = n % 10;
      return tensEN[ten] + (rem > 0 ? '-' + unitsEN[rem] : '');
    }
    if (n < 1000) {
      const hundred = Math.floor(n / 100);
      const rem = n % 100;
      return unitsEN[hundred] + ' Hundred' + (rem > 0 ? ' ' + convertEN(rem) : '');
    }
    if (n < 1000000) {
      const thousand = Math.floor(n / 1000);
      const rem = n % 1000;
      return convertEN(thousand) + ' Thousand' + (rem > 0 ? ' ' + convertEN(rem) : '');
    }
    if (n < 1000000000) {
      const million = Math.floor(n / 1000000);
      const rem = n % 1000000;
      return convertEN(million) + ' Million' + (rem > 0 ? ' ' + convertEN(rem) : '');
    }
    return n.toString();
  }

  if (lang === 'bm') {
    let result = '';
    if (ringgit === 0) {
      result = 'Sifar Ringgit';
    } else {
      result = 'Ringgit Malaysia ' + convertBM(ringgit);
    }
    if (sen > 0) {
      result += ' Dan ' + convertBM(sen) + ' Sen';
    }
    result += ' Sahaja';
    return result.toUpperCase();
  } else {
    let result = '';
    if (ringgit === 0) {
      result = 'Zero Ringgit';
    } else {
      result = 'Malaysian Ringgit ' + convertEN(ringgit);
    }
    if (sen > 0) {
      result += ' And ' + convertEN(sen) + ' Cents';
    }
    result += ' Only';
    return result.toUpperCase();
  }
}

function openPdfDocModal(booking, defaultDocType = 'quotation', monthIndex = null) {
  if (!booking) {
    booking = appState.bookings && appState.bookings[0];
    if (!booking) {
      showToast(appState.settings.language === 'bm' ? 'Tiada rekod tempahan untuk dijana dokumen.' : 'No booking record available to generate document.');
      return;
    }
  }

  // Ensure any other open backdrops (e.g. WhatsApp modal) are cleanly closed first
  closeAllModals();

  appState.activePdfBooking = booking;
  appState.activePdfMonthIndex = monthIndex ? parseInt(monthIndex) : null;
  const isMonthly = booking.rentalType === 'monthly';

  // Intelligently select default document type
  const paidAmt = Number(booking.depositPaid || (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0) || 0);
  const totalAmt = Number(booking.totalAmount || 0);

  if (monthIndex) {
    const invs = getOrInitMonthlyInvoices(booking);
    const targetInv = invs.find(x => x.monthIndex === parseInt(monthIndex));
    if (targetInv && targetInv.status === 'paid' && defaultDocType !== 'invoice') {
      defaultDocType = 'receipt';
    } else {
      defaultDocType = 'invoice';
    }
  } else {
    if (defaultDocType === 'deposit_receipt' || (booking.status === 'booked' && defaultDocType !== 'invoice' && defaultDocType !== 'quotation')) {
      defaultDocType = 'deposit_receipt';
    } else if (defaultDocType === 'receipt') {
      if (paidAmt > 0 && paidAmt < totalAmt) {
        defaultDocType = 'deposit_receipt';
      } else {
        defaultDocType = 'receipt';
      }
    }
  }

  appState.activePdfDocType = defaultDocType || 'quotation';
  appState.activePdfLang = appState.settings.language || 'bm';

  // Setup monthly tenancy scope controls
  const monthlyGroup = document.getElementById('pdfMonthlyTenancyGroup');
  const scopeSelect = document.getElementById('pdfMonthlyDocScopeSelect');
  const utilityWrap = document.getElementById('pdfMonthlyUtilityExtraWrap');
  const utilityInput = document.getElementById('pdfMonthlyUtilityExtraInput');

  const btnPdfAgrTab = document.getElementById('btnPdfTabAgreement');
  if (btnPdfAgrTab) {
    btnPdfAgrTab.style.display = isMonthly ? 'inline-flex' : 'none';
  }

  if (monthlyGroup && scopeSelect) {
    if (isMonthly) {
      monthlyGroup.style.display = 'block';
      scopeSelect.innerHTML = '';

      const optMoveIn = document.createElement('option');
      optMoveIn.value = 'move_in';
      optMoveIn.textContent = appState.activePdfLang === 'bm'
        ? '📋 Pakej Kemasukan Awal (Sebut Harga / Move-In Package)'
        : '📋 Move-In Initial Package (Quotation Statement)';
      scopeSelect.appendChild(optMoveIn);

      const invs = getOrInitMonthlyInvoices(booking);
      invs.forEach(inv => {
        const opt = document.createElement('option');
        opt.value = inv.monthIndex;
        const isPaid = inv.status === 'paid';
        opt.textContent = appState.activePdfLang === 'bm'
          ? `📅 Invois Bulan ke-${inv.monthIndex} (${inv.periodStart} → ${inv.periodEnd}) [${isPaid ? 'DIBAYAR' : 'BELUM'}]`
          : `📅 Month ${inv.monthIndex} Invoice (${inv.periodStart} → ${inv.periodEnd}) [${isPaid ? 'PAID' : 'DUE'}]`;
        scopeSelect.appendChild(opt);
      });

      const optAgr = document.createElement('option');
      optAgr.value = 'tenancy_agreement';
      optAgr.textContent = appState.activePdfLang === 'bm'
        ? '📜 Surat Perjanjian Sewaan (Buka Penjana Tenancy Agreement)'
        : '📜 Residential Tenancy Agreement (Open Agreement Generator)';
      scopeSelect.appendChild(optAgr);

      if (monthIndex) {
        scopeSelect.value = String(monthIndex);
        if (utilityWrap) utilityWrap.style.display = 'block';
        const targetInv = invs.find(x => x.monthIndex === parseInt(monthIndex));
        if (utilityInput && targetInv) utilityInput.value = targetInv.utilityCharges || 0;
      } else {
        scopeSelect.value = 'move_in';
        if (utilityWrap) utilityWrap.style.display = 'none';
      }

      scopeSelect.onchange = () => {
        if (scopeSelect.value === 'tenancy_agreement') {
          closePdfDocModal();
          openAgreementModal(booking, 'preview');
          return;
        }
        if (scopeSelect.value === 'move_in') {
          appState.activePdfMonthIndex = null;
          if (utilityWrap) utilityWrap.style.display = 'none';
          if (appState.activePdfDocType !== 'quotation') {
            setPdfDocType('quotation');
            return;
          }
        } else {
          appState.activePdfMonthIndex = parseInt(scopeSelect.value);
          if (utilityWrap) utilityWrap.style.display = 'block';
          const targetInv = invs.find(x => x.monthIndex === appState.activePdfMonthIndex);
          if (utilityInput && targetInv) utilityInput.value = targetInv.utilityCharges || 0;
          if (appState.activePdfDocType === 'quotation') {
            setPdfDocType('invoice');
            return;
          }
        }
        updatePdfDocView();
      };

      if (utilityInput) {
        utilityInput.oninput = () => {
          if (appState.activePdfMonthIndex) {
            const targetInv = invs.find(x => x.monthIndex === appState.activePdfMonthIndex);
            if (targetInv) {
              targetInv.utilityCharges = parseFloat(utilityInput.value) || 0;
              targetInv.totalAmount = (targetInv.rentAmount || 0) + targetInv.utilityCharges;
              saveToStorage();
              updatePdfDocView();
            }
          }
        };
      }
    } else {
      monthlyGroup.style.display = 'none';
      if (utilityWrap) utilityWrap.style.display = 'none';
    }
  }

  // Quotation validity days
  const valDays = booking.quotationValidityDays || appState.settings.quotationValidityDays || 3;
  const valInput = document.getElementById('pdfQuotationValidityInput');
  if (valInput) valInput.value = valDays;

  // Deposit amount input
  const depAmt = paidAmt > 0 
    ? paidAmt 
    : (isMonthly ? (booking.depositAmount || Math.round((booking.monthlyRate || 1200) * 0.5)) : Math.round(totalAmt * (appState.settings.defaultDepositPct || 30) / 100));
  const depInput = document.getElementById('pdfDepositAmountInput');
  if (depInput) depInput.value = depAmt;

  // Payment Reference input
  const payRefInput = document.getElementById('pdfPaymentRefInput');
  if (payRefInput) {
    payRefInput.value = booking.lastPaymentRef ? `${booking.lastPaymentBank || 'Pindahan Bank'} - ${booking.lastPaymentRef}` : '';
  }

  // Client company and LPO
  const compInput = document.getElementById('pdfClientCompanyInput');
  if (compInput) compInput.value = booking.guestCompany || '';

  const lpoInput = document.getElementById('pdfLpoRefInput');
  if (lpoInput) lpoInput.value = booking.lpoRef || '';

  // Show WhatsApp prompt banner asking user if they want to send the file
  const banner = document.getElementById('pdfWaPromptBanner');
  if (banner) banner.style.display = 'flex';

  const statusCard = document.getElementById('pdfActionStatusCard');
  if (statusCard) {
    statusCard.style.display = 'none';
    statusCard.innerHTML = '';
  }

  // Highlight active doc tab
  updatePdfTypeTabsUI();
  updatePdfLangButtonsUI();
  updatePdfValidityPresetsUI(valDays);

  // Render preview with error boundary
  try {
    updatePdfDocView();
  } catch (err) {
    console.error('Error updating PDF document view:', err);
  }

  // Open modal
  const modal = document.getElementById('pdfDocModal');
  if (modal) modal.classList.add('active');
}

function closePdfDocModal() {
  const modal = document.getElementById('pdfDocModal');
  if (modal) modal.classList.remove('active');
}

function setPdfDocType(type) {
  appState.activePdfDocType = type;
  updatePdfTypeTabsUI();
  updatePdfDocView();
}

function setPdfLanguage(lang) {
  appState.activePdfLang = lang;
  updatePdfLangButtonsUI();
  updatePdfDocView();
}

function setPdfQuotationValidity(days) {
  const cleanDays = Math.max(1, parseInt(days) || 3);
  const valInput = document.getElementById('pdfQuotationValidityInput');
  if (valInput) valInput.value = cleanDays;

  if (appState.activePdfBooking) {
    appState.activePdfBooking.quotationValidityDays = cleanDays;
    saveToStorage();
  }

  updatePdfValidityPresetsUI(cleanDays);
  updatePdfDocView();
}

function updatePdfTypeTabsUI() {
  const type = appState.activePdfDocType || 'quotation';
  const tabs = [
    { id: 'btnPdfTabQuotation', type: 'quotation' },
    { id: 'btnPdfTabInvoice', type: 'invoice' },
    { id: 'btnPdfTabDeposit', type: 'deposit_receipt' },
    { id: 'btnPdfTabReceipt', type: 'receipt' }
  ];

  tabs.forEach(t => {
    const el = document.getElementById(t.id);
    if (el) el.classList.toggle('active', t.type === type);
  });

  // Toggle visibility of customization controls based on active doc type
  const validityGroup = document.getElementById('pdfQuotationValidityGroup');
  if (validityGroup) {
    validityGroup.style.display = type === 'quotation' ? 'block' : 'none';
  }

  const depositGroup = document.getElementById('pdfDepositAmountGroup');
  if (depositGroup) {
    depositGroup.style.display = (type === 'deposit_receipt' || type === 'invoice') ? 'block' : 'none';
  }

  const payRefGroup = document.getElementById('pdfPaymentRefGroup');
  if (payRefGroup) {
    payRefGroup.style.display = (type === 'deposit_receipt' || type === 'receipt') ? 'block' : 'none';
  }
}

function updatePdfLangButtonsUI() {
  const lang = appState.activePdfLang || 'bm';
  const btnBM = document.getElementById('btnPdfLangBM');
  const btnEN = document.getElementById('btnPdfLangEN');
  if (btnBM) btnBM.classList.toggle('active', lang === 'bm');
  if (btnEN) btnEN.classList.toggle('active', lang === 'en');
}

function updatePdfValidityPresetsUI(days) {
  document.querySelectorAll('.pdf-validity-preset').forEach(btn => {
    const d = parseInt(btn.getAttribute('data-days'));
    btn.classList.toggle('active', d === days);
  });
}

function updatePdfDocView() {
  const booking = appState.activePdfBooking;
  if (!booking) return;

  const prop = getPropertyById(booking.propertyId) || { name: 'Homestay Unit', address: '' };
  const settings = appState.settings || {};
  let docType = appState.activePdfDocType || 'quotation';
  const lang = appState.activePdfLang || 'bm';
  const t = PDF_DOC_I18N[lang] || PDF_DOC_I18N.bm;
  const currency = settings.currency || 'RM';

  // 1. Host Information
  const bizNameEl = document.getElementById('pdfHostBizName');
  if (bizNameEl) bizNameEl.textContent = settings.businessName || 'MY HOMESTAY';

  const ssmEl = document.getElementById('pdfHostSsm');
  if (ssmEl) {
    ssmEl.textContent = settings.businessSsm ? settings.businessSsm : '20260100988-X (SSM)';
  }

  const addrEl = document.getElementById('pdfHostAddress');
  if (addrEl) addrEl.textContent = settings.businessAddress || prop.address || 'Premis Homestay & Perkhidmatan Penginapan';

  const phoneEl = document.getElementById('pdfHostPhone');
  if (phoneEl) phoneEl.textContent = settings.ownerPhone || prop.contactPhone || '-';

  const emailEl = document.getElementById('pdfHostEmail');
  if (emailEl) emailEl.textContent = settings.businessEmail || (settings.ownerPhone ? `host@${settings.ownerPhone.replace(/\D/g, '')}.com` : 'host@myhomestay.com');

  const premisIdEl = document.getElementById('pdfHostPremisId');
  if (premisIdEl) premisIdEl.textContent = prop.id ? `HM-${prop.id.replace(/\D/g, '')}` : 'HM-1088';

  // 2. Tenancy & Rental Type Determination
  const isMonthly = booking.rentalType === 'monthly';
  const mRate = Number(booking.monthlyRate || 0);
  const rDep = (booking.rentalDeposit !== undefined && booking.rentalDeposit !== null && booking.rentalDeposit !== '') 
    ? Number(booking.rentalDeposit) 
    : mRate;
  const uDep = (booking.utilitiesDeposit !== undefined && booking.utilitiesDeposit !== null && booking.utilitiesDeposit !== '') 
    ? Number(booking.utilitiesDeposit) 
    : 300;
  const aFee = Number(booking.agreementFee || 0);
  const totalMoveIn = mRate + rDep + uDep + aFee;

  const activeMonthIdx = appState.activePdfMonthIndex;
  const monthlyInvoices = isMonthly ? getOrInitMonthlyInvoices(booking) : [];
  const currentMonthInv = (isMonthly && activeMonthIdx) 
    ? monthlyInvoices.find(x => x.monthIndex === activeMonthIdx) 
    : null;

  // Financial figures calculation
  let grandTotal = 0;
  let depositPaidAmt = 0;
  let balAmt = 0;

  if (isMonthly) {
    if (currentMonthInv) {
      const curMonthTotal = Number((currentMonthInv.rentAmount || mRate) + (currentMonthInv.utilityCharges || 0));
      grandTotal = curMonthTotal;
      const isPaid = currentMonthInv.status === 'paid';
      depositPaidAmt = isPaid ? curMonthTotal : 0;
      balAmt = isPaid ? 0 : curMonthTotal;
    } else {
      grandTotal = totalMoveIn;
      depositPaidAmt = parseFloat(document.getElementById('pdfDepositAmountInput')?.value);
      if (isNaN(depositPaidAmt)) {
        depositPaidAmt = Number(booking.depositPaid || (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0) || 0);
      }
      if (depositPaidAmt === 0 && (docType === 'deposit_receipt' || booking.status === 'booked')) {
        depositPaidAmt = Number(booking.depositAmount || Math.round(mRate * 0.5));
      }
      balAmt = Math.max(0, grandTotal - depositPaidAmt);
    }
  } else {
    const nights = booking.nights || 1;
    const ratePerNight = nights > 0 ? (booking.baseRate ? booking.baseRate / nights : (booking.totalAmount - (booking.cleaningFee || 0)) / nights) : booking.totalAmount;
    const accommodationTotal = ratePerNight * nights;
    grandTotal = booking.totalAmount || (accommodationTotal + (booking.cleaningFee || 0));

    depositPaidAmt = parseFloat(document.getElementById('pdfDepositAmountInput')?.value);
    if (isNaN(depositPaidAmt)) {
      depositPaidAmt = Number(booking.depositPaid || (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0) || 0);
    }
    if (depositPaidAmt === 0 && (docType === 'deposit_receipt' || booking.status === 'booked')) {
      depositPaidAmt = Number(booking.depositAmount || Math.round(grandTotal * (settings.defaultDepositPct || 30) / 100));
    }
    balAmt = Math.max(0, grandTotal - depositPaidAmt);
  }

  // Update Deposit balance hint in toolbar
  const depBalHint = document.getElementById('pdfDepositBalanceHint');
  if (depBalHint) {
    depBalHint.textContent = lang === 'bm' ? `Baki: ${currency} ${balAmt.toFixed(2)}` : `Bal: ${currency} ${balAmt.toFixed(2)}`;
    depBalHint.style.color = balAmt > 0 ? '#b45309' : '#059669';
  }

  // 3. Document Number & Date & Meta
  const year = new Date().getFullYear();
  const idShort = (booking.id || '').replace(/\D/g, '').slice(-4) || '1088';
  let docPrefix = 'QT';
  let docTitle = t.docTitleQuotation;
  let docNoTitle = t.lblPdfDocNoTitleQuotation;
  let docDateTitle = t.lblPdfDocDateTitleQuotation;
  let docBadge = t.docBadgeQuotation;
  let badgeBg = '#e0f2fe';
  let badgeColor = '#0369a1';
  let titleColor = '#ea580c';

  if (isMonthly) {
    if (currentMonthInv) {
      if (docType === 'receipt' || currentMonthInv.status === 'paid') {
        docPrefix = `REC-M${currentMonthInv.monthIndex}`;
        docTitle = lang === 'bm' ? `Resit Bayaran Sewa Bulan ke-${currentMonthInv.monthIndex}` : `Monthly Rent Receipt Month ${currentMonthInv.monthIndex}`;
        docNoTitle = t.lblPdfDocNoTitleReceipt;
        docDateTitle = t.lblPdfDocDateTitleReceipt;
        docBadge = lang === 'bm' ? `RESIT SEWA BULAN KE-${currentMonthInv.monthIndex}` : `RENT RECEIPT MONTH ${currentMonthInv.monthIndex}`;
        badgeBg = '#d1fae5'; badgeColor = '#065f46'; titleColor = '#059669';
      } else {
        docPrefix = `INV-M${currentMonthInv.monthIndex}`;
        docTitle = lang === 'bm' ? `Invois Sewa Bulan ke-${currentMonthInv.monthIndex}` : `Monthly Rent Invoice Month ${currentMonthInv.monthIndex}`;
        docNoTitle = t.lblPdfDocNoTitleInvoice;
        docDateTitle = t.lblPdfDocDateTitleInvoice;
        docBadge = lang === 'bm' ? `INVOIS SEWA BULAN KE-${currentMonthInv.monthIndex}` : `MONTHLY RENT INVOICE MONTH ${currentMonthInv.monthIndex}`;
        badgeBg = '#ede9fe'; badgeColor = '#5b21b6'; titleColor = '#5b21b6';
      }
    } else {
      if (docType === 'invoice') {
        docPrefix = 'INV-M';
        docTitle = t.docTitleInvoiceMonthly || (lang === 'bm' ? 'Invois Kemasukan Sewaan Bulanan' : 'Monthly Tenancy Move-in Invoice');
        docNoTitle = t.lblPdfDocNoTitleInvoice;
        docDateTitle = t.lblPdfDocDateTitleInvoice;
        docBadge = t.docBadgeInvoiceMonthly || (lang === 'bm' ? 'INVOIS SEWAAN BULANAN' : 'MONTHLY TENANCY INVOICE');
        badgeBg = '#ede9fe'; badgeColor = '#5b21b6'; titleColor = '#5b21b6';
      } else if (docType === 'deposit_receipt') {
        docPrefix = 'REC-BOOK-M';
        docTitle = t.docTitleDepositReceiptMonthly || (lang === 'bm' ? 'Resit Bayaran Booking Sewaan' : 'Tenancy Booking Receipt');
        docNoTitle = t.lblPdfDocNoTitleDepositReceipt;
        docDateTitle = t.lblPdfDocDateTitleDepositReceipt;
        docBadge = t.docBadgeDepositReceiptMonthly || (lang === 'bm' ? 'RESIT BAYARAN BOOKING SEWAAN' : 'TENANCY BOOKING RECEIPT');
        badgeBg = '#dbeafe'; badgeColor = '#1e40af'; titleColor = '#0284c7';
      } else if (docType === 'receipt') {
        docPrefix = 'REC-M';
        docTitle = t.docTitleReceiptMonthly || (lang === 'bm' ? 'Resit Rasmi Bayaran Kemasukan' : 'Move-in Payment Receipt');
        docNoTitle = t.lblPdfDocNoTitleReceipt;
        docDateTitle = t.lblPdfDocDateTitleReceipt;
        docBadge = t.docBadgeReceiptMonthly || (lang === 'bm' ? 'RESIT RASMI BAYARAN KEMASUKAN' : 'MOVE-IN PAYMENT RECEIPT');
        badgeBg = '#d1fae5'; badgeColor = '#065f46'; titleColor = '#059669';
      } else {
        docPrefix = 'QUO-M';
        docTitle = t.docTitleQuotationMonthly || (lang === 'bm' ? 'Sebut Harga Sewaan Bulanan' : 'Monthly Tenancy Quotation');
        docNoTitle = t.lblPdfDocNoTitleQuotation;
        docDateTitle = t.lblPdfDocDateTitleQuotation;
        docBadge = t.docBadgeQuotationMonthly || (lang === 'bm' ? 'SEBUT HARGA SEWAAN BULANAN' : 'MONTHLY TENANCY QUOTATION');
        badgeBg = '#e0f2fe'; badgeColor = '#0369a1'; titleColor = '#ea580c';
      }
    }
  } else {
    if (docType === 'invoice') {
      docPrefix = 'INV';
      docTitle = t.docTitleInvoice;
      docNoTitle = t.lblPdfDocNoTitleInvoice;
      docDateTitle = t.lblPdfDocDateTitleInvoice;
      docBadge = t.docBadgeInvoice;
      badgeBg = '#ede9fe'; badgeColor = '#5b21b6'; titleColor = '#5b21b6';
    } else if (docType === 'deposit_receipt') {
      docPrefix = 'REC-DEP';
      docTitle = t.docTitleDepositReceipt;
      docNoTitle = t.lblPdfDocNoTitleDepositReceipt;
      docDateTitle = t.lblPdfDocDateTitleDepositReceipt;
      docBadge = t.docBadgeDepositReceipt;
      badgeBg = '#dbeafe'; badgeColor = '#1e40af'; titleColor = '#0284c7';
    } else if (docType === 'receipt') {
      docPrefix = 'REC';
      docTitle = t.docTitleReceipt;
      docNoTitle = t.lblPdfDocNoTitleReceipt;
      docDateTitle = t.lblPdfDocDateTitleReceipt;
      docBadge = t.docBadgeReceipt;
      badgeBg = '#d1fae5'; badgeColor = '#065f46'; titleColor = '#059669';
    }
  }

  const fullDocNo = `${docPrefix}-${year}-${idShort}`;

  const titleEl = document.getElementById('pdfDocTitle');
  if (titleEl) {
    titleEl.textContent = docTitle;
    titleEl.style.color = titleColor;
  }

  const lblDocNoEl = document.getElementById('lblPdfDocNoTitle');
  if (lblDocNoEl) lblDocNoEl.textContent = docNoTitle;

  const docNoEl = document.getElementById('pdfDocNo');
  if (docNoEl) docNoEl.textContent = fullDocNo;

  const lblDocDateEl = document.getElementById('lblPdfDocDateTitle');
  if (lblDocDateEl) lblDocDateEl.textContent = docDateTitle;

  const docDateEl = document.getElementById('pdfDocDate');
  if (docDateEl) {
    const d = new Date();
    docDateEl.textContent = d.toLocaleDateString(lang === 'bm' ? 'ms-MY' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) + ' 12:00 PM';
  }

  // Validity calculation (Quotation only)
  const valDays = parseInt(document.getElementById('pdfQuotationValidityInput')?.value) || booking.quotationValidityDays || settings.quotationValidityDays || 3;
  const expDateObj = new Date();
  expDateObj.setDate(expDateObj.getDate() + valDays);
  const expFormatted = expDateObj.toLocaleDateString(lang === 'bm' ? 'ms-MY' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

  const valRow = document.getElementById('pdfDocValidityRow');
  const lblValTitle = document.getElementById('lblPdfValidityTitle');
  const docValEl = document.getElementById('pdfDocValidity');
  if (lblValTitle) lblValTitle.textContent = t.lblPdfValidityTitle;
  if (docValEl) docValEl.textContent = `${expFormatted} (${valDays} ${lang === 'bm' ? 'Hari' : 'Days'})`;
  if (valRow) valRow.style.display = (docType === 'quotation' && !currentMonthInv) ? 'block' : 'none';

  const calcDateEl = document.getElementById('pdfValidityCalculatedDate');
  if (calcDateEl) calcDateEl.textContent = lang === 'bm' ? `Hingga ${expFormatted}` : `Until ${expFormatted}`;

  // LPO Row
  const lpoInputVal = document.getElementById('pdfLpoRefInput')?.value.trim() || booking.lpoRef || '';
  const lpoRow = document.getElementById('pdfDocLpoRow');
  const lblLpoTitle = document.getElementById('lblPdfLpoTitle');
  const lpoText = document.getElementById('pdfDocLpo');
  if (lblLpoTitle) lblLpoTitle.textContent = t.lblPdfLpoTitle;
  if (lpoRow && lpoText) {
    if (lpoInputVal) {
      lpoRow.style.display = 'block';
      lpoText.textContent = lpoInputVal;
    } else {
      lpoRow.style.display = 'none';
    }
  }

  // Payment Method & Transaction Reference Row
  const payMethodRow = document.getElementById('pdfDocPayMethodRow');
  const lblPayMethodTitle = document.getElementById('lblPdfPayMethodTitle');
  const payMethodText = document.getElementById('pdfDocPayMethodText');
  const userPayRef = document.getElementById('pdfPaymentRefInput')?.value.trim();
  const paymentRefStr = userPayRef || (booking.lastPaymentRef ? `${booking.lastPaymentBank || 'Bank'} - ${booking.lastPaymentRef}` : '');

  if (lblPayMethodTitle) lblPayMethodTitle.textContent = t.lblPdfPayMethodTitle;
  if (payMethodRow && payMethodText) {
    if ((docType === 'deposit_receipt' || docType === 'receipt') && paymentRefStr) {
      payMethodRow.style.display = 'block';
      payMethodText.textContent = paymentRefStr;
    } else {
      payMethodRow.style.display = 'none';
    }
  }

  // Watermark
  const watermark = document.getElementById('pdfPaidWatermark');
  if (watermark) {
    if (docType === 'deposit_receipt' || (isMonthly && docType === 'deposit_receipt')) {
      watermark.classList.remove('hidden');
      watermark.textContent = lang === 'bm' ? 'DEPOSIT DITERIMA' : 'DEPOSIT PAID';
      watermark.style.color = 'rgba(2, 132, 199, 0.16)';
      watermark.style.borderColor = 'rgba(2, 132, 199, 0.28)';
    } else if (docType === 'receipt' || (isMonthly && currentMonthInv && currentMonthInv.status === 'paid')) {
      watermark.classList.remove('hidden');
      watermark.textContent = lang === 'bm' ? 'TELAH LUNAS' : 'PAID IN FULL';
      watermark.style.color = 'rgba(16, 185, 129, 0.16)';
      watermark.style.borderColor = 'rgba(16, 185, 129, 0.28)';
    } else {
      watermark.classList.add('hidden');
    }
  }

  // 4. Recipient Particulars (Bill To)
  const lblBillToEl = document.getElementById('lblPdfBillTo');
  if (lblBillToEl) lblBillToEl.textContent = t.lblPdfBillTo;

  const companyInputVal = document.getElementById('pdfClientCompanyInput')?.value.trim() || booking.guestCompany || '';
  const clientCompanyEl = document.getElementById('pdfClientCompanyText');
  if (clientCompanyEl) {
    if (companyInputVal) {
      clientCompanyEl.textContent = companyInputVal;
      clientCompanyEl.style.display = 'block';
    } else {
      clientCompanyEl.style.display = 'none';
    }
  }

  const clientNameEl = document.getElementById('pdfClientNameText');
  if (clientNameEl) {
    clientNameEl.textContent = (companyInputVal ? (lang === 'bm' ? 'U.P: ' : 'Attn: ') : '') + (booking.guestName || 'Tetamu');
  }

  const custPhoneEl = document.getElementById('pdfClientPhone');
  if (custPhoneEl) custPhoneEl.textContent = booking.guestPhone || '-';

  const custEmailEl = document.getElementById('pdfClientEmail');
  if (custEmailEl) custEmailEl.textContent = booking.guestEmail || '-';

  const nricEl = document.getElementById('pdfClientNric');
  if (nricEl) nricEl.textContent = booking.guestNric || '-';

  const custAddrEl = document.getElementById('pdfClientAddress');
  const custAddrDiv = document.getElementById('pdfClientAddressDiv');
  if (custAddrDiv && custAddrEl) {
    if (booking.guestAddress) {
      custAddrDiv.style.display = 'block';
      custAddrEl.textContent = booking.guestAddress;
    } else {
      custAddrDiv.style.display = 'none';
    }
  }

  // 5. Homestay / Tenancy Stay Particulars
  const propNameEl = document.getElementById('pdfPropNameText');
  if (propNameEl) propNameEl.textContent = prop.name;

  const propAddrEl = document.getElementById('pdfPropAddressText');
  if (propAddrEl) propAddrEl.textContent = prop.address ? `(${prop.address})` : '';

  const lblCheckInDate = document.getElementById('lblPdfCheckInDate');
  const lblCheckOutDate = document.getElementById('lblPdfCheckOutDate');
  const checkInDateEl = document.getElementById('pdfCheckInDate');
  const checkInTimeEl = document.getElementById('pdfCheckInTime');
  const checkOutDateEl = document.getElementById('pdfCheckOutDate');
  const checkOutTimeEl = document.getElementById('pdfCheckOutTime');
  const durTextEl = document.getElementById('pdfDurationGuestText');
  const guests = booking.guestCount || booking.adults || 1;

  if (isMonthly) {
    if (currentMonthInv) {
      if (lblCheckInDate) lblCheckInDate.textContent = lang === 'bm' ? 'Tempoh Mula:' : 'Period Start:';
      if (lblCheckOutDate) lblCheckOutDate.textContent = lang === 'bm' ? 'Tempoh Akhir:' : 'Period End:';
      if (checkInDateEl) checkInDateEl.textContent = currentMonthInv.periodStart || '-';
      if (checkInTimeEl) checkInTimeEl.textContent = `${lang === 'bm' ? 'Akhir Bayar' : 'Due'}: ${currentMonthInv.dueDate}`;
      if (checkOutDateEl) checkOutDateEl.textContent = currentMonthInv.periodEnd || '-';
      if (checkOutTimeEl) checkOutTimeEl.textContent = currentMonthInv.status === 'paid' ? (lang === 'bm' ? 'LUNAS' : 'PAID') : (lang === 'bm' ? 'BELUM' : 'DUE');
      if (durTextEl) {
        durTextEl.textContent = lang === 'bm'
          ? `Bulan ke-${currentMonthInv.monthIndex} drpd ${booking.monthlyDuration || 6} Bulan • ${guests} Penyewa`
          : `Month ${currentMonthInv.monthIndex} of ${booking.monthlyDuration || 6} • ${guests} Tenant(s)`;
      }
    } else {
      if (lblCheckInDate) lblCheckInDate.textContent = lang === 'bm' ? 'Mula Sewa:' : 'Start Date:';
      if (lblCheckOutDate) lblCheckOutDate.textContent = lang === 'bm' ? 'Tamat Sewa:' : 'End Date:';
      if (checkInDateEl) checkInDateEl.textContent = booking.checkIn || '-';
      if (checkInTimeEl) checkInTimeEl.textContent = lang === 'bm' ? 'Kemasukan' : 'Move-in';
      if (checkOutDateEl) checkOutDateEl.textContent = booking.checkOut || '-';
      if (checkOutTimeEl) checkOutTimeEl.textContent = lang === 'bm' ? 'Serahan Kunci' : 'Handover';
      if (durTextEl) {
        durTextEl.textContent = lang === 'bm'
          ? `${booking.monthlyDuration || 1} Bulan • ${guests} Penyewa`
          : `${booking.monthlyDuration || 1} Month(s) • ${guests} Tenant(s)`;
      }
    }
  } else {
    const nights = booking.nights || 1;
    if (lblCheckInDate) lblCheckInDate.textContent = lang === 'bm' ? 'Masuk:' : 'Check-In:';
    if (lblCheckOutDate) lblCheckOutDate.textContent = lang === 'bm' ? 'Keluar:' : 'Check-Out:';
    if (checkInDateEl) checkInDateEl.textContent = booking.checkIn || '-';
    if (checkInTimeEl) checkInTimeEl.textContent = prop.checkInTime || '3:00 PM';
    if (checkOutDateEl) checkOutDateEl.textContent = booking.checkOut || '-';
    if (checkOutTimeEl) checkOutTimeEl.textContent = prop.checkOutTime || '12:00 PM';
    if (durTextEl) {
      durTextEl.textContent = lang === 'bm' 
        ? `${nights} Malam • ${guests} Tetamu`
        : `${nights} Nights • ${guests} Guests`;
    }
  }

  // 6. Itemized Table
  const tableBody = document.getElementById('pdfTableBody');
  if (tableBody) {
    tableBody.innerHTML = '';

    if (isMonthly) {
      if (currentMonthInv) {
        // Specific Month Invoice Table
        let rIdx = 1;
        const tr1 = document.createElement('tr');
        tr1.style.borderBottom = '1px solid #f1f5f9';
        tr1.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? `Sewa Bulanan (Bulan ke-${currentMonthInv.monthIndex})` : `Monthly Rental (Month ${currentMonthInv.monthIndex})`}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? `Kitaran sewaan dari ${currentMonthInv.periodStart} hingga ${currentMonthInv.periodEnd}` : `Rental billing period from ${currentMonthInv.periodStart} to ${currentMonthInv.periodEnd}`}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">997212</td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Bulan' : 'Mth'}</td>
          <td style="padding:8px 8px; text-align:right;">${Number(currentMonthInv.rentAmount || mRate).toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${Number(currentMonthInv.rentAmount || mRate).toFixed(2)}</td>
        `;
        tableBody.appendChild(tr1);

        if (currentMonthInv.utilityCharges && currentMonthInv.utilityCharges > 0) {
          const tr2 = document.createElement('tr');
          tr2.style.borderBottom = '1px solid #f1f5f9';
          tr2.innerHTML = `
            <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
            <td style="padding:8px 8px;">
              <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Caj Penggunaan Utiliti Sebenar (Air & Elektrik)' : 'Actual Utility Usage Charges (Water & Electricity)'}</strong>
              <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Caj bil utiliti sebenar yang ditambah ke dalam sewa bulanan mengikut penggunaan' : 'Actual utility usage charges added into monthly rental invoice per usage'}</span>
            </td>
            <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">998412</td>
            <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Pakej' : 'Unit'}</td>
            <td style="padding:8px 8px; text-align:right;">${Number(currentMonthInv.utilityCharges).toFixed(2)}</td>
            <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
            <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${Number(currentMonthInv.utilityCharges).toFixed(2)}</td>
          `;
          tableBody.appendChild(tr2);
        }
      } else {
        // Move-in Package Quotation / Move-in Statement
        let rIdx = 1;

        // Row 1: Advance Monthly Rental (1 Month)
        const tr1 = document.createElement('tr');
        tr1.style.borderBottom = '1px solid #f1f5f9';
        tr1.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Sewa Bulan Pertama (Bayaran Pendahuluan)' : '1st Month Advance Rental'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Bayaran sewa bulan pertama dikutip secara pendahuluan (sewa bagi setiap bulan berikutnya diinvois pada awal bulan)' : 'Advance payment for 1st month rental (subsequent months invoiced at the beginning of each month)'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">997212</td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Bulan' : 'Mth'}</td>
          <td style="padding:8px 8px; text-align:right;">${mRate.toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${mRate.toFixed(2)}</td>
        `;
        tableBody.appendChild(tr1);

        // Row 2: Rental Security Deposit (1 Month Rent)
        const tr2 = document.createElement('tr');
        tr2.style.borderBottom = '1px solid #f1f5f9';
        tr2.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Deposit Keselamatan Sewaan (1 Bulan Sewa)' : 'Rental Security Deposit (1 Month Rent)'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Deposit sekuriti 1 bulan sewa (Boleh dipulangkan sepenuhnya pada akhir tempoh sewaan tertakluk kepada keadaan premis)' : 'Security deposit equal to 1 month rent (Fully refundable at end of tenancy subject to unit handover)'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">997219</td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Bulan' : 'Mth'}</td>
          <td style="padding:8px 8px; text-align:right;">${rDep.toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${rDep.toFixed(2)}</td>
        `;
        tableBody.appendChild(tr2);

        // Row 3: Utilities Deposit (RM 300)
        const tr3 = document.createElement('tr');
        tr3.style.borderBottom = '1px solid #f1f5f9';
        tr3.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Deposit Utiliti / Air & Elektrik (Boleh Dipulangkan)' : 'Utilities Deposit / Water & Electricity (Refundable)'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Deposit cagaran utiliti RM300 (Boleh dipulangkan sepenuhnya pada akhir tempoh sewaan tertakluk kepada penyelesaian bil utiliti)' : 'Utility security deposit of RM300 (Fully refundable at end of tenancy subject to utility arrears settlement)'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">997220</td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Pakej' : 'Unit'}</td>
          <td style="padding:8px 8px; text-align:right;">${uDep.toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${uDep.toFixed(2)}</td>
        `;
        tableBody.appendChild(tr3);

        // Row 4: Agreement Fee (if any)
        if (aFee > 0) {
          const tr4 = document.createElement('tr');
          tr4.style.borderBottom = '1px solid #f1f5f9';
          tr4.innerHTML = `
            <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
            <td style="padding:8px 8px;">
              <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Yuran Perjanjian Sewa & Duti Setem' : 'Tenancy Agreement & Legal Stamp Duty'}</strong>
              <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Penyediaan dokumen kontrak perjanjian sewaan & duti setem sah' : 'Tenancy contract preparation, administrative documentation & legal stamp duty'}</span>
            </td>
            <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">998211</td>
            <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00 ${lang === 'bm' ? 'Dok' : 'Doc'}</td>
            <td style="padding:8px 8px; text-align:right;">${aFee.toFixed(2)}</td>
            <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
            <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${aFee.toFixed(2)}</td>
          `;
          tableBody.appendChild(tr4);
        }

        // Row 5: Monthly Utilities Policy Row
        const tr5 = document.createElement('tr');
        tr5.style.background = '#fcfdfd';
        tr5.style.borderBottom = '1px solid #f1f5f9';
        tr5.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rIdx++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Kadar Caj Bil Utiliti Bulanan (Elektrik & Air)' : 'Monthly Utilities Billing Policy (Electricity & Water)'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Bagi sewaan jangka panjang melebihi 1 bulan, penyewa membayar bil utiliti terus kepada pembekal atau ditambah ke dalam invois sewa bulanan mengikut kadar penggunaan sebenar setiap bulan' : 'In long term rental over 1 month, tenant will pay direct or plus in monthly rental per usage charges'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">998412</td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">-</td>
          <td style="padding:8px 8px; text-align:right; font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Kadar Sebenar' : 'Actual Rate'}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#059669;">${lang === 'bm' ? 'IKUT PENGGUNAAN' : 'PER USAGE'}</td>
        `;
        tableBody.appendChild(tr5);
      }
    } else {
      const nights = booking.nights || 1;
      const ratePerNight = nights > 0 ? (booking.baseRate ? booking.baseRate / nights : (booking.totalAmount - (booking.cleaningFee || 0)) / nights) : booking.totalAmount;
      const accommodationTotal = ratePerNight * nights;

      // Row 1: Accommodation Stay
      const tr1 = document.createElement('tr');
      tr1.style.borderBottom = '1px solid #f1f5f9';
      tr1.innerHTML = `
        <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">1</td>
        <td style="padding:8px 8px;">
          <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Sewa Penginapan Homestay (Accommodation Stay)' : 'Homestay Accommodation Rental'}</strong>
          <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? `Penginapan dari ${booking.checkIn} hingga ${booking.checkOut} (${nights} malam)` : `Stay from ${booking.checkIn} to ${booking.checkOut} (${nights} nights)`}</span>
        </td>
        <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">996311</td>
        <td style="padding:8px 8px; text-align:center; font-weight:700;">${nights}.00</td>
        <td style="padding:8px 8px; text-align:right;">${ratePerNight.toFixed(2)}</td>
        <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
        <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${accommodationTotal.toFixed(2)}</td>
      `;
      tableBody.appendChild(tr1);

      // Row 2: Cleaning fee (if any)
      let rowIndex = 2;
      if (booking.cleaningFee && booking.cleaningFee > 0) {
        const tr2 = document.createElement('tr');
        tr2.style.borderBottom = '1px solid #f1f5f9';
        tr2.innerHTML = `
          <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rowIndex++}</td>
          <td style="padding:8px 8px;">
            <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Fi Pembersihan & Pengemasan (Turnover Cleaning Fee)' : 'Sanitized Cleaning & Turnover Fee'}</strong>
            <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Penyediaan cadar bersih, tuala, sanitasi premis dan pengemasan' : 'Fresh linen, bath towels, room sanitization and turnover service'}</span>
          </td>
          <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">998533</td>
          <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00</td>
          <td style="padding:8px 8px; text-align:right;">${Number(booking.cleaningFee).toFixed(2)}</td>
          <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
          <td style="padding:8px 8px; text-align:right; font-weight:800; color:#0f172a;">${Number(booking.cleaningFee).toFixed(2)}</td>
        `;
        tableBody.appendChild(tr2);
      }

      // Row 3: Utilities & WiFi (Included)
      const tr3 = document.createElement('tr');
      tr3.style.background = '#fcfdfd';
      tr3.style.borderBottom = '1px solid #f1f5f9';
      tr3.innerHTML = `
        <td style="padding:8px 8px; text-align:center; font-weight:700; color:#64748b;">${rowIndex++}</td>
        <td style="padding:8px 8px;">
          <strong style="color:#0f172a; display:block;">${lang === 'bm' ? 'Utiliti, Elektrik, Air & WiFi Berkelajuan Tinggi' : 'Utilities, Electricity, Water & High-Speed WiFi'}</strong>
          <span style="font-size:10.5px; color:#64748b;">${lang === 'bm' ? 'Penghawa dingin sepenuhnya, bekalan air bersih dan internet tanpa had' : 'Full air-conditioning, clean water supply and unlimited high-speed WiFi access'}</span>
        </td>
        <td style="padding:8px 8px; text-align:center; font-family:monospace; color:#64748b;">998412</td>
        <td style="padding:8px 8px; text-align:center; font-weight:700;">1.00</td>
        <td style="padding:8px 8px; text-align:right;">0.00</td>
        <td style="padding:8px 8px; text-align:center; color:#64748b;">0.00</td>
        <td style="padding:8px 8px; text-align:right; font-weight:800; color:#059669;">${lang === 'bm' ? 'TERMASUK' : 'INCLUDED'}</td>
      `;
      tableBody.appendChild(tr3);
    }
  }

  // 7. Calculations & Financial Summary
  const subtotalQtyEl = document.getElementById('pdfSubtotalQty');
  const subtotalEl = document.getElementById('pdfValSubtotal');
  const taxSubtotalEl = document.getElementById('pdfValTaxableSubtotal');
  const extraChargesEl = document.getElementById('pdfValExtraCharges');
  const depRow = document.getElementById('pdfRowDeposit');
  const depVal = document.getElementById('pdfValDepositReq');
  const depLbl = document.getElementById('lblPdfDepositReq');
  const paidRow = document.getElementById('pdfRowPaid');
  const paidVal = document.getElementById('pdfValPaid');
  const paidLbl = document.getElementById('lblPdfPaid');
  const balRow = document.getElementById('pdfRowBalance');
  const balVal = document.getElementById('pdfValBalance');
  const balLbl = document.getElementById('lblPdfBalance');
  const grandTotalEl = document.getElementById('pdfValGrandTotal');
  const grandTotalLbl = document.getElementById('lblPdfGrandTotal');
  const wordsTitleLbl = document.getElementById('lblPdfWordsTitle');
  const wordsEl = document.getElementById('pdfTotalAmountInWords');

  if (isMonthly) {
    if (currentMonthInv) {
      const curMonthTotal = Number((currentMonthInv.rentAmount || mRate) + (currentMonthInv.utilityCharges || 0));
      const isPaid = currentMonthInv.status === 'paid';

      if (subtotalQtyEl) subtotalQtyEl.textContent = currentMonthInv.utilityCharges > 0 ? '2.00' : '1.00';
      if (subtotalEl) subtotalEl.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
      if (taxSubtotalEl) taxSubtotalEl.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
      if (extraChargesEl) extraChargesEl.textContent = `${currency} ${(currentMonthInv.utilityCharges || 0).toFixed(2)}`;

      if (depRow) depRow.style.display = 'none';

      if (isPaid) {
        if (paidRow && paidVal && paidLbl) {
          paidRow.style.display = 'flex';
          paidLbl.textContent = lang === 'bm' ? 'Bayaran Diterima (+):' : 'Payment Received (+):';
          paidVal.textContent = `${currency} ${curMonthTotal.toFixed(2)} (${lang === 'bm' ? 'LUNAS' : 'PAID'})`;
          paidVal.style.color = '#059669';
        }
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = lang === 'bm' ? 'Baki Belum Jelas:' : 'Balance Due:';
          balVal.textContent = `${currency} 0.00`;
          balVal.style.color = '#059669';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH SEWA BULANAN DIBAYAR' : 'MONTHLY RENT PAID';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
          grandTotalEl.style.color = '#059669';
        }
      } else {
        if (paidRow) paidRow.style.display = 'none';
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = lang === 'bm' ? 'Baki Perlu Dijelaskan:' : 'Amount Due:';
          balVal.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
          balVal.style.color = '#b45309';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH PERLU DIBAYAR (AMOUNT DUE)' : 'TOTAL AMOUNT DUE';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${curMonthTotal.toFixed(2)}`;
          grandTotalEl.style.color = '#5b21b6';
        }
      }

      if (wordsTitleLbl) wordsTitleLbl.textContent = lang === 'bm' ? 'Jumlah Sewa Bulanan Dalam Perkataan' : 'Monthly Rent Amount in Words';
      if (wordsEl) wordsEl.textContent = numberToWordsMYR(curMonthTotal, lang);

    } else {
      // Move-in Package Quotation / Move-in Statement
      const totalQty = (1 + 1 + 1 + (aFee > 0 ? 1 : 0)).toFixed(2);
      if (subtotalQtyEl) subtotalQtyEl.textContent = totalQty;
      if (subtotalEl) subtotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
      if (taxSubtotalEl) taxSubtotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
      if (extraChargesEl) extraChargesEl.textContent = `${currency} 0.00`;

      const bookingFee = booking.depositPaid > 0 
        ? booking.depositPaid 
        : (booking.depositAmount && booking.depositAmount > 0 ? booking.depositAmount : Math.round(mRate * 0.5));
      const balMoveIn = Math.max(0, totalMoveIn - (docType === 'deposit_receipt' ? depositPaidAmt : (booking.depositPaid > 0 ? booking.depositPaid : bookingFee)));

      if (docType === 'quotation') {
        if (depRow && depVal && depLbl) {
          depRow.style.display = 'flex';
          depLbl.textContent = lang === 'bm' ? 'Bayaran Booking (Kunci Unit):' : 'Booking Fee to Reserve Unit:';
          depVal.textContent = `${currency} ${bookingFee.toFixed(2)}`;
        }
        if (paidRow) paidRow.style.display = 'none';
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = lang === 'bm' ? 'Baki Bayaran Sebelum Kunci/Masuk:' : 'Balance Due before Move-in:';
          balVal.textContent = `${currency} ${balMoveIn.toFixed(2)}`;
          balVal.style.color = '#b45309';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH PAKEJ KEMASUKAN (MOVE-IN)' : 'TOTAL MOVE-IN PACKAGE';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
          grandTotalEl.style.color = '#ea580c';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = lang === 'bm' ? 'Jumlah Pakej Kemasukan Dalam Perkataan' : 'Total Move-in Package in Words';
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(totalMoveIn, lang);

      } else if (docType === 'deposit_receipt') {
        if (depRow) depRow.style.display = 'none';
        if (paidRow && paidVal && paidLbl) {
          paidRow.style.display = 'flex';
          paidLbl.textContent = t.lblPdfDepositPaidRow;
          paidVal.textContent = `(+) ${currency} ${depositPaidAmt.toFixed(2)}`;
          paidVal.style.color = '#059669';
        }
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = lang === 'bm' ? 'Baki Sebelum Serahan Kunci:' : 'Balance Due before Handover:';
          balVal.textContent = `${currency} ${Math.max(0, totalMoveIn - depositPaidAmt).toFixed(2)} (${lang === 'bm' ? 'BELUM JELAS' : 'PENDING'})`;
          balVal.style.color = '#b45309';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH BAYARAN BOOKING DITERIMA' : 'BOOKING DEPOSIT RECEIVED';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${depositPaidAmt.toFixed(2)}`;
          grandTotalEl.style.color = '#0284c7';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleDeposit;
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(depositPaidAmt, lang);

      } else if (docType === 'receipt') {
        if (depRow) depRow.style.display = 'none';
        if (paidRow && paidVal && paidLbl) {
          paidRow.style.display = 'flex';
          paidLbl.textContent = t.lblPdfPaid;
          paidVal.textContent = `${currency} ${totalMoveIn.toFixed(2)} (${lang === 'bm' ? 'PENUH' : 'FULL'})`;
          paidVal.style.color = '#059669';
        }
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = t.lblPdfBalance;
          balVal.textContent = `${currency} 0.00 (${lang === 'bm' ? 'LUNAS / SELESAI' : 'SETTLED'})`;
          balVal.style.color = '#059669';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH BAYARAN PENUH KEMASUKAN' : 'FULL MOVE-IN SETTLEMENT';
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
          grandTotalEl.style.color = '#059669';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(totalMoveIn, lang);

      } else if (docType === 'invoice') {
        if (depRow) depRow.style.display = 'none';
        if (depositPaidAmt > 0) {
          if (paidRow && paidVal && paidLbl) {
            paidRow.style.display = 'flex';
            paidLbl.textContent = t.lblPdfDepositDeductedRow;
            paidVal.textContent = `(-) ${currency} ${depositPaidAmt.toFixed(2)}`;
            paidVal.style.color = '#059669';
          }
          if (balRow && balVal && balLbl) {
            balRow.style.display = 'flex';
            balLbl.textContent = t.lblPdfBalance;
            balVal.textContent = `${currency} ${balAmt.toFixed(2)}`;
            balVal.style.color = balAmt <= 0 ? '#059669' : '#b45309';
          }
          if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalInvoice;
          if (grandTotalEl) {
            grandTotalEl.textContent = `${currency} ${balAmt.toFixed(2)}`;
            grandTotalEl.style.color = balAmt <= 0 ? '#059669' : '#5b21b6';
          }
          if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
          if (wordsEl) wordsEl.textContent = numberToWordsMYR(balAmt, lang);
        } else {
          if (paidRow) paidRow.style.display = 'none';
          if (balRow) balRow.style.display = 'none';
          if (grandTotalLbl) grandTotalLbl.textContent = lang === 'bm' ? 'JUMLAH PAKEJ KEMASUKAN' : 'TOTAL MOVE-IN PACKAGE';
          if (grandTotalEl) {
            grandTotalEl.textContent = `${currency} ${totalMoveIn.toFixed(2)}`;
            grandTotalEl.style.color = '#5b21b6';
          }
          if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
          if (wordsEl) wordsEl.textContent = numberToWordsMYR(totalMoveIn, lang);
        }
      }
    }
  } else {
    // Existing daily booking calculations
    const nights = booking.nights || 1;
    const totalQty = (nights + (booking.cleaningFee && booking.cleaningFee > 0 ? 1 : 0)).toFixed(2);
    if (subtotalQtyEl) subtotalQtyEl.textContent = totalQty;
    if (subtotalEl) subtotalEl.textContent = `${currency} ${Number(grandTotal).toFixed(2)}`;
    if (taxSubtotalEl) taxSubtotalEl.textContent = `${currency} ${Number(grandTotal).toFixed(2)}`;
    if (extraChargesEl) extraChargesEl.textContent = `${currency} 0.00`;

    const depositPct = settings.defaultDepositPct || 30;
    const depReqAmount = booking.depositAmount && booking.depositAmount > 0 ? booking.depositAmount : (grandTotal * depositPct / 100);

    if (docType === 'deposit_receipt') {
      if (depRow) depRow.style.display = 'none';
      if (paidRow && paidVal && paidLbl) {
        paidRow.style.display = 'flex';
        paidLbl.textContent = t.lblPdfDepositPaidRow;
        paidVal.textContent = `(+) ${currency} ${depositPaidAmt.toFixed(2)}`;
        paidVal.style.color = '#059669';
      }
      if (balRow && balVal && balLbl) {
        balRow.style.display = 'flex';
        balLbl.textContent = t.lblPdfBalance;
        balVal.textContent = `${currency} ${balAmt.toFixed(2)} (${lang === 'bm' ? 'BELUM JELAS' : 'PENDING'})`;
        balVal.style.color = '#b45309';
      }
      if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalDepositReceipt;
      if (grandTotalEl) {
        grandTotalEl.textContent = `${currency} ${depositPaidAmt.toFixed(2)}`;
        grandTotalEl.style.color = '#0284c7';
      }
      if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleDeposit;
      if (wordsEl) wordsEl.textContent = numberToWordsMYR(depositPaidAmt, lang);

    } else if (docType === 'receipt') {
      if (depRow) depRow.style.display = 'none';
      if (paidRow && paidVal && paidLbl) {
        paidRow.style.display = 'flex';
        paidLbl.textContent = t.lblPdfPaid;
        paidVal.textContent = `${currency} ${grandTotal.toFixed(2)} (${lang === 'bm' ? 'PENUH' : 'FULL'})`;
        paidVal.style.color = '#059669';
      }
      if (balRow && balVal && balLbl) {
        balRow.style.display = 'flex';
        balLbl.textContent = t.lblPdfBalance;
        balVal.textContent = `${currency} 0.00 (${lang === 'bm' ? 'LUNAS / SELESAI' : 'SETTLED'})`;
        balVal.style.color = '#059669';
      }
      if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalReceipt;
      if (grandTotalEl) {
        grandTotalEl.textContent = `${currency} ${grandTotal.toFixed(2)}`;
        grandTotalEl.style.color = '#059669';
      }
      if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
      if (wordsEl) wordsEl.textContent = numberToWordsMYR(grandTotal, lang);

    } else if (docType === 'invoice') {
      if (depRow) depRow.style.display = 'none';
      if (depositPaidAmt > 0) {
        if (paidRow && paidVal && paidLbl) {
          paidRow.style.display = 'flex';
          paidLbl.textContent = t.lblPdfDepositDeductedRow;
          paidVal.textContent = `(-) ${currency} ${depositPaidAmt.toFixed(2)}`;
          paidVal.style.color = '#059669';
        }
        if (balRow && balVal && balLbl) {
          balRow.style.display = 'flex';
          balLbl.textContent = t.lblPdfBalance;
          balVal.textContent = `${currency} ${balAmt.toFixed(2)}`;
          balVal.style.color = balAmt <= 0 ? '#059669' : '#b45309';
        }
        if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalInvoice;
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${balAmt.toFixed(2)}`;
          grandTotalEl.style.color = balAmt <= 0 ? '#059669' : '#5b21b6';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(balAmt, lang);
      } else {
        if (paidRow) paidRow.style.display = 'none';
        if (balRow) balRow.style.display = 'none';
        if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalInvoiceNoDep;
        if (grandTotalEl) {
          grandTotalEl.textContent = `${currency} ${grandTotal.toFixed(2)}`;
          grandTotalEl.style.color = '#5b21b6';
        }
        if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
        if (wordsEl) wordsEl.textContent = numberToWordsMYR(grandTotal, lang);
      }
    } else {
      // Quotation
      if (depRow && depVal && depLbl) {
        depRow.style.display = 'flex';
        depLbl.textContent = `${t.lblPdfDepositReq} (${depositPct}%):`;
        depVal.textContent = `${currency} ${depReqAmount.toFixed(2)}`;
      }
      if (paidRow) paidRow.style.display = 'none';
      if (balRow) balRow.style.display = 'none';

      if (grandTotalLbl) grandTotalLbl.textContent = t.lblPdfGrandTotalQuotation;
      if (grandTotalEl) {
        grandTotalEl.textContent = `${currency} ${grandTotal.toFixed(2)}`;
        grandTotalEl.style.color = '#ea580c';
      }
      if (wordsTitleLbl) wordsTitleLbl.textContent = t.lblPdfWordsTitleGeneral;
      if (wordsEl) wordsEl.textContent = numberToWordsMYR(grandTotal, lang);
    }
  }

  // 8. Terms & Notes
  const termsList = document.getElementById('pdfTermsList');
  if (termsList) {
    termsList.innerHTML = '';
    let list;
    if (isMonthly) {
      if (currentMonthInv) {
        list = t.termsInvoiceMonthly || PDF_DOC_I18N.bm.termsInvoiceMonthly;
      } else {
        list = docType === 'quotation' 
          ? (t.termsQuotationMonthly || PDF_DOC_I18N.bm.termsQuotationMonthly)
          : (docType === 'deposit_receipt' ? t.termsDepositReceipt : (docType === 'invoice' ? (t.termsInvoiceMonthly || PDF_DOC_I18N.bm.termsInvoiceMonthly) : t.termsReceipt));
      }
    } else {
      list = docType === 'deposit_receipt' 
        ? t.termsDepositReceipt 
        : docType === 'quotation' 
          ? t.termsQuotation 
          : docType === 'invoice' 
            ? t.termsInvoice 
            : t.termsReceipt;
    }
    list.forEach(item => {
      const li = document.createElement('li');
      li.textContent = item;
      termsList.appendChild(li);
    });
  }

  // 9. Bank Details
  const bankNameEl = document.getElementById('pdfBankName');
  if (bankNameEl) bankNameEl.textContent = settings.bankName || 'Maybank';

  const bankAccNumEl = document.getElementById('pdfBankAccNum');
  if (bankAccNumEl) bankAccNumEl.textContent = settings.bankAccNum || '5123 4567 8901';

  const bankAccHolderEl = document.getElementById('pdfBankAccHolder');
  if (bankAccHolderEl) bankAccHolderEl.textContent = settings.bankAccHolder || settings.businessName || 'Homestay Host';

  const bankBranchEl = document.getElementById('pdfBankBranch');
  if (bankBranchEl) bankBranchEl.textContent = settings.bankBranch || 'Changlun / Cawangan Utama';

  const duitNowEl = document.getElementById('pdfDuitNow');
  const duitNowRow = document.getElementById('pdfDuitNowRow');
  if (duitNowRow && duitNowEl) {
    if (settings.duitNow) {
      duitNowRow.style.display = 'flex';
      duitNowEl.textContent = settings.duitNow;
    } else {
      duitNowRow.style.display = 'none';
    }
  }

  // Document UID
  const uidEl = document.getElementById('pdfDocUid');
  if (uidEl) uidEl.textContent = `UID: MHY-${year}-${idShort}`;

  // Translated Labels
  const thItemEl = document.getElementById('thPdfItem');
  if (thItemEl) thItemEl.textContent = t.thPdfItem;

  const thHsnEl = document.getElementById('thPdfHsn');
  if (thHsnEl) thHsnEl.textContent = t.thPdfHsn;

  const thQtyEl = document.getElementById('thPdfQty');
  if (thQtyEl) thQtyEl.textContent = t.thPdfQty;

  const thRateEl = document.getElementById('thPdfRate');
  if (thRateEl) thRateEl.textContent = `${t.thPdfRate} (${currency})`;

  const thTaxEl = document.getElementById('thPdfTax');
  if (thTaxEl) thTaxEl.textContent = `${t.thPdfTax} (${currency})`;

  const thAmtEl = document.getElementById('thPdfAmount');
  if (thAmtEl) thAmtEl.textContent = `${t.thPdfAmount} (${currency})`;

  const subTotalTableLbl = document.getElementById('lblPdfSubTotalTable');
  if (subTotalTableLbl) subTotalTableLbl.textContent = t.lblPdfSubTotalTable;

  const extraChargesLbl = document.getElementById('lblPdfExtraCharges');
  if (extraChargesLbl) extraChargesLbl.textContent = t.lblPdfExtraCharges;

  const taxableLbl = document.getElementById('lblPdfTaxableAmount');
  if (taxableLbl) taxableLbl.textContent = t.lblPdfTaxableAmount;

  const cgstLbl = document.getElementById('lblPdfCgst');
  if (cgstLbl) cgstLbl.textContent = t.lblPdfCgst;

  const sgstLbl = document.getElementById('lblPdfSgst');
  if (sgstLbl) sgstLbl.textContent = t.lblPdfSgst;

  const discLbl = document.getElementById('lblPdfDiscount');
  if (discLbl) discLbl.textContent = t.lblPdfDiscount;

  const bankTitleLbl = document.getElementById('lblPdfBankTitle');
  if (bankTitleLbl) bankTitleLbl.textContent = t.lblPdfBankTitle;

  const accHolderLbl = document.getElementById('lblPdfAccHolder');
  if (accHolderLbl) accHolderLbl.textContent = t.lblPdfAccHolder;

  const accNumLbl = document.getElementById('lblPdfAccNum');
  if (accNumLbl) accNumLbl.textContent = t.lblPdfAccNum;

  const bankNameLbl = document.getElementById('lblPdfBankName');
  if (bankNameLbl) bankNameLbl.textContent = t.lblPdfBankName;

  const branchLbl = document.getElementById('lblPdfBranch');
  if (branchLbl) branchLbl.textContent = t.lblPdfBranch;

  const duitNowLbl = document.getElementById('lblPdfDuitNow');
  if (duitNowLbl) duitNowLbl.textContent = t.lblPdfDuitNow;

  const termsTitleLbl = document.getElementById('lblPdfTermsTitle');
  if (termsTitleLbl) termsTitleLbl.textContent = t.lblPdfTermsTitle;

  const authLbl = document.getElementById('lblPdfAuthorized');
  if (authLbl) authLbl.textContent = t.lblPdfAuthorized;

  const sigTextEl = document.getElementById('pdfSignatureText');
  if (sigTextEl) sigTextEl.textContent = settings.ownerName || (lang === 'bm' ? 'Pengurus Homestay' : 'Homestay Manager');

  // WhatsApp Prompt Banner Translations
  const waPromptTitle = document.getElementById('txtWaPromptTitle');
  if (waPromptTitle) waPromptTitle.textContent = t.txtWaPromptTitle;

  const waPromptSub = document.getElementById('txtWaPromptSub');
  if (waPromptSub) waPromptSub.textContent = t.txtWaPromptSub;

  const btnPromptYes = document.getElementById('txtBtnPromptYes');
  if (btnPromptYes) btnPromptYes.textContent = t.txtBtnPromptYes;

  const btnPromptNo = document.getElementById('txtBtnPromptNo');
  if (btnPromptNo) btnPromptNo.textContent = t.txtBtnPromptNo;
}

function printPdfDocument() {
  const isBM = (appState.activePdfLang || appState.settings.language) === 'bm';
  showToast(isBM ? 'Membuka dialog cetak... Sila pilih "Save as PDF" / "Simpan sebagai PDF".' : 'Opening print dialog... Please select "Save as PDF".');
  setTimeout(() => {
    window.print();
  }, 350);
}

/**
 * Helper: Extract structured metadata and filenames for current PDF document
 */
function getPdfDocMeta() {
  const booking = appState.activePdfBooking;
  if (!booking) return null;
  const docType = appState.activePdfDocType || 'quotation';
  const lang = appState.activePdfLang || appState.settings.language || 'bm';
  const isBM = lang === 'bm';
  const prop = getPropertyById(booking.propertyId) || { name: 'Homestay Unit' };
  const year = new Date().getFullYear();
  const idShort = (booking.id || '').replace(/\D/g, '').slice(-4) || '1088';
  const isMonthly = (booking.rentalType === 'monthly');
  const activeMonth = appState.activePdfMonthIndex;

  let prefix = 'QT';
  let docTitle = isBM ? 'Sebut Harga Rasmi' : 'Official Quotation';

  if (isMonthly) {
    if (activeMonth !== null && activeMonth !== undefined) {
      if (docType === 'receipt') {
        prefix = `REC_M${activeMonth}`;
        docTitle = isBM ? `Resit Bayaran Sewa Bulan ke-${activeMonth}` : `Month ${activeMonth} Rent Payment Receipt`;
      } else {
        prefix = `INV_M${activeMonth}`;
        docTitle = isBM ? `Invois Sewa Bulan ke-${activeMonth}` : `Month ${activeMonth} Rent Invoice`;
      }
    } else {
      if (docType === 'invoice') {
        prefix = 'INV_M';
        docTitle = isBM ? 'Invois Kemasukan Sewaan Bulanan' : 'Monthly Tenancy Move-in Invoice';
      } else if (docType === 'deposit_receipt') {
        prefix = 'REC_BOOK_M';
        docTitle = isBM ? 'Resit Bayaran Booking Sewaan' : 'Tenancy Booking Receipt';
      } else if (docType === 'receipt') {
        prefix = 'REC_M';
        docTitle = isBM ? 'Resit Rasmi Bayaran Kemasukan' : 'Move-in Payment Receipt';
      } else {
        prefix = 'QUO_M';
        docTitle = isBM ? 'Sebut Harga Pakej Kemasukan Sewaan Bulanan' : 'Monthly Tenancy Move-In Quotation';
      }
    }
  } else {
    if (docType === 'invoice') {
      prefix = 'INV';
      docTitle = isBM ? 'Invois Rasmi' : 'Official Invoice';
    } else if (docType === 'deposit_receipt') {
      prefix = 'REC_DEP';
      docTitle = isBM ? 'Resit Bayaran Deposit' : 'Deposit Payment Receipt';
    } else if (docType === 'receipt') {
      prefix = 'REC';
      docTitle = isBM ? 'Resit Bayaran Penuh' : 'Official Payment Receipt';
    }
  }

  const cleanName = (booking.guestName || 'Tetamu').replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `${prefix}_${year}_${idShort}_${cleanName}.pdf`;
  const fullDocNo = `${prefix.replace(/_/g, '-')}-${year}-${idShort}`;
  return { booking, docType, lang, isBM, prop, year, idShort, prefix, docTitle, cleanName, fileName, fullDocNo, isMonthly, activeMonth };
}

/**
 * Reliable PDF Blob generator using direct, scroll-safe A4 element capture.
 * Guarantees standard 794px A4 layout, zero blank pages, zero horizontal cutoffs on PC & Mobile!
 */
function generatePdfBlob(onSuccess, onError) {
  const element = document.getElementById('printablePdfSheet');
  if (!element) {
    if (onError) onError(new Error('Elemen PDF tidak ditemui'));
    return;
  }

  const meta = getPdfDocMeta();
  const fileName = meta ? meta.fileName : 'Dokumen.pdf';

  if (typeof window.html2pdf === 'function') {
    // 1. Capture current scroll offsets so we can restore them seamlessly
    const modalBody = document.querySelector('#pdfDocModal .modal-body') || document.querySelector('.modal-body');
    const savedModalScroll = modalBody ? modalBody.scrollTop : 0;
    const savedWinScrollY = window.scrollY || window.pageYOffset || 0;
    const savedWinScrollX = window.scrollX || window.pageXOffset || 0;

    // 2. Temporarily reset scroll to 0 so html2canvas renders from exact top without viewport clipping
    if (modalBody) modalBody.scrollTop = 0;
    window.scrollTo(0, 0);

    // 3. Temporarily apply compact A4 1-page rendering class & enforce standard 794px width
    element.classList.add('pdf-rendering-mode');

    // 4. Configure html2pdf with zero margins and origin coordinates
    const opt = {
      margin: 0,
      filename: fileName,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        logging: false,
        scrollY: 0,
        scrollX: 0,
        backgroundColor: '#ffffff'
      },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    let resolved = false;
    const restore = () => {
      element.classList.remove('pdf-rendering-mode');
      if (modalBody) modalBody.scrollTop = savedModalScroll;
      window.scrollTo(savedWinScrollX, savedWinScrollY);
    };

    const timer = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        restore();
        console.warn('html2pdf took longer than 6s, triggering fallback');
        if (onError) onError(new Error('timeout'));
      }
    }, 6000);

    window.html2pdf().set(opt).from(element).output('blob').then(blob => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        restore();
        if (onSuccess) onSuccess(blob, fileName);
      }
    }).catch(err => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        restore();
        console.warn('html2pdf generation error:', err);
        if (onError) onError(err);
      }
    });
  } else {
    if (onError) onError(new Error('html2pdf_not_loaded'));
  }
}

/**
 * Direct file download as standard PDF with interactive feedback card
 */
function downloadPdfDocument() {
  const meta = getPdfDocMeta();
  if (!meta) return;

  const isBM = meta.isBM;
  const fileName = meta.fileName;
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  const statusCard = document.getElementById('pdfActionStatusCard');

  if (statusCard) {
    statusCard.style.display = 'block';
    statusCard.innerHTML = `
      <div style="background:#eff6ff; border:1.5px solid #3b82f6; border-radius:12px; padding:16px; display:flex; align-items:center; gap:12px; box-shadow:0 4px 12px rgba(59,130,246,0.1);">
        <div class="loading-spinner" style="width:26px; height:26px; border-width:3px; border-color:#3b82f6; border-top-color:transparent; flex-shrink:0;"></div>
        <div>
          <strong style="color:#1d4ed8; font-size:13.5px; display:block;">${isBM ? 'Sedang Menjana Fail PDF Standard A4...' : 'Generating Official A4 PDF Document...'}</strong>
          <span style="font-size:11.5px; color:#2563eb;">${isBM ? `Fail "${fileName}" sedang diproses untuk muat turun terus ke komputer/peranti anda.` : `Processing "${fileName}" for download.`}</span>
        </div>
      </div>
    `;
    statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  showToast(isBM ? 'Menjana fail PDF rasmi...' : 'Generating official PDF...');

  generatePdfBlob((blob, fName) => {
    const blobUrl = URL.createObjectURL(blob);

    // 1. Direct Anchor Download (Guaranteed download to user's Downloads folder)
    const downloadAnchor = document.createElement('a');
    downloadAnchor.href = blobUrl;
    downloadAnchor.download = fName;
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    setTimeout(() => {
      document.body.removeChild(downloadAnchor);
    }, 1500);

    // 2. Rich Interactive Status Card with Direct Links & Shortcuts
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#ecfdf5; border:2px solid #10b981; border-radius:12px; padding:18px; box-shadow:0 6px 16px rgba(16,185,129,0.12);">
          <div style="display:flex; align-items:flex-start; gap:14px; margin-bottom:14px;">
            <div style="width:44px; height:44px; border-radius:50%; background:#10b981; color:#fff; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0; box-shadow:0 3px 8px rgba(16,185,129,0.35);">
              <i class="fa-solid fa-circle-check"></i>
            </div>
            <div style="flex:1;">
              <h4 style="margin:0; color:#065f46; font-size:15px; font-weight:800;">
                ${isBM ? '✅ Fail PDF Berjaya Dijana & Dimuat Turun!' : '✅ PDF Document Generated & Downloaded!'}
              </h4>
              <p style="margin:4px 0 0 0; font-size:12px; color:#047857; line-height:1.5;">
                ${isBM 
                  ? `Fail telah disimpan terus ke folder <strong>Downloads</strong> komputer / telefon anda sebagai:<br><strong style="font-family:monospace; color:#0f172a; background:#e2e8f0; padding:2px 6px; border-radius:4px;">${fName}</strong>`
                  : `File saved directly into your <strong>Downloads</strong> folder as:<br><strong style="font-family:monospace; color:#0f172a; background:#e2e8f0; padding:2px 6px; border-radius:4px;">${fName}</strong>`}
              </p>
              ${!isMobile ? `
                <div style="margin-top:6px; font-size:11px; color:#64748b;">
                  ${isBM ? '💡 Tip: Tekan <kbd style="background:#f1f5f9; border:1px solid #cbd5e1; padding:1px 5px; border-radius:3px;">Ctrl</kbd> + <kbd style="background:#f1f5f9; border:1px solid #cbd5e1; padding:1px 5px; border-radius:3px;">J</kbd> (Windows) atau semak ikon muat turun pelayar.' : '💡 Tip: Press Ctrl + J to see downloaded files.'}
                </div>
              ` : `
                <div style="margin-top:8px; font-size:11.5px; color:#14532d; background:#dcfce7; border:1px solid #86efac; border-radius:8px; padding:8px 12px; line-height:1.5;">
                  📱 <strong>Pengguna Telefon:</strong> Fail PDF telah disimpan ke folder <strong>Downloads</strong> peranti anda. Anda boleh membukanya daripada notifikasi muat turun di bar atas skrin atau kongsi terus ke WhatsApp.
                </div>
              `}
            </div>
          </div>
          <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
            ${!isMobile ? `
              <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:linear-gradient(135deg, #0284c7, #0369a1);">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? '👁️ Buka & Lihat PDF Sekarang' : '👁️ View PDF Now'}
              </a>
              <a href="${blobUrl}" download="${fName}" class="btn btn-outline btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; color:#065f46; border-color:#059669; background:#fff;">
                <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun Semula' : 'Download Again'}
              </a>
            ` : `
              <a href="${blobUrl}" download="${fName}" class="btn btn-primary btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:linear-gradient(135deg, #ea580c, #c2410c);">
                <i class="fa-solid fa-file-arrow-down"></i> ${isBM ? '📥 Muat Turun Semula' : '📥 Download Again'}
              </a>
            `}
            <button type="button" class="btn btn-whatsapp btn-sm" id="btnStatusCardWa" style="font-weight:800; display:inline-flex; align-items:center; gap:6px;">
              <i class="fa-brands fa-whatsapp"></i> ${isBM ? '📲 Hantar ke WhatsApp Tetamu' : 'Send via WhatsApp'}
            </button>
            <button type="button" class="btn btn-outline btn-sm" id="btnDismissStatusCard" style="font-size:11px; background:#fff; color:#64748b; margin-left:auto;">
              ${isBM ? 'Tutup' : 'Dismiss'}
            </button>
          </div>
        </div>
      `;
      document.getElementById('btnStatusCardWa')?.addEventListener('click', sharePdfViaWhatsApp);
      document.getElementById('btnDismissStatusCard')?.addEventListener('click', () => {
        statusCard.style.display = 'none';
      });
      statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    showToast(isBM 
      ? `✅ Fail dimuat turun: "${fName}" (Disimpan di Downloads)` 
      : `✅ Downloaded: "${fName}"`, 6000);

  }, (err) => {
    console.warn('PDF blob generation error, fallback to print:', err);
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#fffbeb; border:1.5px solid #f59e0b; border-radius:12px; padding:16px;">
          <strong style="color:#b45309; display:block; font-size:13.5px;">⚠️ Menggunakan Cetakan Sistem Pelayar</strong>
          <p style="margin:4px 0 10px 0; font-size:12px; color:#92400e;">
            ${isBM 
              ? 'Tetingkap cetakan dibuka. Sila pilih <strong>"Save as PDF" / "Simpan sebagai PDF"</strong> pada pilihan Destination/Pencetak untuk menyimpan fail.'
              : 'Print dialog opened. Please select "Save as PDF" to save the file.'}
          </p>
          <button type="button" class="btn btn-primary btn-sm" id="btnRetryPrint" style="font-weight:700;">
            <i class="fa-solid fa-print"></i> ${isBM ? 'Buka Cetak / Simpan PDF' : 'Print / Save as PDF'}
          </button>
        </div>
      `;
      document.getElementById('btnRetryPrint')?.addEventListener('click', () => window.print());
    }
    window.print();
  });
}

/**
 * Open generated PDF directly in a new browser tab for immediate viewing/printing
 */
function viewPdfInNewTab() {
  const meta = getPdfDocMeta();
  if (!meta) return;

  const isBM = meta.isBM;
  const fileName = meta.fileName;
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  // On Mobile: Browsers cannot render blob: PDFs in new tabs (results in blank white tab).
  // Automatically trigger download so phone opens it in native PDF viewer.
  if (isMobile) {
    showToast(isBM ? 'Menjana & memuat turun fail PDF untuk telefon...' : 'Generating & downloading PDF for mobile...');
    downloadPdfDocument();
    return;
  }

  // Pre-open window synchronously to avoid popup blocker
  let newTab = null;
  try {
    newTab = window.open('about:blank', '_blank');
    if (newTab) {
      newTab.document.write(`
        <!DOCTYPE html><html><body style="font-family:system-ui,sans-serif; text-align:center; padding:50px; background:#f8fafc; color:#0f172a;">
          <h3 style="color:#0284c7;">Menjana Fail PDF...</h3><p style="color:#64748b;">Sila tunggu sebentar, dokumen akan dibuka serta-merta.</p>
        </body></html>
      `);
    }
  } catch(e) {
    console.warn('Could not pre-open new tab:', e);
  }

  showToast(isBM ? 'Menjana PDF untuk dibuka di tab baru...' : 'Generating PDF to open in new tab...');

  generatePdfBlob((blob, fName) => {
    const blobUrl = URL.createObjectURL(blob);
    if (newTab && !newTab.closed) {
      newTab.location.href = blobUrl;
    } else {
      window.open(blobUrl, '_blank');
    }

    const statusCard = document.getElementById('pdfActionStatusCard');
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#f0fdf4; border:1.5px solid #10b981; border-radius:12px; padding:14px 16px; display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap;">
          <div style="display:flex; align-items:center; gap:10px;">
            <i class="fa-solid fa-circle-check" style="color:#059669; font-size:20px;"></i>
            <span style="font-size:12.5px; color:#065f46; font-weight:700;">
              ${isBM ? 'PDF telah dibuka di tab baru pelayar anda!' : 'PDF opened in a new browser tab!'}
            </span>
          </div>
          <div style="display:flex; gap:6px;">
            <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-xs" style="font-weight:700; text-decoration:none;">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? 'Klik Sini Jika Tab Tidak Terbuka' : 'Click Here If Tab Did Not Open'}
            </a>
            <a href="${blobUrl}" download="${fName}" class="btn btn-outline btn-xs" style="font-weight:700; text-decoration:none; background:#fff;">
              <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun' : 'Download'}
            </a>
          </div>
        </div>
      `;
    }
    showToast(isBM ? 'PDF dibuka di tab baru pelayar anda!' : 'PDF opened in a new browser tab!');
  }, (err) => {
    console.warn('Error generating PDF for new tab:', err);
    window.print();
  });
}

/**
 * Share PDF directly to WhatsApp with file attachment & unblockable popup prevention
 */
function sharePdfViaWhatsApp() {
  const meta = getPdfDocMeta();
  if (!meta) return;

  const { booking, docType, lang, isBM, prop, fullDocNo, fileName, docTitle } = meta;
  const currency = appState.settings.currency || 'RM';
  const grandTotal = booking.totalAmount || 0;

  let depositPaidAmt = parseFloat(document.getElementById('pdfDepositAmountInput')?.value);
  if (isNaN(depositPaidAmt)) {
    depositPaidAmt = Number(booking.depositPaid || (booking.payments || []).reduce((sum, p) => sum + (p.amount || 0), 0) || 0);
  }
  if (depositPaidAmt === 0 && (docType === 'deposit_receipt' || booking.status === 'booked')) {
    depositPaidAmt = Number(booking.depositAmount || Math.round(grandTotal * (appState.settings.defaultDepositPct || 30) / 100));
  }
  const balAmt = Math.max(0, grandTotal - depositPaidAmt);

  const isMonthly = (booking.rentalType === 'monthly');
  const activeMonth = appState.activePdfMonthIndex;

  let message = '';
  if (isMonthly) {
    if (activeMonth !== null && activeMonth !== undefined) {
      const inv = (booking.monthlyInvoices || []).find(x => x.monthIndex === activeMonth);
      const invTotal = inv ? (inv.totalAmount || inv.rentAmount) : (booking.monthlyRate || 0);
      const isPaid = inv && inv.status === 'paid';
      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi bayaran sewaan *Bulan ke-${activeMonth}* di *${prop.name}* (${inv ? `${inv.periodStart} → ${inv.periodEnd}` : ''}).\n\n💰 *Jumlah: ${currency} ${invTotal.toFixed(2)}* (${isPaid ? 'TELAH DIBAYAR' : `Tarikh Akhir: ${inv ? inv.dueDate : '-'}`})\n\n📄 *Sila rujuk fail PDF yang dilampirkan.* Terima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) for *Month ${activeMonth}* rental at *${prop.name}* (${inv ? `${inv.periodStart} → ${inv.periodEnd}` : ''}).\n\n💰 *Amount: ${currency} ${invTotal.toFixed(2)}* (${isPaid ? 'PAID' : `Due Date: ${inv ? inv.dueDate : '-'}`})\n\n📄 *Please refer to the attached PDF file.* Thank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    } else if (docType === 'deposit_receipt') {
      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi pengesahan bayaran booking sewaan bulanan di *${prop.name}* (${booking.monthlyStart || booking.checkIn}, tempoh ${booking.monthlyDuration || 6} Bulan).\n\n💰 *Rekod Bayaran:*\n• Pakej Kemasukan: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Booking Diterima:* *${currency} ${depositPaidAmt.toFixed(2)}*\n• 💳 *Baki Sebelum Serahan Kunci:* *${currency} ${balAmt.toFixed(2)}*\n\n📄 *Sila rujuk fail PDF yang dilampirkan.*\n\nTerima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) confirming your booking payment for monthly tenancy at *${prop.name}* (${booking.monthlyStart || booking.checkIn}, duration ${booking.monthlyDuration || 6} Months).\n\n💰 *Payment Record:*\n• Move-in Package: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Booking Received:* *${currency} ${depositPaidAmt.toFixed(2)}*\n• 💳 *Balance Due upon Key Handover:* *${currency} ${balAmt.toFixed(2)}*\n\n📄 *Please refer to the attached PDF file.*\n\nThank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    } else {
      // Monthly Move-in Quotation or Move-in Invoice
      const mRate = booking.monthlyRate || 0;
      const rDep = booking.rentalDeposit !== undefined ? booking.rentalDeposit : mRate;
      const uDep = booking.utilitiesDeposit !== undefined ? booking.utilitiesDeposit : 300;
      const aFee = booking.agreementFee !== undefined ? booking.agreementFee : 0;
      const totalMoveIn = mRate + rDep + uDep + aFee;
      const bookingFee = (booking.depositPaid > 0) ? booking.depositPaid : Math.round(mRate * 0.5);
      const balHandover = Math.max(0, totalMoveIn - bookingFee);

      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi sewaan bulanan di *${prop.name}* (${booking.monthlyStart || booking.checkIn}, tempoh ${booking.monthlyDuration || 6} Bulan).\n\n💰 *Perincian Pakej Kemasukan (Move-In):*\n• Sewa Bulan Pertama (Pendahuluan): ${currency} ${mRate.toFixed(2)}\n• Deposit Keselamatan Sewa (1 Bulan Sewa): ${currency} ${rDep.toFixed(2)}\n• Deposit Utiliti (Air & Elektrik): ${currency} ${uDep.toFixed(2)}\n${aFee > 0 ? `• Yuran Perjanjian Sewa & Duti Setem: ${currency} ${aFee.toFixed(2)}\n` : ''}----------------------------------------\n💵 *Jumlah Bayaran Kemasukan:* *${currency} ${totalMoveIn.toFixed(2)}*\n🔒 *Bayaran Booking Diperlukan untuk Kunci Unit:* ${currency} ${bookingFee.toFixed(2)}\n⏳ *Baki Sebelum Serahan Kunci:* ${currency} ${balHandover.toFixed(2)}\n\n📌 *Syarat & Polisi Sewaan Bulanan:*\n1. Bayaran sewa bulanan dikutip secara pendahuluan (advance) pada awal setiap bulan sewaan melalui Invois Rasmi.\n2. Bagi sewaan jangka panjang melebihi 1 bulan, bil utiliti (elektrik & air) adalah mengikut kadar penggunaan bulanan sebenar (dibayar terus oleh penyewa atau dimasukkan ke dalam invois sewa bulanan).\n3. Deposit Keselamatan (1 bulan sewa) dan Deposit Utiliti (RM 300) akan dipulangkan sepenuhnya pada akhir tempoh sewaan tertakluk kepada bil utiliti dan pemeriksaan unit.\n\n📄 *Sila rujuk fail PDF yang dilampirkan.*\n\nTerima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) for the monthly tenancy at *${prop.name}* (${booking.monthlyStart || booking.checkIn}, duration ${booking.monthlyDuration || 6} Months).\n\n💰 *Move-in Initial Package Breakdown:*\n• 1st Month Advance Rent: ${currency} ${mRate.toFixed(2)}\n• Rental Security Deposit (1 Month Rent): ${currency} ${rDep.toFixed(2)}\n• Utilities Deposit (Electricity & Water): ${currency} ${uDep.toFixed(2)}\n${aFee > 0 ? `• Tenancy Agreement & Stamp Duty: ${currency} ${aFee.toFixed(2)}\n` : ''}----------------------------------------\n💵 *Total Move-in Package:* *${currency} ${totalMoveIn.toFixed(2)}*\n🔒 *Booking Fee to Reserve Unit:* ${currency} ${bookingFee.toFixed(2)}\n⏳ *Balance Due upon Key Handover:* ${currency} ${balHandover.toFixed(2)}\n\n📌 *Monthly Tenancy Terms & Policies:*\n1. Monthly rental is collected in advance at the beginning of each rental month via official invoice.\n2. In long-term rentals over 1 month, utilities (electricity & water) are charged per actual usage (paid directly by tenant or added into monthly invoice).\n3. Rental Deposit (1 month rent) and Utilities Deposit (RM 300) are fully refundable at the end of tenancy subject to utility clearance and unit inspection.\n\n📄 *Please refer to the attached PDF file.*\n\nThank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    }
  } else {
    if (docType === 'deposit_receipt') {
      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi bayaran deposit penginapan di *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n💰 *Rekod Bayaran:*\n• Jumlah Pakej: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Deposit Diterima:* *${currency} ${depositPaidAmt.toFixed(2)}*\n• 💳 *Baki Sebelum Masuk:* *${currency} ${balAmt.toFixed(2)}*\n\n📄 *Sila rujuk fail PDF yang dilampirkan.* Sila maklumkan kepada kami sekiranya pihak kewangan / pejabat anda memerlukan sebarang pengesahan lanjut.\n\nTerima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) confirming your deposit payment for the stay at *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n💰 *Payment Record:*\n• Total Package: ${currency} ${grandTotal.toFixed(2)}\n• ✅ *Deposit Received:* *${currency} ${depositPaidAmt.toFixed(2)}*\n• 💳 *Remaining Balance:* *${currency} ${balAmt.toFixed(2)}*\n\n📄 *Please refer to the attached PDF file.* Kindly let us know if your accounts / finance department requires any further verification.\n\nThank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    } else {
      message = isBM
        ? `Salam Sejahtera ${booking.guestName}.\n\nDilampirkan dokumen rasmi *${docTitle}* (*No: ${fullDocNo}*) bagi penginapan di *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n📄 *Sila rujuk fail PDF yang dilampirkan.* Sila maklumkan kepada kami sekiranya pihak kewangan / pejabat anda memerlukan sebarang pengesahan lanjut.\n\nTerima kasih.\n*${appState.settings.businessName || 'Pengurusan Homestay'}*`
        : `Greetings ${booking.guestName}.\n\nAttached is the official *${docTitle}* (*Ref: ${fullDocNo}*) for your stay at *${prop.name}* (${booking.checkIn} → ${booking.checkOut}).\n\n📄 *Please refer to the attached PDF file.* Kindly let us know if your accounts / finance department requires any further verification.\n\nThank you.\n*${appState.settings.businessName || 'Homestay Management'}*`;
    }
  }

  // Copy text to clipboard
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(message);
  }

  const cleanPhone = normalizePhoneNumber(booking.guestPhone);
  const waUrl = cleanPhone 
    ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`
    : `https://wa.me/?text=${encodeURIComponent(message)}`;

  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  let waWindow = null;

  // ON DESKTOP: Pre-open the window synchronously within the user click gesture!
  // This guarantees that browser popup blockers will NEVER block WhatsApp Web!
  if (!isMobile) {
    try {
      waWindow = window.open('about:blank', '_blank');
      if (waWindow) {
        waWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head><title>Menghubungkan ke WhatsApp...</title></head>
          <body style="font-family:system-ui,sans-serif; text-align:center; padding:50px; background:#f8fafc; color:#0f172a;">
            <div style="max-width:480px; margin:0 auto; background:#fff; padding:30px; border-radius:16px; box-shadow:0 4px 20px rgba(0,0,0,0.08); border:1px solid #e2e8f0;">
              <div style="font-size:36px; margin-bottom:12px;">📲</div>
              <h2 style="color:#15803d; margin:0 0 8px 0; font-size:20px;">Menghubungkan ke WhatsApp Tetamu...</h2>
              <p style="color:#64748b; font-size:13px; line-height:1.5; margin:0 0 16px 0;">Fail PDF sedang dijana dan dimuat turun ke komputer anda.</p>
              <div style="display:inline-block; border:3px solid #e2e8f0; border-top-color:#15803d; border-radius:50%; width:24px; height:24px; animation:spin 0.8s linear infinite;"></div>
              <style>@keyframes spin { to { transform: rotate(360deg); } }</style>
            </div>
          </body>
          </html>
        `);
      }
    } catch(e) {
      console.warn('Could not pre-open blank window:', e);
    }
  }

  const statusCard = document.getElementById('pdfActionStatusCard');
  if (statusCard) {
    statusCard.style.display = 'block';
    statusCard.innerHTML = `
      <div style="background:#eff6ff; border:1.5px solid #3b82f6; border-radius:12px; padding:16px; display:flex; align-items:center; gap:12px; box-shadow:0 4px 12px rgba(59,130,246,0.1);">
        <div class="loading-spinner" style="width:26px; height:26px; border-width:3px; border-color:#3b82f6; border-top-color:transparent; flex-shrink:0;"></div>
        <div>
          <strong style="color:#1d4ed8; font-size:13.5px; display:block;">${isBM ? 'Menjana Fail PDF & Menghubungkan ke WhatsApp...' : 'Generating PDF & Connecting to WhatsApp...'}</strong>
          <span style="font-size:11.5px; color:#2563eb;">${isBM ? 'Sila tunggu sebentar, fail sedang disediakan...' : 'Please wait a moment...'}</span>
        </div>
      </div>
    `;
    statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  showToast(isBM ? 'Menjana fail PDF dan menghubungkan ke WhatsApp...' : 'Generating PDF & connecting to WhatsApp...');

  generatePdfBlob(async (pdfBlob, fName) => {
    const pdfFile = new File([pdfBlob], fName, { type: 'application/pdf' });
    const blobUrl = URL.createObjectURL(pdfBlob);

    // 1. If mobile browser supports Web Share API Level 2 with files, attach directly to WhatsApp
    if (isMobile && navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
      try {
        if (waWindow) waWindow.close();
        await navigator.share({
          title: `${docTitle} (${fullDocNo})`,
          text: message,
          files: [pdfFile]
        });
        showToast(isBM ? '✅ Berjaya dikongsi ke WhatsApp!' : '✅ Shared to WhatsApp successfully!');
        if (statusCard) statusCard.style.display = 'none';
        return;
      } catch (shareErr) {
        if (shareErr.name === 'AbortError') return;
        console.warn('navigator.share failed, fallback to download + open WhatsApp:', shareErr);
      }
    }

    // 2. Desktop & Mobile fallback:
    // Download PDF directly to Downloads folder
    const downloadAnchor = document.createElement('a');
    downloadAnchor.href = blobUrl;
    downloadAnchor.download = fName;
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    setTimeout(() => {
      document.body.removeChild(downloadAnchor);
    }, 1500);

    // Redirect the pre-opened window directly to waUrl
    if (waWindow && !waWindow.closed) {
      waWindow.location.href = waUrl;
    }

    // Render unblockable, crystal-clear Step-by-Step Card
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#f0fdf4; border:2px solid #22c55e; border-radius:12px; padding:18px; box-shadow:0 6px 18px rgba(34,197,94,0.15);">
          <div style="display:flex; align-items:flex-start; gap:14px; margin-bottom:14px;">
            <div style="width:46px; height:46px; border-radius:50%; background:#22c55e; color:#fff; display:flex; align-items:center; justify-content:center; font-size:24px; flex-shrink:0; box-shadow:0 3px 10px rgba(34,197,94,0.4);">
              <i class="fa-brands fa-whatsapp"></i>
            </div>
            <div style="flex:1;">
              <h4 style="margin:0; color:#14532d; font-size:15px; font-weight:800;">
                ${isBM ? '✅ Fail PDF Dimuat Turun & WhatsApp Sedia Dihantar!' : '✅ PDF Downloaded & WhatsApp Ready!'}
              </h4>
              <p style="margin:4px 0 8px 0; font-size:12px; color:#166534; line-height:1.5;">
                ${isBM 
                  ? `Fail rasmi <strong>${fName}</strong> telah dimuat turun ke folder <strong>Downloads</strong> anda.` 
                  : `Official file <strong>${fName}</strong> has been saved into your <strong>Downloads</strong> folder.`}
              </p>
              <div style="background:#dcfce7; border:1px solid #86efac; border-radius:8px; padding:10px 12px; font-size:12px; color:#14532d; line-height:1.6;">
                <strong>${isBM ? '👉 2 Langkah Mudah Untuk Menghantar:' : '👉 2 Easy Steps to Send:'}</strong><br>
                1. ${isBM ? 'Tetingkap WhatsApp telah dibuka (atau klik butang hijau di bawah).' : 'WhatsApp window is opened (or click the green button below).'}<br>
                2. ${isBM ? `Di WhatsApp tetamu, klik ikon <strong>Lampiran (📎 atau +)</strong> dan pilih fail <strong style="font-family:monospace;">${fName}</strong> dari folder Downloads.` : `In WhatsApp chat, click <strong>Attachment (📎 or +)</strong> and select the downloaded PDF.`}
              </div>
            </div>
          </div>

          <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
            <a href="${waUrl}" target="_blank" class="btn btn-whatsapp btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:8px; padding:8px 16px; font-size:13px;">
              <i class="fa-brands fa-whatsapp"></i> ${isBM ? '📲 Buka WhatsApp Sekarang (Pautan Langsung)' : '📲 Open WhatsApp Now'}
            </a>
            <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px;">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? '👁️ Lihat Fail PDF' : '👁️ View PDF'}
            </a>
            <a href="${blobUrl}" download="${fName}" class="btn btn-outline btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:#fff; color:#065f46; border-color:#059669;">
              <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun Semula' : 'Download Again'}
            </a>
            <button type="button" class="btn btn-outline btn-sm" id="btnDismissWaStatus" style="font-size:11px; background:#fff; color:#64748b; margin-left:auto;">
              ${isBM ? 'Tutup' : 'Dismiss'}
            </button>
          </div>
        </div>
      `;
      document.getElementById('btnDismissWaStatus')?.addEventListener('click', () => {
        statusCard.style.display = 'none';
      });
      statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    showToast(isBM ? `Fail PDF (${fName}) dimuat turun ke Downloads!` : `PDF (${fName}) downloaded!`, 6000);

  }, (err) => {
    console.error('Error generating PDF for WhatsApp:', err);
    if (waWindow && !waWindow.closed) {
      waWindow.location.href = waUrl;
    } else {
      window.open(waUrl, '_blank');
    }
  });
}



// ==========================================================================
// 15. DIGITAL GUEST GUIDE MODAL
// ==========================================================================

function openGuestGuideModal() {
  const content = document.getElementById('guestGuideContent');
  content.innerHTML = '';

  const prop = appState.selectedPropertyId !== 'all' 
    ? getPropertyById(appState.selectedPropertyId) 
    : appState.properties[0];

  if (!prop) {
    showToast('Please create a homestay unit first.');
    return;
  }

  // QR Code URL using Google Chart API or QR service
  const wifiString = `WIFI:S:${encodeURIComponent(prop.wifiName || '')};T:WPA;P:${encodeURIComponent(prop.wifiPass || '')};;`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(wifiString)}`;

  content.innerHTML = `
    <div class="guest-guide-hero">
      <h3 style="font-size:18px; font-weight:800;">${prop.name}</h3>
      <p class="card-subtitle"><i class="fa-solid fa-location-dot"></i> ${prop.address || 'Homestay Address'}${prop.gpsLocation ? ` • <a href="${prop.gpsLocation}" target="_blank" style="color:var(--primary); font-weight:700; text-decoration:none;"><i class="fa-solid fa-map-location-dot"></i> Maps / GPS</a>` : ''}</p>
      
      <div class="qr-code-box">
        <img src="${qrUrl}" alt="WiFi QR Code" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Crect width=%22100%22 height=%22100%22 fill=%22%23f1f5f9%22/%3E%3Ctext x=%2250%22 y=%2255%22 font-size=%2212%22 text-anchor=%22middle%22 fill=%22%2364748b%22%3EWiFi QR%3C/text%3E%3C/svg%3E'">
      </div>
      <p style="font-size:11px; font-weight:700; color:var(--primary);">📱 Scan to Connect to WiFi Automatically</p>
    </div>

    <div class="guide-info-card">
      <h4><i class="fa-solid fa-wifi" style="color:var(--primary)"></i> WiFi Credentials</h4>
      <p>Network: <strong>${prop.wifiName || 'None'}</strong></p>
      <p>Password: <strong>${prop.wifiPass || 'None'}</strong></p>
    </div>

    <div class="guide-info-card">
      <h4><i class="fa-solid fa-key" style="color:var(--warning)"></i> Smart Lock / Access</h4>
      <p>Door PIN Code: <strong>${prop.doorCode || 'Provided upon arrival'}</strong></p>
      <p>Check-In: <strong>${prop.checkInTime || '3:00 PM'}</strong> • Check-Out: <strong>${prop.checkOutTime || '12:00 PM'}</strong></p>
    </div>

    <div class="guide-info-card">
      <h4><i class="fa-solid fa-circle-exclamation" style="color:var(--danger)"></i> House Rules</h4>
      <p>${prop.rules || 'Please treat our home with respect.'}</p>
    </div>

    <button class="btn btn-whatsapp btn-block" id="btnShareGuideWa" style="margin-top:12px;">
      <i class="fa-brands fa-whatsapp"></i> Share Guide with Guest via WhatsApp
    </button>
  `;

  document.getElementById('btnShareGuideWa').addEventListener('click', () => {
    const text = `🏡 *Welcome Guide - ${prop.name}*\n\n` +
      `📍 *Address:* ${prop.address || 'Standard Address'}\n` +
      (prop.gpsLocation ? `🗺️ *GPS / Google Maps:* ${prop.gpsLocation}\n` : '') +
      `📶 *WiFi:* ${prop.wifiName} (Pass: ${prop.wifiPass})\n` +
      `🔑 *Door PIN:* ${prop.doorCode}\n` +
      `📜 *Rules:* ${prop.rules}\n\n` +
      `Need assistance? Feel free to message us anytime!`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  });

  document.getElementById('guestGuideModal').classList.add('active');
}

// ==========================================================================
// 16. DATA BACKUP, EXPORT & RESTORE
// ==========================================================================

function exportDataBackup() {
  const isLangBm = appState.settings.language === 'bm';
  const exportObject = {
    version: APP_VERSION,
    exportDate: new Date().toISOString(),
    properties: appState.properties,
    bookings: appState.bookings,
    turnovers: appState.turnovers,
    expenses: appState.expenses,
    contacts: appState.contacts,
    maintenanceTeam: appState.contacts, // Explicitly named Maintenance Team & Suppliers directory
    maintenanceTasks: appState.turnovers, // Maintenance and turnover cleaning records
    promotionalMedia: appState.promotionalMedia,
    settings: appState.settings,
    licenseKey: appState.licenseKey,
    isLicensed: appState.isLicensed,
    isMasterAdmin: appState.isMasterAdmin
  };

  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportObject, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `StayManager_Backup_${new Date().toISOString().split('T')[0]}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
  showToast(isLangBm 
    ? '🎉 Fail sandaran (termasuk Pasukan Penyelenggaraan & Tempahan) berjaya dimuat turun!' 
    : '🎉 Backup file (including Maintenance Team, Bookings & Payments) downloaded safely!');
}

function importDataBackup(event) {
  const file = event.target.files[0];
  if (!file) return;

  const isLangBm = appState.settings.language === 'bm';
  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const data = JSON.parse(e.target.result);
      if (data.properties && Array.isArray(data.properties)) {
        appState.properties = data.properties;
        appState.bookings = data.bookings || [];
        appState.turnovers = data.turnovers || data.maintenanceTasks || [];
        appState.expenses = data.expenses || [];
        appState.contacts = (Array.isArray(data.maintenanceTeam) && data.maintenanceTeam.length > 0)
          ? data.maintenanceTeam
          : (Array.isArray(data.contacts) ? data.contacts : [...DEFAULT_CONTACTS]);
        appState.promotionalMedia = data.promotionalMedia || [...DEFAULT_PROMO_MEDIA];
        appState.settings = data.settings || DEFAULT_SETTINGS;
        if (data.licenseKey) {
          const check = verifyLicenseKey(data.licenseKey, null);
          if (check.valid) {
            appState.isLicensed = true;
            appState.licenseKey = data.licenseKey;
            appState.isMasterAdmin = check.isMaster;
          }
        } else if (data.isLicensed) {
          appState.isLicensed = true;
          if (data.isMasterAdmin) appState.isMasterAdmin = true;
        }
        saveToStorage();
        renderApp();
        showToast(isLangBm 
          ? '🎉 Salinan sandaran (termasuk Pasukan Penyelenggaraan & Tempahan) berjaya dipulihkan!' 
          : '🎉 Backup (including Maintenance Team & Bookings) restored successfully!');
      } else {
        alert(isLangBm ? 'Format fail sandaran tidak sah.' : 'Invalid backup file format.');
      }
    } catch (err) {
      alert(isLangBm ? 'Ralat membaca fail sandaran JSON.' : 'Error parsing JSON backup file.');
    }
  };
  reader.readAsText(file);
}

function restoreAutoBackup() {
  const autoBackupStr = localStorage.getItem('staymanager_auto_backup');
  if (!autoBackupStr) {
    alert(t('no_auto_backup_found'));
    return;
  }
  try {
    const data = JSON.parse(autoBackupStr);
    const dateStr = data.backupDate ? new Date(data.backupDate).toLocaleString() : 'Pre-update';
    const propCount = (data.properties && data.properties.length) || 0;
    const bookCount = (data.bookings && data.bookings.length) || 0;
    const isLangBm = appState.settings.language === 'bm';
    const promptMsg = isLangBm 
      ? `Salinan Keselamatan Sebelum Kemaskini dijumpai!\nTarikh: ${dateStr}\nHomestay: ${propCount} unit\nTempahan: ${bookCount} rekod\n\nAdakah anda mahu memulihkan data ini sekarang?`
      : `Pre-Update Safety Snapshot found!\nDate: ${dateStr}\nHomestays: ${propCount} units\nBookings: ${bookCount} records\n\nDo you want to restore this data now?`;

    if (confirm(promptMsg)) {
      if (Array.isArray(data.properties)) appState.properties = data.properties;
      if (Array.isArray(data.bookings)) appState.bookings = data.bookings;
      if (Array.isArray(data.turnovers)) appState.turnovers = data.turnovers;
      if (Array.isArray(data.expenses)) appState.expenses = data.expenses;
      if (Array.isArray(data.maintenanceTeam) && data.maintenanceTeam.length > 0) {
        appState.contacts = data.maintenanceTeam;
      } else if (Array.isArray(data.contacts)) {
        appState.contacts = data.contacts;
      }
      if (Array.isArray(data.promotionalMedia)) appState.promotionalMedia = data.promotionalMedia;
      if (data.settings) appState.settings = { ...DEFAULT_SETTINGS, ...data.settings };
      if (data.licenseKey) {
        const check = verifyLicenseKey(data.licenseKey, null);
        if (check.valid) {
          appState.isLicensed = true;
          appState.licenseKey = data.licenseKey;
          appState.isMasterAdmin = check.isMaster;
        }
      } else if (data.isLicensed) {
        appState.isLicensed = true;
        if (data.isMasterAdmin) appState.isMasterAdmin = true;
      }
      saveToStorage();
      renderApp();
      showToast(isLangBm ? '🎉 Salinan keselamatan (termasuk Pasukan Penyelenggaraan) berjaya dipulihkan!' : '🎉 Safety snapshot (including Maintenance Team) successfully restored!');
    }
  } catch (err) {
    alert('Error restoring safety snapshot: ' + err.message);
  }
}

function resetAllData() {
  if (confirm('Are you sure you want to clear all homestays, bookings, turnovers, and expenses? Your license key and preferences will be preserved.')) {
    const preservedLicense = appState.licenseKey;
    const preservedIsLicensed = appState.isLicensed;
    const preservedIsMaster = appState.isMasterAdmin;
    const preservedSettings = { ...appState.settings };

    appState.properties = [];
    appState.bookings = [];
    appState.turnovers = [];
    appState.expenses = [];
    appState.contacts = [...DEFAULT_CONTACTS];
    appState.promotionalMedia = [];
    appState.selectedPropertyId = 'all';
    appState.isLicensed = preservedIsLicensed;
    appState.licenseKey = preservedLicense;
    appState.isMasterAdmin = preservedIsMaster;
    appState.settings = preservedSettings;

    // Mark as initialized so demo data does not auto-seed on reload
    localStorage.setItem('staymanager_initialized', 'true');
    saveToStorage();
    renderApp();
    showToast('All homestay & booking data cleared successfully!');
  }
}

// ==========================================================================
// 17. THEME & UTILITIES
// ==========================================================================

function toggleTheme() {
  const isDark = document.body.classList.contains('theme-dark');
  const newTheme = isDark ? 'light' : 'dark';
  applyTheme(newTheme);
  appState.settings.theme = newTheme;
  saveToStorage();
}

function applyTheme(theme) {
  if (theme === 'dark') {
    document.body.classList.remove('theme-light');
    document.body.classList.add('theme-dark');
    document.getElementById('btnThemeToggle').innerHTML = '<i class="fa-solid fa-sun"></i>';
  } else {
    document.body.classList.remove('theme-dark');
    document.body.classList.add('theme-light');
    document.getElementById('btnThemeToggle').innerHTML = '<i class="fa-solid fa-moon"></i>';
  }
}

function closeAllModals() {
  document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.classList.remove('active');
    m.style.display = '';
  });
}

function showToast(message) {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<i class="fa-solid fa-circle-check" style="color:var(--success);"></i> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px)';
    toast.style.transition = 'all 0.2s ease';
    setTimeout(() => toast.remove(), 200);
  }, 2800);
}

// ==========================================================================
// 18. IN-APP USER MANUAL & INTERACTIVE GUIDE ENGINE
// ==========================================================================

const USER_GUIDE_DATA = {
  en: [
    {
      id: 'guide-install',
      icon: 'fa-mobile-screen-button',
      title: '1. How to Install on Your Phone (iOS & Android)',
      content: `
        <p>You do not need to download anything from the App Store or Google Play. The app installs directly from your web browser as a fast, lightweight mobile app.</p>
        <div class="guide-callout success">
          <strong>🍏 iPhone / iPad (Safari):</strong><br>
          1. Open the app link in <strong>Safari</strong>.<br>
          2. Tap the <strong>Share</strong> button (box with an arrow pointing up at the bottom).<br>
          3. Scroll down and tap <strong>"Add to Home Screen"</strong>.<br>
          4. Tap <strong>Add</strong> in the top-right corner. The app icon will appear on your home screen!
        </div>
        <div class="guide-callout">
          <strong>🤖 Android (Chrome / Samsung Internet):</strong><br>
          1. Open the app link in <strong>Google Chrome</strong>.<br>
          2. Tap the <strong>Three Dots Menu (⋮)</strong> at the top right.<br>
          3. Tap <strong>"Install App"</strong> or <strong>"Add to Home screen"</strong>.<br>
          4. Confirm by tapping <strong>Install</strong>.
        </div>
        <p style="font-size:11.5px; color:var(--text-muted);"><i class="fa-solid fa-bolt"></i> <strong>Offline Ready:</strong> Once installed, the app opens full-screen like a native app and works even with no internet connection.</p>
      `
    },
    {
      id: 'guide-license',
      icon: 'fa-key',
      title: '2. Activating Your License Key',
      content: `
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Go to the <strong>Settings (⚙️)</strong> tab (or tap the <strong>DEMO</strong> badge in the header).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">Tap <strong>"Enter License Key"</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Enter your registered <strong>WhatsApp Phone Number</strong> (e.g. <code>+60123456789</code>) and paste your <strong>License Key</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text">Tap <strong>"Activate Full App"</strong>. You now have lifetime access with unlimited homestays!</div>
        </div>
      `
    },
    {
      id: 'guide-props',
      icon: 'fa-house-chimney',
      title: '3. Adding Homestays & Room Rentals',
      content: `
        <p>You can manage entire houses, villas, apartments, or individual room rentals:</p>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Tap <strong>Settings (⚙️)</strong> > Tap <strong>"+ Add Homestay Unit"</strong> (or tap <strong>"+ Add"</strong> in the top header).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">
            <strong>Fill in Unit Particulars:</strong><br>
            • <strong>Category:</strong> Entire House, Master Room, Medium Room, Single Room, or Studio.<br>
            • <strong>Location:</strong> Full Address and <strong>GPS / Google Maps Link</strong> (for guest navigation).<br>
            • <strong>Access:</strong> Smart Lock Door PIN (e.g. <code>5829#</code>) and WiFi Name/Password.<br>
            • <strong>Pricing:</strong> Standard nightly rate and cleaning fee.
          </div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tap <strong>"Save Property"</strong>.</div>
        </div>
      `
    },
    {
      id: 'guide-bookings',
      icon: 'fa-calendar-plus',
      title: '4. Creating Bookings (Daily vs. Monthly)',
      content: `
        <p>Tap the floating <strong><code>+</code> (Add)</strong> button on the bottom-right to create a booking:</p>
        <div class="guide-callout success">
          <strong>☀️ Daily / Short-Term Stays:</strong><br>
          • Select <strong>"Daily / Short-Term"</strong> (monthly fields are automatically blocked).<br>
          • Enter Check-In/Out dates, Nightly Rate, and Cleaning Fee.<br>
          • Tap quick deposit presets: <code>30%</code>, <code>50%</code>, or <code>100% Full</code>.<br>
          • Enter guest particulars: Name, WhatsApp Phone, NRIC/Passport, and Address.
        </div>
        <div class="guide-callout">
          <strong>📅 Monthly Tenancy:</strong><br>
          • Select <strong>"Monthly Tenancy"</strong> (daily fields are automatically blocked).<br>
          • Enter Start Date, Duration (e.g. 6 Months), and Monthly Rental.<br>
          • Enter Rental Deposit, Utilities Deposit, and Tenancy Agreement Fee.<br>
          • The system automatically calculates the <strong>Total Move-In Package</strong>.
        </div>
        <div class="guide-callout success">
          <strong>💡 Calendar View (Check-In vs. Check-Out Modes):</strong><br>
          • <strong>📥 Check-In Mode:</strong> Highlights days when guests arrive with count badges (e.g. 📥 1) and lists upcoming arrivals.<br>
          • <strong>📤 Check-Out Mode:</strong> Highlights departure dates (e.g. 📤 1). Displays vacating unit notices with 1-tap <code>+ Book This Unit Starting Today</code> button!<br>
          • <strong>🛏️ All Stays:</strong> View overnight stays with colored dots for each homestay unit.<br>
          • <strong>4-Metric Bar:</strong> Tap any date to inspect Check-Ins, Check-Outs, In-Stay guests, and units available tonight.
        </div>
      `
    },
    {
      id: 'guide-invoicing',
      icon: 'fa-file-invoice-dollar',
      title: '5. Multi-Month Rental Invoices & Receipts',
      content: `
        <p>For monthly tenancies, the app provides a sequential monthly billing schedule:</p>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Go to the <strong>Bookings</strong> tab and tap <strong>"📑 Monthly Invoices (X/Y)"</strong> on any monthly booking card.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Send Invoice:</strong> Tap <code>Invoice</code> next to any month (e.g. Month 2). You can enter optional utility arrears (TNB/Water) before opening WhatsApp.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Mark Paid:</strong> Tap <code>Mark Paid</code> when the tenant transfers rent.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Send Receipt:</strong> Tap <code>Receipt</code> to send an official WhatsApp payment confirmation (<code>REC-RENT-M2-XXXX</code>).</div>
        </div>
      `
    },
    {
      id: 'guide-receipts',
      icon: 'fa-receipt',
      title: '5B. Digital Payment Receipts & Bank Reference Capture',
      content: `
        <p>When guests transfer booking deposits, balance settlements, or monthly rentals and share their bank slips, easily record and archive them:</p>
        <div class="guide-callout success">
          <strong>📸 Auto Image Compression:</strong><br>
          Bank slips and camera photos are compressed by 97% down to ~40KB–70KB without losing text sharpness, preserving your browser storage indefinitely!
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Capture Receipt:</strong> Tap <code>+ Resit / + Receipt</code> on any booking card, or tap <code>Mark Deposit Paid</code> / <code>Mark Fully Paid</code>. The receipt capture modal opens with recommended amounts pre-filled.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Bank & Ref No:</strong> Select the bank (Maybank, CIMB, Bank Islam, DuitNow, etc.) and paste or type the tenant's transaction reference ID.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Upload Slip:</strong> Tap or drag the screenshot into the dropzone. It previews instantly with the compressed size.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Receipt Gallery:</strong> Tap the <code>🧾 X Receipt(s)</code> chip anytime to inspect all attached receipts, copy reference numbers with 1 tap, or zoom full-screen with the Lightbox viewer.</div>
        </div>
      `
    },
    {
      id: 'guide-wa',
      icon: 'fa-brands fa-whatsapp',
      title: '6. 1-Tap WhatsApp Automation (9 Templates)',
      content: `
        <p>Tap the WhatsApp button on any booking card to choose from 9 pre-formatted templates with zero manual typing:</p>
        <ul style="padding-left:18px; margin:6px 0;">
          <li><strong>📄 Quotation:</strong> Send price breakdown, location, & deposit request.</li>
          <li><strong>🧾 Deposit Receipt:</strong> Confirm booking & lock calendar dates.</li>
          <li><strong>📅 Check-In Reminder:</strong> Send friendly arrival guide with check-in time, address, GPS link, access PIN, & payment status (sent at owner's discretion when arrival is near).</li>
          <li><strong>🔑 Full Receipt & Keys:</strong> Send Door Lock PIN, WiFi credentials, address & directions.</li>
          <li><strong>📑 Monthly Invoice:</strong> Send monthly rent bill with due date & bank account.</li>
          <li><strong>🧾 Monthly Rent Receipt:</strong> Send official rent payment confirmation.</li>
          <li><strong>🏁 Check-Out Reminder:</strong> Reminder on check-out time & key return.</li>
          <li><strong>💰 Deposit Refund Statement:</strong> Itemized statement with utility deductions.</li>
          <li><strong>🧹 Cleaner Notice:</strong> Job alert with unit address, GPS link, check-out time & PIN code.</li>
        </ul>
      `
    },
    {
      id: 'guide-refunds',
      icon: 'fa-money-bill-transfer',
      title: '7. End of Tenancy & Deposit Refunds',
      content: `
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Tap <strong>"End Tenancy & Refund Deposit"</strong> on the booking card.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">Enter any deductions for <strong>Unpaid Utilities (TNB/Water)</strong> or <strong>Repairs/Cleaning</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tap <strong>"Send Refund Statement"</strong> — opens an itemized, transparent statement in WhatsApp for your tenant!</div>
        </div>
      `
    },
    {
      id: 'guide-cleaning',
      icon: 'fa-broom',
      title: '8. Turnovers, Maintenance Team & Supplier Dispatch',
      content: `
        <p>Keep your homestays pristine, coordinate cleaning crews, technicians, and restock supplies with 1-click WhatsApp alerts:</p>
        <div class="guide-callout success">
          <strong>👷 Team & Supplier Directory (Settings > Maintenance Team & Suppliers):</strong><br>
          • Store phone numbers, rates, and notes for your cleaners, aircond specialists, plumbers, electricians, handymen, and supply vendors (linen/laundry, cooking gas, toiletries).<br>
          • Direct 1-tap WhatsApp chat and dispatch alert buttons on every contact card.
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Turnover Cleaning:</strong> Every checkout generates a turnover card in the <strong>Turnovers (🧹)</strong> tab. Tap <strong>"WhatsApp Cleaner"</strong> to open the Dispatch modal with target date, cleaning window, address, GPS link, and Smart Lock PIN pre-filled.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Service & Repair Alerts:</strong> Tap <strong>"🛠️ Service / Supply Alert"</strong> in the Turnovers header anytime to dispatch job requests for aircond servicing, plumbing leaks, electrical power trips, or general handyman fixes with urgency levels (Urgent / High / Normal).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Supply Restock Orders:</strong> Order fresh bedsheets, bath towels from your linen supplier or cooking gas cylinders from your gas vendor with 1 tap.</div>
        </div>
      `
    },
    {
      id: 'guide-finances',
      icon: 'fa-chart-line',
      title: '9. Financial Reports & Monthly Profit',
      content: `
        <p>Tap the <strong>Finances (📈)</strong> tab to see your business performance:</p>
        <ul style="padding-left:18px; margin:6px 0;">
          <li>💵 <strong>Total Revenue:</strong> Total booking income collected.</li>
          <li>📉 <strong>Total Expenses:</strong> Operational costs logged (tap <em>+ Add Expense</em>).</li>
          <li>🏆 <strong>Net Profit:</strong> Actual profit in green (<em>Revenue minus Expenses</em>).</li>
          <li>📊 <strong>Property Share:</strong> Percentage bars showing which unit earns the most.</li>
        </ul>
      `
    },
    {
      id: 'guide-backup',
      icon: 'fa-shield-halved',
      title: '10. Zero-Data-Loss Updates & Backups',
      content: `
        <div class="guide-callout success">
          <strong>🔒 100% Data Preservation Guarantee:</strong><br>
          All your homestays, bookings, tenant records, invoices, and license keys are stored in your device's persistent <code>localStorage</code> database. Updating the app only refreshes the code cache — it <strong>never deletes or touches your data</strong>!
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>1-Tap Auto Banner:</strong> When an update is deployed, tap <strong>"Update Now"</strong> on the notification banner at the top of the screen to activate instantly (~1s).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Check in Settings:</strong> You can also go to <strong>Settings (⚙️) > App Version & Updates</strong> and tap <strong>"Check for Updates"</strong> anytime.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>PWA Mobile App:</strong> For apps installed on your home screen, closing the app and reopening while connected to internet triggers automatic update in the background.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Safety Backup:</strong> Under <strong>Settings (⚙️) > Data Backup</strong>, tap <strong>"Export Backup (.json)"</strong> to save an encrypted snapshot of your business anytime.</div>
        </div>
      `
    }
  ],
  bm: [
    {
      id: 'guide-install',
      icon: 'fa-mobile-screen-button',
      title: '1. Cara Pasang di Telefon Pintar (iOS & Android)',
      content: `
        <p>Anda tidak perlu memuat turun apa-apa dari App Store atau Google Play. Aplikasi ini dipasang terus dari pelayar web anda sebagai aplikasi telefon pintar yang pantas dan ringan.</p>
        <div class="guide-callout success">
          <strong>🍏 Pengguna iPhone / iPad (Safari):</strong><br>
          1. Buka pautan aplikasi di <strong>Safari</strong>.<br>
          2. Tekan butang <strong>Kongsi (Share)</strong> (ikon petak dengan anak panah ke atas di bahagian bawah).<br>
          3. Skrol ke bawah dan tekan <strong>"Add to Home Screen" (Tambah ke Skrin Utama)</strong>.<br>
          4. Tekan <strong>Add</strong> di penjuru kanan atas. Ikon aplikasi akan muncul di skrin utama telefon anda!
        </div>
        <div class="guide-callout">
          <strong>🤖 Pengguna Android (Chrome / Samsung Internet):</strong><br>
          1. Buka pautan aplikasi di <strong>Google Chrome</strong>.<br>
          2. Tekan ikon <strong>Tiga Titik (⋮)</strong> di penjuru kanan atas.<br>
          3. Tekan <strong>"Install App" (Pasang Aplikasi)</strong> atau <strong>"Add to Home screen"</strong>.<br>
          4. Sahkan dengan menekan <strong>Install</strong>.
        </div>
        <p style="font-size:11.5px; color:var(--text-muted);"><i class="fa-solid fa-bolt"></i> <strong>Sedia Luar Talian:</strong> Selepas dipasang, aplikasi dibuka skrin penuh dan berfungsi walaupun tiada sambungan internet.</p>
      `
    },
    {
      id: 'guide-license',
      icon: 'fa-key',
      title: '2. Mengaktifkan Kunci Lesen Anda',
      content: `
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Pergi ke tab <strong>Tetapan (⚙️)</strong> (atau tekan lencana <strong>DEMO</strong> di bar atas).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">Tekan <strong>"Masukkan Kunci Lesen"</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Masukkan <strong>Nombor WhatsApp Berdaftar</strong> anda (cth: <code>+60123456789</code>) dan tampal <strong>Kunci Lesen</strong> anda.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text">Tekan <strong>"Aktifkan Aplikasi Penuh"</strong>. Anda kini memiliki akses seumur hidup dengan unit tanpa had!</div>
        </div>
      `
    },
    {
      id: 'guide-props',
      icon: 'fa-house-chimney',
      title: '3. Menambah Unit Homestay & Bilik Sewa',
      content: `
        <p>Anda boleh menguruskan seluruh rumah, vila, apartmen, atau bilik sewa individu:</p>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Tekan <strong>Tetapan (⚙️)</strong> > Tekan <strong>"+ Tambah Unit Homestay / Bilik"</strong> (atau tekan <strong>"+ Tambah"</strong> di bar atas).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">
            <strong>Isikan Butiran Unit:</strong><br>
            • <strong>Kategori:</strong> Seluruh Rumah, Bilik Master, Bilik Medium, Bilik Single, atau Studio.<br>
            • <strong>Lokasi:</strong> Alamat Penuh dan <strong>Pautan GPS / Google Maps</strong> (panduan arah tetamu).<br>
            • <strong>Akses:</strong> Kod PIN Kunci Pintu Pintar (cth: <code>5829#</code>) dan Nama/Kata Laluan WiFi.<br>
            • <strong>Harga:</strong> Kadar asas semalam dan yuran pembersihan.
          </div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tekan <strong>"Simpan Unit Homestay"</strong>.</div>
        </div>
      `
    },
    {
      id: 'guide-bookings',
      icon: 'fa-calendar-plus',
      title: '4. Merekod Tempahan (Harian & Bulanan)',
      content: `
        <p>Tekan butang terapung <strong><code>+</code> (Tambah)</strong> di penjuru kanan bawah untuk membuka borang tempahan:</p>
        <div class="guide-callout success">
          <strong>☀️ Sewaan Harian / Jangka Pendek:</strong><br>
          • Pilih <strong>"Harian / Jangka Pendek"</strong> (bahagian bulanan disekat automatik).<br>
          • Masukkan Tarikh Masuk/Keluar, Kadar Semalam, dan Yuran Pembersihan.<br>
          • Tekan pilihan deposit pantas: <code>30%</code>, <code>50%</code>, atau <code>100% Penuh</code>.<br>
          • Isikan maklumat tetamu: Nama, WhatsApp, No. KP/Pasport, dan Alamat.
        </div>
        <div class="guide-callout">
          <strong>📅 Sewaan Bulanan (Bilik / Rumah):</strong><br>
          • Pilih <strong>"Sewaan Bulanan"</strong> (bahagian harian disekat automatik).<br>
          • Masukkan Tarikh Mula, Tempoh (cth: 6 Bulan), dan Sewa Bulanan.<br>
          • Masukkan Deposit Sewa, Deposit Utiliti, dan Yuran Perjanjian Sewa.<br>
          • Sistem mengira <strong>Jumlah Pakej Kemasukan (Move-In)</strong> secara automatik.
        </div>
        <div class="guide-callout success">
          <strong>💡 Paparan Kalendar (Mod Daftar Masuk vs. Daftar Keluar):</strong><br>
          • <strong>📥 Mod Daftar Masuk:</strong> Menandakan hari ketibaan tetamu dengan lencana bilangan (cth: 📥 1) dan menyusun senarai ketibaan terdekat.<br>
          • <strong>📤 Mod Daftar Keluar:</strong> Menandakan hari tetamu keluar (cth: 📤 1). Memaparkan notis unit sedia dibersihkan berserta butang 1-sentuhan <code>+ Tempah Unit Ini Mulai Hari Ini</code>!<br>
          • <strong>🛏️ Penginapan:</strong> Paparkan semua malam penginapan dengan titik warna bagi setiap unit homestay.<br>
          • <strong>Bar 4-Statistik:</strong> Tekan mana-mana tarikh untuk melihat Masuk, Keluar, Menginap, dan unit Kosong Malam Ini.
        </div>
      `
    },
    {
      id: 'guide-invoicing',
      icon: 'fa-file-invoice-dollar',
      title: '5. Invois & Resit Sewaan Bulanan',
      content: `
        <p>Bagi sewaan bulanan, sistem menyediakan jadual bil bulanan berurutan:</p>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Buka tab <strong>Tempahan</strong> dan tekan butang <strong>"📑 Jadual Invois (X/Y)"</strong> pada kad sewaan bulanan.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Hantar Invois:</strong> Tekan <code>Invois</code> pada mana-mana bulan (cth: Bulan 2). Boleh masukkan caj utiliti TNB/Air tambahan jika ada sebelum buka WhatsApp.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Tanda Bayar:</strong> Tekan <code>Tanda Bayar</code> apabila penyewa telah memindahkan bayaran sewa.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Hantar Resit:</strong> Tekan <code>Resit</code> untuk menghantar resit rasmi WhatsApp pengesahan bayaran sewa (<code>REC-RENT-M2-XXXX</code>).</div>
        </div>
      `
    },
    {
      id: 'guide-receipts',
      icon: 'fa-receipt',
      title: '5B. Rekod Resit Digital & No. Rujukan Bank',
      content: `
        <p>Apabila tetamu atau penyewa memindahkan wang deposit, baki bayaran, atau sewa bulanan dan berkongsi slip transaksi di WhatsApp, anda boleh merekod dan menyimpannya terus di dalam aplikasi:</p>
        <div class="guide-callout success">
          <strong>📸 Pemampatan Imej Pintar:</strong><br>
          Gambar slip bank dimampatkan secara automatik sebanyak 97% ke ~40KB–70KB tanpa menjejaskan kejelasan teks nombor akaun dan ID transaksi, mengelakkan memori peranti penuh!
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Buka Borang Resit:</strong> Tekan <code>+ Resit</code> pada mana-mana kad tempahan, atau tekan <code>Tanda Deposit Dibayar</code> / <code>Tanda Bayaran Penuh</code>. Jumlah bayaran dicadangkan automatik.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Pilih Bank & No. Rujukan:</strong> Pilih bank (Maybank, CIMB, Bank Islam, DuitNow, dll.) dan tekan <code>Tampal</code> atau taip ID Rujukan Transaksi bank.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Muat Naik Slip:</strong> Tekan atau seret tangkapan skrin resit. Pratonton imej dan saiz mampat dipaparkan serta-merta.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Galeri Resit & No. Rujukan:</strong> Tekan lencana <code>🧾 X Resit</code> bila-bila masa untuk semak semua resit yang disimpan, salin no rujukan dengan 1 sentuhan, atau lihat gambar skrin penuh (Lightbox) berserta butang Muat Turun.</div>
        </div>
      `
    },
    {
      id: 'guide-wa',
      icon: 'fa-brands fa-whatsapp',
      title: '6. Automasi WhatsApp 1-Sentuhan (9 Templat)',
      content: `
        <p>Tekan butang WhatsApp pada mana-mana kad tempahan untuk memilih daripada 9 templat siap sedia tanpa perlu taip manual:</p>
        <ul style="padding-left:18px; margin:6px 0;">
          <li><strong>📄 Sebut Harga:</strong> Hantar perincian harga rasmi, lokasi, & jumlah bayaran booking.</li>
          <li><strong>🧾 Resit Booking / Deposit:</strong> Pengesahan deposit & unit ditanda ditempah.</li>
          <li><strong>📅 Peringatan Daftar Masuk:</strong> Peringatan mesra ketibaan berserta waktu masuk, alamat, pautan GPS Maps, PIN pintu & status baki bayaran (dihantar mengikut budi bicara pemilik apabila tarikh masuk hampir).</li>
          <li><strong>🔑 Resit Penuh & Panduan Kunci:</strong> Resit bayaran penuh berserta PIN pintu, WiFi, alamat & panduan.</li>
          <li><strong>📑 Invois Sewa Bulanan:</strong> Invois bulanan mengikut bulan, tarikh akhir & no bank.</li>
          <li><strong>🧾 Resit Rasmi Sewa Bulanan:</strong> Resit rasmi pengesahan bayaran sewa bulanan.</li>
          <li><strong>🏁 Peringatan Daftar Keluar:</strong> Peringatan waktu keluar, suis elektrik & kunci.</li>
          <li><strong>💰 Penyata Pulangan Deposit:</strong> Penyata perincian deposit & tolakan bil utiliti.</li>
          <li><strong>🧹 Arahan Pembersihan:</strong> Arahan tugasan kepada pembersih berserta alamat, GPS, & kod PIN pintu.</li>
        </ul>
      `
    },
    {
      id: 'guide-refunds',
      icon: 'fa-money-bill-transfer',
      title: '7. Tamat Sewaan & Pemulangan Deposit',
      content: `
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text">Tekan butang <strong>"Tamat Sewa & Pulang Deposit"</strong> pada kad tempahan.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text">Masukkan jumlah tolakan jika ada <strong>Tunggakan Utiliti (TNB/Air)</strong> atau <strong>Kerosakan / Pembersihan</strong>.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text">Tekan <strong>"Hantar Penyata Pulangan"</strong> — membuka penyata tolakan yang telus dan jelas di WhatsApp penyewa!</div>
        </div>
      `
    },
    {
      id: 'guide-cleaning',
      icon: 'fa-broom',
      title: '8. Pembersihan, Pasukan Penyelenggaraan & Tempahan Bekalan',
      content: `
        <p>Kekalkan kebersihan homestay anda, selaraskan kakitangan pembersihan, juruteknik, dan tempahan stok bekalan sepantas 1-klik WhatsApp:</p>
        <div class="guide-callout success">
          <strong>👷 Direktori Pasukan & Pembekal (Tetapan > Pasukan Penyelenggaraan & Pembekal):</strong><br>
          • Simpan nombor telefon, kadar caj dan nota kerja untuk tukang cuci, pakar aircond, tukang paip, juruelektrik, tukang rumah, dan pembekal (dobi linen, tong gas memasak, sabun/syampu).<br>
          • Butang sembang terus WhatsApp dan butang hantar notis tugasan tersedia pada setiap kad kenalan.
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Pembersihan Unit (Turnover):</strong> Setiap daftar keluar menjana tugasan di tab <strong>Pembersihan (🧹)</strong>. Tekan <strong>"WhatsApp Cleaner"</strong> untuk membuka tetingkap Notis dengan tarikh, waktu mengemas, alamat, pautan GPS Maps, dan Kod PIN pintu tersedia automatik.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Notis Pembaikan & Servis:</strong> Tekan <strong>"🛠️ Notis Servis & Bekalan"</strong> di bar atas tab Pembersihan pada bila-bila masa untuk menghantar tugasan servis aircond, paip bocor, bekalan elektrik trip, atau baiki perkakasan dengan tahap keperluan (Kecemasan / Tinggi / Biasa).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Pesanan Tambahan Stok:</strong> Tempah set cadar & tuala baru dari pembekal linen atau tong gas memasak baru daripada pembekal gas dengan 1 sentuhan.</div>
        </div>
      `
    },
    {
      id: 'guide-finances',
      icon: 'fa-chart-line',
      title: '9. Laporan Kewangan & Untung Bersih',
      content: `
        <p>Tekan tab <strong>Kewangan (📈)</strong> untuk melihat prestasi perniagaan anda:</p>
        <ul style="padding-left:18px; margin:6px 0;">
          <li>💵 <strong>Jumlah Hasil:</strong> Jumlah pendapatan sewaan yang diterima.</li>
          <li>📉 <strong>Jumlah Perbelanjaan:</strong> Kos operasi yang direkod (tekan <em>+ Tambah Kos</em>).</li>
          <li>🏆 <strong>Untung Bersih:</strong> Keuntungan sebenar berwarna hijau (<em>Hasil tolak Perbelanjaan</em>).</li>
          <li>📊 <strong>Pecahan Unit:</strong> Carta peratusan unit homestay/bilik yang menjana hasil tertinggi.</li>
        </ul>
      `
    },
    {
      id: 'guide-backup',
      icon: 'fa-shield-halved',
      title: '10. Kemas Kini Tanpa Hilang Data & Sandaran',
      content: `
        <div class="guide-callout success">
          <strong>🔒 Jaminan 100% Data Selamat:</strong><br>
          Semua maklumat homestay, tempahan, rekod penyewa, invois, dan lesen disimpan secara kekal di dalam <code>localStorage</code> peranti anda. Kemas kini aplikasi hanya memperbaharui kod program — ia <strong>tidak sekali-kali memadamkan data anda</strong>!
        </div>
        <div class="guide-step">
          <div class="guide-step-num">1</div>
          <div class="guide-step-text"><strong>Sepanduk 1-Sentuhan:</strong> Apabila versi baharu dikeluarkan, tekan <strong>"Kemas Kini Sekarang"</strong> pada sepanduk atas untuk memuatkan versi terkini (~1 saat).</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">2</div>
          <div class="guide-step-text"><strong>Semak di Tetapan:</strong> Anda juga boleh pergi ke <strong>Tetapan (⚙️) > Versi Aplikasi</strong> dan tekan <strong>"Semak Kemas Kini"</strong> pada bila-bila masa.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">3</div>
          <div class="guide-step-text"><strong>Aplikasi Telefon (PWA):</strong> Jika dipasang di skrin utama telefon, tutup aplikasi sepenuhnya dan buka semula semasa ada internet untuk muat turun fail terkini di latar belakang.</div>
        </div>
        <div class="guide-step">
          <div class="guide-step-num">4</div>
          <div class="guide-step-text"><strong>Sandaran Keselamatan:</strong> Di <strong>Tetapan (⚙️) > Sandaran Data</strong>, tekan <strong>"Eksport Sandaran (.json)"</strong> bila-bila masa untuk simpan salinan keselamatan fail bisnes anda.</div>
        </div>
      `
    }
  ]
};

function openProSystemModal() {
  const modal = document.getElementById('proSystemModal');
  if (!modal) return;

  const isBM = appState.settings.language === 'bm';
  const statusText = document.getElementById('proModalStatusText');
  const verText = document.getElementById('proModalVersionText');
  const titleEl = document.getElementById('proModalTitle');
  const subEl = document.getElementById('proModalSub');

  if (titleEl) {
    titleEl.textContent = appState.isMasterAdmin 
      ? (isBM ? 'Hab Pentadbir (Master Admin)' : 'Master Admin Hub') 
      : (isBM ? 'Hab Sistem StayManager Pro' : 'StayManager Pro Hub');
  }
  if (subEl) {
    subEl.textContent = isBM ? 'Status Akaun & Akses Pantas' : 'System Status & Quick Tools';
  }

  if (statusText) {
    if (appState.isMasterAdmin) {
      statusText.textContent = '👑 MASTER ADMIN';
      statusText.style.color = 'var(--primary)';
    } else {
      statusText.textContent = isBM ? '✨ LESEN PRO SEUMUR HIDUP' : '✨ LIFETIME PRO ACTIVE';
      statusText.style.color = 'var(--success)';
    }
  }

  if (verText) {
    verText.textContent = `v${APP_VERSION}`;
  }

  modal.classList.add('active');
}

function closeProSystemModal() {
  const modal = document.getElementById('proSystemModal');
  if (modal) modal.classList.remove('active');
}

function openUserGuideModal() {
  const currentAppLang = appState.settings.language || 'en';
  
  // Set segment active state matching app language
  document.querySelectorAll('#guideLangSegmented .segment-btn').forEach(b => {
    b.classList.toggle('active', b.getAttribute('data-glang') === currentAppLang);
  });

  renderUserGuideAccordion(currentAppLang);
  document.getElementById('userGuideModal').classList.add('active');
}

function renderUserGuideAccordion(lang = 'en') {
  const container = document.getElementById('userGuideAccordion');
  if (!container) return;
  container.innerHTML = '';

  const list = USER_GUIDE_DATA[lang] || USER_GUIDE_DATA.en;

  list.forEach((item, index) => {
    const card = document.createElement('div');
    card.className = `guide-card ${index === 0 ? 'active' : ''}`;
    card.innerHTML = `
      <div class="guide-card-header">
        <div class="guide-card-title-group">
          <div class="guide-card-icon">
            <i class="fa-solid ${item.icon}"></i>
          </div>
          <h4 class="guide-card-title">${item.title}</h4>
        </div>
        <i class="fa-solid fa-chevron-down guide-card-chevron"></i>
      </div>
      <div class="guide-card-body">
        ${item.content}
      </div>
    `;

    card.querySelector('.guide-card-header').addEventListener('click', () => {
      const wasActive = card.classList.contains('active');
      container.querySelectorAll('.guide-card').forEach(c => c.classList.remove('active'));
      if (!wasActive) card.classList.add('active');
    });

    container.appendChild(card);
  });
}

// ==========================================================================
// 19. RESIDENTIAL TENANCY AGREEMENT GENERATOR MODULE (v2.7.0)
// Automated legal Malaysian Tenancy Agreement with Muslim-friendly covenants
// ==========================================================================

const DEFAULT_AGREEMENT_INVENTORY = [
  { item: 'Air Conditioner & Remote / Pendingin Hawa', qty: 2, condition: 'Good & Functional / Baik' },
  { item: 'Refrigerator (2-Door) / Peti Sejuk', qty: 1, condition: 'Good & Functional / Baik' },
  { item: 'Automatic Washing Machine / Mesin Basuh', qty: 1, condition: 'Good & Functional / Baik' },
  { item: 'Smart Television & Remote / TV Pintar', qty: 1, condition: 'Good & Functional / Baik' },
  { item: 'Queen Bed Frame, Mattress & Wardrobe / Katil & Tilam', qty: 2, condition: 'Clean & Good / Baik' },
  { item: 'Single Bed Frame & Mattress / Katil Bujang', qty: 1, condition: 'Clean & Good / Baik' },
  { item: 'Dining Table & 4 Chairs / Set Meja Makan', qty: 1, condition: 'Good & Sturdy / Baik' },
  { item: 'Living Room Sofa & Coffee Table / Set Sofa', qty: 1, condition: 'Good & Clean / Baik' },
  { item: 'Kitchen Gas Stove & Cylinder / Dapur Gas & Tong', qty: 1, condition: 'Clean & Functional / Baik' },
  { item: 'Ceiling / Wall Fans / Kipas Siling & Dinding', qty: 4, condition: 'Good & Working / Baik' },
  { item: 'House Keys & Gate Access / Kunci Rumah & Akses', qty: 2, condition: 'Complete Sets / Lengkap' }
];

const AGREEMENT_DOC_I18N = {
  bm: {
    docHeaderTitle: 'SURAT PERJANJIAN PENYEWAAN KEDIAMAN',
    docHeaderSub: 'RESIDENTIAL TENANCY AGREEMENT',
    preambleP1: (date, landlordName, landlordIc, tenantName, tenantIc) =>
      `PERJANJIAN INI diperbuat pada tarikh <strong>${date}</strong> DI ANTARA <strong>${landlordName}</strong> (No. K/P / SSM: <strong>${landlordIc || '-'}</strong>) yang beralamat di tempat yang dinyatakan dalam Seksyen 2 Jadual Pertama (selepas ini dirujuk sebagai <strong>"Tuan Rumah"</strong>) di satu pihak; DAN <strong>${tenantName}</strong> (No. K/P / Pasport: <strong>${tenantIc || '-'}</strong>) yang beralamat tetap seperti dalam Seksyen 3 Jadual Pertama (selepas ini dirujuk sebagai <strong>"Penyewa"</strong>) di pihak yang satu lagi.`,
    preambleP2: (propName, propAddress) =>
      `BAHAWASANYA Tuan Rumah adalah pemilik berdaftar bagi premis kediaman yang dikenali sebagai <strong>"${propName}"</strong> yang beralamat di <strong>${propAddress}</strong> (selepas ini dirujuk sebagai <strong>"Premis Demis"</strong>) bersama segala lekapan, perabot dan inventori yang disenaraikan dalam Jadual Kedua. Tuan Rumah dengan ini bersetuju memberi sewaan dan Penyewa bersetuju menerima sewaan Premis Demis tersebut tertakluk kepada syarat-syarat dan fasal-fasal yang ditetapkan di bawah.`,
    
    // First Schedule
    firstScheduleTitle: 'JADUAL PERTAMA (FIRST SCHEDULE)',
    firstScheduleSub: 'JADUAL BUTIR-BUTIR PERJANJIAN PENYEWAAN',
    thItemNo: 'Item',
    thSubject: 'Perkara',
    thParticulars: 'Butir-Butir / Perincian',
    
    schDate: 'Tarikh Perjanjian',
    schLandlord: 'Tuan Rumah (Lessor)',
    schTenant: 'Penyewa (Lessee)',
    schProperty: 'Premis Yang Disewakan (Premis Demis)',
    schTerm: 'Tempoh Sewaan',
    schDates: 'Tarikh Permulaan & Tamat',
    schRent: 'Kadar Sewa Bulanan',
    schDue: 'Tarikh Genap Masa Bayaran',
    schRentalDep: 'Wang Cagaran Sewa (1 Bulan)',
    schUtilDep: 'Wang Cagaran Utiliti (Elektrik & Air)',
    schAdvance: 'Bayaran Sewa Pendahuluan (Bulan Pertama)',
    schFee: 'Duti Setem & Yuran Perjanjian',
    schUse: 'Kegunaan Premis Dibenarkan',
    schUseVal: 'Kediaman Persendirian Sahaja (Ditegah Perusahaan / Komersial)',
    schRenew: 'Opsyen Pembaharuan Sewaan',

    // Covenants
    sec1Title: 'FASAL 1: TANGGUNGJAWAB & AKU JANJI PENYEWA',
    sec1Clauses: [
      'Membayar sewa bulanan tepat pada tarikh yang ditetapkan tanpa sebarang tuntutan atau penolakan ke dalam akaun bank Tuan Rumah.',
      'Membayar semua bil penggunaan elektrik, air, caj perkhidmatan pembetungan (Indah Water) dan sebarang bil utiliti lain mengikut meter bacaan atau invois bulanan yang dikemukakan.',
      'Menjaga kebersihan dan keselamatan bahagian dalaman dan luaran premis, perabot, dan perkakas elektrik yang disenaraikan dalam Jadual Kedua agar sentiasa berada dalam keadaan baik, bersih dan berfungsi.',
      'Dilarang melakukan sebarang ubah suai struktur, meruntuhkan dinding, mengecat warna lain, atau menebuk lubang pada dinding tanpa mendapat persetujuan bertulis terlebih dahulu daripada Tuan Rumah.',
      'Dilarang sama sekali menyewakan semula (sublet), menyerahkan hak sewaan, atau berkongsi kediaman dengan mana-mana pihak ketiga tanpa kebenaran bertulis daripada Tuan Rumah.',
      'Membenarkan Tuan Rumah atau wakil yang diberikuasa memasuki premis pada bila-bila masa yang munasabah untuk tujuan pemeriksaan atau pembaikan dengan memberi notis awal sekurang-kurangnya 24 jam.',
      'Tidak menyimpan atau membenarkan disimpan sebarang barangan berbahaya, mudah terbakar, bahan letupan atau bahan terlarang di sisi undang-undang Malaysia di dalam premis.'
    ],

    // Special Muslim-Friendly Condition Clause (CRITICAL REQUIREMENT)
    secMuslimTitle: 'FASAL 2: KLAUSA KHAS PEMELIHARAAN KEADAAN RUMAH MESRA MUSLIM',
    secMuslimSub: 'Syarat pematuhan kesucian kediaman dan ketenteraman masyarakat Islam',
    secMuslimClauses: [
      '<strong>Makanan & Minuman Halal Sahaja:</strong> Penyewa, penghuni, dan mana-mana tetamu dilarang sama sekali membawa masuk, memasak, menyimpan atau memakan apa-apa makanan yang tidak halal, termasuk daging babi dan apa-apa produk atau ramuan yang berasaskannya di dalam premis sewaan.',
      '<strong>Larangan Mutlak Minuman Keras & Alkohol:</strong> Dilarang sama sekali membawa masuk, menyimpan, meminum, menghidang atau menjual arak, bir, wiski, atau sebarang minuman beralkohol yang memabukkan di dalam mana-mana bahagian premis.',
      '<strong>Larangan Haiwan Peliharaan Tidak Patuh Syarak:</strong> Dilarang sama sekali membawa masuk, memelihara atau membiarkan anjing atau apa-apa haiwan peliharaan yang tidak mematuhi hukum syarak di dalam kawasan rumah atau sekitarnya.',
      '<strong>Pemeliharaan Adab, Keharmonian Kejiranan & Larangan Maksiat:</strong> Penyewa bertanggungjawab memastikan premis digunakan secara beradab dan bermoral selaras dengan undang-undang negara dan tatasusila masyarakat setempat. Dilarang sama sekali melakukan perbuatan maksiat, pergaulan bebas / khalwat, aktiviti perjudian, dadah atau sebarang aktiviti yang melanggar hukum syarak.',
      '<strong>Hak Penamatan Serta-Merta & Kos Pensucian (Sertu):</strong> Sekiranya Penyewa didapati melanggar mana-mana peruntukan di bawah Fasal Khas ini, Tuan Rumah berhak menamatkan Perjanjian Sewaan ini serta-merta tanpa sebarang notis pemulangan sewa, mengarahkan Penyewa mengosongkan premis dalam tempoh 48 jam, dan menggunakan wang cagaran sewa/deposit untuk menanggung kos pembersihan menyeluruh premis termasuk kos pensucian (sertu/samak) jika perlu.'
    ],

    sec3Title: 'FASAL 3: TANGGUNGJAWAB & AKU JANJI TUAN RUMAH',
    sec3Clauses: [
      'Menyerahkan milikan kosong Premis Demis bersama kunci dan inventori dalam keadaan bersih, elok dan selamat untuk diduduki pada tarikh permulaan sewaan.',
      'Membayar cukai tanah (Quit Rent), cukai taksiran (Assessment Tax) dan sebarang caj penyelenggaraan bangunan/strata (jika ada).',
      'Menjamin bahawa Penyewa yang membayar sewa dan mematuhi terma perjanjian berhak menikmati dan mendiami Premis Demis dengan aman dan tenteram tanpa gangguan (Quiet Enjoyment).',
      'Membaiki sebarang kerosakan struktur utama bangunan (seperti bumbung bocor, retakan dinding utama, paip utama pecah) yang bukan disebabkan oleh salah laku atau kecuaian Penyewa.'
    ],

    sec4Title: 'FASAL 4: WANG CAGARAN (DEPOSIT) & POLISI PEMULANGAN',
    sec4Clauses: [
      'Wang Cagaran Sewa dan Utiliti hendaklah dibayar semasa menandatangani perjanjian ini dan dipegang oleh Tuan Rumah sebagai jaminan pematuhan syarat perjanjian.',
      'Wang cagaran ini tidak boleh sekali-kali dianggap atau digunakan oleh Penyewa sebagai bayaran sewa bulanan.',
      'Tuan Rumah akan memulangkan baki Wang Cagaran Sewa dan Cagaran Utiliti tanpa faedah kepada Penyewa dalam tempoh empat belas (14) hari selepas tarikh tamat sewaan dan penyerahan kunci, setelah ditolak sebarang tunggakan bil utiliti, kos pembaikan kerosakan fizikal, atau kos pembersihan premis.'
    ],

    sec5Title: 'FASAL 5: PENAMATAN SEWAAN, KEMUNGKIRAN & PENGOSONGAN',
    sec5Clauses: [
      'Sekiranya sewa bulanan tertunggak melebihi tempoh empat belas (14) hari daripada tarikh genap masa bayaran, Tuan Rumah berhak menuntut penamatan perjanjian dan mengambil semula milikan sah ke atas Premis Demis.',
      'Jika mana-mana pihak berhasrat menamatkan sewaan sebelum tamat tempoh yang dipersetujui, pihak tersebut hendaklah memberi notis bertulis sekurang-kurangnya dua (2) bulan atau membayar gantirugi sewa sebanyak dua (2) bulan.',
      'Pada hari terakhir sewaan, Penyewa hendaklah menyerahkan semula premis dan semua inventori dalam keadaan bersih dan baik (kehausan munasabah dikecualikan) bersama semua set kunci asal.'
    ],

    // Second Schedule: Inventory
    secondScheduleTitle: 'JADUAL KEDUA (SECOND SCHEDULE)',
    secondScheduleSub: 'SENARAI LEKAPAN, PERABOT & INVENTORI PREMIS',
    thInvNo: 'No.',
    thInvItem: 'Perkara / Perkakas / Perabot',
    thInvQty: 'Kuantiti',
    thInvCond: 'Keadaan Semasa Penyerahan',
    invVerifiedNote: 'Semua inventori dan perkakas di atas telah disemak, disahkan lengkap dan berfungsi dengan baik oleh kedua-dua pihak pada tarikh penyerahan kunci premis.',

    // Execution & Signatures
    executionTitle: 'METERAI & TANDATANGAN PIHAK-PIHAK',
    executionSub: 'DITANDATANGANI OLEH PIHAK-PIHAK PADA HARI DAN TAHUN SEPERTI YANG DINYATAKAN DI ATAS',
    signedByLandlord: 'Ditandatangani oleh TUAN RUMAH:',
    signedByTenant: 'Ditandatangani oleh PENYEWA:',
    witnessedBy: 'Disaksikan oleh SAKSI:',
    nameLabel: 'Nama:',
    icLabel: 'No. K/P:',
    dateLabel: 'Tarikh:',
    stampDutyNote: 'PENGESAHAN DUTI SETEM (STAMP DUTY LHDN)',
    stampDutyDesc: 'Dokumen ini boleh dimatikan setem hasil secara dalam talian melalui Portal STAMPS Lembaga Hasil Dalam Negeri Malaysia (LHDN) untuk tujuan perundangan rasmi.'
  },

  en: {
    docHeaderTitle: 'RESIDENTIAL TENANCY AGREEMENT',
    docHeaderSub: 'SURAT PERJANJIAN PENYEWAAN KEDIAMAN',
    preambleP1: (date, landlordName, landlordIc, tenantName, tenantIc) =>
      `THIS AGREEMENT is made on <strong>${date}</strong> BETWEEN <strong>${landlordName}</strong> (NRIC / Reg No: <strong>${landlordIc || '-'}</strong>) having its address as stated in Section 2 of the First Schedule (hereinafter referred to as the <strong>"Landlord"</strong>) of the one part; AND <strong>${tenantName}</strong> (NRIC / Passport: <strong>${tenantIc || '-'}</strong>) residing at the permanent address stated in Section 3 of the First Schedule (hereinafter referred to as the <strong>"Tenant"</strong>) of the other part.`,
    preambleP2: (propName, propAddress) =>
      `WHEREAS the Landlord is the registered owner of the residential property known as <strong>"${propName}"</strong> situated at <strong>${propAddress}</strong> (hereinafter referred to as the <strong>"Demised Premises"</strong>) together with all fixtures, furniture, and fittings specified in the Second Schedule hereto. The Landlord agrees to let and the Tenant agrees to take the Demised Premises on the terms and covenants contained herein.`,

    // First Schedule
    firstScheduleTitle: 'FIRST SCHEDULE',
    firstScheduleSub: 'SCHEDULE OF TENANCY PARTICULAR DETAILS',
    thItemNo: 'Item',
    thSubject: 'Subject Matter',
    thParticulars: 'Particulars & Descriptions',

    schDate: 'Agreement Execution Date',
    schLandlord: 'Landlord (Lessor)',
    schTenant: 'Tenant (Lessee)',
    schProperty: 'Demised Premises Address',
    schTerm: 'Tenancy Term / Duration',
    schDates: 'Commencement & Expiry Dates',
    schRent: 'Monthly Rental Amount',
    schDue: 'Monthly Rent Due Date',
    schRentalDep: 'Rental Security Deposit (1 Month)',
    schUtilDep: 'Utilities Deposit (Water & Electric)',
    schAdvance: 'Advance Rental (First Month)',
    schFee: 'Agreement Preparation & Stamping Fee',
    schUse: 'Permitted Use of Premises',
    schUseVal: 'Private Residential Dwelling Only (Commercial use strictly prohibited)',
    schRenew: 'Option to Renew Notice',

    // Covenants
    sec1Title: "SECTION 1: TENANT'S COVENANTS & OBLIGATIONS",
    sec1Clauses: [
      'To pay the reserved monthly rent promptly on the stipulated due date without any deduction into the designated bank account of the Landlord.',
      'To pay all charges for water, electricity, sewerage services (Indah Water), and other utilities consumed on the premises directly or upon presentation of monthly billing statements.',
      'To maintain the interior and fixtures of the Demised Premises, including furniture and electrical appliances listed in the Second Schedule, in a clean, tenantable, and working condition.',
      'Not to make any structural alterations, renovations, wall hacking, or paint work without first obtaining the prior written consent of the Landlord.',
      'Strictly not to assign, sublet, or share possession of the Demised Premises or any part thereof with any third party without prior written permission from the Landlord.',
      'To permit the Landlord or authorized representatives to enter upon the Demised Premises at all reasonable times for inspection or maintenance purposes upon giving at least 24 hours prior notice.',
      'Not to bring, store, or permit to be stored on the premises any combustible, hazardous, explosive, or illicit goods in contravention of the laws of Malaysia.'
    ],

    // Special Muslim-Friendly Condition Clause (CRITICAL REQUIREMENT)
    secMuslimTitle: 'SECTION 2: SPECIAL MUSLIM-FRIENDLY HOUSE COVENANTS',
    secMuslimSub: 'Covenants for maintaining Muslim living conditions and community sanctity',
    secMuslimClauses: [
      '<strong>Halal Food & Drink Requirement:</strong> The Tenant and any occupants or guests are strictly prohibited from bringing, cooking, storing, or consuming any non-halal food, including pork and any pork-derived products or ingredients, inside the Demised Premises.',
      '<strong>Absolute Prohibition of Liquor & Alcohol:</strong> Strictly no intoxicating alcoholic beverages, beer, wine, or spirits shall be brought into, stored, consumed, served, or sold on the Demised Premises.',
      '<strong>Prohibition of Syarak-Restricted Pets:</strong> The Tenant shall not bring or keep dogs or any animals prohibited by Islamic principles (syarak) inside or around the compound of the Demised Premises.',
      '<strong>Islamic Decorum, Neighborhood Harmony & Prohibition of Vice:</strong> The Tenant undertakes to maintain standard moral and neighborhood decorum. Strictly no immoral acts, illicit cohabitation (khalwat), gambling, drug abuse, or unlawful conduct contrary to Islamic norms and Malaysian law shall occur on the premises.',
      '<strong>Landlord Right of Immediate Termination & Cleansing (Sertu) Costs:</strong> Any breach of this Special Covenant shall entitle the Landlord to immediately terminate this Tenancy Agreement without compensation, demand vacant possession within 48 hours, and forfeit/apply deposits towards professional deep-cleansing and Islamic ritual purification (sertu/samak) expenses where required.'
    ],

    sec3Title: "SECTION 3: LANDLORD'S COVENANTS & OBLIGATIONS",
    sec3Clauses: [
      'To deliver vacant possession of the Demised Premises together with keys and inventoried fixtures in clean and habitable condition on the commencement date.',
      'To pay all quit rent, property assessment taxes, and building management service maintenance charges (if applicable).',
      'To ensure that the Tenant paying the rent and observing the covenants shall peaceably hold and enjoy the Demised Premises during the term without any interruption by the Landlord (Quiet Enjoyment).',
      'To maintain and repair main structural components (e.g., roof leaks, structural walls, main external pipes) not caused by the negligence or misuse of the Tenant.'
    ],

    sec4Title: 'SECTION 4: SECURITY & UTILITY DEPOSITS REFUND POLICY',
    sec4Clauses: [
      'The Rental Deposit and Utilities Deposit paid upon execution shall be retained by the Landlord as security against default or physical damage.',
      'Under no circumstances shall the Tenant treat the deposits as payment for monthly rent.',
      'The Landlord shall refund the balance of the deposits without interest to the Tenant within fourteen (14) days after the expiration of the tenancy, subject to deduction for outstanding utility bills and repair of damaged inventory.'
    ],

    sec5Title: 'SECTION 5: TERMINATION, DEFAULT & RE-ENTRY',
    sec5Clauses: [
      'If the monthly rent remains unpaid for fourteen (14) days after becoming due, the Landlord shall be entitled to terminate this agreement and re-enter upon the Demised Premises.',
      'Either party may terminate the tenancy prior to expiration by serving at least two (2) months prior written notice or paying two (2) months rent in lieu of notice.',
      'Upon determination of the tenancy, the Tenant shall peacefully yield up the Demised Premises and inventoried items in good, clean condition (reasonable wear and tear excepted) together with all original keys.'
    ],

    // Second Schedule: Inventory
    secondScheduleTitle: 'SECOND SCHEDULE',
    secondScheduleSub: 'SCHEDULE OF FIXTURES, FITTINGS & INVENTORY',
    thInvNo: 'No.',
    thInvItem: 'Item / Fixture Description',
    thInvQty: 'Qty',
    thInvCond: 'Condition at Handover',
    invVerifiedNote: 'All fixtures and appliances listed above have been inspected, tested, and verified to be complete and in good working order by both parties upon key handover.',

    // Execution & Signatures
    executionTitle: 'EXECUTION & SIGNATURES',
    executionSub: 'IN WITNESS WHEREOF the parties have hereunto executed this Agreement on the day and year first above written',
    signedByLandlord: 'Signed by the LANDLORD:',
    signedByTenant: 'Signed by the TENANT:',
    witnessedBy: 'Witnessed by WITNESS:',
    nameLabel: 'Name:',
    icLabel: 'NRIC / Passport:',
    dateLabel: 'Date:',
    stampDutyNote: 'STAMP DUTY ATTESTATION (INLAND REVENUE BOARD / LHDN)',
    stampDutyDesc: 'This agreement may be digitally stamped via the Inland Revenue Board of Malaysia (LHDN) STAMPS portal for official legal and evidentiary enforcement.'
  }
};

/**
 * Initialize agreement generator module event listeners
 */
function initAgreementGenerator() {
  appState.activeAgreementBooking = null;
  appState.activeAgreementLang = 'bm';

  // Modal navigation tabs
  const tabForm = document.getElementById('btnAgrTabForm');
  const tabPreview = document.getElementById('btnAgrTabPreview');
  const formWrap = document.getElementById('agrTabFormContainer');
  const previewWrap = document.getElementById('agrTabPreviewContainer');

  if (tabForm && tabPreview) {
    tabForm.addEventListener('click', () => {
      tabForm.classList.add('active');
      tabPreview.classList.remove('active');
      if (formWrap) formWrap.style.display = 'block';
      if (previewWrap) previewWrap.style.display = 'none';
    });

    tabPreview.addEventListener('click', () => {
      tabPreview.classList.add('active');
      tabForm.classList.remove('active');
      if (formWrap) formWrap.style.display = 'none';
      if (previewWrap) previewWrap.style.display = 'block';
      renderAgreementPreview();
    });
  }

  const btnGoPreview = document.getElementById('btnAgrGoToPreview');
  if (btnGoPreview && tabPreview) {
    btnGoPreview.addEventListener('click', () => {
      tabPreview.click();
      const modalBody = document.querySelector('#agreementGeneratorModal .modal-body');
      if (modalBody) modalBody.scrollTop = 0;
    });
  }

  const btnBackForm = document.getElementById('btnAgrBackToForm');
  if (btnBackForm && tabForm) {
    btnBackForm.addEventListener('click', () => {
      tabForm.click();
      const modalBody = document.querySelector('#agreementGeneratorModal .modal-body');
      if (modalBody) modalBody.scrollTop = 0;
    });
  }

  // Modal close buttons
  const btnClose = document.getElementById('btnCloseAgreementModal');
  const btnCloseBtn = document.getElementById('btnCloseAgreementModalBtn');
  if (btnClose) btnClose.addEventListener('click', closeAllModals);
  if (btnCloseBtn) btnCloseBtn.addEventListener('click', closeAllModals);

  // Language buttons
  const btnBM = document.getElementById('btnAgrLangBM');
  const btnEN = document.getElementById('btnAgrLangEN');
  if (btnBM && btnEN) {
    btnBM.addEventListener('click', () => {
      btnBM.classList.add('active');
      btnEN.classList.remove('active');
      appState.activeAgreementLang = 'bm';
      renderAgreementPreview();
    });
    btnEN.addEventListener('click', () => {
      btnEN.classList.add('active');
      btnBM.classList.remove('active');
      appState.activeAgreementLang = 'en';
      renderAgreementPreview();
    });
  }

  // Booking selection & Auto-fill
  const bSelect = document.getElementById('agrBookingSelect');
  if (bSelect) {
    bSelect.addEventListener('change', () => {
      const bid = bSelect.value;
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        populateAgreementForm(b);
      }
    });
  }

  const btnAuto = document.getElementById('btnAgrAutoFill');
  if (btnAuto) {
    btnAuto.addEventListener('click', () => {
      const bid = document.getElementById('agrBookingSelect')?.value;
      const b = appState.bookings.find(x => x.id === bid);
      if (b) {
        populateAgreementForm(b, true);
        showToast(appState.settings.language === 'bm' ? 'Maklumat tempahan berjaya dimuatkan semula!' : 'Booking particulars re-populated successfully!');
      } else {
        showToast(appState.settings.language === 'bm' ? 'Sila pilih rekod tempahan di atas.' : 'Please select a booking record above.');
      }
    });
  }

  // Add Inventory Item
  const btnAddInv = document.getElementById('btnAgrAddInventoryItem');
  if (btnAddInv) {
    btnAddInv.addEventListener('click', () => {
      addCustomInventoryRow('', 1, 'Baik & Berfungsi / Good', true);
    });
  }

  // Actions: Save Draft, Print, WhatsApp, Download PDF (Top Toolbar & Bottom Action Bar)
  const btnSave = document.getElementById('btnSaveAgreementDraft');
  if (btnSave) btnSave.addEventListener('click', (e) => { e?.preventDefault(); saveAgreementDraft(); });

  const btnPrint = document.getElementById('btnPrintAgreementDoc');
  if (btnPrint) btnPrint.addEventListener('click', (e) => { e?.preventDefault(); printAgreementDocument(); });

  const btnEmail = document.getElementById('btnEmailAgreement');
  if (btnEmail) btnEmail.addEventListener('click', (e) => { e?.preventDefault(); sendAgreementEmail(); });

  const btnEmailBottom = document.getElementById('btnEmailAgreementBottom');
  if (btnEmailBottom) btnEmailBottom.addEventListener('click', (e) => { e?.preventDefault(); sendAgreementEmail(); });

  const btnWa = document.getElementById('btnShareAgreementWa');
  if (btnWa) btnWa.addEventListener('click', (e) => { e?.preventDefault(); shareAgreementWhatsApp(); });

  const btnWaBottom = document.getElementById('btnShareAgreementWaBottom');
  if (btnWaBottom) btnWaBottom.addEventListener('click', (e) => { e?.preventDefault(); shareAgreementWhatsApp(); });

  const btnPdf = document.getElementById('btnDownloadAgreementPdf');
  if (btnPdf) btnPdf.addEventListener('click', (e) => { e?.preventDefault(); downloadAgreementPdf(); });

  const btnPdfBottom = document.getElementById('btnDownloadAgreementPdfBottom');
  if (btnPdfBottom) btnPdfBottom.addEventListener('click', (e) => { e?.preventDefault(); downloadAgreementPdf(); });

  // Recalculate duration when dates change
  const startInput = document.getElementById('agrStartDate');
  const endInput = document.getElementById('agrEndDate');
  if (startInput && endInput) {
    const handleDatesChange = () => {
      if (startInput.value && endInput.value) {
        const d1 = new Date(startInput.value);
        const d2 = new Date(endInput.value);
        if (d2 > d1) {
          const diffMonths = Math.max(1, Math.round((d2 - d1) / (1000 * 60 * 60 * 24 * 30.4375)));
          const durEl = document.getElementById('agrDurationMonths');
          if (durEl) durEl.value = diffMonths;
        }
      }
    };
    startInput.addEventListener('change', handleDatesChange);
    endInput.addEventListener('change', handleDatesChange);
  }
}

/**
 * Open agreement modal, auto-populating from booking
 */
function openAgreementModal(booking = null, defaultTab = 'preview') {
  // If booking not provided, resolve fallback
  if (!booking) {
    if (appState.activeWaBooking && appState.activeWaBooking.rentalType === 'monthly') {
      booking = appState.activeWaBooking;
    } else if (appState.activePdfBooking && appState.activePdfBooking.rentalType === 'monthly') {
      booking = appState.activePdfBooking;
    } else {
      booking = appState.bookings.find(b => b.rentalType === 'monthly') || appState.bookings[0] || null;
    }
  }

  // CRITICAL: Close all existing active modals (e.g. monthlyInvoicesModal, pdfDocModal)
  // to prevent modal backdrop collisions, pointer blockages, and viewport stacking bugs.
  closeAllModals();

  appState.activeAgreementBooking = booking;
  appState.activeAgreementLang = (appState.settings && appState.settings.language === 'en') ? 'en' : 'bm';

  const isBM = appState.activeAgreementLang === 'bm';
  showToast(isBM ? 'Membuka Penjana Perjanjian Sewaan...' : 'Opening Tenancy Agreement Generator...');

  // 1. Populate bookings dropdown
  populateAgreementBookingSelect(booking ? booking.id : null);

  // 2. Populate form
  const activeBooking = booking || (() => {
    const bid = document.getElementById('agrBookingSelect')?.value;
    return appState.bookings.find(b => b.id === bid) || null;
  })();

  populateAgreementForm(activeBooking);

  // 3. Switch tab and render preview if defaultTab === 'preview'
  const tabForm = document.getElementById('btnAgrTabForm');
  const tabPreview = document.getElementById('btnAgrTabPreview');
  const formWrap = document.getElementById('agrTabFormContainer');
  const previewWrap = document.getElementById('agrTabPreviewContainer');

  if (defaultTab === 'preview' && tabPreview) {
    tabPreview.classList.add('active');
    if (tabForm) tabForm.classList.remove('active');
    if (formWrap) formWrap.style.display = 'none';
    if (previewWrap) previewWrap.style.display = 'block';
    renderAgreementPreview();
  } else if (tabForm) {
    tabForm.classList.add('active');
    if (tabPreview) tabPreview.classList.remove('active');
    if (formWrap) formWrap.style.display = 'block';
    if (previewWrap) previewWrap.style.display = 'none';
  }

  // 4. Update language toggle active pill
  const btnBM = document.getElementById('btnAgrLangBM');
  const btnEN = document.getElementById('btnAgrLangEN');
  if (appState.activeAgreementLang === 'en') {
    if (btnEN) btnEN.classList.add('active');
    if (btnBM) btnBM.classList.remove('active');
  } else {
    if (btnBM) btnBM.classList.add('active');
    if (btnEN) btnEN.classList.remove('active');
  }

  // 5. Open modal with explicit flex display & top scroll
  const modal = document.getElementById('agreementGeneratorModal');
  if (modal) {
    modal.style.display = 'flex';
    modal.classList.add('active');
    const modalBody = modal.querySelector('.modal-body');
    if (modalBody) modalBody.scrollTop = 0;
  }
}
window.openAgreementModal = openAgreementModal;

/**
 * Populate bookings select element
 */
function populateAgreementBookingSelect(selectedBookingId = null) {
  const select = document.getElementById('agrBookingSelect');
  if (!select) return;
  select.innerHTML = '';

  const monthlyBookings = appState.bookings.filter(b => b.rentalType === 'monthly');
  const otherBookings = appState.bookings.filter(b => b.rentalType !== 'monthly');

  if (monthlyBookings.length > 0) {
    const grpMonthly = document.createElement('optgroup');
    grpMonthly.label = '── Sewaan Bulanan / Monthly Rentals ──';
    monthlyBookings.forEach(b => {
      const prop = getPropertyById(b.propertyId);
      const opt = document.createElement('option');
      opt.value = b.id;
      opt.textContent = `${b.guestName} • ${prop.name} (${b.checkIn} → ${b.checkOut} • RM${b.monthlyRate || b.totalAmount}/bln)`;
      grpMonthly.appendChild(opt);
    });
    select.appendChild(grpMonthly);
  }

  if (otherBookings.length > 0) {
    const grpOther = document.createElement('optgroup');
    grpOther.label = '── Rekod Tempahan Harian Lain ──';
    otherBookings.forEach(b => {
      const prop = getPropertyById(b.propertyId);
      const opt = document.createElement('option');
      opt.value = b.id;
      opt.textContent = `${b.guestName} • ${prop.name} (${b.checkIn} → ${b.checkOut})`;
      grpOther.appendChild(opt);
    });
    select.appendChild(grpOther);
  }

  if (select.options.length === 0) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = 'Tiada rekod tempahan (Borang Manual)';
    select.appendChild(opt);
  }

  if (selectedBookingId) {
    select.value = selectedBookingId;
  } else if (monthlyBookings.length > 0) {
    select.value = monthlyBookings[0].id;
  }
}

/**
 * Populate form inputs from booking or defaults
 */
function populateAgreementForm(booking = null, forceReset = false) {
  const settings = appState.settings || {};
  const isBM = appState.settings.language === 'bm';
  const todayStr = new Date().toISOString().split('T')[0];

  // Check if booking has saved agreement draft
  if (booking && booking.tenancyAgreement && !forceReset) {
    const draft = booking.tenancyAgreement;
    document.getElementById('agrLandlordName').value = draft.landlordName || settings.businessName || '';
    document.getElementById('agrLandlordIc').value = draft.landlordIc || settings.ownerIc || '';
    document.getElementById('agrLandlordPhone').value = draft.landlordPhone || settings.businessPhone || '';
    document.getElementById('agrLandlordAddress').value = draft.landlordAddress || settings.businessAddress || '';

    document.getElementById('agrTenantName').value = draft.tenantName || booking.guestName || '';
    document.getElementById('agrTenantIc').value = draft.tenantIc || booking.guestIc || '';
    document.getElementById('agrTenantPhone').value = draft.tenantPhone || booking.guestPhone || '';
    document.getElementById('agrTenantEmail').value = draft.tenantEmail || booking.guestEmail || '';
    document.getElementById('agrTenantAddress').value = draft.tenantAddress || booking.guestAddress || '';

    document.getElementById('agrPropertyName').value = draft.propertyName || '';
    document.getElementById('agrPropertyType').value = draft.propertyType || '';
    document.getElementById('agrPropertyAddress').value = draft.propertyAddress || '';

    document.getElementById('agrAgreementDate').value = draft.agreementDate || todayStr;
    document.getElementById('agrStartDate').value = draft.startDate || booking.checkIn || '';
    document.getElementById('agrEndDate').value = draft.endDate || booking.checkOut || '';
    document.getElementById('agrDurationMonths').value = draft.durationMonths || booking.monthlyDuration || 6;

    document.getElementById('agrMonthlyRent').value = draft.monthlyRent || booking.monthlyRate || '';
    document.getElementById('agrRentalDueDay').value = draft.rentalDueDay || (isBM ? '7hb setiap bulan' : '7th of every month');
    document.getElementById('agrRentalDeposit').value = draft.rentalDeposit !== undefined ? draft.rentalDeposit : '';
    document.getElementById('agrUtilitiesDeposit').value = draft.utilitiesDeposit !== undefined ? draft.utilitiesDeposit : 300;
    document.getElementById('agrAdvanceRent').value = draft.advanceRent !== undefined ? draft.advanceRent : '';
    document.getElementById('agrAgreementFee').value = draft.agreementFee !== undefined ? draft.agreementFee : 150;
    document.getElementById('agrRenewalNotice').value = draft.renewalNotice || (isBM ? '2 Bulan bertulis sebelum tamat sewaan' : '2 Months prior written notice');
    document.getElementById('agrPaymentAccount').value = draft.paymentAccount || '';

    const chkMuslim = document.getElementById('agrMuslimFriendlyEnabled');
    if (chkMuslim) chkMuslim.checked = draft.muslimFriendlyEnabled !== false;
    document.getElementById('agrCustomClauses').value = draft.customClauses || '';

    document.getElementById('agrLandlordWitnessName').value = draft.landlordWitnessName || '';
    document.getElementById('agrLandlordWitnessIc').value = draft.landlordWitnessIc || '';
    document.getElementById('agrTenantWitnessName').value = draft.tenantWitnessName || '';
    document.getElementById('agrTenantWitnessIc').value = draft.tenantWitnessIc || '';

    renderDefaultInventoryRows(draft.inventory);
    return;
  }

  // Auto-populate from fresh booking & settings
  const prop = booking ? getPropertyById(booking.propertyId) : (appState.properties[0] || {});
  const mRate = booking ? (Number(booking.monthlyRate || booking.baseRate || 1200)) : 1200;
  const mDeposit = (booking && booking.rentalDeposit !== undefined && booking.rentalDeposit !== null && booking.rentalDeposit !== '')
    ? Number(booking.rentalDeposit)
    : mRate;
  const uDeposit = (booking && booking.utilitiesDeposit !== undefined && booking.utilitiesDeposit !== null && booking.utilitiesDeposit !== '')
    ? Number(booking.utilitiesDeposit)
    : 300;
  const aFee = (booking && booking.agreementFee !== undefined && booking.agreementFee !== null && booking.agreementFee !== '')
    ? Number(booking.agreementFee)
    : 150;

  // Landlord
  document.getElementById('agrLandlordName').value = settings.businessName || 'Pengurusan Homestay & Kediaman';
  document.getElementById('agrLandlordIc').value = settings.ownerIc || '';
  document.getElementById('agrLandlordPhone').value = settings.businessPhone || settings.phone || '+60123456789';
  document.getElementById('agrLandlordAddress').value = settings.businessAddress || 'Malaysia';

  // Tenant
  document.getElementById('agrTenantName').value = booking ? booking.guestName : '';
  document.getElementById('agrTenantIc').value = booking ? (booking.guestIc || '') : '';
  document.getElementById('agrTenantPhone').value = booking ? (booking.guestPhone || '') : '';
  document.getElementById('agrTenantEmail').value = booking ? (booking.guestEmail || '') : '';
  document.getElementById('agrTenantAddress').value = booking ? (booking.guestAddress || '') : '';

  // Property
  document.getElementById('agrPropertyName').value = prop ? prop.name : '';
  document.getElementById('agrPropertyType').value = prop.propType === 'entire'
    ? (isBM ? 'Rumah Kediaman (Whole House)' : 'Residential House (Whole Unit)')
    : (prop.roomNo ? `Bilik Kediaman (${prop.roomNo})` : 'Rumah Kediaman');
  document.getElementById('agrPropertyAddress').value = prop.address || '';

  // Dates & Terms
  document.getElementById('agrAgreementDate').value = todayStr;
  document.getElementById('agrStartDate').value = booking ? booking.checkIn : todayStr;
  document.getElementById('agrEndDate').value = booking ? booking.checkOut : '';
  document.getElementById('agrDurationMonths').value = booking ? (booking.monthlyDuration || 6) : 6;

  document.getElementById('agrMonthlyRent').value = mRate;
  document.getElementById('agrRentalDueDay').value = isBM ? '7hb setiap bulan' : '7th of every month';
  document.getElementById('agrRentalDeposit').value = mDeposit;
  document.getElementById('agrUtilitiesDeposit').value = uDeposit;
  document.getElementById('agrAdvanceRent').value = mRate;
  document.getElementById('agrAgreementFee').value = aFee;
  document.getElementById('agrRenewalNotice').value = isBM ? '2 Bulan bertulis sebelum tamat sewaan' : '2 Months prior written notice';

  // Bank Account
  const bankStr = `${settings.bankName || 'Maybank'} - ${settings.bankAccount || '5140-xxxx-xxxx'} (${settings.bankHolder || settings.businessName || 'Tuan Rumah'})`;
  document.getElementById('agrPaymentAccount').value = bankStr;

  // Muslim Condition (Enabled by default as per user request)
  const chkMuslim = document.getElementById('agrMuslimFriendlyEnabled');
  if (chkMuslim) chkMuslim.checked = true;
  document.getElementById('agrCustomClauses').value = '';

  // Witnesses
  document.getElementById('agrLandlordWitnessName').value = '';
  document.getElementById('agrLandlordWitnessIc').value = '';
  document.getElementById('agrTenantWitnessName').value = '';
  document.getElementById('agrTenantWitnessIc').value = '';

  // Inventory Checklist
  renderDefaultInventoryRows();

  // Status badge update
  const statusBadge = document.getElementById('agrBookingStatusBadge');
  if (statusBadge && booking) {
    statusBadge.innerHTML = `<span style="color:var(--success); font-weight:700;"><i class="fa-solid fa-check-circle"></i> Maklumat tempahan "${booking.guestName}" (${prop.name}) dimuatkan.</span>`;
  }
}

/**
 * Render inventory table rows
 */
function renderDefaultInventoryRows(savedInventory = null) {
  const tbody = document.getElementById('agrInventoryTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  const list = (savedInventory || DEFAULT_AGREEMENT_INVENTORY).filter(item => {
    const name = (item.item || '').toLowerCase();
    return !name.includes('water heater') && !name.includes('pemanas air');
  });
  list.forEach(item => {
    addCustomInventoryRow(item.item, item.qty, item.condition, item.checked !== false);
  });
}

/**
 * Add an inventory item row into the table
 */
function addCustomInventoryRow(item = '', qty = 1, condition = 'Baik & Berfungsi / Good', checked = true) {
  const tbody = document.getElementById('agrInventoryTableBody');
  if (!tbody) return;

  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td style="padding:6px; text-align:center;">
      <input type="checkbox" class="agr-inv-check" ${checked ? 'checked' : ''} style="accent-color:var(--primary); transform:scale(1.1);">
    </td>
    <td style="padding:6px;">
      <input type="text" class="agr-inv-item" value="${escapeHtml(item)}" placeholder="Nama perkakas / perabot">
    </td>
    <td style="padding:6px; text-align:center;">
      <input type="number" class="agr-inv-qty" value="${qty || 1}" min="1" max="99" style="text-align:center;">
    </td>
    <td style="padding:6px;">
      <input type="text" class="agr-inv-condition" value="${escapeHtml(condition)}" placeholder="Keadaan (Baik & Berfungsi)">
    </td>
    <td style="padding:6px; text-align:center;">
      <button type="button" class="btn btn-outline btn-xs btn-del-inv-row" style="padding:2px 6px; color:var(--danger); border-color:var(--danger);">
        <i class="fa-solid fa-trash-can"></i>
      </button>
    </td>
  `;

  tr.querySelector('.btn-del-inv-row').addEventListener('click', () => {
    tr.remove();
  });

  tbody.appendChild(tr);
}

/**
 * Gather all agreement form inputs into an object
 */
function getAgreementFormData() {
  const getVal = id => (document.getElementById(id)?.value || '').trim();

  // Inventory
  const inventory = [];
  document.querySelectorAll('#agrInventoryTableBody tr').forEach(tr => {
    const isChecked = tr.querySelector('.agr-inv-check')?.checked;
    const item = tr.querySelector('.agr-inv-item')?.value.trim();
    const qty = parseInt(tr.querySelector('.agr-inv-qty')?.value) || 1;
    const condition = tr.querySelector('.agr-inv-condition')?.value.trim();
    if (item) {
      inventory.push({
        item,
        qty,
        condition: condition || 'Baik & Berfungsi / Good',
        checked: !!isChecked
      });
    }
  });

  return {
    landlordName: getVal('agrLandlordName'),
    landlordIc: getVal('agrLandlordIc'),
    landlordPhone: getVal('agrLandlordPhone'),
    landlordAddress: getVal('agrLandlordAddress'),

    tenantName: getVal('agrTenantName'),
    tenantIc: getVal('agrTenantIc'),
    tenantPhone: getVal('agrTenantPhone'),
    tenantEmail: getVal('agrTenantEmail'),
    tenantAddress: getVal('agrTenantAddress'),

    propertyName: getVal('agrPropertyName'),
    propertyType: getVal('agrPropertyType'),
    propertyAddress: getVal('agrPropertyAddress'),

    agreementDate: getVal('agrAgreementDate'),
    startDate: getVal('agrStartDate'),
    endDate: getVal('agrEndDate'),
    durationMonths: parseInt(getVal('agrDurationMonths')) || 6,

    monthlyRent: parseFloat(getVal('agrMonthlyRent')) || 0,
    rentalDueDay: getVal('agrRentalDueDay') || '7hb setiap bulan',
    rentalDeposit: parseFloat(getVal('agrRentalDeposit')) || 0,
    utilitiesDeposit: parseFloat(getVal('agrUtilitiesDeposit')) || 0,
    advanceRent: parseFloat(getVal('agrAdvanceRent')) || 0,
    agreementFee: parseFloat(getVal('agrAgreementFee')) || 0,
    renewalNotice: getVal('agrRenewalNotice'),
    paymentAccount: getVal('agrPaymentAccount'),

    muslimFriendlyEnabled: document.getElementById('agrMuslimFriendlyEnabled')?.checked ?? true,
    customClauses: getVal('agrCustomClauses'),

    inventory,

    landlordWitnessName: getVal('agrLandlordWitnessName'),
    landlordWitnessIc: getVal('agrLandlordWitnessIc'),
    tenantWitnessName: getVal('agrTenantWitnessName'),
    tenantWitnessIc: getVal('agrTenantWitnessIc')
  };
}

/**
 * Format date for official Malaysian legal document
 */
function formatLegalDate(isoDateStr, lang = 'bm') {
  if (!isoDateStr) return '-';
  const parts = isoDateStr.split('-');
  if (parts.length !== 3) return isoDateStr;
  const day = parseInt(parts[2], 10);
  const monthIdx = parseInt(parts[1], 10) - 1;
  const year = parts[0];

  const monthsBM = ['Januari', 'Februari', 'Mac', 'April', 'Mei', 'Jun', 'Julai', 'Ogos', 'September', 'Oktober', 'November', 'Disember'];
  const monthsEN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const monthName = lang === 'en' ? (monthsEN[monthIdx] || parts[1]) : (monthsBM[monthIdx] || parts[1]);
  return `${day} ${monthName} ${year}`;
}

/**
 * Render the live A4 agreement document preview
 */
function renderAgreementPreview() {
  const sheet = document.getElementById('printableAgreementSheet');
  if (!sheet) return;

  const data = getAgreementFormData();
  const lang = appState.activeAgreementLang || 'bm';
  const i18n = AGREEMENT_DOC_I18N[lang] || AGREEMENT_DOC_I18N.bm;

  const formattedDate = formatLegalDate(data.agreementDate, lang);
  const formattedStart = formatLegalDate(data.startDate, lang);
  const formattedEnd = formatLegalDate(data.endDate, lang);

  const formatRM = val => `RM ${Number(val || 0).toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  // Checked inventory items only (safeguard against water heater)
  const activeInventory = (data.inventory || []).filter(x => {
    if (!x.checked) return false;
    const name = (x.item || '').toLowerCase();
    return !name.includes('water heater') && !name.includes('pemanas air');
  });

  // Generate Document HTML
  sheet.innerHTML = `
    <!-- DOCUMENT HEADER -->
    <div style="text-align:center; margin-bottom:20px; border-bottom:2px solid #0f172a; padding-bottom:12px;">
      <h1 class="agr-doc-title">${i18n.docHeaderTitle}</h1>
      <div class="agr-doc-subtitle">${i18n.docHeaderSub}</div>
      <div style="font-size:10.5pt; font-weight:bold; letter-spacing:0.5px;">
        ${lang === 'en' ? 'BETWEEN' : 'DI ANTARA'}<br>
        <span style="font-size:12pt; text-transform:uppercase;">${escapeHtml(data.landlordName || 'TUAN RUMAH')}</span><br>
        ${lang === 'en' ? 'AND' : 'DAN'}<br>
        <span style="font-size:12pt; text-transform:uppercase;">${escapeHtml(data.tenantName || 'PENYEWA')}</span>
      </div>
    </div>

    <!-- PREAMBLE -->
    <div class="agr-preamble">
      <p style="margin-bottom:10px;">
        ${i18n.preambleP1(
          formattedDate,
          escapeHtml(data.landlordName || 'TUAN RUMAH'),
          escapeHtml(data.landlordIc || '-'),
          escapeHtml(data.tenantName || 'PENYEWA'),
          escapeHtml(data.tenantIc || '-')
        )}
      </p>
      <p style="margin-bottom:0;">
        ${i18n.preambleP2(
          escapeHtml(data.propertyName || 'PREMIS KEDIAMAN'),
          escapeHtml(data.propertyAddress || '-')
        )}
      </p>
    </div>

    <!-- FIRST SCHEDULE -->
    <div class="agr-clause-block">
      <div class="agr-clause-title" style="text-align:center;">${i18n.firstScheduleTitle}</div>
      <div style="text-align:center; font-size:10pt; font-style:italic; margin-bottom:8px;">${i18n.firstScheduleSub}</div>

      <table class="agr-schedule-table">
        <thead>
          <tr>
            <th class="agr-schedule-item-num">${i18n.thItemNo}</th>
            <th class="agr-schedule-item-title">${i18n.thSubject}</th>
            <th>${i18n.thParticulars}</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="agr-schedule-item-num">1.</td>
            <td class="agr-schedule-item-title">${i18n.schDate}</td>
            <td><strong>${formattedDate}</strong></td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">2.</td>
            <td class="agr-schedule-item-title">${i18n.schLandlord}</td>
            <td>
              <strong>${escapeHtml(data.landlordName || '-')}</strong><br>
              ${lang === 'en' ? 'NRIC / Reg No:' : 'No. K/P / SSM:'} ${escapeHtml(data.landlordIc || '-')}<br>
              ${lang === 'en' ? 'Phone:' : 'No. Tel:'} ${escapeHtml(data.landlordPhone || '-')}<br>
              ${lang === 'en' ? 'Address:' : 'Alamat:'} ${escapeHtml(data.landlordAddress || '-')}
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">3.</td>
            <td class="agr-schedule-item-title">${i18n.schTenant}</td>
            <td>
              <strong>${escapeHtml(data.tenantName || '-')}</strong><br>
              ${lang === 'en' ? 'NRIC / Passport:' : 'No. K/P / Pasport:'} ${escapeHtml(data.tenantIc || '-')}<br>
              ${lang === 'en' ? 'Phone:' : 'No. Tel:'} ${escapeHtml(data.tenantPhone || '-')}<br>
              ${data.tenantEmail ? `${lang === 'en' ? 'Email:' : 'Emel:'} ${escapeHtml(data.tenantEmail)}<br>` : ''}
              ${lang === 'en' ? 'Permanent Address:' : 'Alamat Tetap:'} ${escapeHtml(data.tenantAddress || '-')}
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">4.</td>
            <td class="agr-schedule-item-title">${i18n.schProperty}</td>
            <td>
              <strong>${escapeHtml(data.propertyName || '-')}</strong> (${escapeHtml(data.propertyType || '-')})<br>
              ${escapeHtml(data.propertyAddress || '-')}
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">5.</td>
            <td class="agr-schedule-item-title">${i18n.schTerm}</td>
            <td><strong>${data.durationMonths} ${lang === 'en' ? 'Months' : 'Bulan'}</strong></td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">6.</td>
            <td class="agr-schedule-item-title">${i18n.schDates}</td>
            <td>
              ${lang === 'en' ? 'From' : 'Mulai'}: <strong>${formattedStart}</strong><br>
              ${lang === 'en' ? 'To' : 'Hingga'}: <strong>${formattedEnd}</strong>
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">7.</td>
            <td class="agr-schedule-item-title">${i18n.schRent}</td>
            <td>
              <strong style="font-size:11.5pt;">${formatRM(data.monthlyRent)}</strong> ${lang === 'en' ? 'per month' : 'sebulan'}<br>
              <span style="font-size:9.5pt; color:#475569;">(${lang === 'en' ? 'Bank Account' : 'Akaun Bayaran'}: ${escapeHtml(data.paymentAccount || '-')})</span>
            </td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">8.</td>
            <td class="agr-schedule-item-title">${i18n.schDue}</td>
            <td><strong>${escapeHtml(data.rentalDueDay || '7hb setiap bulan')}</strong></td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">9.</td>
            <td class="agr-schedule-item-title">${i18n.schRentalDep}</td>
            <td><strong>${formatRM(data.rentalDeposit)}</strong> (${lang === 'en' ? 'Security Deposit' : 'Cagaran Keselamatan'})</td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">10.</td>
            <td class="agr-schedule-item-title">${i18n.schUtilDep}</td>
            <td><strong>${formatRM(data.utilitiesDeposit)}</strong> (${lang === 'en' ? 'Electricity & Water' : 'Elektrik & Air'})</td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">11.</td>
            <td class="agr-schedule-item-title">${i18n.schAdvance}</td>
            <td><strong>${formatRM(data.advanceRent)}</strong> (${lang === 'en' ? 'First month rental payment' : 'Sewa bulan pertama semasa kemasukan'})</td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">12.</td>
            <td class="agr-schedule-item-title">${i18n.schFee}</td>
            <td><strong>${formatRM(data.agreementFee)}</strong></td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">13.</td>
            <td class="agr-schedule-item-title">${i18n.schUse}</td>
            <td>${i18n.schUseVal}</td>
          </tr>
          <tr>
            <td class="agr-schedule-item-num">14.</td>
            <td class="agr-schedule-item-title">${i18n.schRenew}</td>
            <td>${escapeHtml(data.renewalNotice || (lang === 'en' ? '2 Months written notice prior to expiration' : '2 Bulan notis bertulis sebelum tamat sewaan'))}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- COVENANTS -->
    <div style="margin-top:20px;">
      
      <!-- FASAL 1: TENANT COVENANTS -->
      <div class="agr-clause-block">
        <div class="agr-clause-title">${i18n.sec1Title}</div>
        <ol class="agr-clause-list">
          ${i18n.sec1Clauses.map(clause => `<li>${clause}</li>`).join('')}
        </ol>
      </div>

      <!-- FASAL 2: SPECIAL MUSLIM-FRIENDLY HOUSE COVENANTS (HIGHLIGHTED PER USER SPECIFICATION) -->
      ${data.muslimFriendlyEnabled ? `
        <div class="agr-clause-block">
          <div class="agr-clause-title" style="color:#065f46; border-bottom:2px solid #059669;">
            ${i18n.secMuslimTitle}
          </div>
          <div style="font-size:10pt; font-style:italic; color:#065f46; margin-bottom:8px;">
            ${i18n.secMuslimSub}
          </div>
          <div class="agr-muslim-highlight-box">
            <ol class="agr-clause-list" style="margin:0; padding-left:18px;">
              ${i18n.secMuslimClauses.map(clause => `<li style="margin-bottom:6px;">${clause}</li>`).join('')}
            </ol>
            ${data.customClauses ? `
              <div style="margin-top:10px; padding-top:8px; border-top:1px dashed #86efac; font-size:10.5pt;">
                <strong>${lang === 'en' ? 'Additional Landlord Special Rules:' : 'Syarat Khas Tambahan Tuan Rumah:'}</strong><br>
                ${escapeHtml(data.customClauses).replace(/\n/g, '<br>')}
              </div>
            ` : ''}
          </div>
        </div>
      ` : ''}

      <!-- FASAL 3: LANDLORD COVENANTS -->
      <div class="agr-clause-block">
        <div class="agr-clause-title">${i18n.sec3Title}</div>
        <ol class="agr-clause-list">
          ${i18n.sec3Clauses.map(clause => `<li>${clause}</li>`).join('')}
        </ol>
      </div>

      <!-- FASAL 4: DEPOSITS & REFUND -->
      <div class="agr-clause-block">
        <div class="agr-clause-title">${i18n.sec4Title}</div>
        <ol class="agr-clause-list">
          ${i18n.sec4Clauses.map(clause => `<li>${clause}</li>`).join('')}
        </ol>
      </div>

      <!-- FASAL 5: TERMINATION & DEFAULT -->
      <div class="agr-clause-block">
        <div class="agr-clause-title">${i18n.sec5Title}</div>
        <ol class="agr-clause-list">
          ${i18n.sec5Clauses.map(clause => `<li>${clause}</li>`).join('')}
        </ol>
      </div>

    </div>

    <!-- SECOND SCHEDULE: INVENTORY -->
    <div class="agr-clause-block" style="margin-top:24px;">
      <div class="agr-clause-title" style="text-align:center;">${i18n.secondScheduleTitle}</div>
      <div style="text-align:center; font-size:10pt; font-style:italic; margin-bottom:8px;">${i18n.secondScheduleSub}</div>

      <table class="agr-inventory-schedule-table">
        <thead>
          <tr>
            <th style="width:36px; text-align:center;">${i18n.thInvNo}</th>
            <th>${i18n.thInvItem}</th>
            <th style="width:60px; text-align:center;">${i18n.thInvQty}</th>
            <th style="width:180px;">${i18n.thInvCond}</th>
          </tr>
        </thead>
        <tbody>
          ${activeInventory.length > 0 ? activeInventory.map((inv, idx) => `
            <tr>
              <td style="text-align:center;">${idx + 1}.</td>
              <td><strong>${escapeHtml(inv.item)}</strong></td>
              <td style="text-align:center;">${inv.qty}</td>
              <td>${escapeHtml(inv.condition)}</td>
            </tr>
          `).join('') : `
            <tr>
              <td colspan="4" style="text-align:center; font-style:italic; padding:10px;">
                ${lang === 'en' ? 'Demised Premises leased unfurnished or inventory verified separately.' : 'Premis disewakan tanpa perabot tambahan atau inventori disahkan berasingan.'}
              </td>
            </tr>
          `}
        </tbody>
      </table>
      <div style="font-size:9.5pt; font-style:italic; color:#475569; margin-top:4px;">
        ${i18n.invVerifiedNote}
      </div>
    </div>

    <!-- EXECUTION & SIGNATURES -->
    <div class="agr-signatures">
      <div class="agr-clause-title" style="text-align:center; border:none; margin-bottom:4px;">${i18n.executionTitle}</div>
      <div style="text-align:center; font-size:9.5pt; font-style:italic; margin-bottom:18px;">${i18n.executionSub}</div>

      <div class="agr-sig-grid">
        <!-- Landlord Column -->
        <div class="agr-sig-card">
          <div>
            <strong>${i18n.signedByLandlord}</strong>
            <div style="height:60px; border-bottom:1px solid #0f172a; margin-top:20px;"></div>
          </div>
          <div style="font-size:10pt; line-height:1.4; margin-top:8px;">
            ${i18n.nameLabel} <strong>${escapeHtml(data.landlordName || '')}</strong><br>
            ${i18n.icLabel} ${escapeHtml(data.landlordIc || '-')}<br>
            ${i18n.dateLabel} ${formattedDate}
          </div>
        </div>

        <!-- Tenant Column -->
        <div class="agr-sig-card">
          <div>
            <strong>${i18n.signedByTenant}</strong>
            <div style="height:60px; border-bottom:1px solid #0f172a; margin-top:20px;"></div>
          </div>
          <div style="font-size:10pt; line-height:1.4; margin-top:8px;">
            ${i18n.nameLabel} <strong>${escapeHtml(data.tenantName || '')}</strong><br>
            ${i18n.icLabel} ${escapeHtml(data.tenantIc || '-')}<br>
            ${i18n.dateLabel} ${formattedDate}
          </div>
        </div>
      </div>

      <!-- Witnesses Grid -->
      <div class="agr-sig-grid" style="margin-top:12px;">
        <!-- Landlord Witness -->
        <div class="agr-sig-card">
          <div>
            <strong>${i18n.witnessedBy} (${lang === 'en' ? 'For Landlord' : 'Bagi Tuan Rumah'})</strong>
            <div style="height:50px; border-bottom:1px solid #0f172a; margin-top:16px;"></div>
          </div>
          <div style="font-size:10pt; line-height:1.4; margin-top:8px;">
            ${i18n.nameLabel} ${escapeHtml(data.landlordWitnessName || '________________________')}<br>
            ${i18n.icLabel} ${escapeHtml(data.landlordWitnessIc || '________________________')}<br>
            ${i18n.dateLabel} ${formattedDate}
          </div>
        </div>

        <!-- Tenant Witness -->
        <div class="agr-sig-card">
          <div>
            <strong>${i18n.witnessedBy} (${lang === 'en' ? 'For Tenant' : 'Bagi Penyewa'})</strong>
            <div style="height:50px; border-bottom:1px solid #0f172a; margin-top:16px;"></div>
          </div>
          <div style="font-size:10pt; line-height:1.4; margin-top:8px;">
            ${i18n.nameLabel} ${escapeHtml(data.tenantWitnessName || '________________________')}<br>
            ${i18n.icLabel} ${escapeHtml(data.tenantWitnessIc || '________________________')}<br>
            ${i18n.dateLabel} ${formattedDate}
          </div>
        </div>
      </div>

      <!-- Stamp Duty Box -->
      <div class="agr-stamp-panel">
        <strong>${i18n.stampDutyNote}</strong><br>
        <span style="font-size:9pt; color:#334155;">${i18n.stampDutyDesc}</span>
      </div>
    </div>
  `;
}

/**
 * Generate agreement PDF blob using html2pdf.js with multi-page handling
 */
function generateAgreementPdfBlob(onSuccess, onError) {
  const element = document.getElementById('printableAgreementSheet');
  if (!element) {
    if (onError) onError(new Error('element_not_found'));
    return;
  }

  // Ensure document preview is fully rendered
  renderAgreementPreview();

  const formData = getAgreementFormData();
  const tenantClean = (formData.tenantName || 'Penyewa').replace(/[^a-zA-Z0-9]/g, '_');
  const isBM = appState.activeAgreementLang === 'bm';
  const fileName = isBM ? `Surat_Perjanjian_Sewaan_${tenantClean}.pdf` : `Tenancy_Agreement_${tenantClean}.pdf`;

  if (typeof window.html2pdf === 'function') {
    const modalBody = document.querySelector('#agreementGeneratorModal .modal-body') || document.querySelector('.modal-body');
    const savedModalScroll = modalBody ? modalBody.scrollTop : 0;
    const savedWinScrollY = window.scrollY || window.pageYOffset || 0;
    const savedWinScrollX = window.scrollX || window.pageXOffset || 0;

    if (modalBody) modalBody.scrollTop = 0;
    window.scrollTo(0, 0);

    element.classList.add('agr-rendering-mode');

    const opt = {
      margin: [10, 10, 10, 10], // top, left, bottom, right margins in mm
      filename: fileName,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        logging: false,
        scrollY: 0,
        scrollX: 0,
        backgroundColor: '#ffffff'
      },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak: { mode: 'css' }
    };

    let resolved = false;
    const restore = () => {
      element.classList.remove('agr-rendering-mode');
      if (modalBody) modalBody.scrollTop = savedModalScroll;
      window.scrollTo(savedWinScrollX, savedWinScrollY);
    };

    const timer = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        restore();
        console.warn('html2pdf agreement generation timeout (15s fallback)');
        if (onError) onError(new Error('timeout'));
      }
    }, 15000);

    window.html2pdf().set(opt).from(element).toPdf().get('pdf').then(pdf => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        restore();
        try {
          const blob = pdf.output('blob');
          if (onSuccess) onSuccess(blob, fileName);
        } catch (blobErr) {
          console.warn('pdf.output blob error, falling back to output blob promise:', blobErr);
          window.html2pdf().set(opt).from(element).output('blob').then(altBlob => {
            if (onSuccess) onSuccess(altBlob, fileName);
          }).catch(altErr => {
            if (onError) onError(altErr);
          });
        }
      }
    }).catch(err => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        restore();
        console.warn('html2pdf agreement error:', err);
        if (onError) onError(err);
      }
    });
  } else {
    if (onError) onError(new Error('html2pdf_not_loaded'));
  }
}

/**
 * Direct file download as standard multi-page A4 PDF to Downloads folder
 */
let activeAgreementBlobUrl = null;

function downloadAgreementPdf(callback) {
  const isBM = appState.activeAgreementLang === 'bm';
  const statusCard = document.getElementById('agrActionStatusCard');
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  if (statusCard) {
    statusCard.style.display = 'block';
    statusCard.innerHTML = `
      <div style="background:#eff6ff; border:1.5px solid #0284c7; border-radius:12px; padding:16px; display:flex; align-items:center; gap:12px; box-shadow:0 4px 12px rgba(2,132,199,0.12);">
        <div class="loading-spinner" style="width:26px; height:26px; border-width:3px; border-color:#0284c7; border-top-color:transparent; flex-shrink:0;"></div>
        <div>
          <strong style="color:#0369a1; font-size:13.5px; display:block;">${isBM ? 'Sedang Menjana Fail PDF Surat Perjanjian A4...' : 'Generating Official A4 Tenancy Agreement PDF...'}</strong>
          <span style="font-size:11.5px; color:#0284c7;">${isBM ? 'Format surat perjanjian, klausa mesra Muslim & jadual inventori sedang diproses untuk muat turun terus ke folder Downloads.' : 'Processing formal covenants, Muslim-friendly conditions & inventory schedule for direct download.'}</span>
        </div>
      </div>
    `;
    statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  showToast(isBM ? 'Menjana fail PDF Perjanjian Sewa...' : 'Generating Tenancy Agreement PDF...');

  generateAgreementPdfBlob((blob, fileName) => {
    try {
      if (activeAgreementBlobUrl) {
        try { URL.revokeObjectURL(activeAgreementBlobUrl); } catch (e) {}
      }
      activeAgreementBlobUrl = URL.createObjectURL(blob);
      const blobUrl = activeAgreementBlobUrl;

      // 1. Direct Anchor Download (Guaranteed download to user's Downloads folder)
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        document.body.removeChild(a);
      }, 1500);

      // 2. Render the rich, clear status card just like quotation, receipt and invoice
      if (statusCard) {
        statusCard.style.display = 'block';
        statusCard.innerHTML = `
          <div style="background:#ecfdf5; border:2px solid #10b981; border-radius:12px; padding:18px; box-shadow:0 6px 16px rgba(16,185,129,0.12);">
            <div style="display:flex; align-items:flex-start; gap:14px; margin-bottom:14px;">
              <div style="width:44px; height:44px; border-radius:50%; background:#10b981; color:#fff; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0; box-shadow:0 3px 8px rgba(16,185,129,0.35);">
                <i class="fa-solid fa-circle-check"></i>
              </div>
              <div style="flex:1;">
                <h4 style="margin:0; color:#065f46; font-size:15px; font-weight:800;">
                  ${isBM ? '✅ Surat Perjanjian Berjaya Dijana & Dimuat Turun!' : '✅ Tenancy Agreement Generated & Downloaded!'}
                </h4>
                <p style="margin:4px 0 0 0; font-size:12px; color:#047857; line-height:1.5;">
                  ${isBM 
                    ? `Fail telah disimpan terus ke folder <strong>Downloads</strong> komputer / telefon anda sebagai:<br><strong style="font-family:monospace; color:#0f172a; background:#e2e8f0; padding:2px 6px; border-radius:4px;">${fileName}</strong>`
                    : `File saved directly into your <strong>Downloads</strong> folder as:<br><strong style="font-family:monospace; color:#0f172a; background:#e2e8f0; padding:2px 6px; border-radius:4px;">${fileName}</strong>`}
                </p>
                ${!isMobile ? `
                  <div style="margin-top:6px; font-size:11px; color:#64748b;">
                    ${isBM ? '💡 Tip: Tekan <kbd style="background:#f1f5f9; border:1px solid #cbd5e1; padding:1px 5px; border-radius:3px;">Ctrl</kbd> + <kbd style="background:#f1f5f9; border:1px solid #cbd5e1; padding:1px 5px; border-radius:3px;">J</kbd> (Windows) atau semak ikon muat turun pelayar untuk membuka fail terus dari folder Downloads.' : '💡 Tip: Press Ctrl + J to see downloaded files in Downloads folder.'}
                  </div>
                ` : `
                  <div style="margin-top:8px; font-size:11.5px; color:#14532d; background:#dcfce7; border:1px solid #86efac; border-radius:8px; padding:8px 12px; line-height:1.5;">
                    📱 <strong>Pengguna Telefon:</strong> Fail PDF telah disimpan ke folder <strong>Downloads</strong> peranti anda. Anda kini boleh melampirkannya ke WhatsApp atau Emel dengan mudah.
                  </div>
                `}
              </div>
            </div>

            <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
              <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:linear-gradient(135deg, #0284c7, #0369a1);">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? '👁️ Buka & Lihat PDF Sekarang' : '👁️ View PDF Now'}
              </a>
              <a href="${blobUrl}" download="${fileName}" class="btn btn-outline btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; color:#065f46; border-color:#059669; background:#fff;">
                <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun Semula' : 'Download Again'}
              </a>
              <button type="button" class="btn btn-whatsapp btn-sm" id="btnStatusCardAgrWa" style="font-weight:800; display:inline-flex; align-items:center; gap:6px;">
                <i class="fa-brands fa-whatsapp"></i> ${isBM ? '📲 Hantar ke WhatsApp Tetamu' : 'Send via WhatsApp'}
              </button>
              <button type="button" class="btn btn-outline btn-sm" id="btnStatusCardAgrEmail" style="font-weight:700; display:inline-flex; align-items:center; gap:6px; color:#1e293b; background:#fff;">
                <i class="fa-solid fa-envelope"></i> ${isBM ? '✉️ Emel Penyewa' : 'Email Tenant'}
              </button>
              <button type="button" class="btn btn-outline btn-sm" id="btnDismissAgrStatus" style="font-size:11px; background:#fff; color:#64748b; margin-left:auto;">
                ${isBM ? 'Tutup' : 'Dismiss'}
              </button>
            </div>
          </div>
        `;

        document.getElementById('btnStatusCardAgrWa')?.addEventListener('click', () => shareAgreementWhatsApp(blob, fileName));
        document.getElementById('btnStatusCardAgrEmail')?.addEventListener('click', () => sendAgreementEmail(fileName));
        document.getElementById('btnDismissAgrStatus')?.addEventListener('click', () => {
          statusCard.style.display = 'none';
        });
        statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }

      showToast(isBM ? `Fail PDF (${fileName}) berjaya dimuat turun ke folder Downloads!` : `Tenancy Agreement PDF (${fileName}) downloaded!`);
      if (typeof callback === 'function') callback(blob, fileName);
    } catch (e) {
      console.error('Download error in callback:', e);
    }
  }, err => {
    console.warn('PDF generation fallback to window.print:', err);
    if (statusCard) {
      statusCard.innerHTML = `
        <div style="background:#fffbeb; border:1.5px solid #f59e0b; border-radius:10px; padding:12px; display:flex; align-items:center; justify-content:space-between; gap:10px;">
          <div style="display:flex; align-items:center; gap:8px;">
            <i class="fa-solid fa-triangle-exclamation" style="color:#d97706; font-size:16px;"></i>
            <span style="font-size:11.5px; color:#92400e;">${isBM ? 'Membuka dialog cetakan pelayar...' : 'Opening browser print dialog...'}</span>
          </div>
        </div>
      `;
    }
    setTimeout(() => {
      window.print();
    }, 400);
  });
}

/**
 * Print agreement document directly using browser native print
 */
function printAgreementDocument() {
  renderAgreementPreview();
  setTimeout(() => {
    window.print();
  }, 100);
}

/**
 * Share agreement summary & confirmation via WhatsApp with PDF Download to Downloads folder
 */
function shareAgreementWhatsApp(existingBlob = null, existingFileName = null) {
  const formData = getAgreementFormData();
  const phone = (formData.tenantPhone || '').replace(/[^0-9+]/g, '');
  const isBM = appState.activeAgreementLang === 'bm';
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  const statusCard = document.getElementById('agrActionStatusCard');

  let msg = '';
  if (isBM) {
    msg = `Salam sejahtera ${formData.tenantName},\n\n` +
      `Dilampirkan dokumen rasmi *Surat Perjanjian Penyewaan Kediaman* bagi premis *${formData.propertyName}*:\n\n` +
      `📅 *Tempoh Sewaan:* ${formData.startDate} hingga ${formData.endDate} (${formData.durationMonths} Bulan)\n` +
      `💰 *Kadar Sewa:* RM ${Number(formData.monthlyRent || 0).toFixed(2)} / bulan (Genap masa: ${formData.rentalDueDay})\n` +
      `🛡️ *Cagaran Sewa:* RM ${Number(formData.rentalDeposit || 0).toFixed(2)}\n` +
      `💡 *Cagaran Utiliti:* RM ${Number(formData.utilitiesDeposit || 0).toFixed(2)}\n` +
      `🕌 *Syarat Khas Kediaman:* Mematuhi syarat rumah mesra Muslim (Makanan halal, larangan mutlak arak/alkohol, larangan haiwan terlarang & pemeliharaan syarak).\n\n` +
      `📄 *Sila rujuk fail PDF rasmi yang dilampirkan bersama ini.* Terima kasih!\n_${formData.landlordName}_`;
  } else {
    msg = `Greetings ${formData.tenantName},\n\n` +
      `Attached is the official *Residential Tenancy Agreement* for *${formData.propertyName}*:\n\n` +
      `📅 *Tenancy Term:* ${formData.startDate} to ${formData.endDate} (${formData.durationMonths} Months)\n` +
      `💰 *Monthly Rent:* RM ${Number(formData.monthlyRent || 0).toFixed(2)} / month (Due: ${formData.rentalDueDay})\n` +
      `🛡️ *Rental Deposit:* RM ${Number(formData.rentalDeposit || 0).toFixed(2)}\n` +
      `💡 *Utilities Deposit:* RM ${Number(formData.utilitiesDeposit || 0).toFixed(2)}\n` +
      `🕌 *Special Covenants:* Compliance with Muslim-friendly house requirements (Halal food only, strictly no alcohol, no dogs & Islamic decorum).\n\n` +
      `📄 *Please refer to the attached official PDF document.* Thank you!\n_${formData.landlordName}_`;
  }

  // Copy text to clipboard
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(msg);
  }

  const cleanPhone = normalizePhoneNumber(phone);
  const waUrl = cleanPhone 
    ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`
    : `https://wa.me/?text=${encodeURIComponent(msg)}`;

  let waWindow = null;
  if (!isMobile) {
    try {
      waWindow = window.open('about:blank', '_blank');
      if (waWindow) {
        waWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head><title>Menghubungkan ke WhatsApp...</title></head>
          <body style="font-family:system-ui,sans-serif; text-align:center; padding:50px; background:#f8fafc; color:#0f172a;">
            <div style="max-width:480px; margin:0 auto; background:#fff; padding:30px; border-radius:16px; box-shadow:0 4px 20px rgba(0,0,0,0.08); border:1px solid #e2e8f0;">
              <div style="font-size:36px; margin-bottom:12px;">📲</div>
              <h2 style="color:#15803d; margin:0 0 8px 0; font-size:20px;">Menghubungkan ke WhatsApp Penyewa...</h2>
              <p style="color:#64748b; font-size:13px; line-height:1.5; margin:0 0 16px 0;">Fail PDF Surat Perjanjian sedang dimuat turun ke folder Downloads anda.</p>
              <div style="display:inline-block; border:3px solid #e2e8f0; border-top-color:#15803d; border-radius:50%; width:24px; height:24px; animation:spin 0.8s linear infinite;"></div>
              <style>@keyframes spin { to { transform: rotate(360deg); } }</style>
            </div>
          </body>
          </html>
        `);
      }
    } catch(e) {
      console.warn('Could not pre-open window:', e);
    }
  }

  const handlePdfReady = async (pdfBlob, fName) => {
    const pdfFile = new File([pdfBlob], fName, { type: 'application/pdf' });
    const blobUrl = URL.createObjectURL(pdfBlob);

    // 1. Mobile Web Share Level 2 (Direct WhatsApp file attachment)
    if (isMobile && navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
      try {
        if (waWindow) waWindow.close();
        await navigator.share({
          title: `Surat Perjanjian Sewaan (${formData.tenantName})`,
          text: msg,
          files: [pdfFile]
        });
        showToast(isBM ? '✅ Berjaya dikongsi ke WhatsApp!' : '✅ Shared to WhatsApp successfully!');
        if (statusCard) statusCard.style.display = 'none';
        return;
      } catch (shareErr) {
        if (shareErr.name === 'AbortError') return;
        console.warn('navigator.share failed, fallback to download + open WhatsApp:', shareErr);
      }
    }

    // 2. Download directly to Downloads folder
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = fName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); }, 1500);

    if (waWindow && !waWindow.closed) {
      waWindow.location.href = waUrl;
    }

    // Step-by-Step Card
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#f0fdf4; border:2px solid #22c55e; border-radius:12px; padding:18px; box-shadow:0 6px 18px rgba(34,197,94,0.15);">
          <div style="display:flex; align-items:flex-start; gap:14px; margin-bottom:14px;">
            <div style="width:46px; height:46px; border-radius:50%; background:#22c55e; color:#fff; display:flex; align-items:center; justify-content:center; font-size:24px; flex-shrink:0; box-shadow:0 3px 10px rgba(34,197,94,0.4);">
              <i class="fa-brands fa-whatsapp"></i>
            </div>
            <div style="flex:1;">
              <h4 style="margin:0; color:#14532d; font-size:15px; font-weight:800;">
                ${isBM ? '✅ Fail PDF Dimuat Turun & WhatsApp Sedia Dihantar!' : '✅ PDF Downloaded & WhatsApp Ready!'}
              </h4>
              <p style="margin:4px 0 8px 0; font-size:12px; color:#166534; line-height:1.5;">
                ${isBM 
                  ? `Fail rasmi <strong>${fName}</strong> telah dimuat turun terus ke folder <strong>Downloads</strong> anda.` 
                  : `Official file <strong>${fName}</strong> has been saved directly into your <strong>Downloads</strong> folder.`}
              </p>
              <div style="background:#dcfce7; border:1px solid #86efac; border-radius:8px; padding:10px 12px; font-size:12px; color:#14532d; line-height:1.6;">
                <strong>${isBM ? '👉 2 Langkah Mudah Untuk Menghantar di WhatsApp:' : '👉 2 Easy Steps to Send on WhatsApp:'}</strong><br>
                1. ${isBM ? 'Tetingkap WhatsApp telah dibuka (atau klik butang hijau di bawah).' : 'WhatsApp window is opened (or click green button below).'}<br>
                2. ${isBM ? `Di WhatsApp penyewa, klik ikon <strong>Lampiran (📎 atau +) > Dokumen</strong> dan pilih fail <strong style="font-family:monospace;">${fName}</strong> dari folder Downloads.` : `In WhatsApp chat, click <strong>Attachment (📎 or +) > Document</strong> and select the downloaded PDF.`}
              </div>
            </div>
          </div>

          <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
            <a href="${waUrl}" target="_blank" class="btn btn-whatsapp btn-sm" style="font-weight:800; text-decoration:none; display:inline-flex; align-items:center; gap:8px; padding:8px 16px; font-size:13px;">
              <i class="fa-brands fa-whatsapp"></i> ${isBM ? '📲 Buka WhatsApp Sekarang (Pautan Langsung)' : '📲 Open WhatsApp Now'}
            </a>
            <a href="${blobUrl}" target="_blank" class="btn btn-primary btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px;">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> ${isBM ? '👁️ Lihat Fail PDF' : '👁️ View PDF'}
            </a>
            <a href="${blobUrl}" download="${fName}" class="btn btn-outline btn-sm" style="font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; background:#fff; color:#065f46; border-color:#059669;">
              <i class="fa-solid fa-download"></i> ${isBM ? 'Muat Turun Semula' : 'Download Again'}
            </a>
            <button type="button" class="btn btn-outline btn-sm" id="btnDismissAgrWaStatus" style="font-size:11px; background:#fff; color:#64748b; margin-left:auto;">
              ${isBM ? 'Tutup' : 'Dismiss'}
            </button>
          </div>
        </div>
      `;
      document.getElementById('btnDismissAgrWaStatus')?.addEventListener('click', () => {
        statusCard.style.display = 'none';
      });
      statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    showToast(isBM ? `Fail PDF (${fName}) dimuat turun ke Downloads!` : `PDF (${fName}) downloaded!`);
  };

  if (existingBlob && existingFileName) {
    handlePdfReady(existingBlob, existingFileName);
  } else {
    if (statusCard) {
      statusCard.style.display = 'block';
      statusCard.innerHTML = `
        <div style="background:#eff6ff; border:1.5px solid #0284c7; border-radius:12px; padding:16px; display:flex; align-items:center; gap:12px; box-shadow:0 4px 12px rgba(2,132,199,0.12);">
          <div class="loading-spinner" style="width:26px; height:26px; border-width:3px; border-color:#0284c7; border-top-color:transparent; flex-shrink:0;"></div>
          <div>
            <strong style="color:#0369a1; font-size:13.5px; display:block;">${isBM ? 'Menjana Fail PDF Perjanjian & Menghubungkan ke WhatsApp...' : 'Generating Agreement PDF & Connecting to WhatsApp...'}</strong>
            <span style="font-size:11.5px; color:#0284c7;">${isBM ? 'Sila tunggu sebentar, fail sedang dimuat turun ke folder Downloads...' : 'Please wait a moment...'}</span>
          </div>
        </div>
      `;
      statusCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    showToast(isBM ? 'Menjana fail PDF dan menghubungkan ke WhatsApp...' : 'Generating PDF & connecting to WhatsApp...');
    generateAgreementPdfBlob(handlePdfReady, (err) => {
      console.error('Error generating PDF for WhatsApp:', err);
      if (waWindow && !waWindow.closed) {
        waWindow.location.href = waUrl;
      } else {
        window.open(waUrl, '_blank');
      }
    });
  }
}

/**
 * Send agreement document via Email client with attachment guidance
 */
function sendAgreementEmail(fileName = null) {
  const formData = getAgreementFormData();
  const email = (formData.tenantEmail || '').trim();
  const isBM = appState.activeAgreementLang === 'bm';
  const tenantClean = (formData.tenantName || 'Penyewa').replace(/[^a-zA-Z0-9]/g, '_');
  const actualFileName = fileName || (isBM ? `Surat_Perjanjian_Sewaan_${tenantClean}.pdf` : `Tenancy_Agreement_${tenantClean}.pdf`);

  const subject = isBM 
    ? `Surat Perjanjian Sewaan Kediaman - ${formData.propertyName} (${formData.tenantName})`
    : `Residential Tenancy Agreement - ${formData.propertyName} (${formData.tenantName})`;

  let body = '';
  if (isBM) {
    body = `Salam sejahtera ${formData.tenantName},\n\n` +
      `Bersama-sama ini dilampirkan dokumen rasmi Surat Perjanjian Penyewaan Kediaman bagi premis ${formData.propertyName} untuk semakan, pengesahan dan simpanan anda.\n\n` +
      `Butiran Utama Sewaan:\n` +
      `• Premis: ${formData.propertyName}\n` +
      `• Tempoh: ${formData.startDate} hingga ${formData.endDate} (${formData.durationMonths} Bulan)\n` +
      `• Sewa Bulanan: RM ${Number(formData.monthlyRent || 0).toFixed(2)} (Genap masa: ${formData.rentalDueDay})\n` +
      `• Cagaran Sewa: RM ${Number(formData.rentalDeposit || 0).toFixed(2)}\n` +
      `• Cagaran Utiliti: RM ${Number(formData.utilitiesDeposit || 0).toFixed(2)}\n` +
      `• Syarat Kediaman: Mematuhi syarat rumah mesra Muslim (makanan halal, larangan mutlak arak/alkohol, larangan haiwan terlarang & adab ketenteraman).\n\n` +
      `Sila rujuk fail PDF yang dilampirkan ("${actualFileName}"). Sila cetak atau turun tandatangan dan kembalikan salinan bertandatangan kepada pihak kami.\n\n` +
      `Sekian, terima kasih.\n${formData.landlordName}\n${formData.landlordPhone}`;
  } else {
    body = `Dear ${formData.tenantName},\n\n` +
      `Attached is the official Residential Tenancy Agreement for ${formData.propertyName} for your review, execution, and records.\n\n` +
      `Tenancy Particulars:\n` +
      `• Demised Premises: ${formData.propertyName}\n` +
      `• Term: ${formData.startDate} to ${formData.endDate} (${formData.durationMonths} Months)\n` +
      `• Monthly Rent: RM ${Number(formData.monthlyRent || 0).toFixed(2)} (Due Date: ${formData.rentalDueDay})\n` +
      `• Security Deposit: RM ${Number(formData.rentalDeposit || 0).toFixed(2)}\n` +
      `• Utilities Deposit: RM ${Number(formData.utilitiesDeposit || 0).toFixed(2)}\n` +
      `• House Condition: Compliance with Muslim-friendly covenants.\n\n` +
      `Please find attached the official PDF agreement file ("${actualFileName}"). Kindly review, sign and return a copy to us.\n\n` +
      `Kind regards,\n${formData.landlordName}\n${formData.landlordPhone}`;
  }

  const mailtoUrl = `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  window.open(mailtoUrl, '_blank');

  showToast(isBM ? 'Membuka aplikasi emel... Sila lampirkan fail PDF dari folder Downloads anda.' : 'Opening email client... Please attach the PDF file from your Downloads folder.', 6000);
}

window.downloadAgreementPdf = downloadAgreementPdf;
window.shareAgreementWhatsApp = shareAgreementWhatsApp;
window.sendAgreementEmail = sendAgreementEmail;

/**
 * Save agreement draft into the booking record
 */
function saveAgreementDraft() {
  const formData = getAgreementFormData();
  const bookingId = document.getElementById('agrBookingSelect')?.value;
  const booking = appState.bookings.find(b => b.id === bookingId);
  const isBM = appState.settings.language === 'bm';

  if (booking) {
    booking.tenancyAgreement = {
      ...formData,
      savedAt: new Date().toISOString()
    };
    saveToStorage();
    showToast(isBM ? 'Deraf Perjanjian Sewaan berjaya disimpan ke rekod penyewa!' : 'Tenancy Agreement draft saved successfully to tenant booking record!');
  } else {
    showToast(isBM ? 'Borang perjanjian dikemas kini.' : 'Agreement form updated.');
  }
}

// Start application
if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}

